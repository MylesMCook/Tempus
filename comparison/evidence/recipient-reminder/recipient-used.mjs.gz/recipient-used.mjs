import assert from 'node:assert/strict';
import {parse,appendSelection} from '@tempus-date/core';
import {prepareCalendarFile} from '@tempus-date/core/calendar';
const context={timezone:'America/Chicago',reference:'2026-09-12T16:00:00Z'};
const input='Buy apples for Sam on 11/01/2026 at 1:30am for 30 minutes';
const metadata={title:'Buy apples for Sam',uid:'11111111-2222-4333-8444-555555555555',stamp:context.reference};
let selection;
for(const id of ['event:title','2026-11-01','interval:start:2026-11-01T07:30:00Z']){
 const r=parse(input,{...context,selection});assert.equal(r.status,'needs-clarification');assert.ok(r.clarification.choices.some(c=>c.id===id));assert.equal(prepareCalendarFile(r,metadata).ok,false);selection=appendSelection(selection,{contextKey:r.clarification.contextKey,id});
}
const result=parse(input,{...context,selection});assert.equal(result.status,'resolved');assert.equal(result.event.text,metadata.title);assert.equal(input.slice(result.event.span.start,result.event.span.end),metadata.title);assert.equal(result.value.start.result.iso,'2026-11-01T07:30:00.000Z');assert.equal(result.value.end.result.iso,'2026-11-01T08:00:00.000Z');assert.equal(prepareCalendarFile(result,metadata).ok,true);
const edited=input.replace('Sam','Jo');assert.deepEqual(parse(edited,{...context,selection}),parse(edited,context));assert.equal(prepareCalendarFile(parse(edited,{...context,selection}),metadata).ok,false);
console.log(JSON.stringify({status:'passed',node:process.version,input,event:result.event.text,start:result.value.start.result.iso,end:result.value.end.result.iso,edited}));
