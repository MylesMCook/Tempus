import assert from 'node:assert/strict';
import {parse,appendSelection} from '@tempus-date/core';
import {prepareCalendarFile} from '@tempus-date/core/calendar';
const context={timezone:'America/Chicago',reference:'2026-09-12T16:00:00Z'};
const input='Buy 3 apples and 2 pears on 11/01/2026 at 1:30am for 30 minutes';
const metadata={uid:'11111111-2222-4333-8444-555555555555',stamp:context.reference,title:'Buy 3 apples and 2 pears'};
let selection;
for(const id of ['event:title','2026-11-01','interval:start:2026-11-01T07:30:00Z']){
 const r=parse(input,{...context,selection});assert.equal(r.status,'needs-clarification');assert.ok(r.clarification.choices.some(c=>c.id===id));assert.equal(prepareCalendarFile(r,metadata).ok,false);selection=appendSelection(selection,{contextKey:r.clarification.contextKey,id});
}
const r=parse(input,{...context,selection});assert.equal(r.status,'resolved');assert.equal(r.event.text,metadata.title);assert.equal(r.input,input);assert.equal(input.slice(r.event.span.start,r.event.span.end),metadata.title);assert.equal(input.slice(r.source.span.start,r.source.span.end),r.source.text);
const file=prepareCalendarFile(r,metadata);assert.equal(file.ok,true);assert.equal(file.eventCount,1);assert.ok(file.text.includes('DTSTART:20261101T073000Z'));assert.ok(file.text.includes('DTEND:20261101T080000Z'));
const edited=input.replace('2 pears','4 pears');assert.deepEqual(parse(edited,{...context,selection}),parse(edited,context));assert.equal(prepareCalendarFile(parse(edited,{...context,selection}),metadata).ok,false);
console.log(JSON.stringify({status:'passed',node:process.version,input,event:r.event,file}));
