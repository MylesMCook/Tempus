import {parse} from '@tempus-date/core';
const context={timezone:'America/Chicago',reference:'2026-09-12T16:00:00Z'};
for(const input of ['Buy 3 apples and 2 pears then call Sam tomorrow at noon','Buy 3 apples and 2 pears before calling Sam tomorrow','Buy 3 apples and 2 pears if available tomorrow','Buy 3 apples and 2 pears and tomorrow at noon','Buy 3 apples and 2 pears then email Jo tomorrow','Buy 3 apples and 2 pears tomorrow at noon']){const result=parse(input,context);console.log(JSON.stringify({input,result}));}
