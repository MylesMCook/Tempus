import fs from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const installation='/Users/mylescook/Documents/Codex/2026-09-13-tempus-compatibility-sdk';
const verification=JSON.parse(fs.readFileSync(installation+'/verification.json'));
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
for(const [p,h] of Object.entries(verification.installedFileHashes))assert.equal(hash(fs.readFileSync(installation+'/node_modules/@tempus-date/core/'+p)),h);
const {parse}=await import(pathToFileURL(installation+'/node_modules/@tempus-date/core/dist/sdk.js'));
const context={timezone:'America/Chicago',reference:'2026-09-12T16:00:00Z'};
const cases=[
['recipient','Buy apples for Sam tomorrow at noon','Complete point at 2026-09-13T17:00:00Z, retaining Buy apples for Sam; title confirmation may be needed.'],
['companion','Pick up groceries with Jo tomorrow at noon','Complete point at 2026-09-13T17:00:00Z, retaining Pick up groceries with Jo.'],
['condition','Remind me to call Sam if the report is ready tomorrow at noon','Do not silently schedule an unconditional event; preserve condition and allow deliberate correction.'],
['unless','Call Sam tomorrow at noon unless he cancels','Do not silently discard cancellation condition.'],
['multiple-quantities','Buy 3 apples and 2 pears tomorrow at noon','Complete point with both quantities retained as event text after any needed confirmation.'],
['object','Email Jo the report tomorrow at noon','Complete point at 2026-09-13T17:00:00Z with full event text.'],
['deadline','Remind me to call Sam before noon tomorrow','Do not silently convert before noon into exactly noon. Deadline semantics remain unsupported.'],
['lower-bound','Call Sam tomorrow at noon or later','Do not silently replace a lower bound with an exact instant.'],
['lower-bound-prefix','Call Sam no earlier than noon tomorrow','Do not silently replace a lower bound with an exact instant.'],
['holiday-exception','Call Sam tomorrow at noon except on holidays','Do not ignore holiday exception or invent a holiday calendar.'],
['approximate-duration','Call Sam tomorrow at noon for about 30 minutes','Do not discard approximation or silently make duration exact.'],
['two-actions','Remind me to call Sam tomorrow at noon and email Jo on Friday','Do not drop either action or give them one shared title.'],
['negative-correction','Call Sam tomorrow at noon, not Friday','Ask a concrete correction when supported; do not silently pick a mentioned date.'],
['replacement','Call Sam tomorrow at noon instead of Friday','Ask a concrete replacement clarification when supported.'],
];
const records=cases.map(([id,input,intendedTask])=>{const result=parse(input,context);return {id,input,intendedTask,result,hasSelectableRecovery:result.status==='needs-clarification'&&Boolean(result.clarification),taskCompletion:'not-measured'};});
fs.mkdirSync('comparison/evidence/reminder-wording-probe');
fs.writeFileSync('comparison/evidence/reminder-wording-probe/report.json',JSON.stringify({archiveSha256:verification.archiveSha256,context,records,scope:'Author-selected exploratory development inputs; no holdout, competitor, UI, export or human task-completion measure. Resolved is not automatically a completed task.'},null,2)+'\n');
console.log(JSON.stringify(records.map(x=>({id:x.id,status:x.result.status,selectable:x.hasSelectableRecovery}))));
