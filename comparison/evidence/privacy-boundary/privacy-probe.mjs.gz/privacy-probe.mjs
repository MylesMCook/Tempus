import assert from 'node:assert/strict';
import fs from 'node:fs';
import {chromium} from '/Users/mylescook/node_modules/playwright-core/index.mjs';
const browser=await chromium.launch({channel:'chrome'});const rows=[];
try {for(const width of [320,1280]){
 const context=await browser.newContext({viewport:{width,height:950},timezoneId:'America/Chicago'});const page=await context.newPage();const requests=[];
 await page.goto('http://127.0.0.1:5175');await page.waitForLoadState('networkidle');
 page.on('request',r=>requests.push({url:r.url(),method:r.method(),body:r.postData()}));
 const input='Buy 3 apples and 2 pears on 11/01/2026 at 1:30am for 30 minutes';
 await page.locator('#date-expression').fill(input);
 for(const name of [/^Use “Buy 3 apples and 2 pears”$/, /November 1, 2026/, /UTC-06:00/]) await page.getByRole('button',{name}).click();
 await page.locator('#calendar-export-toggle').click();
 await page.waitForFunction(()=>[...document.querySelectorAll('button')].some(b=>b.textContent.trim()==='Download calendar file'&&!b.disabled));
 const storage=await page.evaluate(()=>({local:{...localStorage},session:{...sessionStorage}}));
 assert.deepEqual(Object.keys(storage.local),['parserSettings']);assert.deepEqual(storage.session,{});
 assert.deepEqual(Object.keys(JSON.parse(storage.local.parserSettings)).sort(),['customFormat','dateFormat','isCustomFormat','timezone']);
 assert.ok(!JSON.stringify(storage).includes('apples'));
 for(const request of requests){const url=new URL(request.url);assert.equal(url.origin,'http://127.0.0.1:5175');assert.equal(url.search,'');assert.equal(request.method,'GET');assert.equal(request.body,null);assert.ok(!url.pathname.startsWith('/api/'));}
 const requestBoundary=[...requests];
 await page.getByRole('link',{name:'Privacy policy',exact:true}).click();
 await page.getByRole('heading',{name:'Copying and calendar files'}).waitFor();
 assert.ok((await page.locator('main').innerText()).includes('Tempus does not upload that file'));
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
 await page.getByRole('link',{name:'Back to calculator'}).click();await page.reload();
 assert.equal(await page.locator('#date-expression').inputValue(),'');
 assert.deepEqual(await context.cookies(),[]);
 rows.push({width,status:'passed',requestBoundary,storedKeys:Object.keys(storage.local),inputClearedAfterReload:true,privacyOverflow:false});await context.close();
}}finally{await browser.close();}
fs.writeFileSync('/Users/mylescook/Documents/Codex/2026-09-13-tempus-privacy-probe.json',JSON.stringify({status:'passed',rows,scope:'Fresh desktop Chrome contexts; local typing/clarification/export preparation, not download/import, live Cloudflare settings or operating-system clipboard policy.'},null,2)+'\n');console.log(JSON.stringify(rows));
