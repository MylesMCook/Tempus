var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e2) {
    throw mod = 0, e2;
  }
};
var __copyProps = (to2, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to2, key) && key !== except)
        __defProp(to2, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to2;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/jsbi@4.3.2/node_modules/jsbi/dist/jsbi-umd.js
var require_jsbi_umd = __commonJS({
  "../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/jsbi@4.3.2/node_modules/jsbi/dist/jsbi-umd.js"(exports, module) {
    (function(e2, t2) {
      "object" == typeof exports && "undefined" != typeof module ? module.exports = t2() : "function" == typeof define && define.amd ? define(t2) : (e2 = e2 || self, e2.JSBI = t2());
    })(exports, function() {
      "use strict";
      var e2 = Math.imul, t2 = Math.clz32;
      function i2(t3, i3) {
        (null == i3 || i3 > t3.length) && (i3 = t3.length);
        for (var _3 = 0, o3 = Array(i3); _3 < i3; _3++) o3[_3] = t3[_3];
        return o3;
      }
      function _2(e3) {
        if (Array.isArray(e3)) return e3;
      }
      function n2(t3) {
        if (void 0 === t3) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return t3;
      }
      function o2(i3, t3, _3) {
        return t3 = r2(t3), v2(i3, b2() ? Reflect.construct(t3, _3 || [], r2(i3).constructor) : t3.apply(i3, _3));
      }
      function l2(e3, t3) {
        if (!(e3 instanceof t3)) throw new TypeError("Cannot call a class as a function");
      }
      function g2(i3, t3, e3) {
        if (b2()) return Reflect.construct.apply(null, arguments);
        var _3 = [null];
        _3.push.apply(_3, t3);
        var n3 = new (i3.bind.apply(i3, _3))();
        return e3 && y2(n3, e3.prototype), n3;
      }
      function a2(i3, e3) {
        for (var _3, n3 = 0; n3 < e3.length; n3++) _3 = e3[n3], _3.enumerable = _3.enumerable || false, _3.configurable = true, "value" in _3 && (_3.writable = true), Object.defineProperty(i3, D2(_3.key), _3);
      }
      function s2(i3, e3, _3) {
        return e3 && a2(i3.prototype, e3), _3 && a2(i3, _3), Object.defineProperty(i3, "prototype", { writable: false }), i3;
      }
      function u2(i3, _3) {
        var e3 = "undefined" != typeof Symbol && i3[Symbol.iterator] || i3["@@iterator"];
        if (!e3) {
          if (Array.isArray(i3) || (e3 = B2(i3)) || _3 && i3 && "number" == typeof i3.length) {
            e3 && (i3 = e3);
            var l3 = 0, g3 = function() {
            };
            return { s: g3, n: function() {
              return l3 >= i3.length ? { done: true } : { done: false, value: i3[l3++] };
            }, e: function(e4) {
              throw e4;
            }, f: g3 };
          }
          throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        }
        var s3, d3 = true, h3 = false;
        return { s: function() {
          e3 = e3.call(i3);
        }, n: function() {
          var t3 = e3.next();
          return d3 = t3.done, t3;
        }, e: function(e4) {
          h3 = true, s3 = e4;
        }, f: function() {
          try {
            d3 || null == e3.return || e3.return();
          } finally {
            if (h3) throw s3;
          }
        } };
      }
      function r2(e3) {
        return r2 = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e4) {
          return e4.__proto__ || Object.getPrototypeOf(e4);
        }, r2(e3);
      }
      function d2(i3, t3) {
        if ("function" != typeof t3 && null !== t3) throw new TypeError("Super expression must either be null or a function");
        i3.prototype = Object.create(t3 && t3.prototype, { constructor: { value: i3, writable: true, configurable: true } }), Object.defineProperty(i3, "prototype", { writable: false }), t3 && y2(i3, t3);
      }
      function h2(e3) {
        try {
          return -1 !== Function.toString.call(e3).indexOf("[native code]");
        } catch (t3) {
          return "function" == typeof e3;
        }
      }
      function b2() {
        try {
          var e3 = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
          }));
        } catch (e4) {
        }
        return (b2 = function() {
          return !!e3;
        })();
      }
      function m2(_3, g3) {
        var l3 = null == _3 ? null : "undefined" != typeof Symbol && _3[Symbol.iterator] || _3["@@iterator"];
        if (null != l3) {
          var s3, d3, r3, h3, b3 = [], a3 = true, m3 = false;
          try {
            if (r3 = (l3 = l3.call(_3)).next, 0 === g3) {
              if (Object(l3) !== l3) return;
              a3 = false;
            } else for (; !(a3 = (s3 = r3.call(l3)).done) && (b3.push(s3.value), b3.length !== g3); a3 = true) ;
          } catch (e3) {
            m3 = true, d3 = e3;
          } finally {
            try {
              if (!a3 && null != l3.return && (h3 = l3.return(), Object(h3) !== h3)) return;
            } finally {
              if (m3) throw d3;
            }
          }
          return b3;
        }
      }
      function c2() {
        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
      }
      function v2(i3, t3) {
        if (t3 && ("object" == typeof t3 || "function" == typeof t3)) return t3;
        if (void 0 !== t3) throw new TypeError("Derived constructors may only return object or undefined");
        return n2(i3);
      }
      function y2(i3, t3) {
        return y2 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(i4, t4) {
          return i4.__proto__ = t4, i4;
        }, y2(i3, t3);
      }
      function f2(t3, i3) {
        return _2(t3) || m2(t3, i3) || B2(t3, i3) || c2();
      }
      function k2(_3, t3) {
        if ("object" != typeof _3 || !_3) return _3;
        var n3 = _3[Symbol.toPrimitive];
        if (void 0 !== n3) {
          var e3 = n3.call(_3, t3 || "default");
          if ("object" != typeof e3) return e3;
          throw new TypeError("@@toPrimitive must return a primitive value.");
        }
        return ("string" === t3 ? String : Number)(_3);
      }
      function D2(e3) {
        var t3 = k2(e3, "string");
        return "symbol" == typeof t3 ? t3 : t3 + "";
      }
      function p2(e3) {
        "@babel/helpers - typeof";
        return p2 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e4) {
          return typeof e4;
        } : function(e4) {
          return e4 && "function" == typeof Symbol && e4.constructor === Symbol && e4 !== Symbol.prototype ? "symbol" : typeof e4;
        }, p2(e3);
      }
      function B2(e3, _3) {
        if (e3) {
          if ("string" == typeof e3) return i2(e3, _3);
          var n3 = {}.toString.call(e3).slice(8, -1);
          return "Object" === n3 && e3.constructor && (n3 = e3.constructor.name), "Map" === n3 || "Set" === n3 ? Array.from(e3) : "Arguments" === n3 || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n3) ? i2(e3, _3) : void 0;
        }
      }
      function S2(e3) {
        var i3 = "function" == typeof Map ? /* @__PURE__ */ new Map() : void 0;
        return S2 = function(e4) {
          function t3() {
            return g2(e4, arguments, r2(this).constructor);
          }
          if (null === e4 || !h2(e4)) return e4;
          if ("function" != typeof e4) throw new TypeError("Super expression must either be null or a function");
          if (void 0 !== i3) {
            if (i3.has(e4)) return i3.get(e4);
            i3.set(e4, t3);
          }
          return t3.prototype = Object.create(e4.prototype, { constructor: { value: t3, enumerable: false, writable: true, configurable: true } }), y2(t3, e4);
        }, S2(e3);
      }
      var C2 = (function(e3) {
        var t3 = Math.abs, i3 = Math.max, _3 = Math.floor;
        function g3(e4, t4) {
          var i4;
          if (l2(this, g3), i4 = o2(this, g3, [e4]), i4.sign = t4, Object.setPrototypeOf(i4, g3.prototype), e4 > g3.__kMaxLength) throw new RangeError("Maximum BigInt size exceeded");
          return i4;
        }
        return d2(g3, e3), s2(g3, [{ key: "toDebugString", value: function e4() {
          var t4, i4 = ["BigInt["], _4 = u2(this);
          try {
            for (_4.s(); !(t4 = _4.n()).done; ) {
              var n3 = t4.value;
              i4.push((n3 ? (n3 >>> 0).toString(16) : n3) + ", ");
            }
          } catch (e5) {
            _4.e(e5);
          } finally {
            _4.f();
          }
          return i4.push("]"), i4.join("");
        } }, { key: "toString", value: function e4() {
          var t4 = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : 10;
          if (2 > t4 || 36 < t4) throw new RangeError("toString() radix argument must be between 2 and 36");
          return 0 === this.length ? "0" : 0 == (t4 & t4 - 1) ? g3.__toStringBasePowerOfTwo(this, t4) : g3.__toStringGeneric(this, t4, false);
        } }, { key: "valueOf", value: function e4() {
          throw new Error("Convert JSBI instances to native numbers using `toNumber`.");
        } }, { key: "__copy", value: function e4() {
          for (var t4 = new g3(this.length, this.sign), _4 = 0; _4 < this.length; _4++) t4[_4] = this[_4];
          return t4;
        } }, { key: "__trim", value: function e4() {
          for (var t4 = this.length, i4 = this[t4 - 1]; 0 === i4; ) t4--, i4 = this[t4 - 1], this.pop();
          return 0 === t4 && (this.sign = false), this;
        } }, { key: "__initializeDigits", value: function e4() {
          for (var t4 = 0; t4 < this.length; t4++) this[t4] = 0;
        } }, { key: "__clzmsd", value: function e4() {
          return g3.__clz30(this.__digit(this.length - 1));
        } }, { key: "__inplaceMultiplyAdd", value: function n3(e4, t4, _4) {
          _4 > this.length && (_4 = this.length);
          for (var o3 = 32767 & e4, l3 = e4 >>> 15, a3 = 0, s3 = t4, u3 = 0; u3 < _4; u3++) {
            var r3 = this.__digit(u3), h3 = 32767 & r3, b3 = r3 >>> 15, m3 = g3.__imul(h3, o3), c3 = g3.__imul(h3, l3), v3 = g3.__imul(b3, o3), y3 = g3.__imul(b3, l3), f3 = s3 + m3 + a3;
            a3 = f3 >>> 30, f3 &= 1073741823, f3 += ((32767 & c3) << 15) + ((32767 & v3) << 15), a3 += f3 >>> 30, s3 = y3 + (c3 >>> 15) + (v3 >>> 15), this.__setDigit(u3, 1073741823 & f3);
          }
          if (0 !== a3 || 0 !== s3) throw new Error("implementation bug");
        } }, { key: "__inplaceAdd", value: function n3(e4, t4, _4) {
          for (var o3, l3 = 0, g4 = 0; g4 < _4; g4++) o3 = this.__halfDigit(t4 + g4) + e4.__halfDigit(g4) + l3, l3 = o3 >>> 15, this.__setHalfDigit(t4 + g4, 32767 & o3);
          return l3;
        } }, { key: "__inplaceSub", value: function n3(e4, t4, _4) {
          var o3 = _4 - 1 >>> 1, l3 = 0;
          if (1 & t4) {
            t4 >>= 1;
            for (var g4 = this.__digit(t4), a3 = 32767 & g4, s3 = 0; s3 < o3; s3++) {
              var u3 = e4.__digit(s3), r3 = (g4 >>> 15) - (32767 & u3) - l3;
              l3 = 1 & r3 >>> 15, this.__setDigit(t4 + s3, (32767 & r3) << 15 | 32767 & a3), g4 = this.__digit(t4 + s3 + 1), a3 = (32767 & g4) - (u3 >>> 15) - l3, l3 = 1 & a3 >>> 15;
            }
            var d3 = e4.__digit(s3), h3 = (g4 >>> 15) - (32767 & d3) - l3;
            l3 = 1 & h3 >>> 15, this.__setDigit(t4 + s3, (32767 & h3) << 15 | 32767 & a3);
            var b3 = d3 >>> 15;
            if (t4 + s3 + 1 >= this.length) throw new RangeError("out of bounds");
            0 == (1 & _4) && (g4 = this.__digit(t4 + s3 + 1), a3 = (32767 & g4) - b3 - l3, l3 = 1 & a3 >>> 15, this.__setDigit(t4 + e4.length, 1073709056 & g4 | 32767 & a3));
          } else {
            t4 >>= 1;
            for (var m3 = 0; m3 < e4.length - 1; m3++) {
              var c3 = this.__digit(t4 + m3), v3 = e4.__digit(m3), y3 = (32767 & c3) - (32767 & v3) - l3;
              l3 = 1 & y3 >>> 15;
              var f3 = (c3 >>> 15) - (v3 >>> 15) - l3;
              l3 = 1 & f3 >>> 15, this.__setDigit(t4 + m3, (32767 & f3) << 15 | 32767 & y3);
            }
            var k3 = this.__digit(t4 + m3), D3 = e4.__digit(m3), p3 = (32767 & k3) - (32767 & D3) - l3;
            l3 = 1 & p3 >>> 15;
            var B3 = 0;
            0 == (1 & _4) && (B3 = (k3 >>> 15) - (D3 >>> 15) - l3, l3 = 1 & B3 >>> 15), this.__setDigit(t4 + m3, (32767 & B3) << 15 | 32767 & p3);
          }
          return l3;
        } }, { key: "__inplaceRightShift", value: function t4(e4) {
          if (0 !== e4) {
            for (var _4, n3 = this.__digit(0) >>> e4, o3 = this.length - 1, l3 = 0; l3 < o3; l3++) _4 = this.__digit(l3 + 1), this.__setDigit(l3, 1073741823 & _4 << 30 - e4 | n3), n3 = _4 >>> e4;
            this.__setDigit(o3, n3);
          }
        } }, { key: "__digit", value: function t4(e4) {
          return this[e4];
        } }, { key: "__unsignedDigit", value: function t4(e4) {
          return this[e4] >>> 0;
        } }, { key: "__setDigit", value: function i4(e4, t4) {
          this[e4] = 0 | t4;
        } }, { key: "__setDigitGrow", value: function i4(e4, t4) {
          this[e4] = 0 | t4;
        } }, { key: "__halfDigitLength", value: function e4() {
          var t4 = this.length;
          return 32767 >= this.__unsignedDigit(t4 - 1) ? 2 * t4 - 1 : 2 * t4;
        } }, { key: "__halfDigit", value: function t4(e4) {
          return 32767 & this[e4 >>> 1] >>> 15 * (1 & e4);
        } }, { key: "__setHalfDigit", value: function i4(e4, t4) {
          var _4 = e4 >>> 1, n3 = this.__digit(_4), o3 = 1 & e4 ? 32767 & n3 | t4 << 15 : 1073709056 & n3 | 32767 & t4;
          this.__setDigit(_4, o3);
        } }], [{ key: "BigInt", value: function t4(e4) {
          var i4 = Number.isFinite;
          if ("number" == typeof e4) {
            if (0 === e4) return g3.__zero();
            if (g3.__isOneDigitInt(e4)) return 0 > e4 ? g3.__oneDigit(-e4, true) : g3.__oneDigit(e4, false);
            if (!i4(e4) || _3(e4) !== e4) throw new RangeError("The number " + e4 + " cannot be converted to BigInt because it is not an integer");
            return g3.__fromDouble(e4);
          }
          if ("string" == typeof e4) {
            var n3 = g3.__fromString(e4);
            if (null === n3) throw new SyntaxError("Cannot convert " + e4 + " to a BigInt");
            return n3;
          }
          if ("boolean" == typeof e4) return true === e4 ? g3.__oneDigit(1, false) : g3.__zero();
          if ("object" === p2(e4)) {
            if (e4.constructor === g3) return e4;
            var o3 = g3.__toPrimitive(e4);
            return g3.BigInt(o3);
          }
          throw new TypeError("Cannot convert " + e4 + " to a BigInt");
        } }, { key: "toNumber", value: function t4(e4) {
          var i4 = e4.length;
          if (0 === i4) return 0;
          if (1 === i4) {
            var _4 = e4.__unsignedDigit(0);
            return e4.sign ? -_4 : _4;
          }
          var n3 = e4.__digit(i4 - 1), o3 = g3.__clz30(n3), l3 = 30 * i4 - o3;
          if (1024 < l3) return e4.sign ? -Infinity : 1 / 0;
          var a3 = l3 - 1, s3 = n3, u3 = i4 - 1, r3 = o3 + 3, d3 = 32 === r3 ? 0 : s3 << r3;
          d3 >>>= 12;
          var h3 = r3 - 12, b3 = 12 <= r3 ? 0 : s3 << 20 + r3, m3 = 20 + r3;
          for (0 < h3 && 0 < u3 && (u3--, s3 = e4.__digit(u3), d3 |= s3 >>> 30 - h3, b3 = s3 << h3 + 2, m3 = h3 + 2); 0 < m3 && 0 < u3; ) u3--, s3 = e4.__digit(u3), b3 |= 30 <= m3 ? s3 << m3 - 30 : s3 >>> 30 - m3, m3 -= 30;
          var c3 = g3.__decideRounding(e4, m3, u3, s3);
          if ((1 === c3 || 0 === c3 && 1 == (1 & b3)) && (b3 = b3 + 1 >>> 0, 0 === b3 && (d3++, 0 != d3 >>> 20 && (d3 = 0, a3++, 1023 < a3)))) return e4.sign ? -Infinity : 1 / 0;
          var v3 = e4.sign ? -2147483648 : 0;
          return a3 = a3 + 1023 << 20, g3.__kBitConversionInts[g3.__kBitConversionIntHigh] = v3 | a3 | d3, g3.__kBitConversionInts[g3.__kBitConversionIntLow] = b3, g3.__kBitConversionDouble[0];
        } }, { key: "unaryMinus", value: function t4(e4) {
          if (0 === e4.length) return e4;
          var i4 = e4.__copy();
          return i4.sign = !e4.sign, i4;
        } }, { key: "bitwiseNot", value: function t4(e4) {
          return e4.sign ? g3.__absoluteSubOne(e4).__trim() : g3.__absoluteAddOne(e4, true);
        } }, { key: "exponentiate", value: function i4(e4, t4) {
          if (t4.sign) throw new RangeError("Exponent must be positive");
          if (0 === t4.length) return g3.__oneDigit(1, false);
          if (0 === e4.length) return e4;
          if (1 === e4.length && 1 === e4.__digit(0)) return e4.sign && 0 == (1 & t4.__digit(0)) ? g3.unaryMinus(e4) : e4;
          if (1 < t4.length) throw new RangeError("BigInt too big");
          var _4 = t4.__unsignedDigit(0);
          if (1 === _4) return e4;
          if (_4 >= g3.__kMaxLengthBits) throw new RangeError("BigInt too big");
          if (1 === e4.length && 2 === e4.__digit(0)) {
            var n3 = 1 + (0 | _4 / 30), o3 = e4.sign && 0 != (1 & _4), l3 = new g3(n3, o3);
            l3.__initializeDigits();
            var a3 = 1 << _4 % 30;
            return l3.__setDigit(n3 - 1, a3), l3;
          }
          var s3 = null, u3 = e4;
          for (0 != (1 & _4) && (s3 = e4), _4 >>= 1; 0 !== _4; _4 >>= 1) u3 = g3.multiply(u3, u3), 0 != (1 & _4) && (null === s3 ? s3 = u3 : s3 = g3.multiply(s3, u3));
          return s3;
        } }, { key: "multiply", value: function _4(e4, t4) {
          if (0 === e4.length) return e4;
          if (0 === t4.length) return t4;
          var n3 = e4.length + t4.length;
          30 <= e4.__clzmsd() + t4.__clzmsd() && n3--;
          var o3 = new g3(n3, e4.sign !== t4.sign);
          o3.__initializeDigits();
          for (var l3 = 0; l3 < e4.length; l3++) g3.__multiplyAccumulate(t4, e4.__digit(l3), o3, l3);
          return o3.__trim();
        } }, { key: "divide", value: function i4(e4, t4) {
          if (0 === t4.length) throw new RangeError("Division by zero");
          if (0 > g3.__absoluteCompare(e4, t4)) return g3.__zero();
          var _4, n3 = e4.sign !== t4.sign, o3 = t4.__unsignedDigit(0);
          if (1 === t4.length && 32767 >= o3) {
            if (1 === o3) return n3 === e4.sign ? e4 : g3.unaryMinus(e4);
            _4 = g3.__absoluteDivSmall(e4, o3, null);
          } else _4 = g3.__absoluteDivLarge(e4, t4, true, false);
          return _4.sign = n3, _4.__trim();
        } }, { key: "remainder", value: function i4(e4, t4) {
          if (0 === t4.length) throw new RangeError("Division by zero");
          if (0 > g3.__absoluteCompare(e4, t4)) return e4;
          var _4 = t4.__unsignedDigit(0);
          if (1 === t4.length && 32767 >= _4) {
            if (1 === _4) return g3.__zero();
            var n3 = g3.__absoluteModSmall(e4, _4);
            return 0 === n3 ? g3.__zero() : g3.__oneDigit(n3, e4.sign);
          }
          var i5 = g3.__absoluteDivLarge(e4, t4, false, true);
          return i5.sign = e4.sign, i5.__trim();
        } }, { key: "add", value: function i4(e4, t4) {
          var _4 = e4.sign;
          return _4 === t4.sign ? g3.__absoluteAdd(e4, t4, _4) : 0 <= g3.__absoluteCompare(e4, t4) ? g3.__absoluteSub(e4, t4, _4) : g3.__absoluteSub(t4, e4, !_4);
        } }, { key: "subtract", value: function i4(e4, t4) {
          var _4 = e4.sign;
          return _4 === t4.sign ? 0 <= g3.__absoluteCompare(e4, t4) ? g3.__absoluteSub(e4, t4, _4) : g3.__absoluteSub(t4, e4, !_4) : g3.__absoluteAdd(e4, t4, _4);
        } }, { key: "leftShift", value: function i4(e4, t4) {
          return 0 === t4.length || 0 === e4.length ? e4 : t4.sign ? g3.__rightShiftByAbsolute(e4, t4) : g3.__leftShiftByAbsolute(e4, t4);
        } }, { key: "signedRightShift", value: function i4(e4, t4) {
          return 0 === t4.length || 0 === e4.length ? e4 : t4.sign ? g3.__leftShiftByAbsolute(e4, t4) : g3.__rightShiftByAbsolute(e4, t4);
        } }, { key: "unsignedRightShift", value: function e4() {
          throw new TypeError("BigInts have no unsigned right shift; use >> instead");
        } }, { key: "lessThan", value: function i4(e4, t4) {
          return 0 > g3.__compareToBigInt(e4, t4);
        } }, { key: "lessThanOrEqual", value: function i4(e4, t4) {
          return 0 >= g3.__compareToBigInt(e4, t4);
        } }, { key: "greaterThan", value: function i4(e4, t4) {
          return 0 < g3.__compareToBigInt(e4, t4);
        } }, { key: "greaterThanOrEqual", value: function i4(e4, t4) {
          return 0 <= g3.__compareToBigInt(e4, t4);
        } }, { key: "equal", value: function _4(e4, t4) {
          if (e4.sign !== t4.sign) return false;
          if (e4.length !== t4.length) return false;
          for (var n3 = 0; n3 < e4.length; n3++) if (e4.__digit(n3) !== t4.__digit(n3)) return false;
          return true;
        } }, { key: "notEqual", value: function i4(e4, t4) {
          return !g3.equal(e4, t4);
        } }, { key: "bitwiseAnd", value: function _4(e4, t4) {
          if (!e4.sign && !t4.sign) return g3.__absoluteAnd(e4, t4).__trim();
          if (e4.sign && t4.sign) {
            var n3 = i3(e4.length, t4.length) + 1, o3 = g3.__absoluteSubOne(e4, n3), l3 = g3.__absoluteSubOne(t4);
            return o3 = g3.__absoluteOr(o3, l3, o3), g3.__absoluteAddOne(o3, true, o3).__trim();
          }
          if (e4.sign) {
            var a3 = [t4, e4];
            e4 = a3[0], t4 = a3[1];
          }
          return g3.__absoluteAndNot(e4, g3.__absoluteSubOne(t4)).__trim();
        } }, { key: "bitwiseXor", value: function _4(e4, t4) {
          if (!e4.sign && !t4.sign) return g3.__absoluteXor(e4, t4).__trim();
          if (e4.sign && t4.sign) {
            var n3 = i3(e4.length, t4.length), o3 = g3.__absoluteSubOne(e4, n3), l3 = g3.__absoluteSubOne(t4);
            return g3.__absoluteXor(o3, l3, o3).__trim();
          }
          var a3 = i3(e4.length, t4.length) + 1;
          if (e4.sign) {
            var s3 = [t4, e4];
            e4 = s3[0], t4 = s3[1];
          }
          var u3 = g3.__absoluteSubOne(t4, a3);
          return u3 = g3.__absoluteXor(u3, e4, u3), g3.__absoluteAddOne(u3, true, u3).__trim();
        } }, { key: "bitwiseOr", value: function _4(e4, t4) {
          var n3 = i3(e4.length, t4.length);
          if (!e4.sign && !t4.sign) return g3.__absoluteOr(e4, t4).__trim();
          if (e4.sign && t4.sign) {
            var o3 = g3.__absoluteSubOne(e4, n3), l3 = g3.__absoluteSubOne(t4);
            return o3 = g3.__absoluteAnd(o3, l3, o3), g3.__absoluteAddOne(o3, true, o3).__trim();
          }
          if (e4.sign) {
            var a3 = [t4, e4];
            e4 = a3[0], t4 = a3[1];
          }
          var s3 = g3.__absoluteSubOne(t4, n3);
          return s3 = g3.__absoluteAndNot(s3, e4, s3), g3.__absoluteAddOne(s3, true, s3).__trim();
        } }, { key: "asIntN", value: function o3(e4, t4) {
          if (0 === t4.length) return t4;
          if (e4 = _3(e4), 0 > e4) throw new RangeError("Invalid value: not (convertible to) a safe integer");
          if (0 === e4) return g3.__zero();
          if (e4 >= g3.__kMaxLengthBits) return t4;
          var l3 = 0 | (e4 + 29) / 30;
          if (t4.length < l3) return t4;
          var a3 = t4.__unsignedDigit(l3 - 1), s3 = 1 << (e4 - 1) % 30;
          if (t4.length === l3 && a3 < s3) return t4;
          var u3 = (a3 & s3) === s3;
          if (!u3) return g3.__truncateToNBits(e4, t4);
          if (!t4.sign) return g3.__truncateAndSubFromPowerOfTwo(e4, t4, true);
          if (0 == (a3 & s3 - 1)) {
            for (var r3 = l3 - 2; 0 <= r3; r3--) if (0 !== t4.__digit(r3)) return g3.__truncateAndSubFromPowerOfTwo(e4, t4, false);
            return t4.length === l3 && a3 === s3 ? t4 : g3.__truncateToNBits(e4, t4);
          }
          return g3.__truncateAndSubFromPowerOfTwo(e4, t4, false);
        } }, { key: "asUintN", value: function i4(e4, t4) {
          if (0 === t4.length) return t4;
          if (e4 = _3(e4), 0 > e4) throw new RangeError("Invalid value: not (convertible to) a safe integer");
          if (0 === e4) return g3.__zero();
          if (t4.sign) {
            if (e4 > g3.__kMaxLengthBits) throw new RangeError("BigInt too big");
            return g3.__truncateAndSubFromPowerOfTwo(e4, t4, false);
          }
          if (e4 >= g3.__kMaxLengthBits) return t4;
          var o3 = 0 | (e4 + 29) / 30;
          if (t4.length < o3) return t4;
          var l3 = e4 % 30;
          if (t4.length == o3) {
            if (0 === l3) return t4;
            var a3 = t4.__digit(o3 - 1);
            if (0 == a3 >>> l3) return t4;
          }
          return g3.__truncateToNBits(e4, t4);
        } }, { key: "ADD", value: function i4(e4, t4) {
          if (e4 = g3.__toPrimitive(e4), t4 = g3.__toPrimitive(t4), "string" == typeof e4) return "string" != typeof t4 && (t4 = t4.toString()), e4 + t4;
          if ("string" == typeof t4) return e4.toString() + t4;
          if (e4 = g3.__toNumeric(e4), t4 = g3.__toNumeric(t4), g3.__isBigInt(e4) && g3.__isBigInt(t4)) return g3.add(e4, t4);
          if ("number" == typeof e4 && "number" == typeof t4) return e4 + t4;
          throw new TypeError("Cannot mix BigInt and other types, use explicit conversions");
        } }, { key: "LT", value: function i4(e4, t4) {
          return g3.__compare(e4, t4, 0);
        } }, { key: "LE", value: function i4(e4, t4) {
          return g3.__compare(e4, t4, 1);
        } }, { key: "GT", value: function i4(e4, t4) {
          return g3.__compare(e4, t4, 2);
        } }, { key: "GE", value: function i4(e4, t4) {
          return g3.__compare(e4, t4, 3);
        } }, { key: "EQ", value: function i4(e4, t4) {
          for (; true; ) {
            if (g3.__isBigInt(e4)) return g3.__isBigInt(t4) ? g3.equal(e4, t4) : g3.EQ(t4, e4);
            if ("number" == typeof e4) {
              if (g3.__isBigInt(t4)) return g3.__equalToNumber(t4, e4);
              if ("object" !== p2(t4)) return e4 == t4;
              t4 = g3.__toPrimitive(t4);
            } else if ("string" == typeof e4) {
              if (g3.__isBigInt(t4)) return e4 = g3.__fromString(e4), null !== e4 && g3.equal(e4, t4);
              if ("object" !== p2(t4)) return e4 == t4;
              t4 = g3.__toPrimitive(t4);
            } else if ("boolean" == typeof e4) {
              if (g3.__isBigInt(t4)) return g3.__equalToNumber(t4, +e4);
              if ("object" !== p2(t4)) return e4 == t4;
              t4 = g3.__toPrimitive(t4);
            } else if ("symbol" === p2(e4)) {
              if (g3.__isBigInt(t4)) return false;
              if ("object" !== p2(t4)) return e4 == t4;
              t4 = g3.__toPrimitive(t4);
            } else if ("object" === p2(e4)) {
              if ("object" === p2(t4) && t4.constructor !== g3) return e4 == t4;
              e4 = g3.__toPrimitive(e4);
            } else return e4 == t4;
          }
        } }, { key: "NE", value: function i4(e4, t4) {
          return !g3.EQ(e4, t4);
        } }, { key: "DataViewGetBigInt64", value: function i4(e4, t4) {
          var _4 = !!(2 < arguments.length && void 0 !== arguments[2]) && arguments[2];
          return g3.asIntN(64, g3.DataViewGetBigUint64(e4, t4, _4));
        } }, { key: "DataViewGetBigUint64", value: function i4(e4, t4) {
          var _4 = !!(2 < arguments.length && void 0 !== arguments[2]) && arguments[2], n3 = _4 ? [4, 0] : [0, 4], o3 = f2(n3, 2), a3 = o3[0], s3 = o3[1], l3 = e4.getUint32(t4 + a3, _4), u3 = e4.getUint32(t4 + s3, _4), r3 = new g3(3, false);
          return r3.__setDigit(0, 1073741823 & u3), r3.__setDigit(1, (268435455 & l3) << 2 | u3 >>> 30), r3.__setDigit(2, l3 >>> 28), r3.__trim();
        } }, { key: "DataViewSetBigInt64", value: function _4(e4, t4, i4) {
          var n3 = !!(3 < arguments.length && void 0 !== arguments[3]) && arguments[3];
          g3.DataViewSetBigUint64(e4, t4, i4, n3);
        } }, { key: "DataViewSetBigUint64", value: function _4(e4, t4, i4) {
          var n3 = !!(3 < arguments.length && void 0 !== arguments[3]) && arguments[3];
          i4 = g3.asUintN(64, i4);
          var o3 = 0, a3 = 0;
          if (0 < i4.length && (a3 = i4.__digit(0), 1 < i4.length)) {
            var s3 = i4.__digit(1);
            a3 |= s3 << 30, o3 = s3 >>> 2, 2 < i4.length && (o3 |= i4.__digit(2) << 28);
          }
          var u3 = n3 ? [4, 0] : [0, 4], r3 = f2(u3, 2), d3 = r3[0], h3 = r3[1];
          e4.setUint32(t4 + d3, o3, n3), e4.setUint32(t4 + h3, a3, n3);
        } }, { key: "__zero", value: function e4() {
          return new g3(0, false);
        } }, { key: "__oneDigit", value: function i4(e4, t4) {
          var _4 = new g3(1, t4);
          return _4.__setDigit(0, e4), _4;
        } }, { key: "__decideRounding", value: function n3(e4, t4, i4, _4) {
          if (0 < t4) return -1;
          var o3;
          if (0 > t4) o3 = -t4 - 1;
          else {
            if (0 === i4) return -1;
            i4--, _4 = e4.__digit(i4), o3 = 29;
          }
          var l3 = 1 << o3;
          if (0 == (_4 & l3)) return -1;
          if (l3 -= 1, 0 != (_4 & l3)) return 1;
          for (; 0 < i4; ) if (i4--, 0 !== e4.__digit(i4)) return 1;
          return 0;
        } }, { key: "__fromDouble", value: function t4(e4) {
          var i4 = 0 > e4;
          g3.__kBitConversionDouble[0] = e4;
          var _4, n3 = 2047 & g3.__kBitConversionInts[g3.__kBitConversionIntHigh] >>> 20, o3 = n3 - 1023, l3 = (0 | o3 / 30) + 1, a3 = new g3(l3, i4), s3 = 1048576, u3 = 1048575 & g3.__kBitConversionInts[g3.__kBitConversionIntHigh] | s3, r3 = g3.__kBitConversionInts[g3.__kBitConversionIntLow], d3 = 20, h3 = o3 % 30, b3 = 0;
          if (h3 < d3) {
            var m3 = d3 - h3;
            b3 = m3 + 32, _4 = u3 >>> m3, u3 = u3 << 32 - m3 | r3 >>> m3, r3 <<= 32 - m3;
          } else if (h3 === d3) b3 = 32, _4 = u3, u3 = r3, r3 = 0;
          else {
            var c3 = h3 - d3;
            b3 = 32 - c3, _4 = u3 << c3 | r3 >>> 32 - c3, u3 = r3 << c3, r3 = 0;
          }
          a3.__setDigit(l3 - 1, _4);
          for (var v3 = l3 - 2; 0 <= v3; v3--) 0 < b3 ? (b3 -= 30, _4 = u3 >>> 2, u3 = u3 << 30 | r3 >>> 2, r3 <<= 30) : _4 = 0, a3.__setDigit(v3, _4);
          return a3.__trim();
        } }, { key: "__isWhitespace", value: function t4(e4) {
          return !!(13 >= e4 && 9 <= e4) || (159 >= e4 ? 32 == e4 : 131071 >= e4 ? 160 == e4 || 5760 == e4 : 196607 >= e4 ? (e4 &= 131071, 10 >= e4 || 40 == e4 || 41 == e4 || 47 == e4 || 95 == e4 || 4096 == e4) : 65279 == e4);
        } }, { key: "__fromString", value: function t4(e4) {
          var i4 = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 0, _4 = 0, n3 = e4.length, o3 = 0;
          if (o3 === n3) return g3.__zero();
          for (var l3 = e4.charCodeAt(o3); g3.__isWhitespace(l3); ) {
            if (++o3 === n3) return g3.__zero();
            l3 = e4.charCodeAt(o3);
          }
          if (43 === l3) {
            if (++o3 === n3) return null;
            l3 = e4.charCodeAt(o3), _4 = 1;
          } else if (45 === l3) {
            if (++o3 === n3) return null;
            l3 = e4.charCodeAt(o3), _4 = -1;
          }
          if (0 === i4) {
            if (i4 = 10, 48 === l3) {
              if (++o3 === n3) return g3.__zero();
              if (l3 = e4.charCodeAt(o3), 88 === l3 || 120 === l3) {
                if (i4 = 16, ++o3 === n3) return null;
                l3 = e4.charCodeAt(o3);
              } else if (79 === l3 || 111 === l3) {
                if (i4 = 8, ++o3 === n3) return null;
                l3 = e4.charCodeAt(o3);
              } else if (66 === l3 || 98 === l3) {
                if (i4 = 2, ++o3 === n3) return null;
                l3 = e4.charCodeAt(o3);
              }
            }
          } else if (16 === i4 && 48 === l3) {
            if (++o3 === n3) return g3.__zero();
            if (l3 = e4.charCodeAt(o3), 88 === l3 || 120 === l3) {
              if (++o3 === n3) return null;
              l3 = e4.charCodeAt(o3);
            }
          }
          if (0 !== _4 && 10 !== i4) return null;
          for (; 48 === l3; ) {
            if (++o3 === n3) return g3.__zero();
            l3 = e4.charCodeAt(o3);
          }
          var a3 = n3 - o3, s3 = g3.__kMaxBitsPerChar[i4], u3 = g3.__kBitsPerCharTableMultiplier - 1;
          if (a3 > 1073741824 / s3) return null;
          var r3 = s3 * a3 + u3 >>> g3.__kBitsPerCharTableShift, h3 = 0 | (r3 + 29) / 30, b3 = new g3(h3, false), c3 = 10 > i4 ? i4 : 10, v3 = 10 < i4 ? i4 - 10 : 0;
          if (0 == (i4 & i4 - 1)) {
            s3 >>= g3.__kBitsPerCharTableShift;
            var y3 = [], f3 = [], k3 = false;
            do {
              for (var D3, p3 = 0, B3 = 0; true; ) {
                if (D3 = void 0, l3 - 48 >>> 0 < c3) D3 = l3 - 48;
                else if ((32 | l3) - 97 >>> 0 < v3) D3 = (32 | l3) - 87;
                else {
                  k3 = true;
                  break;
                }
                if (B3 += s3, p3 = p3 << s3 | D3, ++o3 === n3) {
                  k3 = true;
                  break;
                }
                if (l3 = e4.charCodeAt(o3), 30 < B3 + s3) break;
              }
              y3.push(p3), f3.push(B3);
            } while (!k3);
            g3.__fillFromParts(b3, y3, f3);
          } else {
            b3.__initializeDigits();
            var S3 = false, C3 = 0;
            do {
              for (var I2, A2 = 0, T2 = 1; true; ) {
                if (I2 = void 0, l3 - 48 >>> 0 < c3) I2 = l3 - 48;
                else if ((32 | l3) - 97 >>> 0 < v3) I2 = (32 | l3) - 87;
                else {
                  S3 = true;
                  break;
                }
                var P2 = T2 * i4;
                if (1073741823 < P2) break;
                if (T2 = P2, A2 = A2 * i4 + I2, C3++, ++o3 === n3) {
                  S3 = true;
                  break;
                }
                l3 = e4.charCodeAt(o3);
              }
              u3 = 30 * g3.__kBitsPerCharTableMultiplier - 1;
              var O2 = 0 | (s3 * C3 + u3 >>> g3.__kBitsPerCharTableShift) / 30;
              b3.__inplaceMultiplyAdd(T2, A2, O2);
            } while (!S3);
          }
          if (o3 !== n3) {
            if (!g3.__isWhitespace(l3)) return null;
            for (o3++; o3 < n3; o3++) if (l3 = e4.charCodeAt(o3), !g3.__isWhitespace(l3)) return null;
          }
          return b3.sign = -1 === _4, b3.__trim();
        } }, { key: "__fillFromParts", value: function n3(e4, t4, _4) {
          for (var o3 = 0, l3 = 0, g4 = 0, a3 = t4.length - 1; 0 <= a3; a3--) {
            var s3 = t4[a3], u3 = _4[a3];
            l3 |= s3 << g4, g4 += u3, 30 === g4 ? (e4.__setDigit(o3++, l3), g4 = 0, l3 = 0) : 30 < g4 && (e4.__setDigit(o3++, 1073741823 & l3), g4 -= 30, l3 = s3 >>> u3 - g4);
          }
          if (0 !== l3) {
            if (o3 >= e4.length) throw new Error("implementation bug");
            e4.__setDigit(o3++, l3);
          }
          for (; o3 < e4.length; o3++) e4.__setDigit(o3, 0);
        } }, { key: "__toStringBasePowerOfTwo", value: function _4(e4, t4) {
          var n3 = e4.length, o3 = t4 - 1;
          o3 = (85 & o3 >>> 1) + (85 & o3), o3 = (51 & o3 >>> 2) + (51 & o3), o3 = (15 & o3 >>> 4) + (15 & o3);
          var l3 = o3, a3 = t4 - 1, s3 = e4.__digit(n3 - 1), u3 = g3.__clz30(s3), r3 = 30 * n3 - u3, d3 = 0 | (r3 + l3 - 1) / l3;
          if (e4.sign && d3++, 268435456 < d3) throw new Error("string too long");
          for (var h3 = Array(d3), b3 = d3 - 1, m3 = 0, c3 = 0, v3 = 0; v3 < n3 - 1; v3++) {
            var y3 = e4.__digit(v3), f3 = (m3 | y3 << c3) & a3;
            h3[b3--] = g3.__kConversionChars[f3];
            var k3 = l3 - c3;
            for (m3 = y3 >>> k3, c3 = 30 - k3; c3 >= l3; ) h3[b3--] = g3.__kConversionChars[m3 & a3], m3 >>>= l3, c3 -= l3;
          }
          var D3 = (m3 | s3 << c3) & a3;
          for (h3[b3--] = g3.__kConversionChars[D3], m3 = s3 >>> l3 - c3; 0 !== m3; ) h3[b3--] = g3.__kConversionChars[m3 & a3], m3 >>>= l3;
          if (e4.sign && (h3[b3--] = "-"), -1 !== b3) throw new Error("implementation bug");
          return h3.join("");
        } }, { key: "__toStringGeneric", value: function n3(e4, t4, _4) {
          var o3 = e4.length;
          if (0 === o3) return "";
          if (1 === o3) {
            var l3 = e4.__unsignedDigit(0).toString(t4);
            return false === _4 && e4.sign && (l3 = "-" + l3), l3;
          }
          var a3 = 30 * o3 - g3.__clz30(e4.__digit(o3 - 1)), s3 = g3.__kMaxBitsPerChar[t4], u3 = s3 - 1, r3 = a3 * g3.__kBitsPerCharTableMultiplier;
          r3 += u3 - 1, r3 = 0 | r3 / u3;
          var d3, h3, b3 = r3 + 1 >> 1, m3 = g3.exponentiate(g3.__oneDigit(t4, false), g3.__oneDigit(b3, false)), c3 = m3.__unsignedDigit(0);
          if (1 === m3.length && 32767 >= c3) {
            d3 = new g3(e4.length, false), d3.__initializeDigits();
            for (var v3, y3 = 0, f3 = 2 * e4.length - 1; 0 <= f3; f3--) v3 = y3 << 15 | e4.__halfDigit(f3), d3.__setHalfDigit(f3, 0 | v3 / c3), y3 = 0 | v3 % c3;
            h3 = y3.toString(t4);
          } else {
            var k3 = g3.__absoluteDivLarge(e4, m3, true, true);
            d3 = k3.quotient;
            var D3 = k3.remainder.__trim();
            h3 = g3.__toStringGeneric(D3, t4, true);
          }
          d3.__trim();
          for (var p3 = g3.__toStringGeneric(d3, t4, true); h3.length < b3; ) h3 = "0" + h3;
          return false === _4 && e4.sign && (p3 = "-" + p3), p3 + h3;
        } }, { key: "__unequalSign", value: function t4(e4) {
          return e4 ? -1 : 1;
        } }, { key: "__absoluteGreater", value: function t4(e4) {
          return e4 ? -1 : 1;
        } }, { key: "__absoluteLess", value: function t4(e4) {
          return e4 ? 1 : -1;
        } }, { key: "__compareToBigInt", value: function i4(e4, t4) {
          var _4 = e4.sign;
          if (_4 !== t4.sign) return g3.__unequalSign(_4);
          var n3 = g3.__absoluteCompare(e4, t4);
          return 0 < n3 ? g3.__absoluteGreater(_4) : 0 > n3 ? g3.__absoluteLess(_4) : 0;
        } }, { key: "__compareToNumber", value: function _4(e4, i4) {
          if (g3.__isOneDigitInt(i4)) {
            var n3 = e4.sign, o3 = 0 > i4;
            if (n3 !== o3) return g3.__unequalSign(n3);
            if (0 === e4.length) {
              if (o3) throw new Error("implementation bug");
              return 0 === i4 ? 0 : -1;
            }
            if (1 < e4.length) return g3.__absoluteGreater(n3);
            var l3 = t3(i4), a3 = e4.__unsignedDigit(0);
            return a3 > l3 ? g3.__absoluteGreater(n3) : a3 < l3 ? g3.__absoluteLess(n3) : 0;
          }
          return g3.__compareToDouble(e4, i4);
        } }, { key: "__compareToDouble", value: function i4(e4, t4) {
          if (t4 !== t4) return t4;
          if (t4 === 1 / 0) return -1;
          if (t4 === -Infinity) return 1;
          var _4 = e4.sign, n3 = 0 > t4;
          if (_4 !== n3) return g3.__unequalSign(_4);
          if (0 === t4) throw new Error("implementation bug: should be handled elsewhere");
          if (0 === e4.length) return -1;
          g3.__kBitConversionDouble[0] = t4;
          var o3 = 2047 & g3.__kBitConversionInts[g3.__kBitConversionIntHigh] >>> 20;
          if (2047 == o3) throw new Error("implementation bug: handled elsewhere");
          var l3 = o3 - 1023;
          if (0 > l3) return g3.__absoluteGreater(_4);
          var a3 = e4.length, s3 = e4.__digit(a3 - 1), u3 = g3.__clz30(s3), r3 = 30 * a3 - u3, d3 = l3 + 1;
          if (r3 < d3) return g3.__absoluteLess(_4);
          if (r3 > d3) return g3.__absoluteGreater(_4);
          var h3 = 1048576, b3 = 1048576 | 1048575 & g3.__kBitConversionInts[g3.__kBitConversionIntHigh], m3 = g3.__kBitConversionInts[g3.__kBitConversionIntLow], c3 = 20, v3 = 29 - u3;
          if (v3 !== (0 | (r3 - 1) % 30)) throw new Error("implementation bug");
          var y3, f3 = 0;
          if (v3 < c3) {
            var k3 = c3 - v3;
            f3 = k3 + 32, y3 = b3 >>> k3, b3 = b3 << 32 - k3 | m3 >>> k3, m3 <<= 32 - k3;
          } else if (v3 === c3) f3 = 32, y3 = b3, b3 = m3, m3 = 0;
          else {
            var D3 = v3 - c3;
            f3 = 32 - D3, y3 = b3 << D3 | m3 >>> 32 - D3, b3 = m3 << D3, m3 = 0;
          }
          if (s3 >>>= 0, y3 >>>= 0, s3 > y3) return g3.__absoluteGreater(_4);
          if (s3 < y3) return g3.__absoluteLess(_4);
          for (var p3 = a3 - 2; 0 <= p3; p3--) {
            0 < f3 ? (f3 -= 30, y3 = b3 >>> 2, b3 = b3 << 30 | m3 >>> 2, m3 <<= 30) : y3 = 0;
            var B3 = e4.__unsignedDigit(p3);
            if (B3 > y3) return g3.__absoluteGreater(_4);
            if (B3 < y3) return g3.__absoluteLess(_4);
          }
          if (0 !== b3 || 0 !== m3) {
            if (0 === f3) throw new Error("implementation bug");
            return g3.__absoluteLess(_4);
          }
          return 0;
        } }, { key: "__equalToNumber", value: function _4(e4, i4) {
          return g3.__isOneDigitInt(i4) ? 0 === i4 ? 0 === e4.length : 1 === e4.length && e4.sign === 0 > i4 && e4.__unsignedDigit(0) === t3(i4) : 0 === g3.__compareToDouble(e4, i4);
        } }, { key: "__comparisonResultToBool", value: function i4(e4, t4) {
          return 0 === t4 ? 0 > e4 : 1 === t4 ? 0 >= e4 : 2 === t4 ? 0 < e4 : 3 === t4 ? 0 <= e4 : void 0;
        } }, { key: "__compare", value: function _4(e4, t4, i4) {
          if (e4 = g3.__toPrimitive(e4), t4 = g3.__toPrimitive(t4), "string" == typeof e4 && "string" == typeof t4) switch (i4) {
            case 0:
              return e4 < t4;
            case 1:
              return e4 <= t4;
            case 2:
              return e4 > t4;
            case 3:
              return e4 >= t4;
          }
          if (g3.__isBigInt(e4) && "string" == typeof t4) return t4 = g3.__fromString(t4), null !== t4 && g3.__comparisonResultToBool(g3.__compareToBigInt(e4, t4), i4);
          if ("string" == typeof e4 && g3.__isBigInt(t4)) return e4 = g3.__fromString(e4), null !== e4 && g3.__comparisonResultToBool(g3.__compareToBigInt(e4, t4), i4);
          if (e4 = g3.__toNumeric(e4), t4 = g3.__toNumeric(t4), g3.__isBigInt(e4)) {
            if (g3.__isBigInt(t4)) return g3.__comparisonResultToBool(g3.__compareToBigInt(e4, t4), i4);
            if ("number" != typeof t4) throw new Error("implementation bug");
            return g3.__comparisonResultToBool(g3.__compareToNumber(e4, t4), i4);
          }
          if ("number" != typeof e4) throw new Error("implementation bug");
          if (g3.__isBigInt(t4)) return g3.__comparisonResultToBool(g3.__compareToNumber(t4, e4), 2 ^ i4);
          if ("number" != typeof t4) throw new Error("implementation bug");
          return 0 === i4 ? e4 < t4 : 1 === i4 ? e4 <= t4 : 2 === i4 ? e4 > t4 : 3 === i4 ? e4 >= t4 : void 0;
        } }, { key: "__absoluteAdd", value: function n3(e4, t4, _4) {
          if (e4.length < t4.length) return g3.__absoluteAdd(t4, e4, _4);
          if (0 === e4.length) return e4;
          if (0 === t4.length) return e4.sign === _4 ? e4 : g3.unaryMinus(e4);
          var o3 = e4.length;
          (0 === e4.__clzmsd() || t4.length === e4.length && 0 === t4.__clzmsd()) && o3++;
          for (var l3, a3 = new g3(o3, _4), s3 = 0, u3 = 0; u3 < t4.length; u3++) l3 = e4.__digit(u3) + t4.__digit(u3) + s3, s3 = l3 >>> 30, a3.__setDigit(u3, 1073741823 & l3);
          for (; u3 < e4.length; u3++) {
            var d3 = e4.__digit(u3) + s3;
            s3 = d3 >>> 30, a3.__setDigit(u3, 1073741823 & d3);
          }
          return u3 < a3.length && a3.__setDigit(u3, s3), a3.__trim();
        } }, { key: "__absoluteSub", value: function n3(e4, t4, _4) {
          if (0 === e4.length) return e4;
          if (0 === t4.length) return e4.sign === _4 ? e4 : g3.unaryMinus(e4);
          for (var o3, l3 = new g3(e4.length, _4), a3 = 0, s3 = 0; s3 < t4.length; s3++) o3 = e4.__digit(s3) - t4.__digit(s3) - a3, a3 = 1 & o3 >>> 30, l3.__setDigit(s3, 1073741823 & o3);
          for (; s3 < e4.length; s3++) {
            var u3 = e4.__digit(s3) - a3;
            a3 = 1 & u3 >>> 30, l3.__setDigit(s3, 1073741823 & u3);
          }
          return l3.__trim();
        } }, { key: "__absoluteAddOne", value: function _4(e4, t4) {
          var n3 = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null, o3 = e4.length;
          null === n3 ? n3 = new g3(o3, t4) : n3.sign = t4;
          for (var l3, a3 = 1, s3 = 0; s3 < o3; s3++) l3 = e4.__digit(s3) + a3, a3 = l3 >>> 30, n3.__setDigit(s3, 1073741823 & l3);
          return 0 !== a3 && n3.__setDigitGrow(o3, 1), n3;
        } }, { key: "__absoluteSubOne", value: function _4(e4, t4) {
          var n3 = e4.length;
          t4 = t4 || n3;
          for (var o3, l3 = new g3(t4, false), a3 = 1, s3 = 0; s3 < n3; s3++) o3 = e4.__digit(s3) - a3, a3 = 1 & o3 >>> 30, l3.__setDigit(s3, 1073741823 & o3);
          if (0 !== a3) throw new Error("implementation bug");
          for (var u3 = n3; u3 < t4; u3++) l3.__setDigit(u3, 0);
          return l3;
        } }, { key: "__absoluteAnd", value: function _4(e4, t4) {
          var n3 = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null, o3 = e4.length, l3 = t4.length, a3 = l3;
          if (o3 < l3) {
            a3 = o3;
            var s3 = e4, u3 = o3;
            e4 = t4, o3 = l3, t4 = s3, l3 = u3;
          }
          var r3 = a3;
          null === n3 ? n3 = new g3(r3, false) : r3 = n3.length;
          for (var d3 = 0; d3 < a3; d3++) n3.__setDigit(d3, e4.__digit(d3) & t4.__digit(d3));
          for (; d3 < r3; d3++) n3.__setDigit(d3, 0);
          return n3;
        } }, { key: "__absoluteAndNot", value: function _4(e4, t4) {
          var n3 = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null, o3 = e4.length, l3 = t4.length, a3 = l3;
          o3 < l3 && (a3 = o3);
          var s3 = o3;
          null === n3 ? n3 = new g3(s3, false) : s3 = n3.length;
          for (var u3 = 0; u3 < a3; u3++) n3.__setDigit(u3, e4.__digit(u3) & ~t4.__digit(u3));
          for (; u3 < o3; u3++) n3.__setDigit(u3, e4.__digit(u3));
          for (; u3 < s3; u3++) n3.__setDigit(u3, 0);
          return n3;
        } }, { key: "__absoluteOr", value: function _4(e4, t4) {
          var n3 = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null, o3 = e4.length, l3 = t4.length, a3 = l3;
          if (o3 < l3) {
            a3 = o3;
            var s3 = e4, u3 = o3;
            e4 = t4, o3 = l3, t4 = s3, l3 = u3;
          }
          var r3 = o3;
          null === n3 ? n3 = new g3(r3, false) : r3 = n3.length;
          for (var d3 = 0; d3 < a3; d3++) n3.__setDigit(d3, e4.__digit(d3) | t4.__digit(d3));
          for (; d3 < o3; d3++) n3.__setDigit(d3, e4.__digit(d3));
          for (; d3 < r3; d3++) n3.__setDigit(d3, 0);
          return n3;
        } }, { key: "__absoluteXor", value: function _4(e4, t4) {
          var n3 = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null, o3 = e4.length, l3 = t4.length, a3 = l3;
          if (o3 < l3) {
            a3 = o3;
            var s3 = e4, u3 = o3;
            e4 = t4, o3 = l3, t4 = s3, l3 = u3;
          }
          var r3 = o3;
          null === n3 ? n3 = new g3(r3, false) : r3 = n3.length;
          for (var d3 = 0; d3 < a3; d3++) n3.__setDigit(d3, e4.__digit(d3) ^ t4.__digit(d3));
          for (; d3 < o3; d3++) n3.__setDigit(d3, e4.__digit(d3));
          for (; d3 < r3; d3++) n3.__setDigit(d3, 0);
          return n3;
        } }, { key: "__absoluteCompare", value: function _4(e4, t4) {
          var n3 = e4.length - t4.length;
          if (0 != n3) return n3;
          for (var o3 = e4.length - 1; 0 <= o3 && e4.__digit(o3) === t4.__digit(o3); ) o3--;
          return 0 > o3 ? 0 : e4.__unsignedDigit(o3) > t4.__unsignedDigit(o3) ? 1 : -1;
        } }, { key: "__multiplyAccumulate", value: function o3(e4, t4, _4, n3) {
          if (0 !== t4) {
            for (var l3 = 32767 & t4, a3 = t4 >>> 15, s3 = 0, u3 = 0, r3 = 0; r3 < e4.length; r3++, n3++) {
              var d3 = _4.__digit(n3), h3 = e4.__digit(r3), b3 = 32767 & h3, m3 = h3 >>> 15, c3 = g3.__imul(b3, l3), v3 = g3.__imul(b3, a3), y3 = g3.__imul(m3, l3), f3 = g3.__imul(m3, a3);
              d3 += u3 + c3 + s3, s3 = d3 >>> 30, d3 &= 1073741823, d3 += ((32767 & v3) << 15) + ((32767 & y3) << 15), s3 += d3 >>> 30, u3 = f3 + (v3 >>> 15) + (y3 >>> 15), _4.__setDigit(n3, 1073741823 & d3);
            }
            for (; 0 !== s3 || 0 !== u3; n3++) {
              var k3 = _4.__digit(n3);
              k3 += s3 + u3, u3 = 0, s3 = k3 >>> 30, _4.__setDigit(n3, 1073741823 & k3);
            }
          }
        } }, { key: "__internalMultiplyAdd", value: function a3(e4, t4, _4, o3, l3) {
          for (var s3 = _4, u3 = 0, d3 = 0; d3 < o3; d3++) {
            var h3 = e4.__digit(d3), b3 = g3.__imul(32767 & h3, t4), m3 = g3.__imul(h3 >>> 15, t4), c3 = b3 + ((32767 & m3) << 15) + u3 + s3;
            s3 = c3 >>> 30, u3 = m3 >>> 15, l3.__setDigit(d3, 1073741823 & c3);
          }
          if (l3.length > o3) for (l3.__setDigit(o3++, s3 + u3); o3 < l3.length; ) l3.__setDigit(o3++, 0);
          else if (0 !== s3 + u3) throw new Error("implementation bug");
        } }, { key: "__absoluteDivSmall", value: function _4(e4, t4) {
          var n3 = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
          null === n3 && (n3 = new g3(e4.length, false));
          for (var o3 = 0, l3 = 2 * e4.length - 1; 0 <= l3; l3 -= 2) {
            var a3 = (o3 << 15 | e4.__halfDigit(l3)) >>> 0, s3 = 0 | a3 / t4;
            o3 = 0 | a3 % t4, a3 = (o3 << 15 | e4.__halfDigit(l3 - 1)) >>> 0;
            var u3 = 0 | a3 / t4;
            o3 = 0 | a3 % t4, n3.__setDigit(l3 >>> 1, s3 << 15 | u3);
          }
          return n3;
        } }, { key: "__absoluteModSmall", value: function _4(e4, t4) {
          for (var n3, o3 = 0, l3 = 2 * e4.length - 1; 0 <= l3; l3--) n3 = (o3 << 15 | e4.__halfDigit(l3)) >>> 0, o3 = 0 | n3 % t4;
          return o3;
        } }, { key: "__absoluteDivLarge", value: function o3(e4, t4, i4, _4) {
          var l3 = t4.__halfDigitLength(), n3 = t4.length, a3 = e4.__halfDigitLength() - l3, s3 = null;
          i4 && (s3 = new g3(a3 + 2 >>> 1, false), s3.__initializeDigits());
          var r3 = new g3(l3 + 2 >>> 1, false);
          r3.__initializeDigits();
          var d3 = g3.__clz15(t4.__halfDigit(l3 - 1));
          0 < d3 && (t4 = g3.__specialLeftShift(t4, d3, 0));
          for (var h3 = g3.__specialLeftShift(e4, d3, 1), u3 = t4.__halfDigit(l3 - 1), b3 = 0, m3 = a3; 0 <= m3; m3--) {
            var v3 = 32767, y3 = h3.__halfDigit(m3 + l3);
            if (y3 !== u3) {
              var f3 = (y3 << 15 | h3.__halfDigit(m3 + l3 - 1)) >>> 0;
              v3 = 0 | f3 / u3;
              for (var k3 = 0 | f3 % u3, D3 = t4.__halfDigit(l3 - 2), p3 = h3.__halfDigit(m3 + l3 - 2); g3.__imul(v3, D3) >>> 0 > (k3 << 16 | p3) >>> 0 && (v3--, k3 += u3, !(32767 < k3)); ) ;
            }
            g3.__internalMultiplyAdd(t4, v3, 0, n3, r3);
            var B3 = h3.__inplaceSub(r3, m3, l3 + 1);
            0 !== B3 && (B3 = h3.__inplaceAdd(t4, m3, l3), h3.__setHalfDigit(m3 + l3, 32767 & h3.__halfDigit(m3 + l3) + B3), v3--), i4 && (1 & m3 ? b3 = v3 << 15 : s3.__setDigit(m3 >>> 1, b3 | v3));
          }
          if (_4) return h3.__inplaceRightShift(d3), i4 ? { quotient: s3, remainder: h3 } : h3;
          if (i4) return s3;
          throw new Error("unreachable");
        } }, { key: "__clz15", value: function t4(e4) {
          return g3.__clz30(e4) - 15;
        } }, { key: "__specialLeftShift", value: function o3(e4, t4, _4) {
          var l3 = e4.length, n3 = l3 + _4, a3 = new g3(n3, false);
          if (0 === t4) {
            for (var s3 = 0; s3 < l3; s3++) a3.__setDigit(s3, e4.__digit(s3));
            return 0 < _4 && a3.__setDigit(l3, 0), a3;
          }
          for (var u3, r3 = 0, h3 = 0; h3 < l3; h3++) u3 = e4.__digit(h3), a3.__setDigit(h3, 1073741823 & u3 << t4 | r3), r3 = u3 >>> 30 - t4;
          return 0 < _4 && a3.__setDigit(l3, r3), a3;
        } }, { key: "__leftShiftByAbsolute", value: function _4(e4, t4) {
          var n3 = g3.__toShiftAmount(t4);
          if (0 > n3) throw new RangeError("BigInt too big");
          var o3 = 0 | n3 / 30, l3 = n3 % 30, a3 = e4.length, s3 = 0 !== l3 && 0 != e4.__digit(a3 - 1) >>> 30 - l3, u3 = a3 + o3 + (s3 ? 1 : 0), r3 = new g3(u3, e4.sign);
          if (0 === l3) {
            for (var h3 = 0; h3 < o3; h3++) r3.__setDigit(h3, 0);
            for (; h3 < u3; h3++) r3.__setDigit(h3, e4.__digit(h3 - o3));
          } else {
            for (var b3 = 0, m3 = 0; m3 < o3; m3++) r3.__setDigit(m3, 0);
            for (var c3, v3 = 0; v3 < a3; v3++) c3 = e4.__digit(v3), r3.__setDigit(v3 + o3, 1073741823 & c3 << l3 | b3), b3 = c3 >>> 30 - l3;
            if (s3) r3.__setDigit(a3 + o3, b3);
            else if (0 !== b3) throw new Error("implementation bug");
          }
          return r3.__trim();
        } }, { key: "__rightShiftByAbsolute", value: function _4(e4, t4) {
          var n3 = e4.length, o3 = e4.sign, l3 = g3.__toShiftAmount(t4);
          if (0 > l3) return g3.__rightShiftByMaximum(o3);
          var a3 = 0 | l3 / 30, s3 = l3 % 30, u3 = n3 - a3;
          if (0 >= u3) return g3.__rightShiftByMaximum(o3);
          var r3 = false;
          if (o3) {
            var h3 = (1 << s3) - 1;
            if (0 != (e4.__digit(a3) & h3)) r3 = true;
            else for (var b3 = 0; b3 < a3; b3++) if (0 !== e4.__digit(b3)) {
              r3 = true;
              break;
            }
          }
          if (r3 && 0 === s3) {
            var m3 = e4.__digit(n3 - 1), c3 = 0 == ~m3;
            c3 && u3++;
          }
          var v3 = new g3(u3, o3);
          if (0 === s3) {
            v3.__setDigit(u3 - 1, 0);
            for (var y3 = a3; y3 < n3; y3++) v3.__setDigit(y3 - a3, e4.__digit(y3));
          } else {
            for (var f3, k3 = e4.__digit(a3) >>> s3, D3 = n3 - a3 - 1, p3 = 0; p3 < D3; p3++) f3 = e4.__digit(p3 + a3 + 1), v3.__setDigit(p3, 1073741823 & f3 << 30 - s3 | k3), k3 = f3 >>> s3;
            v3.__setDigit(D3, k3);
          }
          return r3 && (v3 = g3.__absoluteAddOne(v3, true, v3)), v3.__trim();
        } }, { key: "__rightShiftByMaximum", value: function t4(e4) {
          return e4 ? g3.__oneDigit(1, true) : g3.__zero();
        } }, { key: "__toShiftAmount", value: function t4(e4) {
          if (1 < e4.length) return -1;
          var i4 = e4.__unsignedDigit(0);
          return i4 > g3.__kMaxLengthBits ? -1 : i4;
        } }, { key: "__toPrimitive", value: function t4(e4) {
          var i4 = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : "default";
          if ("object" !== p2(e4)) return e4;
          if (e4.constructor === g3) return e4;
          if ("undefined" != typeof Symbol && "symbol" === p2(Symbol.toPrimitive) && e4[Symbol.toPrimitive]) {
            var _4 = e4[Symbol.toPrimitive](i4);
            if ("object" !== p2(_4)) return _4;
            throw new TypeError("Cannot convert object to primitive value");
          }
          var n3 = e4.valueOf;
          if (n3) {
            var o3 = n3.call(e4);
            if ("object" !== p2(o3)) return o3;
          }
          var l3 = e4.toString;
          if (l3) {
            var a3 = l3.call(e4);
            if ("object" !== p2(a3)) return a3;
          }
          throw new TypeError("Cannot convert object to primitive value");
        } }, { key: "__toNumeric", value: function t4(e4) {
          return g3.__isBigInt(e4) ? e4 : +e4;
        } }, { key: "__isBigInt", value: function t4(e4) {
          return "object" === p2(e4) && null !== e4 && e4.constructor === g3;
        } }, { key: "__truncateToNBits", value: function _4(e4, t4) {
          for (var n3 = 0 | (e4 + 29) / 30, o3 = new g3(n3, t4.sign), l3 = n3 - 1, a3 = 0; a3 < l3; a3++) o3.__setDigit(a3, t4.__digit(a3));
          var s3 = t4.__digit(l3);
          if (0 != e4 % 30) {
            var u3 = 32 - e4 % 30;
            s3 = s3 << u3 >>> u3;
          }
          return o3.__setDigit(l3, s3), o3.__trim();
        } }, { key: "__truncateAndSubFromPowerOfTwo", value: function n3(e4, t4, _4) {
          for (var o3 = Math.min, l3, a3 = 0 | (e4 + 29) / 30, s3 = new g3(a3, _4), u3 = 0, d3 = a3 - 1, h3 = 0, b3 = o3(d3, t4.length); u3 < b3; u3++) l3 = 0 - t4.__digit(u3) - h3, h3 = 1 & l3 >>> 30, s3.__setDigit(u3, 1073741823 & l3);
          for (; u3 < d3; u3++) s3.__setDigit(u3, 0 | 1073741823 & -h3);
          var m3, c3 = d3 < t4.length ? t4.__digit(d3) : 0, v3 = e4 % 30;
          if (0 === v3) m3 = 0 - c3 - h3, m3 &= 1073741823;
          else {
            var y3 = 32 - v3;
            c3 = c3 << y3 >>> y3;
            var f3 = 1 << 32 - y3;
            m3 = f3 - c3 - h3, m3 &= f3 - 1;
          }
          return s3.__setDigit(d3, m3), s3.__trim();
        } }, { key: "__digitPow", value: function i4(e4, t4) {
          for (var _4 = 1; 0 < t4; ) 1 & t4 && (_4 *= e4), t4 >>>= 1, e4 *= e4;
          return _4;
        } }, { key: "__detectBigEndian", value: function e4() {
          return g3.__kBitConversionDouble[0] = -0, 0 !== g3.__kBitConversionInts[0];
        } }, { key: "__isOneDigitInt", value: function t4(e4) {
          return (1073741823 & e4) === e4;
        } }]);
      })(S2(Array));
      return C2.__kMaxLength = 33554432, C2.__kMaxLengthBits = C2.__kMaxLength << 5, C2.__kMaxBitsPerChar = [0, 0, 32, 51, 64, 75, 83, 90, 96, 102, 107, 111, 115, 119, 122, 126, 128, 131, 134, 136, 139, 141, 143, 145, 147, 149, 151, 153, 154, 156, 158, 159, 160, 162, 163, 165, 166], C2.__kBitsPerCharTableShift = 5, C2.__kBitsPerCharTableMultiplier = 1 << C2.__kBitsPerCharTableShift, C2.__kConversionChars = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"], C2.__kBitConversionBuffer = new ArrayBuffer(8), C2.__kBitConversionDouble = new Float64Array(C2.__kBitConversionBuffer), C2.__kBitConversionInts = new Int32Array(C2.__kBitConversionBuffer), C2.__kBitConversionIntHigh = C2.__detectBigEndian() ? 0 : 1, C2.__kBitConversionIntLow = C2.__detectBigEndian() ? 1 : 0, C2.__clz30 = t2 ? function(e3) {
        return t2(e3) - 2;
      } : function(e3) {
        var t3 = Math.LN2, i3 = Math.log;
        return 0 === e3 ? 30 : 0 | 29 - (0 | i3(e3 >>> 0) / t3);
      }, C2.__imul = e2 || function(e3, t3) {
        return 0 | e3 * t3;
      }, C2;
    });
  }
});

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@js-temporal+polyfill@0.5.1/node_modules/@js-temporal/polyfill/dist/index.esm.js
var import_jsbi = __toESM(require_jsbi_umd(), 1);
var t = import_jsbi.default.BigInt(0);
var n = import_jsbi.default.BigInt(1);
var r = import_jsbi.default.BigInt(2);
var o = import_jsbi.default.BigInt(10);
var i = import_jsbi.default.BigInt(24);
var a = import_jsbi.default.BigInt(60);
var s = import_jsbi.default.BigInt(1e3);
var c = import_jsbi.default.BigInt(1e6);
var d = import_jsbi.default.BigInt(1e9);
var h = import_jsbi.default.multiply(import_jsbi.default.BigInt(3600), d);
var u = import_jsbi.default.multiply(a, d);
var l = import_jsbi.default.multiply(h, i);
function m(t2) {
  return "bigint" == typeof t2 ? import_jsbi.default.BigInt(t2.toString(10)) : t2;
}
function f(n2) {
  return import_jsbi.default.equal(import_jsbi.default.remainder(n2, r), t);
}
function y(n2) {
  return import_jsbi.default.lessThan(n2, t) ? import_jsbi.default.unaryMinus(n2) : n2;
}
function p(t2, n2) {
  return import_jsbi.default.lessThan(t2, n2) ? -1 : import_jsbi.default.greaterThan(t2, n2) ? 1 : 0;
}
function g(t2, n2) {
  return { quotient: import_jsbi.default.divide(t2, n2), remainder: import_jsbi.default.remainder(t2, n2) };
}
var w;
var v;
var b = "slot-epochNanoSeconds";
var D = "slot-iso-date";
var T = "slot-iso-date-time";
var M = "slot-time";
var E = "slot-calendar";
var I = "slot-date-brand";
var C = "slot-year-month-brand";
var O = "slot-month-day-brand";
var $ = "slot-time-zone";
var Y = "slot-years";
var R = "slot-months";
var S = "slot-weeks";
var j = "slot-days";
var k = "slot-hours";
var N = "slot-minutes";
var x = "slot-seconds";
var L = "slot-milliseconds";
var P = "slot-microseconds";
var U = "slot-nanoseconds";
var B = "date";
var Z = "ym";
var F = "md";
var H = "time";
var z = "datetime";
var A = "instant";
var q = "original";
var W = "timezone-canonical";
var _ = "timezone-original";
var J = "calendar-id";
var G = "locale";
var K = "options";
var V = /* @__PURE__ */ new WeakMap();
var X = /* @__PURE__ */ Symbol.for("@@Temporal__GetSlots");
(w = globalThis)[X] || (w[X] = function(e2) {
  return V.get(e2);
});
var Q = globalThis[X];
var ee = /* @__PURE__ */ Symbol.for("@@Temporal__CreateSlots");
(v = globalThis)[ee] || (v[ee] = function(e2) {
  V.set(e2, /* @__PURE__ */ Object.create(null));
});
var te = globalThis[ee];
function ne(e2, ...t2) {
  if (!e2 || "object" != typeof e2) return false;
  const n2 = Q(e2);
  return !!n2 && t2.every(((e3) => e3 in n2));
}
function re(e2, t2) {
  const n2 = Q(e2)?.[t2];
  if (void 0 === n2) throw new TypeError(`Missing internal slot ${t2}`);
  return n2;
}
function oe(e2, t2, n2) {
  const r2 = Q(e2);
  if (void 0 === r2) throw new TypeError("Missing slots for the given container");
  if (r2[t2]) throw new TypeError(`${t2} already has set`);
  r2[t2] = n2;
}
var ie = {};
function ae(e2, t2) {
  Object.defineProperty(e2.prototype, Symbol.toStringTag, { value: t2, writable: false, enumerable: false, configurable: true });
  const n2 = Object.getOwnPropertyNames(e2);
  for (let t3 = 0; t3 < n2.length; t3++) {
    const r3 = n2[t3], o2 = Object.getOwnPropertyDescriptor(e2, r3);
    o2.configurable && o2.enumerable && (o2.enumerable = false, Object.defineProperty(e2, r3, o2));
  }
  const r2 = Object.getOwnPropertyNames(e2.prototype);
  for (let t3 = 0; t3 < r2.length; t3++) {
    const n3 = r2[t3], o2 = Object.getOwnPropertyDescriptor(e2.prototype, n3);
    o2.configurable && o2.enumerable && (o2.enumerable = false, Object.defineProperty(e2.prototype, n3, o2));
  }
  se(t2, e2), se(`${t2}.prototype`, e2.prototype);
}
function se(e2, t2) {
  const n2 = `%${e2}%`;
  if (void 0 !== ie[n2]) throw new Error(`intrinsic ${e2} already exists`);
  ie[n2] = t2;
}
function ce(e2) {
  return ie[e2];
}
function de(e2, t2) {
  let n2 = e2;
  if (0 === n2) return { div: n2, mod: n2 };
  const r2 = Math.sign(n2);
  n2 = Math.abs(n2);
  const o2 = Math.trunc(1 + Math.log10(n2));
  if (t2 >= o2) return { div: 0 * r2, mod: r2 * n2 };
  if (0 === t2) return { div: r2 * n2, mod: 0 * r2 };
  const i2 = n2.toPrecision(o2);
  return { div: r2 * Number.parseInt(i2.slice(0, o2 - t2), 10), mod: r2 * Number.parseInt(i2.slice(o2 - t2), 10) };
}
function he(e2, t2, n2) {
  let r2 = e2, o2 = n2;
  if (0 === r2) return o2;
  const i2 = Math.sign(r2) || Math.sign(o2);
  r2 = Math.abs(r2), o2 = Math.abs(o2);
  const a2 = r2.toPrecision(Math.trunc(1 + Math.log10(r2)));
  if (0 === o2) return i2 * Number.parseInt(a2 + "0".repeat(t2), 10);
  const s2 = a2 + o2.toPrecision(Math.trunc(1 + Math.log10(o2))).padStart(t2, "0");
  return i2 * Number.parseInt(s2, 10);
}
function ue(e2, t2) {
  const n2 = "negative" === t2;
  switch (e2) {
    case "ceil":
      return n2 ? "zero" : "infinity";
    case "floor":
      return n2 ? "infinity" : "zero";
    case "expand":
      return "infinity";
    case "trunc":
      return "zero";
    case "halfCeil":
      return n2 ? "half-zero" : "half-infinity";
    case "halfFloor":
      return n2 ? "half-infinity" : "half-zero";
    case "halfExpand":
      return "half-infinity";
    case "halfTrunc":
      return "half-zero";
    case "halfEven":
      return "half-even";
  }
}
function le(e2, t2, n2, r2, o2) {
  return "zero" === o2 ? e2 : "infinity" === o2 ? t2 : n2 < 0 ? e2 : n2 > 0 ? t2 : "half-zero" === o2 ? e2 : "half-infinity" === o2 ? t2 : r2 ? e2 : t2;
}
var TimeDuration = class _TimeDuration {
  constructor(t2) {
    this.totalNs = m(t2), this.sec = import_jsbi.default.toNumber(import_jsbi.default.divide(this.totalNs, d)), this.subsec = import_jsbi.default.toNumber(import_jsbi.default.remainder(this.totalNs, d));
  }
  static validateNew(t2, n2) {
    if (import_jsbi.default.greaterThan(y(t2), _TimeDuration.MAX)) throw new RangeError(`${n2} of duration time units cannot exceed ${_TimeDuration.MAX} s`);
    return new _TimeDuration(t2);
  }
  static fromEpochNsDiff(t2, n2) {
    const r2 = import_jsbi.default.subtract(m(t2), m(n2));
    return new _TimeDuration(r2);
  }
  static fromComponents(t2, n2, r2, o2, i2, a2) {
    const l2 = import_jsbi.default.add(import_jsbi.default.add(import_jsbi.default.add(import_jsbi.default.add(import_jsbi.default.add(import_jsbi.default.BigInt(a2), import_jsbi.default.multiply(import_jsbi.default.BigInt(i2), s)), import_jsbi.default.multiply(import_jsbi.default.BigInt(o2), c)), import_jsbi.default.multiply(import_jsbi.default.BigInt(r2), d)), import_jsbi.default.multiply(import_jsbi.default.BigInt(n2), u)), import_jsbi.default.multiply(import_jsbi.default.BigInt(t2), h));
    return _TimeDuration.validateNew(l2, "total");
  }
  abs() {
    return new _TimeDuration(y(this.totalNs));
  }
  add(t2) {
    return _TimeDuration.validateNew(import_jsbi.default.add(this.totalNs, t2.totalNs), "sum");
  }
  add24HourDays(t2) {
    return _TimeDuration.validateNew(import_jsbi.default.add(this.totalNs, import_jsbi.default.multiply(import_jsbi.default.BigInt(t2), l)), "sum");
  }
  addToEpochNs(t2) {
    return import_jsbi.default.add(m(t2), this.totalNs);
  }
  cmp(e2) {
    return p(this.totalNs, e2.totalNs);
  }
  divmod(t2) {
    const { quotient: n2, remainder: r2 } = g(this.totalNs, import_jsbi.default.BigInt(t2));
    return { quotient: import_jsbi.default.toNumber(n2), remainder: new _TimeDuration(r2) };
  }
  fdiv(n2) {
    const r2 = m(n2), i2 = import_jsbi.default.BigInt(r2);
    let { quotient: a2, remainder: s2 } = g(this.totalNs, i2);
    const c2 = [];
    let d2;
    const h2 = (import_jsbi.default.lessThan(this.totalNs, t) ? -1 : 1) * Math.sign(import_jsbi.default.toNumber(r2));
    for (; !import_jsbi.default.equal(s2, t) && c2.length < 50; ) s2 = import_jsbi.default.multiply(s2, o), { quotient: d2, remainder: s2 } = g(s2, i2), c2.push(Math.abs(import_jsbi.default.toNumber(d2)));
    return h2 * Number(y(a2).toString() + "." + c2.join(""));
  }
  isZero() {
    return import_jsbi.default.equal(this.totalNs, t);
  }
  round(o2, i2) {
    const a2 = m(o2);
    if (import_jsbi.default.equal(a2, n)) return this;
    const { quotient: s2, remainder: c2 } = g(this.totalNs, a2), d2 = import_jsbi.default.lessThan(this.totalNs, t) ? "negative" : "positive", h2 = import_jsbi.default.multiply(y(s2), a2), u2 = import_jsbi.default.add(h2, a2), l2 = p(y(import_jsbi.default.multiply(c2, r)), a2), w2 = ue(i2, d2), v2 = import_jsbi.default.equal(y(this.totalNs), h2) ? h2 : le(h2, u2, l2, f(s2), w2), b2 = "positive" === d2 ? v2 : import_jsbi.default.unaryMinus(v2);
    return _TimeDuration.validateNew(b2, "rounding");
  }
  sign() {
    return this.cmp(new _TimeDuration(t));
  }
  subtract(t2) {
    return _TimeDuration.validateNew(import_jsbi.default.subtract(this.totalNs, t2.totalNs), "difference");
  }
};
TimeDuration.MAX = import_jsbi.default.BigInt("9007199254740991999999999"), TimeDuration.ZERO = new TimeDuration(t);
var me = /[A-Za-z._][A-Za-z._0-9+-]*/;
var fe = new RegExp(`(?:${/(?:[+-](?:[01][0-9]|2[0-3])(?::?[0-5][0-9])?)/.source}|(?:${me.source})(?:\\/(?:${me.source}))*)`);
var ye = /(?:[+-]\d{6}|\d{4})/;
var pe = /(?:0[1-9]|1[0-2])/;
var ge = /(?:0[1-9]|[12]\d|3[01])/;
var we = new RegExp(`(${ye.source})(?:-(${pe.source})-(${ge.source})|(${pe.source})(${ge.source}))`);
var ve = /(\d{2})(?::(\d{2})(?::(\d{2})(?:[.,](\d{1,9}))?)?|(\d{2})(?:(\d{2})(?:[.,](\d{1,9}))?)?)?/;
var be = /((?:[+-])(?:[01][0-9]|2[0-3])(?::?(?:[0-5][0-9])(?::?(?:[0-5][0-9])(?:[.,](?:\d{1,9}))?)?)?)/;
var De = new RegExp(`([zZ])|${be.source}?`);
var Te = /\[(!)?([a-z_][a-z0-9_-]*)=([A-Za-z0-9]+(?:-[A-Za-z0-9]+)*)\]/g;
var Me = new RegExp([`^${we.source}`, `(?:(?:[tT]|\\s+)${ve.source}(?:${De.source})?)?`, `(?:\\[!?(${fe.source})\\])?`, `((?:${Te.source})*)$`].join(""));
var Ee = new RegExp([`^[tT]?${ve.source}`, `(?:${De.source})?`, `(?:\\[!?${fe.source}\\])?`, `((?:${Te.source})*)$`].join(""));
var Ie = new RegExp(`^(${ye.source})-?(${pe.source})(?:\\[!?${fe.source}\\])?((?:${Te.source})*)$`);
var Ce = new RegExp(`^(?:--)?(${pe.source})-?(${ge.source})(?:\\[!?${fe.source}\\])?((?:${Te.source})*)$`);
var Oe = /(\d+)(?:[.,](\d{1,9}))?/;
var $e = new RegExp(`(?:${Oe.source}H)?(?:${Oe.source}M)?(?:${Oe.source}S)?`);
var Ye = new RegExp(`^([+-])?P${/(?:(\d+)Y)?(?:(\d+)M)?(?:(\d+)W)?(?:(\d+)D)?/.source}(?:T(?!$)${$e.source})?$`, "i");
var Re = 864e5;
var Se = 1e6 * Re;
var je = 6e10;
var ke = 1e8 * Re;
var Ne = xo(ke);
var xe = import_jsbi.default.unaryMinus(Ne);
var Le = import_jsbi.default.add(import_jsbi.default.subtract(xe, l), n);
var Pe = import_jsbi.default.subtract(import_jsbi.default.add(Ne, l), n);
var Ue = 146097 * Re;
var Be = -271821;
var Ze = 275760;
var Fe = Date.UTC(1847, 0, 1);
var He = ["iso8601", "hebrew", "islamic", "islamic-umalqura", "islamic-tbla", "islamic-civil", "islamic-rgsa", "islamicc", "persian", "ethiopic", "ethioaa", "ethiopic-amete-alem", "coptic", "chinese", "dangi", "roc", "indian", "buddhist", "japanese", "gregory"];
var ze = /* @__PURE__ */ new Set(["ACT", "AET", "AGT", "ART", "AST", "BET", "BST", "CAT", "CNT", "CST", "CTT", "EAT", "ECT", "IET", "IST", "JST", "MIT", "NET", "NST", "PLT", "PNT", "PRT", "PST", "SST", "VST"]);
function Ae(e2) {
  return "object" == typeof e2 && null !== e2 || "function" == typeof e2;
}
function qe(e2) {
  if ("bigint" == typeof e2) throw new TypeError("Cannot convert BigInt to number");
  return Number(e2);
}
function We(e2) {
  if ("symbol" == typeof e2) throw new TypeError("Cannot convert a Symbol value to a String");
  return String(e2);
}
function _e(e2) {
  const t2 = qe(e2);
  if (0 === t2) return 0;
  if (Number.isNaN(t2) || t2 === 1 / 0 || t2 === -1 / 0) throw new RangeError("invalid number value");
  const n2 = Math.trunc(t2);
  return 0 === n2 ? 0 : n2;
}
function Je(e2, t2) {
  const n2 = _e(e2);
  if (n2 <= 0) {
    if (void 0 !== t2) throw new RangeError(`property '${t2}' cannot be a a number less than one`);
    throw new RangeError("Cannot convert a number less than one to a positive integer");
  }
  return n2;
}
function Ge(e2) {
  const t2 = qe(e2);
  if (Number.isNaN(t2)) throw new RangeError("not a number");
  if (t2 === 1 / 0 || t2 === -1 / 0) throw new RangeError("infinity is out of range");
  if (!(function(e3) {
    if ("number" != typeof e3 || Number.isNaN(e3) || e3 === 1 / 0 || e3 === -1 / 0) return false;
    const t3 = Math.abs(e3);
    return Math.floor(t3) === t3;
  })(t2)) throw new RangeError(`unsupported fractional value ${e2}`);
  return 0 === t2 ? 0 : t2;
}
function Ke(e2, t2) {
  return String(e2).padStart(t2, "0");
}
function Ve(e2) {
  if ("string" != typeof e2) throw new TypeError(`expected a string, not ${String(e2)}`);
  return e2;
}
function Xe(e2, t2) {
  if (Ae(e2)) {
    const t3 = e2?.toString();
    if ("string" == typeof t3 || "number" == typeof t3) return t3;
    throw new TypeError("Cannot convert object to primitive value");
  }
  return e2;
}
var Qe = ["era", "eraYear", "year", "month", "monthCode", "day", "hour", "minute", "second", "millisecond", "microsecond", "nanosecond", "offset", "timeZone"];
var et = { era: We, eraYear: _e, year: _e, month: Je, monthCode: function(e2) {
  const t2 = Ve(Xe(e2));
  if (t2.length < 3 || t2.length > 4 || "M" !== t2[0] || -1 === "0123456789".indexOf(t2[1]) || -1 === "0123456789".indexOf(t2[2]) || t2[1] + t2[2] === "00" && "L" !== t2[3] || "L" !== t2[3] && void 0 !== t2[3]) throw new RangeError(`bad month code ${t2}; must match M01-M99 or M00L-M99L`);
  return t2;
}, day: Je, hour: _e, minute: _e, second: _e, millisecond: _e, microsecond: _e, nanosecond: _e, offset: function(e2) {
  const t2 = Ve(Xe(e2));
  return sr(t2), t2;
}, timeZone: Bn };
var tt = { hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 };
var nt = [["years", "year", "date"], ["months", "month", "date"], ["weeks", "week", "date"], ["days", "day", "date"], ["hours", "hour", "time"], ["minutes", "minute", "time"], ["seconds", "second", "time"], ["milliseconds", "millisecond", "time"], ["microseconds", "microsecond", "time"], ["nanoseconds", "nanosecond", "time"]];
var rt = Object.fromEntries(nt.map(((e2) => [e2[0], e2[1]])));
var ot = Object.fromEntries(nt.map((([e2, t2]) => [t2, e2])));
var it = nt.map((([, e2]) => e2));
var at = { day: Se, hour: 36e11, minute: 6e10, second: 1e9, millisecond: 1e6, microsecond: 1e3, nanosecond: 1 };
var st = ["days", "hours", "microseconds", "milliseconds", "minutes", "months", "nanoseconds", "seconds", "weeks", "years"];
var ct = Intl.DateTimeFormat;
var dt = /* @__PURE__ */ new Map();
function ht(e2) {
  const t2 = Ao(e2);
  let n2 = dt.get(t2);
  return void 0 === n2 && (n2 = new ct("en-us", { timeZone: t2, hour12: false, era: "short", year: "numeric", month: "numeric", day: "numeric", hour: "numeric", minute: "numeric", second: "numeric" }), dt.set(t2, n2)), n2;
}
function ut(e2) {
  return ne(e2, b) && !ne(e2, $, E);
}
function lt(e2) {
  return ne(e2, Y, R, j, k, N, x, L, P, U);
}
function mt(e2) {
  return ne(e2, I);
}
function ft(e2) {
  return ne(e2, M);
}
function yt(e2) {
  return ne(e2, T);
}
function pt(e2) {
  return ne(e2, C);
}
function gt(e2) {
  return ne(e2, O);
}
function wt(e2) {
  return ne(e2, b, $, E);
}
function vt(e2, t2) {
  if (!t2(e2)) throw new TypeError("invalid receiver: method called with the wrong type of this-object");
}
function bt(e2) {
  if (ne(e2, E) || ne(e2, $)) throw new TypeError("with() does not support a calendar or timeZone property");
  if (ft(e2)) throw new TypeError("with() does not accept Temporal.PlainTime, use withPlainTime() instead");
  if (void 0 !== e2.calendar) throw new TypeError("with() does not support a calendar property");
  if (void 0 !== e2.timeZone) throw new TypeError("with() does not support a timeZone property");
}
function Dt(e2, t2) {
  return "never" === t2 || "auto" === t2 && "iso8601" === e2 ? "" : `[${"critical" === t2 ? "!" : ""}u-ca=${e2}]`;
}
function Tt(e2) {
  let t2, n2, r2 = false;
  for (Te.lastIndex = 0; n2 = Te.exec(e2); ) {
    const { 1: o2, 2: i2, 3: a2 } = n2;
    if ("u-ca" === i2) {
      if (void 0 === t2) t2 = a2, r2 = "!" === o2;
      else if ("!" === o2 || r2) throw new RangeError(`Invalid annotations in ${e2}: more than one u-ca present with critical flag`);
    } else if ("!" === o2) throw new RangeError(`Unrecognized annotation: !${i2}=${a2}`);
  }
  return t2;
}
function Mt(e2) {
  const t2 = Me.exec(e2);
  if (!t2) throw new RangeError(`invalid RFC 9557 string: ${e2}`);
  const n2 = Tt(t2[16]);
  let r2 = t2[1];
  if ("-000000" === r2) throw new RangeError(`invalid RFC 9557 string: ${e2}`);
  const o2 = +r2, i2 = +(t2[2] ?? t2[4] ?? 1), a2 = +(t2[3] ?? t2[5] ?? 1), s2 = void 0 !== t2[6], c2 = +(t2[6] ?? 0), d2 = +(t2[7] ?? t2[10] ?? 0);
  let h2 = +(t2[8] ?? t2[11] ?? 0);
  60 === h2 && (h2 = 59);
  const u2 = (t2[9] ?? t2[12] ?? "") + "000000000", l2 = +u2.slice(0, 3), m2 = +u2.slice(3, 6), f2 = +u2.slice(6, 9);
  let y2, p2 = false;
  t2[13] ? (y2 = void 0, p2 = true) : t2[14] && (y2 = t2[14]);
  const g2 = t2[15];
  return Ur(o2, i2, a2, c2, d2, h2, l2, m2, f2), { year: o2, month: i2, day: a2, time: s2 ? { hour: c2, minute: d2, second: h2, millisecond: l2, microsecond: m2, nanosecond: f2 } : "start-of-day", tzAnnotation: g2, offset: y2, z: p2, calendar: n2 };
}
function Et(e2) {
  const t2 = Ee.exec(e2);
  let n2, r2, o2, i2, a2, s2, c2;
  if (t2) {
    c2 = Tt(t2[10]), n2 = +(t2[1] ?? 0), r2 = +(t2[2] ?? t2[5] ?? 0), o2 = +(t2[3] ?? t2[6] ?? 0), 60 === o2 && (o2 = 59);
    const e3 = (t2[4] ?? t2[7] ?? "") + "000000000";
    if (i2 = +e3.slice(0, 3), a2 = +e3.slice(3, 6), s2 = +e3.slice(6, 9), t2[8]) throw new RangeError("Z designator not supported for PlainTime");
  } else {
    let t3, d2;
    if ({ time: t3, z: d2, calendar: c2 } = Mt(e2), "start-of-day" === t3) throw new RangeError(`time is missing in string: ${e2}`);
    if (d2) throw new RangeError("Z designator not supported for PlainTime");
    ({ hour: n2, minute: r2, second: o2, millisecond: i2, microsecond: a2, nanosecond: s2 } = t3);
  }
  if (Pr(n2, r2, o2, i2, a2, s2), /[tT ][0-9][0-9]/.test(e2)) return { hour: n2, minute: r2, second: o2, millisecond: i2, microsecond: a2, nanosecond: s2, calendar: c2 };
  try {
    const { month: t3, day: n3 } = Ct(e2);
    xr(1972, t3, n3);
  } catch {
    try {
      const { year: t3, month: n3 } = It(e2);
      xr(t3, n3, 1);
    } catch {
      return { hour: n2, minute: r2, second: o2, millisecond: i2, microsecond: a2, nanosecond: s2, calendar: c2 };
    }
  }
  throw new RangeError(`invalid RFC 9557 time-only string ${e2}; may need a T prefix`);
}
function It(e2) {
  const t2 = Ie.exec(e2);
  let n2, r2, o2, i2;
  if (t2) {
    o2 = Tt(t2[3]);
    let a2 = t2[1];
    if ("-000000" === a2) throw new RangeError(`invalid RFC 9557 string: ${e2}`);
    if (n2 = +a2, r2 = +t2[2], i2 = 1, void 0 !== o2 && "iso8601" !== o2) throw new RangeError("YYYY-MM format is only valid with iso8601 calendar");
  } else {
    let t3;
    if ({ year: n2, month: r2, calendar: o2, day: i2, z: t3 } = Mt(e2), t3) throw new RangeError("Z designator not supported for PlainYearMonth");
  }
  return { year: n2, month: r2, calendar: o2, referenceISODay: i2 };
}
function Ct(e2) {
  const t2 = Ce.exec(e2);
  let n2, r2, o2, i2;
  if (t2) {
    if (o2 = Tt(t2[3]), n2 = +t2[1], r2 = +t2[2], void 0 !== o2 && "iso8601" !== o2) throw new RangeError("MM-DD format is only valid with iso8601 calendar");
  } else {
    let t3;
    if ({ month: n2, day: r2, calendar: o2, year: i2, z: t3 } = Mt(e2), t3) throw new RangeError("Z designator not supported for PlainMonthDay");
  }
  return { month: n2, day: r2, calendar: o2, referenceISOYear: i2 };
}
var Ot = new RegExp(`^${fe.source}$`, "i");
var $t = new RegExp(`^${/([+-])([01][0-9]|2[0-3])(?::?([0-5][0-9])?)?/.source}$`);
function Yt(e2) {
  const t2 = Wo.test(e2) ? "Seconds not allowed in offset time zone" : "Invalid time zone";
  throw new RangeError(`${t2}: ${e2}`);
}
function Rt(e2) {
  return Ot.test(e2) || Yt(e2), $t.test(e2) ? { offsetMinutes: sr(e2) / 6e10 } : { tzName: e2 };
}
function St(e2, t2, n2, r2) {
  let o2 = e2, i2 = t2, a2 = n2;
  switch (r2) {
    case "reject":
      xr(o2, i2, a2);
      break;
    case "constrain":
      ({ year: o2, month: i2, day: a2 } = kr(o2, i2, a2));
  }
  return { year: o2, month: i2, day: a2 };
}
function jt(e2, t2, n2, r2, o2, i2, a2) {
  let s2 = e2, c2 = t2, d2 = n2, h2 = r2, u2 = o2, l2 = i2;
  switch (a2) {
    case "reject":
      Pr(s2, c2, d2, h2, u2, l2);
      break;
    case "constrain":
      s2 = jr(s2, 0, 23), c2 = jr(c2, 0, 59), d2 = jr(d2, 0, 59), h2 = jr(h2, 0, 999), u2 = jr(u2, 0, 999), l2 = jr(l2, 0, 999);
  }
  return { hour: s2, minute: c2, second: d2, millisecond: h2, microsecond: u2, nanosecond: l2 };
}
function kt(e2) {
  if (!Ae(e2)) throw new TypeError("invalid duration-like");
  const t2 = { years: void 0, months: void 0, weeks: void 0, days: void 0, hours: void 0, minutes: void 0, seconds: void 0, milliseconds: void 0, microseconds: void 0, nanoseconds: void 0 };
  let n2 = false;
  for (let r2 = 0; r2 < st.length; r2++) {
    const o2 = st[r2], i2 = e2[o2];
    void 0 !== i2 && (n2 = true, t2[o2] = Ge(i2));
  }
  if (!n2) throw new TypeError("invalid duration-like");
  return t2;
}
function Nt({ years: e2, months: t2, weeks: n2, days: r2 }, o2, i2, a2) {
  return { years: e2, months: a2 ?? t2, weeks: i2 ?? n2, days: o2 ?? r2 };
}
function xt(e2, t2) {
  return { isoDate: e2, time: t2 };
}
function Lt(e2) {
  return Ho(e2, "overflow", ["constrain", "reject"], "constrain");
}
function Pt(e2) {
  return Ho(e2, "disambiguation", ["compatible", "earlier", "later", "reject"], "compatible");
}
function Ut(e2, t2) {
  return Ho(e2, "roundingMode", ["ceil", "floor", "expand", "trunc", "halfCeil", "halfFloor", "halfExpand", "halfTrunc", "halfEven"], t2);
}
function Bt(e2, t2) {
  return Ho(e2, "offset", ["prefer", "use", "ignore", "reject"], t2);
}
function Zt(e2) {
  return Ho(e2, "calendarName", ["auto", "always", "never", "critical"], "auto");
}
function Ft(e2) {
  let t2 = e2.roundingIncrement;
  if (void 0 === t2) return 1;
  const n2 = _e(t2);
  if (n2 < 1 || n2 > 1e9) throw new RangeError(`roundingIncrement must be at least 1 and at most 1e9, not ${t2}`);
  return n2;
}
function Ht(e2, t2, n2) {
  const r2 = n2 ? t2 : t2 - 1;
  if (e2 > r2) throw new RangeError(`roundingIncrement must be at least 1 and less than ${r2}, not ${e2}`);
  if (t2 % e2 != 0) throw new RangeError(`Rounding increment must divide evenly into ${t2}`);
}
function zt(e2) {
  const t2 = e2.fractionalSecondDigits;
  if (void 0 === t2) return "auto";
  if ("number" != typeof t2) {
    if ("auto" !== We(t2)) throw new RangeError(`fractionalSecondDigits must be 'auto' or 0 through 9, not ${t2}`);
    return "auto";
  }
  const n2 = Math.floor(t2);
  if (!Number.isFinite(n2) || n2 < 0 || n2 > 9) throw new RangeError(`fractionalSecondDigits must be 'auto' or 0 through 9, not ${t2}`);
  return n2;
}
function At(e2, t2) {
  switch (e2) {
    case "minute":
      return { precision: "minute", unit: "minute", increment: 1 };
    case "second":
      return { precision: 0, unit: "second", increment: 1 };
    case "millisecond":
      return { precision: 3, unit: "millisecond", increment: 1 };
    case "microsecond":
      return { precision: 6, unit: "microsecond", increment: 1 };
    case "nanosecond":
      return { precision: 9, unit: "nanosecond", increment: 1 };
  }
  switch (t2) {
    case "auto":
      return { precision: t2, unit: "nanosecond", increment: 1 };
    case 0:
      return { precision: t2, unit: "second", increment: 1 };
    case 1:
    case 2:
    case 3:
      return { precision: t2, unit: "millisecond", increment: 10 ** (3 - t2) };
    case 4:
    case 5:
    case 6:
      return { precision: t2, unit: "microsecond", increment: 10 ** (6 - t2) };
    case 7:
    case 8:
    case 9:
      return { precision: t2, unit: "nanosecond", increment: 10 ** (9 - t2) };
    default:
      throw new RangeError(`fractionalSecondDigits must be 'auto' or 0 through 9, not ${t2}`);
  }
}
var qt = /* @__PURE__ */ Symbol("~required~");
function Wt(e2, t2, n2, r2, o2 = []) {
  let i2 = [];
  for (let e3 = 0; e3 < nt.length; e3++) {
    const t3 = nt[e3], r3 = t3[1], o3 = t3[2];
    "datetime" !== n2 && n2 !== o3 || i2.push(r3);
  }
  i2 = i2.concat(o2);
  let a2 = r2;
  a2 === qt ? a2 = void 0 : void 0 !== a2 && i2.push(a2);
  let s2 = [];
  s2 = s2.concat(i2);
  for (let e3 = 0; e3 < i2.length; e3++) {
    const t3 = i2[e3], n3 = ot[t3];
    void 0 !== n3 && s2.push(n3);
  }
  let c2 = Ho(e2, t2, s2, a2);
  if (void 0 === c2 && r2 === qt) throw new RangeError(`${t2} is required`);
  return c2 && c2 in rt ? rt[c2] : c2;
}
function _t(e2) {
  const t2 = e2.relativeTo;
  if (void 0 === t2) return {};
  let n2, r2, o2, i2, a2, s2 = "option", c2 = false;
  if (Ae(t2)) {
    if (wt(t2)) return { zonedRelativeTo: t2 };
    if (mt(t2)) return { plainRelativeTo: t2 };
    if (yt(t2)) return { plainRelativeTo: pn(re(t2, T).isoDate, re(t2, E)) };
    o2 = Nn(t2);
    const e3 = tn(o2, t2, ["year", "month", "monthCode", "day"], ["hour", "minute", "second", "millisecond", "microsecond", "nanosecond", "offset", "timeZone"], []);
    ({ isoDate: n2, time: r2 } = on(o2, e3, "constrain")), { offset: a2, timeZone: i2 } = e3, void 0 === a2 && (s2 = "wall");
  } else {
    let e3, d2, h2, u2, l2;
    if ({ year: h2, month: u2, day: l2, time: r2, calendar: o2, tzAnnotation: e3, offset: a2, z: d2 } = Mt(Ve(t2)), e3) i2 = Bn(e3), d2 ? s2 = "exact" : a2 || (s2 = "wall"), c2 = true;
    else if (d2) throw new RangeError("Z designator not supported for PlainDate relativeTo; either remove the Z or add a bracketed time zone");
    o2 || (o2 = "iso8601"), o2 = zo(o2), n2 = { year: h2, month: u2, day: l2 };
  }
  return void 0 === i2 ? { plainRelativeTo: pn(n2, o2) } : { zonedRelativeTo: $n(mn(n2, r2, s2, "option" === s2 ? sr(a2) : 0, i2, "compatible", "reject", c2), i2, o2) };
}
function Jt(e2) {
  return 0 !== re(e2, Y) ? "year" : 0 !== re(e2, R) ? "month" : 0 !== re(e2, S) ? "week" : 0 !== re(e2, j) ? "day" : 0 !== re(e2, k) ? "hour" : 0 !== re(e2, N) ? "minute" : 0 !== re(e2, x) ? "second" : 0 !== re(e2, L) ? "millisecond" : 0 !== re(e2, P) ? "microsecond" : "nanosecond";
}
function Gt(e2, t2) {
  return it.indexOf(e2) > it.indexOf(t2) ? t2 : e2;
}
function Kt(e2) {
  return "year" === e2 || "month" === e2 || "week" === e2;
}
function Vt(e2) {
  return Kt(e2) || "day" === e2 ? "date" : "time";
}
function Xt(e2) {
  return ce("%calendarImpl%")(e2);
}
function Qt(e2) {
  return ce("%calendarImpl%")(re(e2, E));
}
function en(e2, t2, n2 = "date") {
  const r2 = /* @__PURE__ */ Object.create(null), o2 = Xt(e2).isoToDate(t2, { year: true, monthCode: true, day: true });
  return r2.monthCode = o2.monthCode, "month-day" !== n2 && "date" !== n2 || (r2.day = o2.day), "year-month" !== n2 && "date" !== n2 || (r2.year = o2.year), r2;
}
function tn(e2, t2, n2, r2, o2) {
  const i2 = Xt(e2).extraFields(n2), a2 = n2.concat(r2, i2), s2 = /* @__PURE__ */ Object.create(null);
  let c2 = false;
  a2.sort();
  for (let e3 = 0; e3 < a2.length; e3++) {
    const n3 = a2[e3], r3 = t2[n3];
    if (void 0 !== r3) c2 = true, s2[n3] = (0, et[n3])(r3);
    else if ("partial" !== o2) {
      if (o2.includes(n3)) throw new TypeError(`required property '${n3}' missing or undefined`);
      s2[n3] = tt[n3];
    }
  }
  if ("partial" === o2 && !c2) throw new TypeError("no supported properties found");
  return s2;
}
function nn(e2, t2 = "complete") {
  const n2 = ["hour", "microsecond", "millisecond", "minute", "nanosecond", "second"];
  let r2 = false;
  const o2 = /* @__PURE__ */ Object.create(null);
  for (let i2 = 0; i2 < n2.length; i2++) {
    const a2 = n2[i2], s2 = e2[a2];
    void 0 !== s2 ? (o2[a2] = _e(s2), r2 = true) : "complete" === t2 && (o2[a2] = 0);
  }
  if (!r2) throw new TypeError("invalid time-like");
  return o2;
}
function rn(e2, t2) {
  if (Ae(e2)) {
    if (mt(e2)) return Lt(Zo(t2)), pn(re(e2, D), re(e2, E));
    if (wt(e2)) {
      const n4 = zn(re(e2, $), re(e2, b));
      return Lt(Zo(t2)), pn(n4.isoDate, re(e2, E));
    }
    if (yt(e2)) return Lt(Zo(t2)), pn(re(e2, T).isoDate, re(e2, E));
    const n3 = Nn(e2);
    return pn(Ln(n3, tn(n3, e2, ["year", "month", "monthCode", "day"], [], []), Lt(Zo(t2))), n3);
  }
  let { year: n2, month: r2, day: o2, calendar: i2, z: a2 } = Mt(Ve(e2));
  if (a2) throw new RangeError("Z designator not supported for PlainDate");
  return i2 || (i2 = "iso8601"), i2 = zo(i2), Lt(Zo(t2)), pn({ year: n2, month: r2, day: o2 }, i2);
}
function on(e2, t2, n2) {
  return xt(Ln(e2, t2, n2), jt(t2.hour, t2.minute, t2.second, t2.millisecond, t2.microsecond, t2.nanosecond, n2));
}
function an(e2, t2) {
  let n2, r2, o2;
  if (Ae(e2)) {
    if (yt(e2)) return Lt(Zo(t2)), wn(re(e2, T), re(e2, E));
    if (wt(e2)) {
      const n3 = zn(re(e2, $), re(e2, b));
      return Lt(Zo(t2)), wn(n3, re(e2, E));
    }
    if (mt(e2)) return Lt(Zo(t2)), wn(xt(re(e2, D), { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 }), re(e2, E));
    o2 = Nn(e2);
    const i2 = tn(o2, e2, ["year", "month", "monthCode", "day"], ["hour", "minute", "second", "millisecond", "microsecond", "nanosecond"], []), a2 = Lt(Zo(t2));
    ({ isoDate: n2, time: r2 } = on(o2, i2, a2));
  } else {
    let i2, a2, s2, c2;
    if ({ year: a2, month: s2, day: c2, time: r2, calendar: o2, z: i2 } = Mt(Ve(e2)), i2) throw new RangeError("Z designator not supported for PlainDateTime");
    "start-of-day" === r2 && (r2 = { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 }), Ur(a2, s2, c2, r2.hour, r2.minute, r2.second, r2.millisecond, r2.microsecond, r2.nanosecond), o2 || (o2 = "iso8601"), o2 = zo(o2), Lt(Zo(t2)), n2 = { year: a2, month: s2, day: c2 };
  }
  return wn(xt(n2, r2), o2);
}
function sn(e2) {
  const t2 = ce("%Temporal.Duration%");
  if (lt(e2)) return new t2(re(e2, Y), re(e2, R), re(e2, S), re(e2, j), re(e2, k), re(e2, N), re(e2, x), re(e2, L), re(e2, P), re(e2, U));
  if (!Ae(e2)) return (function(e3) {
    const { years: t3, months: n3, weeks: r3, days: o2, hours: i2, minutes: a2, seconds: s2, milliseconds: c2, microseconds: d2, nanoseconds: h2 } = (function(e4) {
      const t4 = Ye.exec(e4);
      if (!t4) throw new RangeError(`invalid duration: ${e4}`);
      if (t4.every(((e5, t5) => t5 < 2 || void 0 === e5))) throw new RangeError(`invalid duration: ${e4}`);
      const n4 = "-" === t4[1] ? -1 : 1, r4 = void 0 === t4[2] ? 0 : _e(t4[2]) * n4, o3 = void 0 === t4[3] ? 0 : _e(t4[3]) * n4, i3 = void 0 === t4[4] ? 0 : _e(t4[4]) * n4, a3 = void 0 === t4[5] ? 0 : _e(t4[5]) * n4, s3 = void 0 === t4[6] ? 0 : _e(t4[6]) * n4, c3 = t4[7], d3 = t4[8], h3 = t4[9], u2 = t4[10], l2 = t4[11];
      let m2 = 0, f2 = 0, y2 = 0;
      if (void 0 !== c3) {
        if (d3 ?? h3 ?? u2 ?? l2) throw new RangeError("only the smallest unit can be fractional");
        y2 = 3600 * _e((c3 + "000000000").slice(0, 9)) * n4;
      } else if (m2 = void 0 === d3 ? 0 : _e(d3) * n4, void 0 !== h3) {
        if (u2 ?? l2) throw new RangeError("only the smallest unit can be fractional");
        y2 = 60 * _e((h3 + "000000000").slice(0, 9)) * n4;
      } else f2 = void 0 === u2 ? 0 : _e(u2) * n4, void 0 !== l2 && (y2 = _e((l2 + "000000000").slice(0, 9)) * n4);
      const p2 = y2 % 1e3, g2 = Math.trunc(y2 / 1e3) % 1e3, w2 = Math.trunc(y2 / 1e6) % 1e3;
      return f2 += Math.trunc(y2 / 1e9) % 60, m2 += Math.trunc(y2 / 6e10), zr(r4, o3, i3, a3, s3, m2, f2, w2, g2, p2), { years: r4, months: o3, weeks: i3, days: a3, hours: s3, minutes: m2, seconds: f2, milliseconds: w2, microseconds: g2, nanoseconds: p2 };
    })(e3);
    return new (ce("%Temporal.Duration%"))(t3, n3, r3, o2, i2, a2, s2, c2, d2, h2);
  })(Ve(e2));
  const n2 = { years: 0, months: 0, weeks: 0, days: 0, hours: 0, minutes: 0, seconds: 0, milliseconds: 0, microseconds: 0, nanoseconds: 0 };
  let r2 = kt(e2);
  for (let e3 = 0; e3 < st.length; e3++) {
    const t3 = st[e3], o2 = r2[t3];
    void 0 !== o2 && (n2[t3] = o2);
  }
  return new t2(n2.years, n2.months, n2.weeks, n2.days, n2.hours, n2.minutes, n2.seconds, n2.milliseconds, n2.microseconds, n2.nanoseconds);
}
function cn(e2) {
  let t2;
  if (Ae(e2)) {
    if (ut(e2) || wt(e2)) return Cn(re(e2, b));
    t2 = Xe(e2);
  } else t2 = e2;
  const { year: n2, month: r2, day: o2, time: i2, offset: a2, z: s2 } = (function(e3) {
    const t3 = Mt(e3);
    if (!t3.z && !t3.offset) throw new RangeError("Temporal.Instant requires a time zone offset");
    return t3;
  })(Ve(t2)), { hour: c2 = 0, minute: d2 = 0, second: h2 = 0, millisecond: u2 = 0, microsecond: l2 = 0, nanosecond: m2 = 0 } = "start-of-day" === i2 ? {} : i2, f2 = $r(n2, r2, o2, c2, d2, h2, u2, l2, m2 - (s2 ? 0 : sr(a2)));
  return Kr(f2.isoDate), Cn(pr(f2));
}
function dn(e2, t2) {
  if (Ae(e2)) {
    if (gt(e2)) return Lt(Zo(t2)), bn(re(e2, D), re(e2, E));
    let n3;
    return ne(e2, E) ? n3 = re(e2, E) : (n3 = e2.calendar, void 0 === n3 && (n3 = "iso8601"), n3 = kn(n3)), bn(Un(n3, tn(n3, e2, ["year", "month", "monthCode", "day"], [], []), Lt(Zo(t2))), n3);
  }
  let { month: n2, day: r2, referenceISOYear: o2, calendar: i2 } = Ct(Ve(e2));
  if (void 0 === i2 && (i2 = "iso8601"), i2 = zo(i2), Lt(Zo(t2)), "iso8601" === i2) return bn({ year: 1972, month: n2, day: r2 }, i2);
  let a2 = { year: o2, month: n2, day: r2 };
  return Lr(a2), a2 = Un(i2, en(i2, a2, "month-day"), "constrain"), bn(a2, i2);
}
function hn(e2, t2) {
  let n2;
  if (Ae(e2)) {
    if (ft(e2)) return Lt(Zo(t2)), Tn(re(e2, M));
    if (yt(e2)) return Lt(Zo(t2)), Tn(re(e2, T).time);
    if (wt(e2)) {
      const n3 = zn(re(e2, $), re(e2, b));
      return Lt(Zo(t2)), Tn(n3.time);
    }
    const { hour: r2, minute: o2, second: i2, millisecond: a2, microsecond: s2, nanosecond: c2 } = nn(e2);
    n2 = jt(r2, o2, i2, a2, s2, c2, Lt(Zo(t2)));
  } else n2 = Et(Ve(e2)), Lt(Zo(t2));
  return Tn(n2);
}
function un(e2) {
  return void 0 === e2 ? { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 } : re(hn(e2), M);
}
function ln(e2, t2) {
  if (Ae(e2)) {
    if (pt(e2)) return Lt(Zo(t2)), En(re(e2, D), re(e2, E));
    const n3 = Nn(e2);
    return En(Pn(n3, tn(n3, e2, ["year", "month", "monthCode"], [], []), Lt(Zo(t2))), n3);
  }
  let { year: n2, month: r2, referenceISODay: o2, calendar: i2 } = It(Ve(e2));
  void 0 === i2 && (i2 = "iso8601"), i2 = zo(i2), Lt(Zo(t2));
  let a2 = { year: n2, month: r2, day: o2 };
  return Hr(a2), a2 = Pn(i2, en(i2, a2, "year-month"), "constrain"), En(a2, i2);
}
function mn(t2, n2, r2, o2, i2, a2, s2, c2) {
  if ("start-of-day" === n2) return _n(i2, t2);
  const d2 = xt(t2, n2);
  if ("wall" === r2 || "ignore" === s2) return An(i2, d2, a2);
  if ("exact" === r2 || "use" === s2) {
    const e2 = $r(t2.year, t2.month, t2.day, n2.hour, n2.minute, n2.second, n2.millisecond, n2.microsecond, n2.nanosecond - o2);
    Kr(e2.isoDate);
    const r3 = pr(e2);
    return Fr(r3), r3;
  }
  Kr(t2);
  const h2 = pr(d2), u2 = Wn(i2, d2);
  for (let t3 = 0; t3 < u2.length; t3++) {
    const n3 = u2[t3], r3 = import_jsbi.default.toNumber(import_jsbi.default.subtract(h2, n3)), i3 = Eo(r3, 6e10, "halfExpand");
    if (r3 === o2 || c2 && i3 === o2) return n3;
  }
  if ("reject" === s2) {
    const e2 = Hn(o2), t3 = nr(d2, "iso8601", "auto");
    throw new RangeError(`Offset ${e2} is invalid for ${t3} in ${i2}`);
  }
  return qn(u2, i2, d2, a2);
}
function fn(e2, t2) {
  let n2, r2, o2, i2, a2, s2, c2, d2 = false, h2 = "option";
  if (Ae(e2)) {
    if (wt(e2)) {
      const n3 = Zo(t2);
      return Pt(n3), Bt(n3, "reject"), Lt(n3), $n(re(e2, b), re(e2, $), re(e2, E));
    }
    a2 = Nn(e2);
    const d3 = tn(a2, e2, ["year", "month", "monthCode", "day"], ["hour", "minute", "second", "millisecond", "microsecond", "nanosecond", "offset", "timeZone"], ["timeZone"]);
    ({ offset: i2, timeZone: o2 } = d3), void 0 === i2 && (h2 = "wall");
    const u3 = Zo(t2);
    s2 = Pt(u3), c2 = Bt(u3, "reject");
    const l2 = Lt(u3);
    ({ isoDate: n2, time: r2 } = on(a2, d3, l2));
  } else {
    let u3, l2, m2, f2, y2;
    ({ year: m2, month: f2, day: y2, time: r2, tzAnnotation: u3, offset: i2, z: l2, calendar: a2 } = (function(e3) {
      const t3 = Mt(e3);
      if (!t3.tzAnnotation) throw new RangeError("Temporal.ZonedDateTime requires a time zone ID in brackets");
      return t3;
    })(Ve(e2))), o2 = Bn(u3), l2 ? h2 = "exact" : i2 || (h2 = "wall"), a2 || (a2 = "iso8601"), a2 = zo(a2), d2 = true;
    const p2 = Zo(t2);
    s2 = Pt(p2), c2 = Bt(p2, "reject"), Lt(p2), n2 = { year: m2, month: f2, day: y2 };
  }
  let u2 = 0;
  return "option" === h2 && (u2 = sr(i2)), $n(mn(n2, r2, h2, u2, o2, s2, c2, d2), o2, a2);
}
function yn(e2, t2, n2) {
  Lr(t2), te(e2), oe(e2, D, t2), oe(e2, E, n2), oe(e2, I, true);
}
function pn(e2, t2) {
  const n2 = ce("%Temporal.PlainDate%"), r2 = Object.create(n2.prototype);
  return yn(r2, e2, t2), r2;
}
function gn(e2, t2, n2) {
  Br(t2), te(e2), oe(e2, T, t2), oe(e2, E, n2);
}
function wn(e2, t2) {
  const n2 = ce("%Temporal.PlainDateTime%"), r2 = Object.create(n2.prototype);
  return gn(r2, e2, t2), r2;
}
function vn(e2, t2, n2) {
  Lr(t2), te(e2), oe(e2, D, t2), oe(e2, E, n2), oe(e2, O, true);
}
function bn(e2, t2) {
  const n2 = ce("%Temporal.PlainMonthDay%"), r2 = Object.create(n2.prototype);
  return vn(r2, e2, t2), r2;
}
function Dn(e2, t2) {
  te(e2), oe(e2, M, t2);
}
function Tn(e2) {
  const t2 = ce("%Temporal.PlainTime%"), n2 = Object.create(t2.prototype);
  return Dn(n2, e2), n2;
}
function Mn(e2, t2, n2) {
  Hr(t2), te(e2), oe(e2, D, t2), oe(e2, E, n2), oe(e2, C, true);
}
function En(e2, t2) {
  const n2 = ce("%Temporal.PlainYearMonth%"), r2 = Object.create(n2.prototype);
  return Mn(r2, e2, t2), r2;
}
function In(e2, t2) {
  Fr(t2), te(e2), oe(e2, b, t2);
}
function Cn(e2) {
  const t2 = ce("%Temporal.Instant%"), n2 = Object.create(t2.prototype);
  return In(n2, e2), n2;
}
function On(e2, t2, n2, r2) {
  Fr(t2), te(e2), oe(e2, b, t2), oe(e2, $, n2), oe(e2, E, r2);
}
function $n(e2, t2, n2 = "iso8601") {
  const r2 = ce("%Temporal.ZonedDateTime%"), o2 = Object.create(r2.prototype);
  return On(o2, e2, t2, n2), o2;
}
function Yn(e2) {
  return Qe.filter(((t2) => void 0 !== e2[t2]));
}
function Rn(e2, t2, n2) {
  const r2 = Yn(n2), o2 = Xt(e2).fieldKeysToIgnore(r2), i2 = /* @__PURE__ */ Object.create(null), a2 = Yn(t2);
  for (let e3 = 0; e3 < Qe.length; e3++) {
    let s2;
    const c2 = Qe[e3];
    a2.includes(c2) && !o2.includes(c2) && (s2 = t2[c2]), r2.includes(c2) && (s2 = n2[c2]), void 0 !== s2 && (i2[c2] = s2);
  }
  return i2;
}
function Sn(e2, t2, n2, r2) {
  const o2 = Xt(e2).dateAdd(t2, n2, r2);
  return Lr(o2), o2;
}
function jn(e2, t2, n2, r2) {
  return Xt(e2).dateUntil(t2, n2, r2);
}
function kn(e2) {
  if (Ae(e2) && ne(e2, E)) return re(e2, E);
  const t2 = Ve(e2);
  try {
    return zo(t2);
  } catch {
  }
  let n2;
  try {
    ({ calendar: n2 } = Mt(t2));
  } catch {
    try {
      ({ calendar: n2 } = Et(t2));
    } catch {
      try {
        ({ calendar: n2 } = It(t2));
      } catch {
        ({ calendar: n2 } = Ct(t2));
      }
    }
  }
  return n2 || (n2 = "iso8601"), zo(n2);
}
function Nn(e2) {
  if (ne(e2, E)) return re(e2, E);
  const { calendar: t2 } = e2;
  return void 0 === t2 ? "iso8601" : kn(t2);
}
function xn(e2, t2) {
  return zo(e2) === zo(t2);
}
function Ln(e2, t2, n2) {
  const r2 = Xt(e2);
  r2.resolveFields(t2, "date");
  const o2 = r2.dateToISO(t2, n2);
  return Lr(o2), o2;
}
function Pn(e2, t2, n2) {
  const r2 = Xt(e2);
  r2.resolveFields(t2, "year-month"), t2.day = 1;
  const o2 = r2.dateToISO(t2, n2);
  return Hr(o2), o2;
}
function Un(e2, t2, n2) {
  const r2 = Xt(e2);
  r2.resolveFields(t2, "month-day");
  const o2 = r2.monthDayToISOReferenceDate(t2, n2);
  return Lr(o2), o2;
}
function Bn(e2) {
  if (Ae(e2) && wt(e2)) return re(e2, $);
  const t2 = Ve(e2);
  if ("UTC" === t2) return "UTC";
  const { tzName: n2, offsetMinutes: r2 } = (function(e3) {
    const { tzAnnotation: t3, offset: n3, z: r3 } = (function(e4) {
      if (Ot.test(e4)) return { tzAnnotation: e4, offset: void 0, z: false };
      try {
        const { tzAnnotation: t4, offset: n4, z: r4 } = Mt(e4);
        if (r4 || t4 || n4) return { tzAnnotation: t4, offset: n4, z: r4 };
      } catch {
      }
      Yt(e4);
    })(e3);
    return t3 ? Rt(t3) : r3 ? Rt("UTC") : n3 ? Rt(n3) : void 0;
  })(t2);
  if (void 0 !== r2) return mr(r2);
  const o2 = hr(n2);
  if (!o2) throw new RangeError(`Unrecognized time zone ${n2}`);
  return o2.identifier;
}
function Zn(e2, t2) {
  if (e2 === t2) return true;
  const n2 = Rt(e2).offsetMinutes, r2 = Rt(t2).offsetMinutes;
  if (void 0 === n2 && void 0 === r2) {
    const n3 = hr(t2);
    if (!n3) return false;
    const r3 = hr(e2);
    return !!r3 && r3.primaryIdentifier === n3.primaryIdentifier;
  }
  return n2 === r2;
}
function Fn(e2, t2) {
  const n2 = Rt(e2).offsetMinutes;
  return void 0 !== n2 ? 6e10 * n2 : lr(e2, t2);
}
function Hn(e2) {
  const t2 = e2 < 0 ? "-" : "+", n2 = Math.abs(e2), r2 = Math.floor(n2 / 36e11), o2 = Math.floor(n2 / 6e10) % 60, i2 = Math.floor(n2 / 1e9) % 60, a2 = n2 % 1e9;
  return `${t2}${Vn(r2, o2, i2, a2, 0 === i2 && 0 === a2 ? "minute" : "auto")}`;
}
function zn(e2, t2) {
  const n2 = Fn(e2, t2);
  let { isoDate: { year: r2, month: o2, day: i2 }, time: { hour: a2, minute: s2, second: c2, millisecond: d2, microsecond: h2, nanosecond: u2 } } = gr(t2);
  return $r(r2, o2, i2, a2, s2, c2, d2, h2, u2 + n2);
}
function An(e2, t2, n2) {
  return qn(Wn(e2, t2), e2, t2, n2);
}
function qn(t2, n2, r2, o2) {
  const i2 = t2.length;
  if (1 === i2) return t2[0];
  if (i2) switch (o2) {
    case "compatible":
    case "earlier":
      return t2[0];
    case "later":
      return t2[i2 - 1];
    case "reject":
      throw new RangeError("multiple instants found");
  }
  if ("reject" === o2) throw new RangeError("multiple instants found");
  const a2 = pr(r2), s2 = import_jsbi.default.subtract(a2, l);
  Fr(s2);
  const c2 = Fn(n2, s2), d2 = import_jsbi.default.add(a2, l);
  Fr(d2);
  const h2 = Fn(n2, d2) - c2;
  switch (o2) {
    case "earlier": {
      const e2 = TimeDuration.fromComponents(0, 0, 0, 0, 0, -h2), t3 = fo(r2.time, e2);
      return Wn(n2, xt(Or(r2.isoDate.year, r2.isoDate.month, r2.isoDate.day + t3.deltaDays), t3))[0];
    }
    case "compatible":
    case "later": {
      const e2 = TimeDuration.fromComponents(0, 0, 0, 0, 0, h2), t3 = fo(r2.time, e2), o3 = Wn(n2, xt(Or(r2.isoDate.year, r2.isoDate.month, r2.isoDate.day + t3.deltaDays), t3));
      return o3[o3.length - 1];
    }
  }
}
function Wn(t2, n2) {
  if ("UTC" === t2) return Kr(n2.isoDate), [pr(n2)];
  const r2 = Rt(t2).offsetMinutes;
  if (void 0 !== r2) {
    const e2 = $r(n2.isoDate.year, n2.isoDate.month, n2.isoDate.day, n2.time.hour, n2.time.minute - r2, n2.time.second, n2.time.millisecond, n2.time.microsecond, n2.time.nanosecond);
    Kr(e2.isoDate);
    const t3 = pr(e2);
    return Fr(t3), [t3];
  }
  return Kr(n2.isoDate), (function(t3, n3) {
    let r3 = pr(n3), o2 = import_jsbi.default.subtract(r3, l);
    import_jsbi.default.lessThan(o2, xe) && (o2 = r3);
    let i2 = import_jsbi.default.add(r3, l);
    import_jsbi.default.greaterThan(i2, Ne) && (i2 = r3);
    const a2 = lr(t3, o2), s2 = lr(t3, i2), c2 = (a2 === s2 ? [a2] : [a2, s2]).map(((o3) => {
      const i3 = import_jsbi.default.subtract(r3, import_jsbi.default.BigInt(o3)), a3 = (function(e2, t4) {
        const { epochMilliseconds: n4, time: { millisecond: r4, microsecond: o4, nanosecond: i4 } } = gr(t4), { year: a4, month: s3, day: c3, hour: d2, minute: h2, second: u2 } = br(e2, n4);
        return $r(a4, s3, c3, d2, h2, u2, r4, o4, i4);
      })(t3, i3);
      if (0 === jo(n3, a3)) return Fr(i3), i3;
    }));
    return c2.filter(((e2) => void 0 !== e2));
  })(t2, n2);
}
function _n(t2, n2) {
  const r2 = xt(n2, { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 }), o2 = Wn(t2, r2);
  if (o2.length) return o2[0];
  const i2 = pr(r2), a2 = import_jsbi.default.subtract(i2, l);
  return Fr(a2), wr(t2, a2);
}
function Jn(e2) {
  let t2;
  return t2 = e2 < 0 || e2 > 9999 ? (e2 < 0 ? "-" : "+") + Ke(Math.abs(e2), 6) : Ke(e2, 4), t2;
}
function Gn(e2) {
  return Ke(e2, 2);
}
function Kn(e2, t2) {
  let n2;
  if ("auto" === t2) {
    if (0 === e2) return "";
    n2 = Ke(e2, 9).replace(/0+$/, "");
  } else {
    if (0 === t2) return "";
    n2 = Ke(e2, 9).slice(0, t2);
  }
  return `.${n2}`;
}
function Vn(e2, t2, n2, r2, o2) {
  let i2 = `${Gn(e2)}:${Gn(t2)}`;
  return "minute" === o2 || (i2 += `:${Gn(n2)}`, i2 += Kn(r2, o2)), i2;
}
function Xn(e2, t2, n2) {
  let r2 = t2;
  void 0 === r2 && (r2 = "UTC");
  const o2 = re(e2, b), i2 = nr(zn(r2, o2), "iso8601", n2, "never");
  let a2 = "Z";
  return void 0 !== t2 && (a2 = fr(Fn(r2, o2))), `${i2}${a2}`;
}
function Qn(e2, t2) {
  const n2 = re(e2, Y), r2 = re(e2, R), o2 = re(e2, S), i2 = re(e2, j), a2 = re(e2, k), s2 = re(e2, N), c2 = Mr(e2);
  let d2 = "";
  0 !== n2 && (d2 += `${Math.abs(n2)}Y`), 0 !== r2 && (d2 += `${Math.abs(r2)}M`), 0 !== o2 && (d2 += `${Math.abs(o2)}W`), 0 !== i2 && (d2 += `${Math.abs(i2)}D`);
  let h2 = "";
  0 !== a2 && (h2 += `${Math.abs(a2)}H`), 0 !== s2 && (h2 += `${Math.abs(s2)}M`);
  const u2 = TimeDuration.fromComponents(0, 0, re(e2, x), re(e2, L), re(e2, P), re(e2, U));
  u2.isZero() && !["second", "millisecond", "microsecond", "nanosecond"].includes(Jt(e2)) && "auto" === t2 || (h2 += `${Math.abs(u2.sec)}${Kn(Math.abs(u2.subsec), t2)}S`);
  let l2 = `${c2 < 0 ? "-" : ""}P${d2}`;
  return h2 && (l2 = `${l2}T${h2}`), l2;
}
function er(e2, t2 = "auto") {
  const { year: n2, month: r2, day: o2 } = re(e2, D);
  return `${Jn(n2)}-${Gn(r2)}-${Gn(o2)}${Dt(re(e2, E), t2)}`;
}
function tr({ hour: e2, minute: t2, second: n2, millisecond: r2, microsecond: o2, nanosecond: i2 }, a2) {
  return Vn(e2, t2, n2, 1e6 * r2 + 1e3 * o2 + i2, a2);
}
function nr(e2, t2, n2, r2 = "auto") {
  const { isoDate: { year: o2, month: i2, day: a2 }, time: { hour: s2, minute: c2, second: d2, millisecond: h2, microsecond: u2, nanosecond: l2 } } = e2;
  return `${Jn(o2)}-${Gn(i2)}-${Gn(a2)}T${Vn(s2, c2, d2, 1e6 * h2 + 1e3 * u2 + l2, n2)}${Dt(t2, r2)}`;
}
function rr(e2, t2 = "auto") {
  const { year: n2, month: r2, day: o2 } = re(e2, D);
  let i2 = `${Gn(r2)}-${Gn(o2)}`;
  const a2 = re(e2, E);
  "always" !== t2 && "critical" !== t2 && "iso8601" === a2 || (i2 = `${Jn(n2)}-${i2}`);
  const s2 = Dt(a2, t2);
  return s2 && (i2 += s2), i2;
}
function or(e2, t2 = "auto") {
  const { year: n2, month: r2, day: o2 } = re(e2, D);
  let i2 = `${Jn(n2)}-${Gn(r2)}`;
  const a2 = re(e2, E);
  "always" !== t2 && "critical" !== t2 && "iso8601" === a2 || (i2 += `-${Gn(o2)}`);
  const s2 = Dt(a2, t2);
  return s2 && (i2 += s2), i2;
}
function ir(e2, t2, n2 = "auto", r2 = "auto", o2 = "auto", i2 = void 0) {
  let a2 = re(e2, b);
  if (i2) {
    const { unit: e3, increment: t3, roundingMode: n3 } = i2;
    a2 = Io(a2, t3, e3, n3);
  }
  const s2 = re(e2, $), c2 = Fn(s2, a2);
  let d2 = nr(zn(s2, a2), "iso8601", t2, "never");
  return "never" !== o2 && (d2 += fr(c2)), "never" !== r2 && (d2 += `[${"critical" === r2 ? "!" : ""}${s2}]`), d2 += Dt(re(e2, E), n2), d2;
}
function ar(e2) {
  return $t.test(e2);
}
function sr(e2) {
  const t2 = _o.exec(e2);
  if (!t2) throw new RangeError(`invalid time zone offset: ${e2}; must match \xB1HH:MM[:SS.SSSSSSSSS]`);
  return ("-" === t2[1] ? -1 : 1) * (1e9 * (60 * (60 * +t2[2] + +(t2[3] || 0)) + +(t2[4] || 0)) + +((t2[5] || 0) + "000000000").slice(0, 9));
}
var cr;
var dr = Object.assign(/* @__PURE__ */ Object.create(null), { "/": true, "-": true, _: true });
function hr(e2) {
  if (void 0 === cr) {
    const e3 = Intl.supportedValuesOf?.("timeZone");
    if (e3) {
      cr = /* @__PURE__ */ new Map();
      for (let t3 = 0; t3 < e3.length; t3++) {
        const n3 = e3[t3];
        cr.set(Ao(n3), n3);
      }
    } else cr = null;
  }
  const t2 = Ao(e2);
  let n2 = cr?.get(t2);
  if (n2) return { identifier: n2, primaryIdentifier: n2 };
  try {
    n2 = ht(e2).resolvedOptions().timeZone;
  } catch {
    return;
  }
  if ("antarctica/south_pole" === t2 && (n2 = "Antarctica/McMurdo"), ze.has(e2)) throw new RangeError(`${e2} is a legacy time zone identifier from ICU. Use ${n2} instead`);
  const r2 = [...t2].map(((e3, n3) => 0 === n3 || dr[t2[n3 - 1]] ? e3.toUpperCase() : e3)).join("").split("/");
  if (1 === r2.length) return "gb-eire" === t2 ? { identifier: "GB-Eire", primaryIdentifier: n2 } : { identifier: t2.length <= 3 || /[-0-9]/.test(t2) ? t2.toUpperCase() : r2[0], primaryIdentifier: n2 };
  if ("Etc" === r2[0]) return { identifier: `Etc/${["Zulu", "Greenwich", "Universal"].includes(r2[1]) ? r2[1] : r2[1].toUpperCase()}`, primaryIdentifier: n2 };
  if ("Us" === r2[0]) return { identifier: `US/${r2[1]}`, primaryIdentifier: n2 };
  const o2 = /* @__PURE__ */ new Map([["Act", "ACT"], ["Lhi", "LHI"], ["Nsw", "NSW"], ["Dar_Es_Salaam", "Dar_es_Salaam"], ["Port_Of_Spain", "Port_of_Spain"], ["Port-Au-Prince", "Port-au-Prince"], ["Isle_Of_Man", "Isle_of_Man"], ["Comodrivadavia", "ComodRivadavia"], ["Knox_In", "Knox_IN"], ["Dumontdurville", "DumontDUrville"], ["Mcmurdo", "McMurdo"], ["Denoronha", "DeNoronha"], ["Easterisland", "EasterIsland"], ["Bajanorte", "BajaNorte"], ["Bajasur", "BajaSur"]]);
  return r2[1] = o2.get(r2[1]) ?? r2[1], r2.length > 2 && (r2[2] = o2.get(r2[2]) ?? r2[2]), { identifier: r2.join("/"), primaryIdentifier: n2 };
}
function ur(e2, t2) {
  const { year: n2, month: r2, day: o2, hour: i2, minute: a2, second: s2 } = br(e2, t2);
  let c2 = t2 % 1e3;
  return c2 < 0 && (c2 += 1e3), 1e6 * (yr({ isoDate: { year: n2, month: r2, day: o2 }, time: { hour: i2, minute: a2, second: s2, millisecond: c2 } }) - t2);
}
function lr(e2, t2) {
  return ur(e2, No(t2, "floor"));
}
function mr(e2) {
  const t2 = e2 < 0 ? "-" : "+", n2 = Math.abs(e2);
  return `${t2}${Vn(Math.floor(n2 / 60), n2 % 60, 0, 0, "minute")}`;
}
function fr(e2) {
  return mr(Eo(e2, je, "halfExpand") / 6e10);
}
function yr({ isoDate: { year: e2, month: t2, day: n2 }, time: { hour: r2, minute: o2, second: i2, millisecond: a2 } }) {
  const s2 = e2 % 400, c2 = (e2 - s2) / 400, d2 = /* @__PURE__ */ new Date();
  return d2.setUTCHours(r2, o2, i2, a2), d2.setUTCFullYear(s2, t2 - 1, n2), d2.getTime() + Ue * c2;
}
function pr(t2) {
  const n2 = yr(t2), r2 = 1e3 * t2.time.microsecond + t2.time.nanosecond;
  return import_jsbi.default.add(xo(n2), import_jsbi.default.BigInt(r2));
}
function gr(t2) {
  let n2 = No(t2, "trunc"), r2 = import_jsbi.default.toNumber(import_jsbi.default.remainder(t2, c));
  r2 < 0 && (r2 += 1e6, n2 -= 1);
  const o2 = Math.floor(r2 / 1e3) % 1e3, i2 = r2 % 1e3, a2 = new Date(n2);
  return { epochMilliseconds: n2, isoDate: { year: a2.getUTCFullYear(), month: a2.getUTCMonth() + 1, day: a2.getUTCDate() }, time: { hour: a2.getUTCHours(), minute: a2.getUTCMinutes(), second: a2.getUTCSeconds(), millisecond: a2.getUTCMilliseconds(), microsecond: o2, nanosecond: i2 } };
}
function wr(e2, t2) {
  if ("UTC" === e2) return null;
  const n2 = No(t2, "floor");
  if (n2 < Fe) return wr(e2, xo(Fe));
  const r2 = Date.now(), o2 = Math.max(n2, r2) + 366 * Re * 3;
  let i2 = n2, a2 = ur(e2, i2), s2 = i2, c2 = a2;
  for (; a2 === c2 && i2 < o2; ) {
    if (s2 = i2 + 2 * Re * 7, s2 > ke) return null;
    c2 = ur(e2, s2), a2 === c2 && (i2 = s2);
  }
  return a2 === c2 ? null : xo(Jo(((t3) => ur(e2, t3)), i2, s2, a2, c2));
}
function vr(t2, n2) {
  if ("UTC" === t2) return null;
  const r2 = No(n2, "ceil"), o2 = Date.now(), i2 = o2 + 366 * Re * 3;
  if (r2 > i2) {
    const n3 = vr(t2, xo(i2));
    if (null === n3 || import_jsbi.default.lessThan(n3, xo(o2))) return n3;
  }
  if ("Africa/Casablanca" === t2 || "Africa/El_Aaiun" === t2) {
    const e2 = Date.UTC(2088, 0, 1);
    if (e2 < r2) return vr(t2, xo(e2));
  }
  let a2 = r2 - 1;
  if (a2 < Fe) return null;
  let s2 = ur(t2, a2), c2 = a2, d2 = s2;
  for (; s2 === d2 && a2 > Fe; ) {
    if (c2 = a2 - 2 * Re * 7, c2 < Fe) return null;
    d2 = ur(t2, c2), s2 === d2 && (a2 = c2);
  }
  return s2 === d2 ? null : xo(Jo(((e2) => ur(t2, e2)), c2, a2, d2, s2));
}
function br(e2, t2) {
  return (function(e3) {
    const t3 = e3.split(/[^\w]+/);
    if (7 !== t3.length) throw new RangeError(`expected 7 parts in "${e3}`);
    const n2 = +t3[0], r2 = +t3[1];
    let o2 = +t3[2];
    const i2 = t3[3];
    if ("b" === i2[0] || "B" === i2[0]) o2 = 1 - o2;
    else if ("a" !== i2[0] && "A" !== i2[0]) throw new RangeError(`Unknown era ${i2} in "${e3}`);
    const a2 = "24" === t3[4] ? 0 : +t3[4], s2 = +t3[5], c2 = +t3[6];
    if (!(Number.isFinite(o2) && Number.isFinite(n2) && Number.isFinite(r2) && Number.isFinite(a2) && Number.isFinite(s2) && Number.isFinite(c2))) throw new RangeError(`Invalid number in "${e3}`);
    return { year: o2, month: n2, day: r2, hour: a2, minute: s2, second: c2 };
  })(ht(e2).format(t2));
}
function Dr(e2) {
  return void 0 !== e2 && !(e2 % 4 != 0 || e2 % 100 == 0 && e2 % 400 != 0);
}
function Tr(e2, t2) {
  return { standard: [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], leapyear: [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31] }[Dr(e2) ? "leapyear" : "standard"][t2 - 1];
}
function Mr(e2) {
  const t2 = [re(e2, Y), re(e2, R), re(e2, S), re(e2, j), re(e2, k), re(e2, N), re(e2, x), re(e2, L), re(e2, P), re(e2, U)];
  for (let e3 = 0; e3 < t2.length; e3++) {
    const n2 = t2[e3];
    if (0 !== n2) return n2 < 0 ? -1 : 1;
  }
  return 0;
}
function Er(e2) {
  const t2 = ["years", "months", "weeks", "days"];
  for (let n2 = 0; n2 < t2.length; n2++) {
    const r2 = e2[t2[n2]];
    if (0 !== r2) return r2 < 0 ? -1 : 1;
  }
  return 0;
}
function Ir(e2) {
  const t2 = Er(e2.date);
  return 0 !== t2 ? t2 : e2.time.sign();
}
function Cr(e2, t2) {
  let n2 = e2, r2 = t2;
  if (!Number.isFinite(n2) || !Number.isFinite(r2)) throw new RangeError("infinity is out of range");
  return r2 -= 1, n2 += Math.floor(r2 / 12), r2 %= 12, r2 < 0 && (r2 += 12), r2 += 1, { year: n2, month: r2 };
}
function Or(e2, t2, n2) {
  let r2 = e2, o2 = t2, i2 = n2;
  if (!Number.isFinite(i2)) throw new RangeError("infinity is out of range");
  ({ year: r2, month: o2 } = Cr(r2, o2));
  const a2 = 146097;
  if (Math.abs(i2) > a2) {
    const e3 = Math.trunc(i2 / a2);
    r2 += 400 * e3, i2 -= e3 * a2;
  }
  let s2 = 0, c2 = o2 > 2 ? r2 : r2 - 1;
  for (; s2 = Dr(c2) ? 366 : 365, i2 < -s2; ) r2 -= 1, c2 -= 1, i2 += s2;
  for (c2 += 1; s2 = Dr(c2) ? 366 : 365, i2 > s2; ) r2 += 1, c2 += 1, i2 -= s2;
  for (; i2 < 1; ) ({ year: r2, month: o2 } = Cr(r2, o2 - 1)), i2 += Tr(r2, o2);
  for (; i2 > Tr(r2, o2); ) i2 -= Tr(r2, o2), { year: r2, month: o2 } = Cr(r2, o2 + 1);
  return { year: r2, month: o2, day: i2 };
}
function $r(e2, t2, n2, r2, o2, i2, a2, s2, c2) {
  const d2 = Yr(r2, o2, i2, a2, s2, c2);
  return xt(Or(e2, t2, n2 + d2.deltaDays), d2);
}
function Yr(e2, t2, n2, r2, o2, i2) {
  let a2, s2 = e2, c2 = t2, d2 = n2, h2 = r2, u2 = o2, l2 = i2;
  ({ div: a2, mod: l2 } = de(l2, 3)), u2 += a2, l2 < 0 && (u2 -= 1, l2 += 1e3), { div: a2, mod: u2 } = de(u2, 3), h2 += a2, u2 < 0 && (h2 -= 1, u2 += 1e3), d2 += Math.trunc(h2 / 1e3), h2 %= 1e3, h2 < 0 && (d2 -= 1, h2 += 1e3), c2 += Math.trunc(d2 / 60), d2 %= 60, d2 < 0 && (c2 -= 1, d2 += 60), s2 += Math.trunc(c2 / 60), c2 %= 60, c2 < 0 && (s2 -= 1, c2 += 60);
  let m2 = Math.trunc(s2 / 24);
  return s2 %= 24, s2 < 0 && (m2 -= 1, s2 += 24), m2 += 0, s2 += 0, c2 += 0, d2 += 0, h2 += 0, u2 += 0, l2 += 0, { deltaDays: m2, hour: s2, minute: c2, second: d2, millisecond: h2, microsecond: u2, nanosecond: l2 };
}
function Rr(e2, t2) {
  const n2 = Nt(e2, 0);
  if (0 === Er(n2)) return e2.days;
  const r2 = re(t2, D), o2 = Sn(re(t2, E), r2, n2, "constrain"), i2 = Gr(r2.year, r2.month - 1, r2.day), a2 = Gr(o2.year, o2.month - 1, o2.day) - i2;
  return e2.days + a2;
}
function Sr(e2) {
  return new (ce("%Temporal.Duration%"))(-re(e2, Y), -re(e2, R), -re(e2, S), -re(e2, j), -re(e2, k), -re(e2, N), -re(e2, x), -re(e2, L), -re(e2, P), -re(e2, U));
}
function jr(e2, t2, n2) {
  return Math.min(n2, Math.max(t2, e2));
}
function kr(e2, t2, n2) {
  const r2 = jr(t2, 1, 12);
  return { year: e2, month: r2, day: jr(n2, 1, Tr(e2, r2)) };
}
function Nr(e2, t2, n2) {
  if (e2 < t2 || e2 > n2) throw new RangeError(`value out of range: ${t2} <= ${e2} <= ${n2}`);
}
function xr(e2, t2, n2) {
  Nr(t2, 1, 12), Nr(n2, 1, Tr(e2, t2));
}
function Lr(e2) {
  Br(xt(e2, { deltaDays: 0, hour: 12, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 }));
}
function Pr(e2, t2, n2, r2, o2, i2) {
  Nr(e2, 0, 23), Nr(t2, 0, 59), Nr(n2, 0, 59), Nr(r2, 0, 999), Nr(o2, 0, 999), Nr(i2, 0, 999);
}
function Ur(e2, t2, n2, r2, o2, i2, a2, s2, c2) {
  xr(e2, t2, n2), Pr(r2, o2, i2, a2, s2, c2);
}
function Br(t2) {
  const n2 = pr(t2);
  (import_jsbi.default.lessThan(n2, Le) || import_jsbi.default.greaterThan(n2, Pe)) && Fr(n2);
}
function Zr(e2) {
  pr(e2);
}
function Fr(t2) {
  if (import_jsbi.default.lessThan(t2, xe) || import_jsbi.default.greaterThan(t2, Ne)) throw new RangeError("date/time value is outside of supported range");
}
function Hr({ year: e2, month: t2 }) {
  Nr(e2, Be, Ze), e2 === Be ? Nr(t2, 4, 12) : e2 === Ze && Nr(t2, 1, 9);
}
function zr(e2, t2, n2, r2, o2, i2, a2, s2, c2, d2) {
  let h2 = 0;
  const u2 = [e2, t2, n2, r2, o2, i2, a2, s2, c2, d2];
  for (let e3 = 0; e3 < u2.length; e3++) {
    const t3 = u2[e3];
    if (t3 === 1 / 0 || t3 === -1 / 0) throw new RangeError("infinite values not allowed as duration fields");
    if (0 !== t3) {
      const e4 = t3 < 0 ? -1 : 1;
      if (0 !== h2 && e4 !== h2) throw new RangeError("mixed-sign values not allowed as duration fields");
      h2 = e4;
    }
  }
  if (Math.abs(e2) >= 2 ** 32 || Math.abs(t2) >= 2 ** 32 || Math.abs(n2) >= 2 ** 32) throw new RangeError("years, months, and weeks must be < 2\xB3\xB2");
  const l2 = de(s2, 3), m2 = de(c2, 6), f2 = de(d2, 9), y2 = de(1e6 * l2.mod + 1e3 * m2.mod + f2.mod, 9).div, p2 = 86400 * r2 + 3600 * o2 + 60 * i2 + a2 + l2.div + m2.div + f2.div + y2;
  if (!Number.isSafeInteger(p2)) throw new RangeError("total of duration time units cannot exceed 9007199254740991.999999999 s");
}
function Ar(e2) {
  return { date: { years: re(e2, Y), months: re(e2, R), weeks: re(e2, S), days: re(e2, j) }, time: TimeDuration.fromComponents(re(e2, k), re(e2, N), re(e2, x), re(e2, L), re(e2, P), re(e2, U)) };
}
function qr(e2) {
  const t2 = TimeDuration.fromComponents(re(e2, k), re(e2, N), re(e2, x), re(e2, L), re(e2, P), re(e2, U)).add24HourDays(re(e2, j));
  return { date: { years: re(e2, Y), months: re(e2, R), weeks: re(e2, S), days: 0 }, time: t2 };
}
function Wr(e2) {
  const t2 = qr(e2), n2 = Math.trunc(t2.time.sec / 86400);
  return zr(t2.date.years, t2.date.months, t2.date.weeks, n2, 0, 0, 0, 0, 0, 0), { ...t2.date, days: n2 };
}
function _r(e2, t2) {
  const n2 = e2.time.sign();
  let r2 = e2.time.abs().subsec, o2 = 0, i2 = 0, a2 = e2.time.abs().sec, s2 = 0, c2 = 0, d2 = 0;
  switch (t2) {
    case "year":
    case "month":
    case "week":
    case "day":
      o2 = Math.trunc(r2 / 1e3), r2 %= 1e3, i2 = Math.trunc(o2 / 1e3), o2 %= 1e3, a2 += Math.trunc(i2 / 1e3), i2 %= 1e3, s2 = Math.trunc(a2 / 60), a2 %= 60, c2 = Math.trunc(s2 / 60), s2 %= 60, d2 = Math.trunc(c2 / 24), c2 %= 24;
      break;
    case "hour":
      o2 = Math.trunc(r2 / 1e3), r2 %= 1e3, i2 = Math.trunc(o2 / 1e3), o2 %= 1e3, a2 += Math.trunc(i2 / 1e3), i2 %= 1e3, s2 = Math.trunc(a2 / 60), a2 %= 60, c2 = Math.trunc(s2 / 60), s2 %= 60;
      break;
    case "minute":
      o2 = Math.trunc(r2 / 1e3), r2 %= 1e3, i2 = Math.trunc(o2 / 1e3), o2 %= 1e3, a2 += Math.trunc(i2 / 1e3), i2 %= 1e3, s2 = Math.trunc(a2 / 60), a2 %= 60;
      break;
    case "second":
      o2 = Math.trunc(r2 / 1e3), r2 %= 1e3, i2 = Math.trunc(o2 / 1e3), o2 %= 1e3, a2 += Math.trunc(i2 / 1e3), i2 %= 1e3;
      break;
    case "millisecond":
      o2 = Math.trunc(r2 / 1e3), r2 %= 1e3, i2 = he(a2, 3, Math.trunc(o2 / 1e3)), o2 %= 1e3, a2 = 0;
      break;
    case "microsecond":
      o2 = he(a2, 6, Math.trunc(r2 / 1e3)), r2 %= 1e3, a2 = 0;
      break;
    case "nanosecond":
      r2 = he(a2, 9, r2), a2 = 0;
  }
  return new (ce("%Temporal.Duration%"))(e2.date.years, e2.date.months, e2.date.weeks, e2.date.days + n2 * d2, n2 * c2, n2 * s2, n2 * a2, n2 * i2, n2 * o2, n2 * r2);
}
function Jr(e2, t2) {
  return Er(e2), t2.sign(), { date: e2, time: t2 };
}
function Gr(e2, t2, n2) {
  return yr({ isoDate: { year: e2, month: t2 + 1, day: n2 }, time: { hour: 0, minute: 0, second: 0, millisecond: 0 } }) / Re;
}
function Kr({ year: e2, month: t2, day: n2 }) {
  if (Math.abs(Gr(e2, t2 - 1, n2)) > 1e8) throw new RangeError("date/time value is outside the supported range");
}
function Vr(e2, t2) {
  const n2 = t2.hour - e2.hour, r2 = t2.minute - e2.minute, o2 = t2.second - e2.second, i2 = t2.millisecond - e2.millisecond, a2 = t2.microsecond - e2.microsecond, s2 = t2.nanosecond - e2.nanosecond;
  return TimeDuration.fromComponents(n2, r2, o2, i2, a2, s2);
}
function Xr(e2, t2, n2, r2, o2) {
  let i2 = TimeDuration.fromEpochNsDiff(t2, e2);
  return i2 = $o(i2, n2, r2, o2), Jr({ years: 0, months: 0, weeks: 0, days: 0 }, i2);
}
function Qr(e2, t2, n2, r2) {
  Zr(e2), Zr(t2);
  let o2 = Vr(e2.time, t2.time);
  const i2 = o2.sign(), a2 = Ro(e2.isoDate, t2.isoDate);
  let s2 = t2.isoDate;
  a2 === i2 && (s2 = Or(s2.year, s2.month, s2.day + i2), o2 = o2.add24HourDays(-i2));
  const c2 = Gt("day", r2), d2 = jn(n2, e2.isoDate, s2, c2);
  return r2 !== c2 && (o2 = o2.add24HourDays(d2.days), d2.days = 0), Jr(d2, o2);
}
function eo(n2, r2, o2, i2, a2) {
  const s2 = import_jsbi.default.subtract(r2, n2);
  if (import_jsbi.default.equal(s2, t)) return { date: { years: 0, months: 0, weeks: 0, days: 0 }, time: TimeDuration.ZERO };
  const c2 = import_jsbi.default.lessThan(s2, t) ? -1 : 1, d2 = zn(o2, n2), h2 = zn(o2, r2);
  let u2, l2 = 0, m2 = 1 === c2 ? 2 : 1, f2 = Vr(d2.time, h2.time);
  for (f2.sign() === -c2 && l2++; l2 <= m2; l2++) {
    u2 = xt(Or(h2.isoDate.year, h2.isoDate.month, h2.isoDate.day - l2 * c2), d2.time);
    const e2 = An(o2, u2, "compatible");
    if (f2 = TimeDuration.fromEpochNsDiff(r2, e2), f2.sign() !== -c2) break;
  }
  const y2 = Gt("day", a2);
  return Jr(jn(i2, d2.isoDate, u2.isoDate, y2), f2);
}
function to(t2, n2, r2, o2, i2, a2, s2, c2, d2) {
  let h2, u2, l2, m2, f2 = n2;
  switch (c2) {
    case "year": {
      const e2 = Eo(f2.date.years, s2, "trunc");
      h2 = e2, u2 = e2 + s2 * t2, l2 = { years: h2, months: 0, weeks: 0, days: 0 }, m2 = { ...l2, years: u2 };
      break;
    }
    case "month": {
      const e2 = Eo(f2.date.months, s2, "trunc");
      h2 = e2, u2 = e2 + s2 * t2, l2 = Nt(f2.date, 0, 0, h2), m2 = Nt(f2.date, 0, 0, u2);
      break;
    }
    case "week": {
      const e2 = Nt(f2.date, 0, 0), n3 = Sn(a2, o2.isoDate, e2, "constrain"), r3 = jn(a2, n3, Or(n3.year, n3.month, n3.day + f2.date.days), "week"), i3 = Eo(f2.date.weeks + r3.weeks, s2, "trunc");
      h2 = i3, u2 = i3 + s2 * t2, l2 = Nt(f2.date, 0, h2), m2 = Nt(f2.date, 0, u2);
      break;
    }
    case "day": {
      const e2 = Eo(f2.date.days, s2, "trunc");
      h2 = e2, u2 = e2 + s2 * t2, l2 = Nt(f2.date, h2), m2 = Nt(f2.date, u2);
      break;
    }
  }
  const y2 = Sn(a2, o2.isoDate, l2, "constrain"), p2 = Sn(a2, o2.isoDate, m2, "constrain");
  let g2, w2;
  const v2 = xt(y2, o2.time), b2 = xt(p2, o2.time);
  i2 ? (g2 = An(i2, v2, "compatible"), w2 = An(i2, b2, "compatible")) : (g2 = pr(v2), w2 = pr(b2));
  const D2 = TimeDuration.fromEpochNsDiff(r2, g2), T2 = TimeDuration.fromEpochNsDiff(w2, g2), M2 = ue(d2, t2 < 0 ? "negative" : "positive"), E2 = D2.add(D2).abs().subtract(T2.abs()).sign(), I2 = Math.abs(h2) / s2 % 2 == 0, C2 = D2.isZero() ? Math.abs(h2) : D2.cmp(T2) ? le(Math.abs(h2), Math.abs(u2), E2, I2, M2) : Math.abs(u2), O2 = new TimeDuration(import_jsbi.default.add(import_jsbi.default.multiply(T2.totalNs, import_jsbi.default.BigInt(h2)), import_jsbi.default.multiply(D2.totalNs, import_jsbi.default.BigInt(s2 * t2)))).fdiv(T2.totalNs), $2 = C2 === Math.abs(u2);
  return f2 = { date: $2 ? m2 : l2, time: TimeDuration.ZERO }, { nudgeResult: { duration: f2, nudgedEpochNs: $2 ? w2 : g2, didExpandCalendarUnit: $2 }, total: O2 };
}
function no(t2, n2, r2, o2, i2, a2, s2, c2, d2) {
  let h2 = t2;
  const u2 = Kt(c2) || o2 && "day" === c2, l2 = Ir(h2) < 0 ? -1 : 1;
  let m2;
  return u2 ? { nudgeResult: m2 } = to(l2, h2, n2, r2, o2, i2, s2, c2, d2) : m2 = o2 ? (function(t3, n3, r3, o3, i3, a3, s3, c3) {
    let d3 = n3;
    const h3 = Sn(i3, r3.isoDate, d3.date, "constrain"), u3 = xt(h3, r3.time), l3 = xt(Or(h3.year, h3.month, h3.day + t3), r3.time), m3 = An(o3, u3, "compatible"), f2 = An(o3, l3, "compatible"), y2 = TimeDuration.fromEpochNsDiff(f2, m3);
    if (y2.sign() !== t3) throw new RangeError("time zone returned inconsistent Instants");
    const p2 = import_jsbi.default.BigInt(at[s3] * a3);
    let g2 = d3.time.round(p2, c3);
    const w2 = g2.subtract(y2), v2 = w2.sign() !== -t3;
    let b2, D2;
    return v2 ? (b2 = t3, g2 = w2.round(p2, c3), D2 = g2.addToEpochNs(f2)) : (b2 = 0, D2 = g2.addToEpochNs(m3)), { duration: Jr(Nt(d3.date, d3.date.days + b2), g2), nudgedEpochNs: D2, didExpandCalendarUnit: v2 };
  })(l2, h2, r2, o2, i2, s2, c2, d2) : (function(t3, n3, r3, o3, i3, a3) {
    let s3 = t3;
    const c3 = s3.time.add24HourDays(s3.date.days), d3 = c3.round(import_jsbi.default.BigInt(o3 * at[i3]), a3), h3 = d3.subtract(c3), { quotient: u3 } = c3.divmod(Se), { quotient: l3 } = d3.divmod(Se), m3 = Math.sign(l3 - u3) === c3.sign(), f2 = h3.addToEpochNs(n3);
    let y2 = 0, p2 = d3;
    return "date" === Vt(r3) && (y2 = l3, p2 = d3.add(TimeDuration.fromComponents(24 * -l3, 0, 0, 0, 0, 0))), { duration: { date: Nt(s3.date, y2), time: p2 }, nudgedEpochNs: f2, didExpandCalendarUnit: m3 };
  })(h2, n2, a2, s2, c2, d2), h2 = m2.duration, m2.didExpandCalendarUnit && "week" !== c2 && (h2 = (function(e2, t3, n3, r3, o3, i3, a3, s3) {
    let c3 = t3;
    if (s3 === a3) return c3;
    const d3 = it.indexOf(a3);
    for (let t4 = it.indexOf(s3) - 1; t4 >= d3; t4--) {
      const s4 = it[t4];
      if ("week" === s4 && "week" !== a3) continue;
      let d4;
      switch (s4) {
        case "year":
          d4 = { years: c3.date.years + e2, months: 0, weeks: 0, days: 0 };
          break;
        case "month": {
          const t5 = c3.date.months + e2;
          d4 = Nt(c3.date, 0, 0, t5);
          break;
        }
        case "week": {
          const t5 = c3.date.weeks + e2;
          d4 = Nt(c3.date, 0, t5);
          break;
        }
      }
      const h3 = xt(Sn(i3, r3.isoDate, d4, "constrain"), r3.time);
      let u3;
      if (u3 = o3 ? An(o3, h3, "compatible") : pr(h3), p(n3, u3) === -e2) break;
      c3 = { date: d4, time: TimeDuration.ZERO };
    }
    return c3;
  })(l2, h2, m2.nudgedEpochNs, r2, o2, i2, a2, Gt(c2, "day"))), h2;
}
function ro(e2, t2, n2, r2, o2, i2) {
  return Kt(i2) || r2 && "day" === i2 ? to(Ir(e2) < 0 ? -1 : 1, e2, t2, n2, r2, o2, 1, i2, "trunc").total : Yo(e2.time.add24HourDays(e2.date.days), i2);
}
function oo(e2, t2, n2, r2, o2, i2, a2) {
  if (0 == jo(e2, t2)) return { date: { years: 0, months: 0, weeks: 0, days: 0 }, time: TimeDuration.ZERO };
  Br(e2), Br(t2);
  const s2 = Qr(e2, t2, n2, r2);
  return "nanosecond" === i2 && 1 === o2 ? s2 : no(s2, pr(t2), e2, null, n2, r2, o2, i2, a2);
}
function io(e2, t2, n2, r2, o2, i2, a2, s2) {
  if ("time" === Vt(o2)) return Xr(e2, t2, i2, a2, s2);
  const c2 = eo(e2, t2, n2, r2, o2);
  return "nanosecond" === a2 && 1 === i2 ? c2 : no(c2, t2, zn(n2, e2), n2, r2, o2, i2, a2, s2);
}
function ao(e2, t2, n2, r2, o2, i2) {
  const a2 = nt.reduce(((e3, t3) => {
    const o3 = t3[0], i3 = t3[1], a3 = t3[2];
    return "datetime" !== n2 && a3 !== n2 || r2.includes(i3) || e3.push(i3, o3), e3;
  }), []);
  let s2 = Wt(t2, "largestUnit", n2, "auto");
  if (r2.includes(s2)) throw new RangeError(`largestUnit must be one of ${a2.join(", ")}, not ${s2}`);
  const c2 = Ft(t2);
  let d2 = Ut(t2, "trunc");
  "since" === e2 && (d2 = (function(e3) {
    switch (e3) {
      case "ceil":
        return "floor";
      case "floor":
        return "ceil";
      case "halfCeil":
        return "halfFloor";
      case "halfFloor":
        return "halfCeil";
      default:
        return e3;
    }
  })(d2));
  const h2 = Wt(t2, "smallestUnit", n2, o2);
  if (r2.includes(h2)) throw new RangeError(`smallestUnit must be one of ${a2.join(", ")}, not ${h2}`);
  const u2 = Gt(i2, h2);
  if ("auto" === s2 && (s2 = u2), Gt(s2, h2) !== s2) throw new RangeError(`largestUnit ${s2} cannot be smaller than smallestUnit ${h2}`);
  const l2 = { hour: 24, minute: 60, second: 60, millisecond: 1e3, microsecond: 1e3, nanosecond: 1e3 }[h2];
  return void 0 !== l2 && Ht(c2, l2, false), { largestUnit: s2, roundingIncrement: c2, roundingMode: d2, smallestUnit: h2 };
}
function so(e2, t2, n2, r2) {
  const o2 = cn(n2), i2 = ao(e2, Zo(r2), "time", [], "nanosecond", "second");
  let a2 = _r(Xr(re(t2, b), re(o2, b), i2.roundingIncrement, i2.smallestUnit, i2.roundingMode), i2.largestUnit);
  return "since" === e2 && (a2 = Sr(a2)), a2;
}
function co(e2, t2, n2, r2) {
  const o2 = rn(n2), i2 = re(t2, E), a2 = re(o2, E);
  if (!xn(i2, a2)) throw new RangeError(`cannot compute difference between dates of ${i2} and ${a2} calendars`);
  const s2 = ao(e2, Zo(r2), "date", [], "day", "day"), c2 = ce("%Temporal.Duration%"), d2 = re(t2, D), h2 = re(o2, D);
  if (0 === Ro(d2, h2)) return new c2();
  let u2 = { date: jn(i2, d2, h2, s2.largestUnit), time: TimeDuration.ZERO };
  if ("day" !== s2.smallestUnit || 1 !== s2.roundingIncrement) {
    const e3 = xt(d2, { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 });
    u2 = no(u2, pr(xt(h2, { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 })), e3, null, i2, s2.largestUnit, s2.roundingIncrement, s2.smallestUnit, s2.roundingMode);
  }
  let l2 = _r(u2, "day");
  return "since" === e2 && (l2 = Sr(l2)), l2;
}
function ho(e2, t2, n2, r2) {
  const o2 = an(n2), i2 = re(t2, E), a2 = re(o2, E);
  if (!xn(i2, a2)) throw new RangeError(`cannot compute difference between dates of ${i2} and ${a2} calendars`);
  const s2 = ao(e2, Zo(r2), "datetime", [], "nanosecond", "day"), c2 = ce("%Temporal.Duration%"), d2 = re(t2, T), h2 = re(o2, T);
  if (0 === jo(d2, h2)) return new c2();
  let u2 = _r(oo(d2, h2, i2, s2.largestUnit, s2.roundingIncrement, s2.smallestUnit, s2.roundingMode), s2.largestUnit);
  return "since" === e2 && (u2 = Sr(u2)), u2;
}
function uo(e2, t2, n2, r2) {
  const o2 = hn(n2), i2 = ao(e2, Zo(r2), "time", [], "nanosecond", "hour");
  let a2 = Vr(re(t2, M), re(o2, M));
  a2 = $o(a2, i2.roundingIncrement, i2.smallestUnit, i2.roundingMode);
  let s2 = _r(Jr({ years: 0, months: 0, weeks: 0, days: 0 }, a2), i2.largestUnit);
  return "since" === e2 && (s2 = Sr(s2)), s2;
}
function lo(e2, t2, n2, r2) {
  const o2 = ln(n2), i2 = re(t2, E), a2 = re(o2, E);
  if (!xn(i2, a2)) throw new RangeError(`cannot compute difference between months of ${i2} and ${a2} calendars`);
  const s2 = ao(e2, Zo(r2), "date", ["week", "day"], "month", "year"), c2 = ce("%Temporal.Duration%");
  if (0 == Ro(re(t2, D), re(o2, D))) return new c2();
  const d2 = en(i2, re(t2, D), "year-month");
  d2.day = 1;
  const h2 = Ln(i2, d2, "constrain"), u2 = en(i2, re(o2, D), "year-month");
  u2.day = 1;
  const l2 = Ln(i2, u2, "constrain");
  let m2 = { date: Nt(jn(i2, h2, l2, s2.largestUnit), 0, 0), time: TimeDuration.ZERO };
  if ("month" !== s2.smallestUnit || 1 !== s2.roundingIncrement) {
    const e3 = xt(h2, { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 });
    m2 = no(m2, pr(xt(l2, { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 })), e3, null, i2, s2.largestUnit, s2.roundingIncrement, s2.smallestUnit, s2.roundingMode);
  }
  let f2 = _r(m2, "day");
  return "since" === e2 && (f2 = Sr(f2)), f2;
}
function mo(t2, n2, r2, o2) {
  const i2 = fn(r2), a2 = re(n2, E), s2 = re(i2, E);
  if (!xn(a2, s2)) throw new RangeError(`cannot compute difference between dates of ${a2} and ${s2} calendars`);
  const c2 = ao(t2, Zo(o2), "datetime", [], "nanosecond", "hour"), d2 = re(n2, b), h2 = re(i2, b), u2 = ce("%Temporal.Duration%");
  let l2;
  if ("date" !== Vt(c2.largestUnit)) l2 = _r(Xr(d2, h2, c2.roundingIncrement, c2.smallestUnit, c2.roundingMode), c2.largestUnit);
  else {
    const t3 = re(n2, $);
    if (!Zn(t3, re(i2, $))) throw new RangeError("When calculating difference between time zones, largestUnit must be 'hours' or smaller because day lengths can vary between time zones due to DST or time zone offset changes.");
    if (import_jsbi.default.equal(d2, h2)) return new u2();
    l2 = _r(io(d2, h2, t3, a2, c2.largestUnit, c2.roundingIncrement, c2.smallestUnit, c2.roundingMode), "hour");
  }
  return "since" === t2 && (l2 = Sr(l2)), l2;
}
function fo({ hour: e2, minute: t2, second: n2, millisecond: r2, microsecond: o2, nanosecond: i2 }, a2) {
  let s2 = n2, c2 = i2;
  return s2 += a2.sec, c2 += a2.subsec, Yr(e2, t2, s2, r2, o2, c2);
}
function yo(e2, t2) {
  const n2 = t2.addToEpochNs(e2);
  return Fr(n2), n2;
}
function po(e2, t2, n2, r2, o2 = "constrain") {
  if (0 === Er(r2.date)) return yo(e2, r2.time);
  const i2 = zn(t2, e2);
  return yo(An(t2, xt(Sn(n2, i2.isoDate, r2.date, o2), i2.time), "compatible"), r2.time);
}
function go(e2, t2, n2) {
  let r2 = sn(n2);
  "subtract" === e2 && (r2 = Sr(r2));
  const o2 = Gt(Jt(t2), Jt(r2));
  if (Kt(o2)) throw new RangeError("For years, months, or weeks arithmetic, use date arithmetic relative to a starting point");
  const i2 = qr(t2), a2 = qr(r2);
  return _r(Jr({ years: 0, months: 0, weeks: 0, days: 0 }, i2.time.add(a2.time)), o2);
}
function wo(e2, t2, n2) {
  let r2 = sn(n2);
  "subtract" === e2 && (r2 = Sr(r2));
  const o2 = Jt(r2);
  if ("date" === Vt(o2)) throw new RangeError(`Duration field ${o2} not supported by Temporal.Instant. Try Temporal.ZonedDateTime instead.`);
  const i2 = qr(r2);
  return Cn(yo(re(t2, b), i2.time));
}
function vo(e2, t2, n2, r2) {
  const o2 = re(t2, E);
  let i2 = sn(n2);
  "subtract" === e2 && (i2 = Sr(i2));
  const a2 = Wr(i2), s2 = Lt(Zo(r2));
  return pn(Sn(o2, re(t2, D), a2, s2), o2);
}
function bo(e2, t2, n2, r2) {
  let o2 = sn(n2);
  "subtract" === e2 && (o2 = Sr(o2));
  const i2 = Lt(Zo(r2)), a2 = re(t2, E), s2 = qr(o2), c2 = re(t2, T), d2 = fo(c2.time, s2.time), h2 = Nt(s2.date, d2.deltaDays);
  return zr(h2.years, h2.months, h2.weeks, h2.days, 0, 0, 0, 0, 0, 0), wn(xt(Sn(a2, c2.isoDate, h2, i2), d2), a2);
}
function Do(e2, t2, n2) {
  let r2 = sn(n2);
  "subtract" === e2 && (r2 = Sr(r2));
  const o2 = qr(r2), { hour: i2, minute: a2, second: s2, millisecond: c2, microsecond: d2, nanosecond: h2 } = fo(re(t2, M), o2.time);
  return Tn(jt(i2, a2, s2, c2, d2, h2, "reject"));
}
function To(e2, t2, n2, r2) {
  let o2 = sn(n2);
  "subtract" === e2 && (o2 = Sr(o2));
  const i2 = Lt(Zo(r2)), a2 = Mr(o2), s2 = re(t2, E), c2 = en(s2, re(t2, D), "year-month");
  c2.day = 1;
  let d2 = Ln(s2, c2, "constrain");
  if (a2 < 0) {
    const e3 = Sn(s2, d2, { months: 1 }, "constrain");
    d2 = Or(e3.year, e3.month, e3.day - 1);
  }
  const h2 = Wr(o2);
  return Lr(d2), En(Pn(s2, en(s2, Sn(s2, d2, h2, i2), "year-month"), i2), s2);
}
function Mo(e2, t2, n2, r2) {
  let o2 = sn(n2);
  "subtract" === e2 && (o2 = Sr(o2));
  const i2 = Lt(Zo(r2)), a2 = re(t2, $), s2 = re(t2, E), c2 = Ar(o2);
  return $n(po(re(t2, b), a2, s2, c2, i2), a2, s2);
}
function Eo(e2, t2, n2) {
  const r2 = Math.trunc(e2 / t2), o2 = e2 % t2, i2 = e2 < 0 ? "negative" : "positive", a2 = Math.abs(r2), s2 = a2 + 1, c2 = Bo(Math.abs(2 * o2) - t2), d2 = a2 % 2 == 0, h2 = ue(n2, i2), u2 = 0 === o2 ? a2 : le(a2, s2, c2, d2, h2);
  return t2 * ("positive" === i2 ? u2 : -u2);
}
function Io(o2, i2, a2, s2) {
  const c2 = at[a2] * i2;
  return (function(o3, i3, a3) {
    const s3 = m(o3), c3 = m(i3), d2 = import_jsbi.default.divide(s3, c3), h2 = import_jsbi.default.remainder(s3, c3), u2 = ue(a3, "positive");
    let l2, g2;
    import_jsbi.default.lessThan(s3, t) ? (l2 = import_jsbi.default.subtract(d2, n), g2 = d2) : (l2 = d2, g2 = import_jsbi.default.add(d2, n));
    const w2 = p(y(import_jsbi.default.multiply(h2, r)), c3) * (import_jsbi.default.lessThan(s3, t) ? -1 : 1) + 0, v2 = import_jsbi.default.equal(h2, t) ? d2 : le(l2, g2, w2, f(l2), u2);
    return import_jsbi.default.multiply(v2, c3);
  })(o2, import_jsbi.default.BigInt(c2), s2);
}
function Co(e2, t2, n2, r2) {
  Zr(e2);
  const { year: o2, month: i2, day: a2 } = e2.isoDate, s2 = Oo(e2.time, t2, n2, r2);
  return xt(Or(o2, i2, a2 + s2.deltaDays), s2);
}
function Oo({ hour: e2, minute: t2, second: n2, millisecond: r2, microsecond: o2, nanosecond: i2 }, a2, s2, c2) {
  let d2;
  switch (s2) {
    case "day":
    case "hour":
      d2 = 1e3 * (1e3 * (1e3 * (60 * (60 * e2 + t2) + n2) + r2) + o2) + i2;
      break;
    case "minute":
      d2 = 1e3 * (1e3 * (1e3 * (60 * t2 + n2) + r2) + o2) + i2;
      break;
    case "second":
      d2 = 1e3 * (1e3 * (1e3 * n2 + r2) + o2) + i2;
      break;
    case "millisecond":
      d2 = 1e3 * (1e3 * r2 + o2) + i2;
      break;
    case "microsecond":
      d2 = 1e3 * o2 + i2;
      break;
    case "nanosecond":
      d2 = i2;
  }
  const h2 = at[s2], u2 = Eo(d2, h2 * a2, c2) / h2;
  switch (s2) {
    case "day":
      return { deltaDays: u2, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 };
    case "hour":
      return Yr(u2, 0, 0, 0, 0, 0);
    case "minute":
      return Yr(e2, u2, 0, 0, 0, 0);
    case "second":
      return Yr(e2, t2, u2, 0, 0, 0);
    case "millisecond":
      return Yr(e2, t2, n2, u2, 0, 0);
    case "microsecond":
      return Yr(e2, t2, n2, r2, u2, 0);
    case "nanosecond":
      return Yr(e2, t2, n2, r2, o2, u2);
    default:
      throw new Error(`Invalid unit ${s2}`);
  }
}
function $o(t2, n2, r2, o2) {
  const i2 = at[r2];
  return t2.round(import_jsbi.default.BigInt(i2 * n2), o2);
}
function Yo(t2, n2) {
  const r2 = at[n2];
  return t2.fdiv(import_jsbi.default.BigInt(r2));
}
function Ro(e2, t2) {
  return e2.year !== t2.year ? Bo(e2.year - t2.year) : e2.month !== t2.month ? Bo(e2.month - t2.month) : e2.day !== t2.day ? Bo(e2.day - t2.day) : 0;
}
function So(e2, t2) {
  return e2.hour !== t2.hour ? Bo(e2.hour - t2.hour) : e2.minute !== t2.minute ? Bo(e2.minute - t2.minute) : e2.second !== t2.second ? Bo(e2.second - t2.second) : e2.millisecond !== t2.millisecond ? Bo(e2.millisecond - t2.millisecond) : e2.microsecond !== t2.microsecond ? Bo(e2.microsecond - t2.microsecond) : e2.nanosecond !== t2.nanosecond ? Bo(e2.nanosecond - t2.nanosecond) : 0;
}
function jo(e2, t2) {
  const n2 = Ro(e2.isoDate, t2.isoDate);
  return 0 !== n2 ? n2 : So(e2.time, t2.time);
}
function ko(e2) {
  const t2 = Lo(e2);
  return void 0 !== globalThis.BigInt ? globalThis.BigInt(t2.toString(10)) : t2;
}
function No(t2, n2) {
  const r2 = m(t2), { quotient: o2, remainder: i2 } = g(r2, c);
  let a2 = import_jsbi.default.toNumber(o2);
  return "floor" === n2 && import_jsbi.default.toNumber(i2) < 0 && (a2 -= 1), "ceil" === n2 && import_jsbi.default.toNumber(i2) > 0 && (a2 += 1), a2;
}
function xo(t2) {
  if (!Number.isInteger(t2)) throw new RangeError("epoch milliseconds must be an integer");
  return import_jsbi.default.multiply(import_jsbi.default.BigInt(t2), c);
}
function Lo(t2) {
  let n2 = t2;
  if ("object" == typeof t2) {
    const e2 = t2[Symbol.toPrimitive];
    e2 && "function" == typeof e2 && (n2 = e2.call(t2, "number"));
  }
  if ("number" == typeof n2) throw new TypeError("cannot convert number to bigint");
  return "bigint" == typeof n2 ? import_jsbi.default.BigInt(n2.toString(10)) : import_jsbi.default.BigInt(n2);
}
var Po = (() => {
  let t2 = import_jsbi.default.BigInt(Date.now() % 1e6);
  return () => {
    const n2 = Date.now(), r2 = import_jsbi.default.BigInt(n2), o2 = import_jsbi.default.add(xo(n2), t2);
    return t2 = import_jsbi.default.remainder(r2, c), import_jsbi.default.greaterThan(o2, Ne) ? Ne : import_jsbi.default.lessThan(o2, xe) ? xe : o2;
  };
})();
function Uo() {
  return new Intl.DateTimeFormat().resolvedOptions().timeZone;
}
function Bo(e2) {
  return e2 < 0 ? -1 : e2 > 0 ? 1 : e2;
}
function Zo(e2) {
  if (void 0 === e2) return /* @__PURE__ */ Object.create(null);
  if (Ae(e2) && null !== e2) return e2;
  throw new TypeError("Options parameter must be an object, not " + (null === e2 ? "null" : typeof e2));
}
function Fo(e2, t2) {
  const n2 = /* @__PURE__ */ Object.create(null);
  return n2[e2] = t2, n2;
}
function Ho(e2, t2, n2, r2) {
  let o2 = e2[t2];
  if (void 0 !== o2) {
    if (o2 = We(o2), !n2.includes(o2)) throw new RangeError(`${t2} must be one of ${n2.join(", ")}, not ${o2}`);
    return o2;
  }
  if (r2 === qt) throw new RangeError(`${t2} option is required`);
  return r2;
}
function zo(e2) {
  const t2 = Ao(e2);
  if (!He.includes(Ao(t2))) throw new RangeError(`invalid calendar identifier ${t2}`);
  switch (t2) {
    case "ethiopic-amete-alem":
      return "ethioaa";
    case "islamicc":
      return "islamic-civil";
  }
  return t2;
}
function Ao(e2) {
  let t2 = "";
  for (let n2 = 0; n2 < e2.length; n2++) {
    const r2 = e2.charCodeAt(n2);
    t2 += r2 >= 65 && r2 <= 90 ? String.fromCharCode(r2 + 32) : String.fromCharCode(r2);
  }
  return t2;
}
function qo(e2) {
  throw new TypeError(`Do not use built-in arithmetic operators with Temporal objects. When comparing, use ${"PlainMonthDay" === e2 ? "Temporal.PlainDate.compare(obj1.toPlainDate(year), obj2.toPlainDate(year))" : `Temporal.${e2}.compare(obj1, obj2)`}, not obj1 > obj2. When coercing to strings, use \`\${obj}\` or String(obj), not '' + obj. When coercing to numbers, use properties or methods of the object, not \`+obj\`. When concatenating with strings, use \`\${str}\${obj}\` or str.concat(obj), not str + obj. In React, coerce to a string before rendering a Temporal object.`);
}
var Wo = new RegExp(`^${be.source}$`);
var _o = new RegExp(`^${/([+-])([01][0-9]|2[0-3])(?::?([0-5][0-9])(?::?([0-5][0-9])(?:[.,](\d{1,9}))?)?)?/.source}$`);
function Jo(e2, t2, n2, r2 = e2(t2), o2 = e2(n2)) {
  let i2 = t2, a2 = n2, s2 = r2, c2 = o2;
  for (; a2 - i2 > 1; ) {
    let t3 = Math.trunc((i2 + a2) / 2);
    const n3 = e2(t3);
    n3 === s2 ? (i2 = t3, s2 = n3) : n3 === c2 && (a2 = t3, c2 = n3);
  }
  return a2;
}
function Go(e2) {
  return [...e2];
}
function Ko(e2, t2) {
  if ("gregory" !== e2 && "iso8601" !== e2) return;
  const n2 = Xo[e2];
  let r2 = t2.year;
  const { dayOfWeek: o2, dayOfYear: i2, daysInYear: a2 } = n2.isoToDate(t2, { dayOfWeek: true, dayOfYear: true, daysInYear: true }), s2 = n2.getFirstDayOfWeek(), c2 = n2.getMinimalDaysInFirstWeek();
  let d2 = (o2 + 7 - s2) % 7, h2 = (o2 - i2 + 7001 - s2) % 7, u2 = Math.floor((i2 - 1 + h2) / 7);
  if (7 - h2 >= c2 && ++u2, 0 == u2) u2 = (function(e3, t3, n3, r3) {
    let o3 = (r3 - e3 - n3 + 1) % 7;
    o3 < 0 && (o3 += 7);
    let i3 = Math.floor((n3 + o3 - 1) / 7);
    return 7 - o3 >= t3 && ++i3, i3;
  })(s2, c2, i2 + n2.isoToDate(n2.dateAdd(t2, { years: -1 }, "constrain"), { daysInYear: true }).daysInYear, o2), r2--;
  else if (i2 >= a2 - 5) {
    let e3 = (d2 + a2 - i2) % 7;
    e3 < 0 && (e3 += 7), 6 - e3 >= c2 && i2 + 7 - d2 > a2 && (u2 = 1, r2++);
  }
  return { week: u2, year: r2 };
}
function Vo(e2, t2, n2, r2, o2) {
  if (t2 !== o2.year) {
    if (e2 * (t2 - o2.year) > 0) return true;
  } else if (n2 !== o2.month) {
    if (e2 * (n2 - o2.month) > 0) return true;
  } else if (r2 !== o2.day && e2 * (r2 - o2.day) > 0) return true;
  return false;
}
var Xo = {};
function Qo(e2) {
  if (!e2.startsWith("M")) throw new RangeError(`Invalid month code: ${e2}.  Month codes must start with M.`);
  const t2 = +e2.slice(1);
  if (Number.isNaN(t2)) throw new RangeError(`Invalid month code: ${e2}`);
  return t2;
}
function ei(e2, t2 = false) {
  return `M${`${e2}`.padStart(2, "0")}${t2 ? "L" : ""}`;
}
function ti(e2, t2 = void 0, n2 = 12) {
  let { month: r2, monthCode: o2 } = e2;
  if (void 0 === o2) {
    if (void 0 === r2) throw new TypeError("Either month or monthCode are required");
    "reject" === t2 && Nr(r2, 1, n2), "constrain" === t2 && (r2 = jr(r2, 1, n2)), o2 = ei(r2);
  } else {
    const e3 = Qo(o2);
    if (o2 !== ei(e3)) throw new RangeError(`Invalid month code: ${o2}`);
    if (void 0 !== r2 && r2 !== e3) throw new RangeError(`monthCode ${o2} and month ${r2} must match if both are present`);
    if (r2 = e3, r2 < 1 || r2 > n2) throw new RangeError(`Invalid monthCode: ${o2}`);
  }
  return { ...e2, month: r2, monthCode: o2 };
}
Xo.iso8601 = { resolveFields(e2, t2) {
  if (("date" === t2 || "year-month" === t2) && void 0 === e2.year) throw new TypeError("year is required");
  if (("date" === t2 || "month-day" === t2) && void 0 === e2.day) throw new TypeError("day is required");
  Object.assign(e2, ti(e2));
}, dateToISO: (e2, t2) => St(e2.year, e2.month, e2.day, t2), monthDayToISOReferenceDate(e2, t2) {
  const { month: n2, day: r2 } = St(e2.year ?? 1972, e2.month, e2.day, t2);
  return { month: n2, day: r2, year: 1972 };
}, extraFields: () => [], fieldKeysToIgnore(e2) {
  const t2 = /* @__PURE__ */ new Set();
  for (let n2 = 0; n2 < e2.length; n2++) {
    const r2 = e2[n2];
    t2.add(r2), "month" === r2 ? t2.add("monthCode") : "monthCode" === r2 && t2.add("month");
  }
  return Go(t2);
}, dateAdd(e2, { years: t2 = 0, months: n2 = 0, weeks: r2 = 0, days: o2 = 0 }, i2) {
  let { year: a2, month: s2, day: c2 } = e2;
  return a2 += t2, s2 += n2, { year: a2, month: s2 } = Cr(a2, s2), { year: a2, month: s2, day: c2 } = St(a2, s2, c2, i2), c2 += o2 + 7 * r2, Or(a2, s2, c2);
}, dateUntil(e2, t2, n2) {
  const r2 = -Ro(e2, t2);
  if (0 === r2) return { years: 0, months: 0, weeks: 0, days: 0 };
  let o2, i2 = 0, a2 = 0;
  if ("year" === n2 || "month" === n2) {
    let s3 = t2.year - e2.year;
    for (0 !== s3 && (s3 -= r2); !Vo(r2, e2.year + s3, e2.month, e2.day, t2); ) i2 = s3, s3 += r2;
    let c3 = r2;
    for (o2 = Cr(e2.year + i2, e2.month + c3); !Vo(r2, o2.year, o2.month, e2.day, t2); ) a2 = c3, c3 += r2, o2 = Cr(o2.year, o2.month + r2);
    "month" === n2 && (a2 += 12 * i2, i2 = 0);
  }
  o2 = Cr(e2.year + i2, e2.month + a2);
  const s2 = kr(o2.year, o2.month, e2.day);
  let c2 = 0, d2 = Gr(t2.year, t2.month - 1, t2.day) - Gr(s2.year, s2.month - 1, s2.day);
  return "week" === n2 && (c2 = Math.trunc(d2 / 7), d2 %= 7), { years: i2, months: a2, weeks: c2, days: d2 };
}, isoToDate({ year: e2, month: t2, day: n2 }, r2) {
  const o2 = { era: void 0, eraYear: void 0, year: e2, month: t2, day: n2, daysInWeek: 7, monthsInYear: 12 };
  if (r2.monthCode && (o2.monthCode = ei(t2)), r2.dayOfWeek) {
    const r3 = t2 + (t2 < 3 ? 10 : -2), i2 = e2 - (t2 < 3 ? 1 : 0), a2 = Math.floor(i2 / 100), s2 = i2 - 100 * a2, c2 = (n2 + Math.floor(2.6 * r3 - 0.2) + (s2 + Math.floor(s2 / 4)) + (Math.floor(a2 / 4) - 2 * a2)) % 7;
    o2.dayOfWeek = c2 + (c2 <= 0 ? 7 : 0);
  }
  if (r2.dayOfYear) {
    let r3 = n2;
    for (let n3 = t2 - 1; n3 > 0; n3--) r3 += Tr(e2, n3);
    o2.dayOfYear = r3;
  }
  return r2.weekOfYear && (o2.weekOfYear = Ko("iso8601", { year: e2, month: t2, day: n2 })), r2.daysInMonth && (o2.daysInMonth = Tr(e2, t2)), (r2.daysInYear || r2.inLeapYear) && (o2.inLeapYear = Dr(e2), o2.daysInYear = o2.inLeapYear ? 366 : 365), o2;
}, getFirstDayOfWeek: () => 1, getMinimalDaysInFirstWeek: () => 4 };
var OneObjectCache = class _OneObjectCache {
  constructor(e2) {
    if (this.map = /* @__PURE__ */ new Map(), this.calls = 0, this.hits = 0, this.misses = 0, void 0 !== e2) {
      let t2 = 0;
      for (const n2 of e2.map.entries()) {
        if (++t2 > _OneObjectCache.MAX_CACHE_ENTRIES) break;
        this.map.set(...n2);
      }
    }
  }
  get(e2) {
    const t2 = this.map.get(e2);
    return t2 && (this.hits++, this.report()), this.calls++, t2;
  }
  set(e2, t2) {
    this.map.set(e2, t2), this.misses++, this.report();
  }
  report() {
  }
  setObject(e2) {
    if (_OneObjectCache.objectMap.get(e2)) throw new RangeError("object already cached");
    _OneObjectCache.objectMap.set(e2, this), this.report();
  }
  static getCacheForObject(e2) {
    let t2 = _OneObjectCache.objectMap.get(e2);
    return t2 || (t2 = new _OneObjectCache(), _OneObjectCache.objectMap.set(e2, t2)), t2;
  }
};
function ni({ isoYear: e2, isoMonth: t2, isoDay: n2 }) {
  return `${Jn(e2)}-${Gn(t2)}-${Gn(n2)}T00:00Z`;
}
function ri(e2, t2) {
  return { years: e2.year - t2.year, months: e2.month - t2.month, days: e2.day - t2.day };
}
OneObjectCache.objectMap = /* @__PURE__ */ new WeakMap(), OneObjectCache.MAX_CACHE_ENTRIES = 1e3;
var HelperBase = class {
  constructor() {
    this.eras = [], this.hasEra = false, this.erasBeginMidYear = false;
  }
  getFormatter() {
    return void 0 === this.formatter && (this.formatter = new Intl.DateTimeFormat(`en-US-u-ca-${this.id}`, { day: "numeric", month: "numeric", year: "numeric", era: "short", timeZone: "UTC" })), this.formatter;
  }
  getCalendarParts(e2) {
    let t2 = this.getFormatter(), n2 = new Date(e2);
    if ("-271821-04-19T00:00Z" === e2) {
      const e3 = t2.resolvedOptions();
      t2 = new Intl.DateTimeFormat(e3.locale, { ...e3, timeZone: "Etc/GMT+1" }), n2 = /* @__PURE__ */ new Date("-271821-04-20T00:00Z");
    }
    try {
      return t2.formatToParts(n2);
    } catch (t3) {
      throw new RangeError(`Invalid ISO date: ${e2}`);
    }
  }
  isoToCalendarDate(e2, t2) {
    const { year: n2, month: r2, day: o2 } = e2, i2 = JSON.stringify({ func: "isoToCalendarDate", isoYear: n2, isoMonth: r2, isoDay: o2, id: this.id }), a2 = t2.get(i2);
    if (a2) return a2;
    const s2 = ni({ isoYear: n2, isoMonth: r2, isoDay: o2 }), c2 = this.getCalendarParts(s2), d2 = {};
    for (let e3 = 0; e3 < c2.length; e3++) {
      const { type: t3, value: n3 } = c2[e3];
      if ("year" !== t3 && "relatedYear" !== t3 || (this.hasEra ? d2.eraYear = +n3 : d2.year = +n3), "month" === t3) {
        const e4 = /^([0-9]*)(.*?)$/.exec(n3);
        if (!e4 || 3 != e4.length || !e4[1] && !e4[2]) throw new RangeError(`Unexpected month: ${n3}`);
        if (d2.month = e4[1] ? +e4[1] : 1, d2.month < 1) throw new RangeError(`Invalid month ${n3} from ${s2}[u-ca-${this.id}] (probably due to https://bugs.chromium.org/p/v8/issues/detail?id=10527)`);
        if (d2.month > 13) throw new RangeError(`Invalid month ${n3} from ${s2}[u-ca-${this.id}] (probably due to https://bugs.chromium.org/p/v8/issues/detail?id=10529)`);
        e4[2] && (d2.monthExtra = e4[2]);
      }
      "day" === t3 && (d2.day = +n3), this.hasEra && "era" === t3 && null != n3 && "" !== n3 && (d2.era = n3.split(" (")[0].normalize("NFD").replace(/[^-0-9 \p{L}]/gu, "").replace(/ /g, "-").toLowerCase());
    }
    if (this.hasEra && void 0 === d2.eraYear) throw new RangeError(`Intl.DateTimeFormat.formatToParts lacks relatedYear in ${this.id} calendar. Try Node 14+ or modern browsers.`);
    if (this.hasEra) {
      const e3 = this.eras.find(((e4) => d2.era === e4.genericName));
      e3 && (d2.era = e3.code);
    }
    if (this.reviseIntlEra) {
      const { era: t3, eraYear: n3 } = this.reviseIntlEra(d2, e2);
      d2.era = t3, d2.eraYear = n3;
    }
    this.checkIcuBugs && this.checkIcuBugs(e2);
    const h2 = this.adjustCalendarDate(d2, t2, "constrain", true);
    if (void 0 === h2.year) throw new RangeError(`Missing year converting ${JSON.stringify(e2)}`);
    if (void 0 === h2.month) throw new RangeError(`Missing month converting ${JSON.stringify(e2)}`);
    if (void 0 === h2.day) throw new RangeError(`Missing day converting ${JSON.stringify(e2)}`);
    return t2.set(i2, h2), ["constrain", "reject"].forEach(((n3) => {
      const r3 = JSON.stringify({ func: "calendarToIsoDate", year: h2.year, month: h2.month, day: h2.day, overflow: n3, id: this.id });
      t2.set(r3, e2);
    })), h2;
  }
  validateCalendarDate(e2) {
    const { month: t2, year: n2, day: r2, eraYear: o2, monthCode: i2, monthExtra: a2 } = e2;
    if (void 0 !== a2) throw new RangeError("Unexpected `monthExtra` value");
    if (void 0 === n2 && void 0 === o2) throw new TypeError("year or eraYear is required");
    if (void 0 === t2 && void 0 === i2) throw new TypeError("month or monthCode is required");
    if (void 0 === r2) throw new RangeError("Missing day");
    if (void 0 !== i2) {
      if ("string" != typeof i2) throw new RangeError("monthCode must be a string, not " + typeof i2);
      if (!/^M([01]?\d)(L?)$/.test(i2)) throw new RangeError(`Invalid monthCode: ${i2}`);
    }
    if (this.hasEra && void 0 === e2.era != (void 0 === e2.eraYear)) throw new TypeError("properties era and eraYear must be provided together");
  }
  adjustCalendarDate(e2, t2 = void 0, n2 = "constrain", r2 = false) {
    if ("lunisolar" === this.calendarType) throw new RangeError("Override required for lunisolar calendars");
    let o2 = e2;
    this.validateCalendarDate(o2);
    const i2 = this.monthsInYear(o2, t2);
    let { month: a2, monthCode: s2 } = o2;
    return { month: a2, monthCode: s2 } = ti(o2, n2, i2), { ...o2, month: a2, monthCode: s2 };
  }
  regulateMonthDayNaive(e2, t2, n2) {
    const r2 = this.monthsInYear(e2, n2);
    let { month: o2, day: i2 } = e2;
    return "reject" === t2 ? (Nr(o2, 1, r2), Nr(i2, 1, this.maximumMonthLength(e2))) : (o2 = jr(o2, 1, r2), i2 = jr(i2, 1, this.maximumMonthLength({ ...e2, month: o2 }))), { ...e2, month: o2, day: i2 };
  }
  calendarToIsoDate(e2, t2 = "constrain", n2) {
    const r2 = e2;
    let o2 = this.adjustCalendarDate(e2, n2, t2, false);
    o2 = this.regulateMonthDayNaive(o2, t2, n2);
    const { year: i2, month: a2, day: s2 } = o2, c2 = JSON.stringify({ func: "calendarToIsoDate", year: i2, month: a2, day: s2, overflow: t2, id: this.id });
    let d2, h2 = n2.get(c2);
    if (h2) return h2;
    if (void 0 !== r2.year && void 0 !== r2.month && void 0 !== r2.day && (r2.year !== o2.year || r2.month !== o2.month || r2.day !== o2.day) && (d2 = JSON.stringify({ func: "calendarToIsoDate", year: r2.year, month: r2.month, day: r2.day, overflow: t2, id: this.id }), h2 = n2.get(d2), h2)) return h2;
    let u2 = this.estimateIsoDate({ year: i2, month: a2, day: s2 });
    const l2 = (e3) => {
      let r3 = this.addDaysIso(u2, e3);
      if (o2.day > this.minimumMonthLength(o2)) {
        let e4 = this.isoToCalendarDate(r3, n2);
        for (; e4.month !== a2 || e4.year !== i2; ) {
          if ("reject" === t2) throw new RangeError(`day ${s2} does not exist in month ${a2} of year ${i2}`);
          r3 = this.addDaysIso(r3, -1), e4 = this.isoToCalendarDate(r3, n2);
        }
      }
      return r3;
    };
    let m2 = 0, f2 = this.isoToCalendarDate(u2, n2), y2 = ri(o2, f2);
    if (0 !== y2.years || 0 !== y2.months || 0 !== y2.days) {
      const e3 = 365 * y2.years + 30 * y2.months + y2.days;
      u2 = this.addDaysIso(u2, e3), f2 = this.isoToCalendarDate(u2, n2), y2 = ri(o2, f2), 0 === y2.years && 0 === y2.months ? u2 = l2(y2.days) : m2 = this.compareCalendarDates(o2, f2);
    }
    let p2 = 8;
    for (; m2; ) {
      u2 = this.addDaysIso(u2, m2 * p2);
      const e3 = f2;
      f2 = this.isoToCalendarDate(u2, n2);
      const i3 = m2;
      if (m2 = this.compareCalendarDates(o2, f2), m2) {
        if (y2 = ri(o2, f2), 0 === y2.years && 0 === y2.months) u2 = l2(y2.days), m2 = 0;
        else if (i3 && m2 !== i3) if (p2 > 1) p2 /= 2;
        else {
          if ("reject" === t2) throw new RangeError(`Can't find ISO date from calendar date: ${JSON.stringify({ ...r2 })}`);
          this.compareCalendarDates(f2, e3) > 0 && (u2 = this.addDaysIso(u2, -1)), m2 = 0;
        }
      }
    }
    if (n2.set(c2, u2), d2 && n2.set(d2, u2), void 0 === o2.year || void 0 === o2.month || void 0 === o2.day || void 0 === o2.monthCode || this.hasEra && (void 0 === o2.era || void 0 === o2.eraYear)) throw new RangeError("Unexpected missing property");
    return u2;
  }
  compareCalendarDates(e2, t2) {
    return e2.year !== t2.year ? Bo(e2.year - t2.year) : e2.month !== t2.month ? Bo(e2.month - t2.month) : e2.day !== t2.day ? Bo(e2.day - t2.day) : 0;
  }
  regulateDate(e2, t2 = "constrain", n2) {
    const r2 = this.calendarToIsoDate(e2, t2, n2);
    return this.isoToCalendarDate(r2, n2);
  }
  addDaysIso(e2, t2) {
    return Or(e2.year, e2.month, e2.day + t2);
  }
  addDaysCalendar(e2, t2, n2) {
    const r2 = this.calendarToIsoDate(e2, "constrain", n2), o2 = this.addDaysIso(r2, t2);
    return this.isoToCalendarDate(o2, n2);
  }
  addMonthsCalendar(e2, t2, n2, r2) {
    let o2 = e2;
    const { day: i2 } = o2;
    for (let e3 = 0, n3 = Math.abs(t2); e3 < n3; e3++) {
      const { month: e4 } = o2, n4 = o2, a2 = t2 < 0 ? -Math.max(i2, this.daysInPreviousMonth(o2, r2)) : this.daysInMonth(o2, r2), s2 = this.calendarToIsoDate(o2, "constrain", r2);
      let c2 = this.addDaysIso(s2, a2);
      if (o2 = this.isoToCalendarDate(c2, r2), t2 > 0) {
        const t3 = this.monthsInYear(n4, r2);
        for (; o2.month - 1 != e4 % t3; ) c2 = this.addDaysIso(c2, -1), o2 = this.isoToCalendarDate(c2, r2);
      }
      o2.day !== i2 && (o2 = this.regulateDate({ ...o2, day: i2 }, "constrain", r2));
    }
    if ("reject" === n2 && o2.day !== i2) throw new RangeError(`Day ${i2} does not exist in resulting calendar month`);
    return o2;
  }
  addCalendar(e2, { years: t2 = 0, months: n2 = 0, weeks: r2 = 0, days: o2 = 0 }, i2, a2) {
    const { year: s2, day: c2, monthCode: d2 } = e2, h2 = this.adjustCalendarDate({ year: s2 + t2, monthCode: d2, day: c2 }, a2), u2 = this.addMonthsCalendar(h2, n2, i2, a2), l2 = o2 + 7 * r2;
    return this.addDaysCalendar(u2, l2, a2);
  }
  untilCalendar(e2, t2, n2, r2) {
    let o2 = 0, i2 = 0, a2 = 0, s2 = 0;
    switch (n2) {
      case "day":
        o2 = this.calendarDaysUntil(e2, t2, r2);
        break;
      case "week": {
        const n3 = this.calendarDaysUntil(e2, t2, r2);
        o2 = n3 % 7, i2 = (n3 - o2) / 7;
        break;
      }
      case "month":
      case "year": {
        const i3 = this.compareCalendarDates(t2, e2);
        if (!i3) return { years: 0, months: 0, weeks: 0, days: 0 };
        const c2 = t2.year - e2.year, d2 = t2.day - e2.day;
        if ("year" === n2 && c2) {
          let n3 = 0;
          t2.monthCode > e2.monthCode && (n3 = 1), t2.monthCode < e2.monthCode && (n3 = -1), n3 || (n3 = Math.sign(d2)), s2 = n3 * i3 < 0 ? c2 - i3 : c2;
        }
        let h2, u2 = s2 ? this.addCalendar(e2, { years: s2 }, "constrain", r2) : e2;
        do {
          a2 += i3, h2 = u2, u2 = this.addMonthsCalendar(h2, i3, "constrain", r2), u2.day !== e2.day && (u2 = this.regulateDate({ ...u2, day: e2.day }, "constrain", r2));
        } while (this.compareCalendarDates(t2, u2) * i3 >= 0);
        a2 -= i3, o2 = this.calendarDaysUntil(h2, t2, r2);
        break;
      }
    }
    return { years: s2, months: a2, weeks: i2, days: o2 };
  }
  daysInMonth(e2, t2) {
    const { day: n2 } = e2, r2 = this.maximumMonthLength(e2), o2 = this.minimumMonthLength(e2);
    if (o2 === r2) return o2;
    const i2 = n2 <= r2 - o2 ? r2 : o2, a2 = this.calendarToIsoDate(e2, "constrain", t2), s2 = this.addDaysIso(a2, i2), c2 = this.isoToCalendarDate(s2, t2), d2 = this.addDaysIso(s2, -c2.day);
    return this.isoToCalendarDate(d2, t2).day;
  }
  daysInPreviousMonth(e2, t2) {
    const { day: n2, month: r2, year: o2 } = e2;
    let i2 = { year: r2 > 1 ? o2 : o2 - 1, month: r2, day: 1 };
    const a2 = r2 > 1 ? r2 - 1 : this.monthsInYear(i2, t2);
    i2 = { ...i2, month: a2 };
    const s2 = this.minimumMonthLength(i2), c2 = this.maximumMonthLength(i2);
    if (s2 === c2) return c2;
    const d2 = this.calendarToIsoDate(e2, "constrain", t2), h2 = this.addDaysIso(d2, -n2);
    return this.isoToCalendarDate(h2, t2).day;
  }
  startOfCalendarYear(e2) {
    return { year: e2.year, month: 1, monthCode: "M01", day: 1 };
  }
  startOfCalendarMonth(e2) {
    return { year: e2.year, month: e2.month, day: 1 };
  }
  calendarDaysUntil(e2, t2, n2) {
    const r2 = this.calendarToIsoDate(e2, "constrain", n2), o2 = this.calendarToIsoDate(t2, "constrain", n2);
    return Gr(o2.year, o2.month - 1, o2.day) - Gr(r2.year, r2.month - 1, r2.day);
  }
  monthDaySearchStartYear(e2, t2) {
    return 1972;
  }
  monthDayFromFields(e2, t2, n2) {
    let r2, o2, i2, a2, s2, { era: c2, eraYear: d2, year: h2, month: u2, monthCode: l2, day: m2 } = e2;
    if (void 0 !== u2 && void 0 === h2 && (!this.hasEra || void 0 === c2 || void 0 === d2)) throw new TypeError("when month is present, year (or era and eraYear) are required");
    (void 0 === l2 || void 0 !== h2 || this.hasEra && void 0 !== d2) && ({ monthCode: l2, day: m2 } = this.isoToCalendarDate(this.calendarToIsoDate(e2, t2, n2), n2));
    const f2 = { year: this.monthDaySearchStartYear(l2, m2), month: 12, day: 31 }, y2 = this.isoToCalendarDate(f2, n2), p2 = y2.monthCode > l2 || y2.monthCode === l2 && y2.day >= m2 ? y2.year : y2.year - 1;
    for (let e3 = 0; e3 < 20; e3++) {
      const c3 = this.adjustCalendarDate({ day: m2, monthCode: l2, year: p2 - e3 }, n2), d3 = this.calendarToIsoDate(c3, "constrain", n2), h3 = this.isoToCalendarDate(d3, n2);
      if ({ year: r2, month: o2, day: i2 } = d3, h3.monthCode === l2 && h3.day === m2) return { month: o2, day: i2, year: r2 };
      if ("constrain" === t2) {
        const e4 = this.maxLengthOfMonthCodeInAnyYear(h3.monthCode);
        if (h3.monthCode === l2 && h3.day === e4 && m2 > e4) return { month: o2, day: i2, year: r2 };
        (void 0 === a2 || h3.monthCode === a2.monthCode && h3.day > a2.day) && (a2 = h3, s2 = d3);
      }
    }
    if ("constrain" === t2 && void 0 !== s2) return s2;
    throw new RangeError(`No recent ${this.id} year with monthCode ${l2} and day ${m2}`);
  }
  getFirstDayOfWeek() {
  }
  getMinimalDaysInFirstWeek() {
  }
};
var HebrewHelper = class extends HelperBase {
  constructor() {
    super(...arguments), this.id = "hebrew", this.calendarType = "lunisolar", this.months = { Tishri: { leap: 1, regular: 1, monthCode: "M01", days: 30 }, Heshvan: { leap: 2, regular: 2, monthCode: "M02", days: { min: 29, max: 30 } }, Kislev: { leap: 3, regular: 3, monthCode: "M03", days: { min: 29, max: 30 } }, Tevet: { leap: 4, regular: 4, monthCode: "M04", days: 29 }, Shevat: { leap: 5, regular: 5, monthCode: "M05", days: 30 }, Adar: { leap: void 0, regular: 6, monthCode: "M06", days: 29 }, "Adar I": { leap: 6, regular: void 0, monthCode: "M05L", days: 30 }, "Adar II": { leap: 7, regular: void 0, monthCode: "M06", days: 29 }, Nisan: { leap: 8, regular: 7, monthCode: "M07", days: 30 }, Iyar: { leap: 9, regular: 8, monthCode: "M08", days: 29 }, Sivan: { leap: 10, regular: 9, monthCode: "M09", days: 30 }, Tamuz: { leap: 11, regular: 10, monthCode: "M10", days: 29 }, Av: { leap: 12, regular: 11, monthCode: "M11", days: 30 }, Elul: { leap: 13, regular: 12, monthCode: "M12", days: 29 } };
  }
  inLeapYear(e2) {
    const { year: t2 } = e2;
    return (7 * t2 + 1) % 19 < 7;
  }
  monthsInYear(e2) {
    return this.inLeapYear(e2) ? 13 : 12;
  }
  minimumMonthLength(e2) {
    return this.minMaxMonthLength(e2, "min");
  }
  maximumMonthLength(e2) {
    return this.minMaxMonthLength(e2, "max");
  }
  minMaxMonthLength(e2, t2) {
    const { month: n2, year: r2 } = e2, o2 = this.getMonthCode(r2, n2), i2 = Object.entries(this.months).find(((e3) => e3[1].monthCode === o2));
    if (void 0 === i2) throw new RangeError(`unmatched Hebrew month: ${n2}`);
    const a2 = i2[1].days;
    return "number" == typeof a2 ? a2 : a2[t2];
  }
  maxLengthOfMonthCodeInAnyYear(e2) {
    return ["M04", "M06", "M08", "M10", "M12"].includes(e2) ? 29 : 30;
  }
  estimateIsoDate(e2) {
    const { year: t2 } = e2;
    return { year: t2 - 3760, month: 1, day: 1 };
  }
  getMonthCode(e2, t2) {
    return this.inLeapYear({ year: e2 }) ? 6 === t2 ? ei(5, true) : ei(t2 < 6 ? t2 : t2 - 1) : ei(t2);
  }
  adjustCalendarDate(e2, t2, n2 = "constrain", r2 = false) {
    let { year: o2, month: i2, monthCode: a2, day: s2, monthExtra: c2 } = e2;
    if (void 0 === o2) throw new TypeError("Missing property: year");
    if (r2) {
      if (c2) {
        const e3 = this.months[c2];
        if (!e3) throw new RangeError(`Unrecognized month from formatToParts: ${c2}`);
        i2 = this.inLeapYear({ year: o2 }) ? e3.leap : e3.regular;
      }
      return a2 = this.getMonthCode(o2, i2), { year: o2, month: i2, day: s2, monthCode: a2 };
    }
    if (this.validateCalendarDate(e2), void 0 === i2) if (a2.endsWith("L")) {
      if ("M05L" !== a2) throw new RangeError(`Hebrew leap month must have monthCode M05L, not ${a2}`);
      if (i2 = 6, !this.inLeapYear({ year: o2 })) {
        if ("reject" === n2) throw new RangeError(`Hebrew monthCode M05L is invalid in year ${o2} which is not a leap year`);
        i2 = 6, a2 = "M06";
      }
    } else {
      i2 = Qo(a2), this.inLeapYear({ year: o2 }) && i2 >= 6 && i2++;
      const e3 = this.monthsInYear({ year: o2 });
      if (i2 < 1 || i2 > e3) throw new RangeError(`Invalid monthCode: ${a2}`);
    }
    else if ("reject" === n2 ? (Nr(i2, 1, this.monthsInYear({ year: o2 })), Nr(s2, 1, this.maximumMonthLength({ year: o2, month: i2 }))) : (i2 = jr(i2, 1, this.monthsInYear({ year: o2 })), s2 = jr(s2, 1, this.maximumMonthLength({ year: o2, month: i2 }))), void 0 === a2) a2 = this.getMonthCode(o2, i2);
    else if (this.getMonthCode(o2, i2) !== a2) throw new RangeError(`monthCode ${a2} doesn't correspond to month ${i2} in Hebrew year ${o2}`);
    return { ...e2, day: s2, month: i2, monthCode: a2, year: o2 };
  }
};
var IslamicBaseHelper = class extends HelperBase {
  constructor() {
    super(...arguments), this.calendarType = "lunar", this.DAYS_PER_ISLAMIC_YEAR = 354 + 11 / 30, this.DAYS_PER_ISO_YEAR = 365.2425;
  }
  inLeapYear(e2, t2) {
    const n2 = { year: e2.year, month: 1, monthCode: "M01", day: 1 }, r2 = { year: e2.year + 1, month: 1, monthCode: "M01", day: 1 };
    return 355 === this.calendarDaysUntil(n2, r2, t2);
  }
  monthsInYear() {
    return 12;
  }
  minimumMonthLength() {
    return 29;
  }
  maximumMonthLength() {
    return 30;
  }
  maxLengthOfMonthCodeInAnyYear() {
    return 30;
  }
  estimateIsoDate(e2) {
    const { year: t2 } = this.adjustCalendarDate(e2);
    return { year: Math.floor(t2 * this.DAYS_PER_ISLAMIC_YEAR / this.DAYS_PER_ISO_YEAR) + 622, month: 1, day: 1 };
  }
};
var IslamicHelper = class extends IslamicBaseHelper {
  constructor() {
    super(...arguments), this.id = "islamic";
  }
};
var IslamicUmalquraHelper = class extends IslamicBaseHelper {
  constructor() {
    super(...arguments), this.id = "islamic-umalqura";
  }
};
var IslamicTblaHelper = class extends IslamicBaseHelper {
  constructor() {
    super(...arguments), this.id = "islamic-tbla";
  }
};
var IslamicCivilHelper = class extends IslamicBaseHelper {
  constructor() {
    super(...arguments), this.id = "islamic-civil";
  }
};
var IslamicRgsaHelper = class extends IslamicBaseHelper {
  constructor() {
    super(...arguments), this.id = "islamic-rgsa";
  }
};
var IslamicCcHelper = class extends IslamicBaseHelper {
  constructor() {
    super(...arguments), this.id = "islamicc";
  }
};
var PersianHelper = class extends HelperBase {
  constructor() {
    super(...arguments), this.id = "persian", this.calendarType = "solar";
  }
  inLeapYear(e2, t2) {
    return 30 === this.daysInMonth({ year: e2.year, month: 12, day: 1 }, t2);
  }
  monthsInYear() {
    return 12;
  }
  minimumMonthLength(e2) {
    const { month: t2 } = e2;
    return 12 === t2 ? 29 : t2 <= 6 ? 31 : 30;
  }
  maximumMonthLength(e2) {
    const { month: t2 } = e2;
    return 12 === t2 ? 30 : t2 <= 6 ? 31 : 30;
  }
  maxLengthOfMonthCodeInAnyYear(e2) {
    return Qo(e2) <= 6 ? 31 : 30;
  }
  estimateIsoDate(e2) {
    const { year: t2 } = this.adjustCalendarDate(e2);
    return { year: t2 + 621, month: 1, day: 1 };
  }
};
var IndianHelper = class extends HelperBase {
  constructor() {
    super(...arguments), this.id = "indian", this.calendarType = "solar", this.months = { 1: { length: 30, month: 3, day: 22, leap: { length: 31, month: 3, day: 21 } }, 2: { length: 31, month: 4, day: 21 }, 3: { length: 31, month: 5, day: 22 }, 4: { length: 31, month: 6, day: 22 }, 5: { length: 31, month: 7, day: 23 }, 6: { length: 31, month: 8, day: 23 }, 7: { length: 30, month: 9, day: 23 }, 8: { length: 30, month: 10, day: 23 }, 9: { length: 30, month: 11, day: 22 }, 10: { length: 30, month: 12, day: 22 }, 11: { length: 30, month: 1, nextYear: true, day: 21 }, 12: { length: 30, month: 2, nextYear: true, day: 20 } }, this.vulnerableToBceBug = "10/11/-79 Saka" !== (/* @__PURE__ */ new Date("0000-01-01T00:00Z")).toLocaleDateString("en-US-u-ca-indian", { timeZone: "UTC" });
  }
  inLeapYear(e2) {
    return oi(e2.year + 78);
  }
  monthsInYear() {
    return 12;
  }
  minimumMonthLength(e2) {
    return this.getMonthInfo(e2).length;
  }
  maximumMonthLength(e2) {
    return this.getMonthInfo(e2).length;
  }
  maxLengthOfMonthCodeInAnyYear(e2) {
    const t2 = Qo(e2);
    let n2 = this.months[t2];
    return n2 = n2.leap ?? n2, n2.length;
  }
  getMonthInfo(e2) {
    const { month: t2 } = e2;
    let n2 = this.months[t2];
    if (void 0 === n2) throw new RangeError(`Invalid month: ${t2}`);
    return this.inLeapYear(e2) && n2.leap && (n2 = n2.leap), n2;
  }
  estimateIsoDate(e2) {
    const t2 = this.adjustCalendarDate(e2), n2 = this.getMonthInfo(t2);
    return Or(t2.year + 78 + (n2.nextYear ? 1 : 0), n2.month, n2.day + t2.day - 1);
  }
  checkIcuBugs(e2) {
    if (this.vulnerableToBceBug && e2.year < 1) throw new RangeError(`calendar '${this.id}' is broken for ISO dates before 0001-01-01 (see https://bugs.chromium.org/p/v8/issues/detail?id=10529)`);
  }
};
function oi(e2) {
  return e2 % 4 == 0 && (e2 % 100 != 0 || e2 % 400 == 0);
}
var GregorianBaseHelperFixedEpoch = class extends HelperBase {
  constructor(e2, t2) {
    super(), this.calendarType = "solar", this.id = e2, this.isoEpoch = t2;
  }
  inLeapYear(e2) {
    const { year: t2 } = this.estimateIsoDate({ month: 1, day: 1, year: e2.year });
    return oi(t2);
  }
  monthsInYear() {
    return 12;
  }
  minimumMonthLength(e2) {
    const { month: t2 } = e2;
    return 2 === t2 ? this.inLeapYear(e2) ? 29 : 28 : [4, 6, 9, 11].indexOf(t2) >= 0 ? 30 : 31;
  }
  maximumMonthLength(e2) {
    return this.minimumMonthLength(e2);
  }
  maxLengthOfMonthCodeInAnyYear(e2) {
    return [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][Qo(e2) - 1];
  }
  estimateIsoDate(e2) {
    const t2 = this.adjustCalendarDate(e2);
    return St(t2.year + this.isoEpoch.year, t2.month + this.isoEpoch.month, t2.day + this.isoEpoch.day, "constrain");
  }
};
var GregorianBaseHelper = class extends HelperBase {
  constructor(e2, t2) {
    super(), this.hasEra = true, this.calendarType = "solar", this.id = e2;
    const { eras: n2, anchorEra: r2 } = (function(e3) {
      let t3, n3 = e3;
      if (0 === n3.length) throw new RangeError("Invalid era data: eras are required");
      if (1 === n3.length && n3[0].reverseOf) throw new RangeError("Invalid era data: anchor era cannot count years backwards");
      if (1 === n3.length && !n3[0].code) throw new RangeError("Invalid era data: at least one named era is required");
      if (n3.filter(((e4) => null != e4.reverseOf)).length > 1) throw new RangeError("Invalid era data: only one era can count years backwards");
      n3.forEach(((e4) => {
        if (e4.isAnchor || !e4.anchorEpoch && !e4.reverseOf) {
          if (t3) throw new RangeError("Invalid era data: cannot have multiple anchor eras");
          t3 = e4, e4.anchorEpoch = { year: e4.hasYearZero ? 0 : 1 };
        } else if (!e4.code) throw new RangeError("If era name is blank, it must be the anchor era");
      })), n3 = n3.filter(((e4) => e4.code)), n3.forEach(((e4) => {
        const { reverseOf: t4 } = e4;
        if (t4) {
          const r4 = n3.find(((e5) => e5.code === t4));
          if (void 0 === r4) throw new RangeError(`Invalid era data: unmatched reverseOf era: ${t4}`);
          e4.reverseOf = r4, e4.anchorEpoch = r4.anchorEpoch, e4.isoEpoch = r4.isoEpoch;
        }
        void 0 === e4.anchorEpoch.month && (e4.anchorEpoch.month = 1), void 0 === e4.anchorEpoch.day && (e4.anchorEpoch.day = 1);
      })), n3.sort(((e4, t4) => {
        if (e4.reverseOf) return 1;
        if (t4.reverseOf) return -1;
        if (!e4.isoEpoch || !t4.isoEpoch) throw new RangeError("Invalid era data: missing ISO epoch");
        return t4.isoEpoch.year - e4.isoEpoch.year;
      }));
      const r3 = n3[n3.length - 1].reverseOf;
      if (r3 && r3 !== n3[n3.length - 2]) throw new RangeError("Invalid era data: invalid reverse-sign era");
      return n3.forEach(((e4, t4) => {
        e4.genericName = "era" + (n3.length - 1 - t4);
      })), { eras: n3, anchorEra: t3 || n3[0] };
    })(t2);
    this.anchorEra = r2, this.eras = n2;
  }
  inLeapYear(e2) {
    const { year: t2 } = this.estimateIsoDate({ month: 1, day: 1, year: e2.year });
    return oi(t2);
  }
  monthsInYear() {
    return 12;
  }
  minimumMonthLength(e2) {
    const { month: t2 } = e2;
    return 2 === t2 ? this.inLeapYear(e2) ? 29 : 28 : [4, 6, 9, 11].indexOf(t2) >= 0 ? 30 : 31;
  }
  maximumMonthLength(e2) {
    return this.minimumMonthLength(e2);
  }
  maxLengthOfMonthCodeInAnyYear(e2) {
    return [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][Qo(e2) - 1];
  }
  completeEraYear(e2) {
    const t2 = (t3, n3, r3) => {
      const o3 = e2[t3];
      if (null != o3 && o3 != n3 && !(r3 || []).includes(o3)) {
        const e3 = r3?.[0];
        throw new RangeError(`Input ${t3} ${o3} doesn't match calculated value ${e3 ? `${n3} (also called ${e3})` : n3}`);
      }
    }, n2 = (t3) => {
      let n3;
      const r3 = { ...e2, year: t3 }, o3 = this.eras.find(((e3, o4) => {
        if (o4 === this.eras.length - 1) {
          if (e3.reverseOf) {
            if (t3 > 0) throw new RangeError(`Signed year ${t3} is invalid for era ${e3.code}`);
            return n3 = e3.anchorEpoch.year - t3, true;
          }
          return n3 = t3 - e3.anchorEpoch.year + (e3.hasYearZero ? 0 : 1), true;
        }
        return this.compareCalendarDates(r3, e3.anchorEpoch) >= 0 && (n3 = t3 - e3.anchorEpoch.year + (e3.hasYearZero ? 0 : 1), true);
      }));
      if (!o3) throw new RangeError(`Year ${t3} was not matched by any era`);
      return { eraYear: n3, era: o3.code, eraNames: o3.names };
    };
    let { year: r2, eraYear: o2, era: i2 } = e2;
    if (null != r2) {
      const e3 = n2(r2);
      ({ eraYear: o2, era: i2 } = e3), t2("era", i2, e3?.eraNames), t2("eraYear", o2);
    } else {
      if (null == o2) throw new RangeError("Either year or eraYear and era are required");
      {
        if (void 0 === i2) throw new RangeError("era and eraYear must be provided together");
        const e3 = this.eras.find((({ code: e4, names: t3 = [] }) => e4 === i2 || t3.includes(i2)));
        if (!e3) throw new RangeError(`Era ${i2} (ISO year ${o2}) was not matched by any era`);
        r2 = e3.reverseOf ? e3.anchorEpoch.year - o2 : o2 + e3.anchorEpoch.year - (e3.hasYearZero ? 0 : 1), t2("year", r2), { eraYear: o2, era: i2 } = n2(r2);
      }
    }
    return { ...e2, year: r2, eraYear: o2, era: i2 };
  }
  adjustCalendarDate(e2, t2, n2 = "constrain") {
    let r2 = e2;
    const { month: o2, monthCode: i2 } = r2;
    return void 0 === o2 && (r2 = { ...r2, month: Qo(i2) }), this.validateCalendarDate(r2), r2 = this.completeEraYear(r2), super.adjustCalendarDate(r2, t2, n2);
  }
  estimateIsoDate(e2) {
    const t2 = this.adjustCalendarDate(e2), { year: n2, month: r2, day: o2 } = t2, { anchorEra: i2 } = this;
    return St(n2 + i2.isoEpoch.year - (i2.hasYearZero ? 0 : 1), r2, o2, "constrain");
  }
};
var SameMonthDayAsGregorianBaseHelper = class extends GregorianBaseHelper {
  constructor(e2, t2) {
    super(e2, t2);
  }
  isoToCalendarDate(e2) {
    const { year: t2, month: n2, day: r2 } = e2, o2 = ei(n2), i2 = t2 - this.anchorEra.isoEpoch.year + 1;
    return this.completeEraYear({ year: i2, month: n2, monthCode: o2, day: r2 });
  }
};
var ii = { inLeapYear(e2) {
  const { year: t2 } = e2;
  return (t2 + 1) % 4 == 0;
}, monthsInYear: () => 13, minimumMonthLength(e2) {
  const { month: t2 } = e2;
  return 13 === t2 ? this.inLeapYear(e2) ? 6 : 5 : 30;
}, maximumMonthLength(e2) {
  return this.minimumMonthLength(e2);
}, maxLengthOfMonthCodeInAnyYear: (e2) => "M13" === e2 ? 6 : 30 };
var OrthodoxBaseHelperFixedEpoch = class extends GregorianBaseHelperFixedEpoch {
  constructor(e2, t2) {
    super(e2, t2), this.inLeapYear = ii.inLeapYear, this.monthsInYear = ii.monthsInYear, this.minimumMonthLength = ii.minimumMonthLength, this.maximumMonthLength = ii.maximumMonthLength, this.maxLengthOfMonthCodeInAnyYear = ii.maxLengthOfMonthCodeInAnyYear;
  }
};
var OrthodoxBaseHelper = class extends GregorianBaseHelper {
  constructor(e2, t2) {
    super(e2, t2), this.inLeapYear = ii.inLeapYear, this.monthsInYear = ii.monthsInYear, this.minimumMonthLength = ii.minimumMonthLength, this.maximumMonthLength = ii.maximumMonthLength, this.maxLengthOfMonthCodeInAnyYear = ii.maxLengthOfMonthCodeInAnyYear;
  }
};
var EthioaaHelper = class extends OrthodoxBaseHelperFixedEpoch {
  constructor() {
    super("ethioaa", { year: -5492, month: 7, day: 17 });
  }
};
var CopticHelper = class extends OrthodoxBaseHelper {
  constructor() {
    super("coptic", [{ code: "coptic", isoEpoch: { year: 284, month: 8, day: 29 } }, { code: "coptic-inverse", reverseOf: "coptic" }]);
  }
};
var EthiopicHelper = class extends OrthodoxBaseHelper {
  constructor() {
    super("ethiopic", [{ code: "ethioaa", names: ["ethiopic-amete-alem", "mundi"], isoEpoch: { year: -5492, month: 7, day: 17 } }, { code: "ethiopic", names: ["incar"], isoEpoch: { year: 8, month: 8, day: 27 }, anchorEpoch: { year: 5501 } }]);
  }
};
var RocHelper = class extends SameMonthDayAsGregorianBaseHelper {
  constructor() {
    super("roc", [{ code: "roc", names: ["minguo"], isoEpoch: { year: 1912, month: 1, day: 1 } }, { code: "roc-inverse", names: ["before-roc"], reverseOf: "roc" }]);
  }
};
var BuddhistHelper = class extends GregorianBaseHelperFixedEpoch {
  constructor() {
    super("buddhist", { year: -543, month: 1, day: 1 });
  }
};
var GregoryHelper = class extends SameMonthDayAsGregorianBaseHelper {
  constructor() {
    super("gregory", [{ code: "gregory", names: ["ad", "ce"], isoEpoch: { year: 1, month: 1, day: 1 } }, { code: "gregory-inverse", names: ["be", "bce"], reverseOf: "gregory" }]);
  }
  reviseIntlEra(e2) {
    let { era: t2, eraYear: n2 } = e2;
    return "b" === t2 && (t2 = "gregory-inverse"), "a" === t2 && (t2 = "gregory"), { era: t2, eraYear: n2 };
  }
  getFirstDayOfWeek() {
    return 1;
  }
  getMinimalDaysInFirstWeek() {
    return 1;
  }
};
var JapaneseHelper = class extends SameMonthDayAsGregorianBaseHelper {
  constructor() {
    super("japanese", [{ code: "reiwa", isoEpoch: { year: 2019, month: 5, day: 1 }, anchorEpoch: { year: 2019, month: 5, day: 1 } }, { code: "heisei", isoEpoch: { year: 1989, month: 1, day: 8 }, anchorEpoch: { year: 1989, month: 1, day: 8 } }, { code: "showa", isoEpoch: { year: 1926, month: 12, day: 25 }, anchorEpoch: { year: 1926, month: 12, day: 25 } }, { code: "taisho", isoEpoch: { year: 1912, month: 7, day: 30 }, anchorEpoch: { year: 1912, month: 7, day: 30 } }, { code: "meiji", isoEpoch: { year: 1868, month: 9, day: 8 }, anchorEpoch: { year: 1868, month: 9, day: 8 } }, { code: "japanese", names: ["japanese", "gregory", "ad", "ce"], isoEpoch: { year: 1, month: 1, day: 1 } }, { code: "japanese-inverse", names: ["japanese-inverse", "gregory-inverse", "bc", "bce"], reverseOf: "japanese" }]), this.erasBeginMidYear = true;
  }
  reviseIntlEra(e2, t2) {
    const { era: n2, eraYear: r2 } = e2, { year: o2 } = t2;
    return this.eras.find(((e3) => e3.code === n2)) ? { era: n2, eraYear: r2 } : o2 < 1 ? { era: "japanese-inverse", eraYear: 1 - o2 } : { era: "japanese", eraYear: o2 };
  }
};
var ChineseBaseHelper = class extends HelperBase {
  constructor() {
    super(...arguments), this.calendarType = "lunisolar";
  }
  inLeapYear(e2, t2) {
    const n2 = this.getMonthList(e2.year, t2);
    return 13 === Object.entries(n2).length;
  }
  monthsInYear(e2, t2) {
    return this.inLeapYear(e2, t2) ? 13 : 12;
  }
  minimumMonthLength() {
    return 29;
  }
  maximumMonthLength() {
    return 30;
  }
  maxLengthOfMonthCodeInAnyYear(e2) {
    return ["M01L", "M09L", "M10L", "M11L", "M12L"].includes(e2) ? 29 : 30;
  }
  monthDaySearchStartYear(e2, t2) {
    const n2 = { M01L: [1651, 1651], M02L: [1947, 1765], M03L: [1966, 1955], M04L: [1963, 1944], M05L: [1971, 1952], M06L: [1960, 1941], M07L: [1968, 1938], M08L: [1957, 1718], M09L: [1832, 1832], M10L: [1870, 1870], M11L: [1814, 1814], M12L: [1890, 1890] }[e2] ?? [1972, 1972];
    return t2 < 30 ? n2[0] : n2[1];
  }
  getMonthList(e2, t2) {
    if (void 0 === e2) throw new TypeError("Missing year");
    const n2 = JSON.stringify({ func: "getMonthList", calendarYear: e2, id: this.id }), r2 = t2.get(n2);
    if (r2) return r2;
    const o2 = this.getFormatter(), i2 = (e3, t3) => {
      const n3 = ni({ isoYear: e3, isoMonth: 2, isoDay: 1 }), r3 = new Date(n3);
      r3.setUTCDate(t3 + 1);
      const i3 = o2.formatToParts(r3), a3 = i3.find(((e4) => "month" === e4.type)).value, s3 = +i3.find(((e4) => "day" === e4.type)).value, c3 = i3.find(((e4) => "relatedYear" === e4.type));
      let d3;
      if (void 0 === c3) throw new RangeError(`Intl.DateTimeFormat.formatToParts lacks relatedYear in ${this.id} calendar. Try Node 14+ or modern browsers.`);
      return d3 = +c3.value, { calendarMonthString: a3, calendarDay: s3, calendarYearToVerify: d3 };
    };
    let a2 = 17, { calendarMonthString: s2, calendarDay: c2, calendarYearToVerify: d2 } = i2(e2, a2);
    "1" !== s2 && (a2 += 29, { calendarMonthString: s2, calendarDay: c2 } = i2(e2, a2)), a2 -= c2 - 5;
    const h2 = {};
    let u2, l2, m2 = 1, f2 = false;
    do {
      ({ calendarMonthString: s2, calendarDay: c2, calendarYearToVerify: d2 } = i2(e2, a2)), u2 && (h2[l2].daysInMonth = u2 + 30 - c2), d2 !== e2 ? f2 = true : (h2[s2] = { monthIndex: m2++ }, a2 += 30), u2 = c2, l2 = s2;
    } while (!f2);
    return h2[l2].daysInMonth = u2 + 30 - c2, t2.set(n2, h2), h2;
  }
  estimateIsoDate(e2) {
    const { year: t2, month: n2 } = e2;
    return { year: t2, month: n2 >= 12 ? 12 : n2 + 1, day: 1 };
  }
  adjustCalendarDate(e2, t2, n2 = "constrain", r2 = false) {
    let { year: o2, month: i2, monthExtra: a2, day: s2, monthCode: c2 } = e2;
    if (void 0 === o2) throw new TypeError("Missing property: year");
    if (r2) {
      if (a2 && "bis" !== a2) throw new RangeError(`Unexpected leap month suffix: ${a2}`);
      const e3 = ei(i2, void 0 !== a2), n3 = `${i2}${a2 || ""}`, r3 = this.getMonthList(o2, t2)[n3];
      if (void 0 === r3) throw new RangeError(`Unmatched month ${n3} in Chinese year ${o2}`);
      return i2 = r3.monthIndex, { year: o2, month: i2, day: s2, monthCode: e3 };
    }
    if (this.validateCalendarDate(e2), void 0 === i2) {
      const e3 = this.getMonthList(o2, t2);
      let r3 = c2.replace(/^M|L$/g, ((e4) => "L" === e4 ? "bis" : ""));
      "0" === r3[0] && (r3 = r3.slice(1));
      let a3 = e3[r3];
      if (i2 = a3 && a3.monthIndex, void 0 === i2 && c2.endsWith("L") && "M13L" != c2 && "constrain" === n2) {
        const t3 = +c2.replace(/^M0?|L$/g, "");
        a3 = e3[t3], a3 && (i2 = a3.monthIndex, c2 = ei(t3));
      }
      if (void 0 === i2) throw new RangeError(`Unmatched month ${c2} in Chinese year ${o2}`);
    } else if (void 0 === c2) {
      const e3 = this.getMonthList(o2, t2), r3 = Object.entries(e3), a3 = r3.length;
      "reject" === n2 ? (Nr(i2, 1, a3), Nr(s2, 1, this.maximumMonthLength())) : (i2 = jr(i2, 1, a3), s2 = jr(s2, 1, this.maximumMonthLength()));
      const d2 = r3.find(((e4) => e4[1].monthIndex === i2));
      if (void 0 === d2) throw new RangeError(`Invalid month ${i2} in Chinese year ${o2}`);
      c2 = ei(+d2[0].replace("bis", ""), -1 !== d2[0].indexOf("bis"));
    } else {
      const e3 = this.getMonthList(o2, t2);
      let n3 = c2.replace(/^M|L$/g, ((e4) => "L" === e4 ? "bis" : ""));
      "0" === n3[0] && (n3 = n3.slice(1));
      const r3 = e3[n3];
      if (!r3) throw new RangeError(`Unmatched monthCode ${c2} in Chinese year ${o2}`);
      if (i2 !== r3.monthIndex) throw new RangeError(`monthCode ${c2} doesn't correspond to month ${i2} in Chinese year ${o2}`);
    }
    return { ...e2, year: o2, month: i2, monthCode: c2, day: s2 };
  }
};
var ChineseHelper = class extends ChineseBaseHelper {
  constructor() {
    super(...arguments), this.id = "chinese";
  }
};
var DangiHelper = class extends ChineseBaseHelper {
  constructor() {
    super(...arguments), this.id = "dangi";
  }
};
var NonIsoCalendar = class {
  constructor(e2) {
    this.helper = e2;
  }
  extraFields(e2) {
    return this.helper.hasEra && e2.includes("year") ? ["era", "eraYear"] : [];
  }
  resolveFields(e2) {
    if ("lunisolar" !== this.helper.calendarType) {
      const t2 = new OneObjectCache();
      ti(e2, void 0, this.helper.monthsInYear({ year: e2.year ?? 1972 }, t2));
    }
  }
  dateToISO(e2, t2) {
    const n2 = new OneObjectCache(), r2 = this.helper.calendarToIsoDate(e2, t2, n2);
    return n2.setObject(r2), r2;
  }
  monthDayToISOReferenceDate(e2, t2) {
    const n2 = new OneObjectCache(), r2 = this.helper.monthDayFromFields(e2, t2, n2);
    return n2.setObject(r2), r2;
  }
  fieldKeysToIgnore(e2) {
    const t2 = /* @__PURE__ */ new Set();
    for (let n2 = 0; n2 < e2.length; n2++) {
      const r2 = e2[n2];
      switch (t2.add(r2), r2) {
        case "era":
          t2.add("eraYear"), t2.add("year");
          break;
        case "eraYear":
          t2.add("era"), t2.add("year");
          break;
        case "year":
          t2.add("era"), t2.add("eraYear");
          break;
        case "month":
          t2.add("monthCode"), this.helper.erasBeginMidYear && (t2.add("era"), t2.add("eraYear"));
          break;
        case "monthCode":
          t2.add("month"), this.helper.erasBeginMidYear && (t2.add("era"), t2.add("eraYear"));
          break;
        case "day":
          this.helper.erasBeginMidYear && (t2.add("era"), t2.add("eraYear"));
      }
    }
    return Go(t2);
  }
  dateAdd(e2, { years: t2, months: n2, weeks: r2, days: o2 }, i2) {
    const a2 = OneObjectCache.getCacheForObject(e2), s2 = this.helper.isoToCalendarDate(e2, a2), c2 = this.helper.addCalendar(s2, { years: t2, months: n2, weeks: r2, days: o2 }, i2, a2), d2 = this.helper.calendarToIsoDate(c2, "constrain", a2);
    return OneObjectCache.getCacheForObject(d2) || new OneObjectCache(a2).setObject(d2), d2;
  }
  dateUntil(e2, t2, n2) {
    const r2 = OneObjectCache.getCacheForObject(e2), o2 = OneObjectCache.getCacheForObject(t2), i2 = this.helper.isoToCalendarDate(e2, r2), a2 = this.helper.isoToCalendarDate(t2, o2);
    return this.helper.untilCalendar(i2, a2, n2, r2);
  }
  isoToDate(e2, t2) {
    const n2 = OneObjectCache.getCacheForObject(e2), r2 = this.helper.isoToCalendarDate(e2, n2);
    if (t2.dayOfWeek && (r2.dayOfWeek = Xo.iso8601.isoToDate(e2, { dayOfWeek: true }).dayOfWeek), t2.dayOfYear) {
      const e3 = this.helper.startOfCalendarYear(r2), t3 = this.helper.calendarDaysUntil(e3, r2, n2);
      r2.dayOfYear = t3 + 1;
    }
    if (t2.weekOfYear && (r2.weekOfYear = Ko(this.helper.id, e2)), r2.daysInWeek = 7, t2.daysInMonth && (r2.daysInMonth = this.helper.daysInMonth(r2, n2)), t2.daysInYear) {
      const e3 = this.helper.startOfCalendarYear(r2), t3 = this.helper.addCalendar(e3, { years: 1 }, "constrain", n2);
      r2.daysInYear = this.helper.calendarDaysUntil(e3, t3, n2);
    }
    return t2.monthsInYear && (r2.monthsInYear = this.helper.monthsInYear(r2, n2)), t2.inLeapYear && (r2.inLeapYear = this.helper.inLeapYear(r2, n2)), r2;
  }
  getFirstDayOfWeek() {
    return this.helper.getFirstDayOfWeek();
  }
  getMinimalDaysInFirstWeek() {
    return this.helper.getMinimalDaysInFirstWeek();
  }
};
for (const e2 of [HebrewHelper, PersianHelper, EthiopicHelper, EthioaaHelper, CopticHelper, ChineseHelper, DangiHelper, RocHelper, IndianHelper, BuddhistHelper, GregoryHelper, JapaneseHelper, IslamicHelper, IslamicUmalquraHelper, IslamicTblaHelper, IslamicCivilHelper, IslamicRgsaHelper, IslamicCcHelper]) {
  const t2 = new e2();
  Xo[t2.id] = new NonIsoCalendar(t2);
}
se("calendarImpl", (function(e2) {
  return Xo[e2];
}));
var ai = Intl.DateTimeFormat;
function si(e2, t2) {
  let n2 = re(e2, t2);
  return "function" == typeof n2 && (n2 = new ai(re(e2, G), n2(re(e2, K))), (function(e3, t3, n3) {
    const r2 = Q(e3);
    if (void 0 === r2) throw new TypeError("Missing slots for the given container");
    if (void 0 === r2[t3]) throw new TypeError(`tried to reset ${t3} which was not set`);
    r2[t3] = n3;
  })(e2, t2, n2)), n2;
}
function ci(e2) {
  return ne(e2, q);
}
var DateTimeFormatImpl = class {
  constructor(e2 = void 0, t2 = void 0) {
    !(function(e3, t3, n2) {
      const r2 = void 0 !== n2;
      let o2;
      if (r2) {
        const e4 = ["localeMatcher", "calendar", "numberingSystem", "hour12", "hourCycle", "timeZone", "weekday", "era", "year", "month", "day", "dayPeriod", "hour", "minute", "second", "fractionalSecondDigits", "timeZoneName", "formatMatcher", "dateStyle", "timeStyle"];
        o2 = (function(e5) {
          if (null == e5) throw new TypeError(`Expected object not ${e5}`);
          return Object(e5);
        })(n2);
        const t4 = /* @__PURE__ */ Object.create(null);
        for (let n3 = 0; n3 < e4.length; n3++) {
          const r3 = e4[n3];
          Object.prototype.hasOwnProperty.call(o2, r3) && (t4[r3] = o2[r3]);
        }
        o2 = t4;
      } else o2 = /* @__PURE__ */ Object.create(null);
      const i2 = new ai(t3, o2), a2 = i2.resolvedOptions();
      if (te(e3), r2) {
        const t4 = Object.assign(/* @__PURE__ */ Object.create(null), a2);
        for (const e4 in t4) Object.prototype.hasOwnProperty.call(o2, e4) || delete t4[e4];
        t4.hour12 = o2.hour12, t4.hourCycle = o2.hourCycle, oe(e3, K, t4);
      } else oe(e3, K, o2);
      oe(e3, G, a2.locale), oe(e3, q, i2), oe(e3, W, a2.timeZone), oe(e3, J, a2.calendar), oe(e3, B, vi), oe(e3, Z, gi), oe(e3, F, wi), oe(e3, H, pi), oe(e3, z, bi), oe(e3, A, Di);
      const s2 = r2 ? o2.timeZone : void 0;
      if (void 0 === s2) oe(e3, _, a2.timeZone);
      else {
        const t4 = We(s2);
        if (t4.startsWith("\u2212")) throw new RangeError("Unicode minus (U+2212) is not supported in time zone offsets");
        oe(e3, _, Bn(t4));
      }
    })(this, e2, t2);
  }
  get format() {
    vt(this, ci);
    const e2 = ui.bind(this);
    return Object.defineProperties(e2, { length: { value: 1, enumerable: false, writable: false, configurable: true }, name: { value: "", enumerable: false, writable: false, configurable: true } }), e2;
  }
  formatRange(e2, t2) {
    return vt(this, ci), mi.call(this, e2, t2);
  }
  formatToParts(e2, ...t2) {
    return vt(this, ci), li.call(this, e2, ...t2);
  }
  formatRangeToParts(e2, t2) {
    return vt(this, ci), fi.call(this, e2, t2);
  }
  resolvedOptions() {
    return vt(this, ci), hi.call(this);
  }
};
"formatToParts" in ai.prototype || delete DateTimeFormatImpl.prototype.formatToParts, "formatRangeToParts" in ai.prototype || delete DateTimeFormatImpl.prototype.formatRangeToParts;
var di = function(e2 = void 0, t2 = void 0) {
  return new DateTimeFormatImpl(e2, t2);
};
function hi() {
  const e2 = re(this, q).resolvedOptions();
  return e2.timeZone = re(this, _), e2;
}
function ui(e2, ...t2) {
  let n2, r2, o2 = $i(e2, this);
  return o2.formatter ? (n2 = o2.formatter, r2 = [No(o2.epochNs, "floor")]) : (n2 = re(this, q), r2 = [e2, ...t2]), n2.format(...r2);
}
function li(e2, ...t2) {
  let n2, r2, o2 = $i(e2, this);
  return o2.formatter ? (n2 = o2.formatter, r2 = [No(o2.epochNs, "floor")]) : (n2 = re(this, q), r2 = [e2, ...t2]), n2.formatToParts(...r2);
}
function mi(e2, t2) {
  if (void 0 === e2 || void 0 === t2) throw new TypeError("Intl.DateTimeFormat.formatRange requires two values");
  const n2 = Ci(e2), r2 = Ci(t2);
  let o2, i2 = [n2, r2];
  if (Ii(n2) !== Ii(r2)) throw new TypeError("Intl.DateTimeFormat.formatRange accepts two values of the same type");
  if (Ii(n2)) {
    if (!Oi(n2, r2)) throw new TypeError("Intl.DateTimeFormat.formatRange accepts two values of the same type");
    const { epochNs: e3, formatter: t3 } = $i(n2, this), { epochNs: a2, formatter: s2 } = $i(r2, this);
    t3 && (o2 = t3, i2 = [No(e3, "floor"), No(a2, "floor")]);
  }
  return o2 || (o2 = re(this, q)), o2.formatRange(...i2);
}
function fi(e2, t2) {
  if (void 0 === e2 || void 0 === t2) throw new TypeError("Intl.DateTimeFormat.formatRange requires two values");
  const n2 = Ci(e2), r2 = Ci(t2);
  let o2, i2 = [n2, r2];
  if (Ii(n2) !== Ii(r2)) throw new TypeError("Intl.DateTimeFormat.formatRangeToParts accepts two values of the same type");
  if (Ii(n2)) {
    if (!Oi(n2, r2)) throw new TypeError("Intl.DateTimeFormat.formatRangeToParts accepts two values of the same type");
    const { epochNs: e3, formatter: t3 } = $i(n2, this), { epochNs: a2, formatter: s2 } = $i(r2, this);
    t3 && (o2 = t3, i2 = [No(e3, "floor"), No(a2, "floor")]);
  }
  return o2 || (o2 = re(this, q)), o2.formatRangeToParts(...i2);
}
function yi(e2 = {}, t2 = {}) {
  const n2 = Object.assign({}, e2), r2 = ["year", "month", "day", "hour", "minute", "second", "weekday", "dayPeriod", "timeZoneName", "dateStyle", "timeStyle"];
  for (let e3 = 0; e3 < r2.length; e3++) {
    const o2 = r2[e3];
    n2[o2] = o2 in t2 ? t2[o2] : n2[o2], false !== n2[o2] && void 0 !== n2[o2] || delete n2[o2];
  }
  return n2;
}
function pi(e2) {
  const t2 = yi(e2, { year: false, month: false, day: false, weekday: false, timeZoneName: false, dateStyle: false });
  if ("long" !== t2.timeStyle && "full" !== t2.timeStyle || (delete t2.timeStyle, Object.assign(t2, { hour: "numeric", minute: "2-digit", second: "2-digit" })), !Mi(t2)) {
    if (Ei(e2)) throw new TypeError(`cannot format Temporal.PlainTime with options [${Object.keys(e2)}]`);
    Object.assign(t2, { hour: "numeric", minute: "numeric", second: "numeric" });
  }
  return t2;
}
function gi(e2) {
  const t2 = { short: { year: "2-digit", month: "numeric" }, medium: { year: "numeric", month: "short" }, long: { year: "numeric", month: "long" }, full: { year: "numeric", month: "long" } }, n2 = yi(e2, { day: false, hour: false, minute: false, second: false, weekday: false, dayPeriod: false, timeZoneName: false, timeStyle: false });
  if ("dateStyle" in n2 && n2.dateStyle) {
    const e3 = n2.dateStyle;
    delete n2.dateStyle, Object.assign(n2, t2[e3]);
  }
  if (!("year" in n2 || "month" in n2 || "era" in n2)) {
    if (Ei(e2)) throw new TypeError(`cannot format PlainYearMonth with options [${Object.keys(e2)}]`);
    Object.assign(n2, { year: "numeric", month: "numeric" });
  }
  return n2;
}
function wi(e2) {
  const t2 = { short: { month: "numeric", day: "numeric" }, medium: { month: "short", day: "numeric" }, long: { month: "long", day: "numeric" }, full: { month: "long", day: "numeric" } }, n2 = yi(e2, { year: false, hour: false, minute: false, second: false, weekday: false, dayPeriod: false, timeZoneName: false, timeStyle: false });
  if ("dateStyle" in n2 && n2.dateStyle) {
    const e3 = n2.dateStyle;
    delete n2.dateStyle, Object.assign(n2, t2[e3]);
  }
  if (!("month" in n2) && !("day" in n2)) {
    if (Ei(e2)) throw new TypeError(`cannot format PlainMonthDay with options [${Object.keys(e2)}]`);
    Object.assign(n2, { month: "numeric", day: "numeric" });
  }
  return n2;
}
function vi(e2) {
  const t2 = yi(e2, { hour: false, minute: false, second: false, dayPeriod: false, timeZoneName: false, timeStyle: false });
  if (!Ti(t2)) {
    if (Ei(e2)) throw new TypeError(`cannot format PlainDate with options [${Object.keys(e2)}]`);
    Object.assign(t2, { year: "numeric", month: "numeric", day: "numeric" });
  }
  return t2;
}
function bi(e2) {
  const t2 = yi(e2, { timeZoneName: false });
  if (("long" === t2.timeStyle || "full" === t2.timeStyle) && (delete t2.timeStyle, Object.assign(t2, { hour: "numeric", minute: "2-digit", second: "2-digit" }), t2.dateStyle)) {
    const e3 = { short: { year: "numeric", month: "numeric", day: "numeric" }, medium: { year: "numeric", month: "short", day: "numeric" }, long: { year: "numeric", month: "long", day: "numeric" }, full: { year: "numeric", month: "long", day: "numeric", weekday: "long" } };
    Object.assign(t2, e3[t2.dateStyle]), delete t2.dateStyle;
  }
  if (!Mi(t2) && !Ti(t2)) {
    if (Ei(e2)) throw new TypeError(`cannot format PlainDateTime with options [${Object.keys(e2)}]`);
    Object.assign(t2, { year: "numeric", month: "numeric", day: "numeric", hour: "numeric", minute: "numeric", second: "numeric" });
  }
  return t2;
}
function Di(e2) {
  let t2 = e2;
  return Mi(t2) || Ti(t2) || (t2 = Object.assign({}, t2, { year: "numeric", month: "numeric", day: "numeric", hour: "numeric", minute: "numeric", second: "numeric" })), t2;
}
function Ti(e2) {
  return "year" in e2 || "month" in e2 || "day" in e2 || "weekday" in e2 || "dateStyle" in e2 || "era" in e2;
}
function Mi(e2) {
  return "hour" in e2 || "minute" in e2 || "second" in e2 || "timeStyle" in e2 || "dayPeriod" in e2 || "fractionalSecondDigits" in e2;
}
function Ei(e2) {
  return Ti(e2) || Mi(e2) || "dateStyle" in e2 || "timeStyle" in e2 || "timeZoneName" in e2;
}
function Ii(e2) {
  return mt(e2) || ft(e2) || yt(e2) || wt(e2) || pt(e2) || gt(e2) || ut(e2);
}
function Ci(e2) {
  return Ii(e2) ? e2 : qe(e2);
}
function Oi(e2, t2) {
  return !(!Ii(e2) || !Ii(t2) || ft(e2) && !ft(t2) || mt(e2) && !mt(t2) || yt(e2) && !yt(t2) || wt(e2) && !wt(t2) || pt(e2) && !pt(t2) || gt(e2) && !gt(t2) || ut(e2) && !ut(t2));
}
function $i(e2, t2) {
  if (ft(e2)) {
    const n2 = { isoDate: { year: 1970, month: 1, day: 1 }, time: re(e2, M) };
    return { epochNs: An(re(t2, W), n2, "compatible"), formatter: si(t2, H) };
  }
  if (pt(e2)) {
    const n2 = re(e2, E), r2 = re(t2, J);
    if (n2 !== r2) throw new RangeError(`cannot format PlainYearMonth with calendar ${n2} in locale with calendar ${r2}`);
    const o2 = xt(re(e2, D), { deltaDays: 0, hour: 12, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 });
    return { epochNs: An(re(t2, W), o2, "compatible"), formatter: si(t2, Z) };
  }
  if (gt(e2)) {
    const n2 = re(e2, E), r2 = re(t2, J);
    if (n2 !== r2) throw new RangeError(`cannot format PlainMonthDay with calendar ${n2} in locale with calendar ${r2}`);
    const o2 = xt(re(e2, D), { deltaDays: 0, hour: 12, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 });
    return { epochNs: An(re(t2, W), o2, "compatible"), formatter: si(t2, F) };
  }
  if (mt(e2)) {
    const n2 = re(e2, E), r2 = re(t2, J);
    if ("iso8601" !== n2 && n2 !== r2) throw new RangeError(`cannot format PlainDate with calendar ${n2} in locale with calendar ${r2}`);
    const o2 = xt(re(e2, D), { deltaDays: 0, hour: 12, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 });
    return { epochNs: An(re(t2, W), o2, "compatible"), formatter: si(t2, B) };
  }
  if (yt(e2)) {
    const n2 = re(e2, E), r2 = re(t2, J);
    if ("iso8601" !== n2 && n2 !== r2) throw new RangeError(`cannot format PlainDateTime with calendar ${n2} in locale with calendar ${r2}`);
    const o2 = re(e2, T);
    return { epochNs: An(re(t2, W), o2, "compatible"), formatter: si(t2, z) };
  }
  if (wt(e2)) throw new TypeError("Temporal.ZonedDateTime not supported in DateTimeFormat methods. Use toLocaleString() instead.");
  return ut(e2) ? { epochNs: re(e2, b), formatter: si(t2, A) } : {};
}
function Yi(e2) {
  const t2 = /* @__PURE__ */ Object.create(null);
  return t2.years = re(e2, Y), t2.months = re(e2, R), t2.weeks = re(e2, S), t2.days = re(e2, j), t2.hours = re(e2, k), t2.minutes = re(e2, N), t2.seconds = re(e2, x), t2.milliseconds = re(e2, L), t2.microseconds = re(e2, P), t2.nanoseconds = re(e2, U), t2;
}
DateTimeFormatImpl.prototype.constructor = di, Object.defineProperty(di, "prototype", { value: DateTimeFormatImpl.prototype, writable: false, enumerable: false, configurable: false }), di.supportedLocalesOf = ai.supportedLocalesOf, ae(di, "Intl.DateTimeFormat");
var { format: Ri, formatToParts: Si } = Intl.DurationFormat?.prototype ?? /* @__PURE__ */ Object.create(null);
function ji(e2) {
  Intl.DurationFormat.prototype.resolvedOptions.call(this);
  const t2 = Yi(sn(e2));
  return Ri.call(this, t2);
}
Intl.DurationFormat?.prototype && (Intl.DurationFormat.prototype.format = ji, Intl.DurationFormat.prototype.formatToParts = function(e2) {
  Intl.DurationFormat.prototype.resolvedOptions.call(this);
  const t2 = Yi(sn(e2));
  return Si.call(this, t2);
});
var ki = Object.freeze({ __proto__: null, DateTimeFormat: di, ModifiedIntlDurationFormatPrototypeFormat: ji });
var Instant = class {
  constructor(e2) {
    if (arguments.length < 1) throw new TypeError("missing argument: epochNanoseconds is required");
    In(this, Lo(e2));
  }
  get epochMilliseconds() {
    return vt(this, ut), No(re(this, b), "floor");
  }
  get epochNanoseconds() {
    return vt(this, ut), ko(import_jsbi.default.BigInt(re(this, b)));
  }
  add(e2) {
    return vt(this, ut), wo("add", this, e2);
  }
  subtract(e2) {
    return vt(this, ut), wo("subtract", this, e2);
  }
  until(e2, t2 = void 0) {
    return vt(this, ut), so("until", this, e2, t2);
  }
  since(e2, t2 = void 0) {
    return vt(this, ut), so("since", this, e2, t2);
  }
  round(e2) {
    if (vt(this, ut), void 0 === e2) throw new TypeError("options parameter is required");
    const t2 = "string" == typeof e2 ? Fo("smallestUnit", e2) : Zo(e2), n2 = Ft(t2), r2 = Ut(t2, "halfExpand"), o2 = Wt(t2, "smallestUnit", "time", qt);
    return Ht(n2, { hour: 24, minute: 1440, second: 86400, millisecond: 864e5, microsecond: 864e8, nanosecond: 864e11 }[o2], true), Cn(Io(re(this, b), n2, o2, r2));
  }
  equals(t2) {
    vt(this, ut);
    const n2 = cn(t2), r2 = re(this, b), o2 = re(n2, b);
    return import_jsbi.default.equal(import_jsbi.default.BigInt(r2), import_jsbi.default.BigInt(o2));
  }
  toString(e2 = void 0) {
    vt(this, ut);
    const t2 = Zo(e2), n2 = zt(t2), r2 = Ut(t2, "trunc"), o2 = Wt(t2, "smallestUnit", "time", void 0);
    if ("hour" === o2) throw new RangeError('smallestUnit must be a time unit other than "hour"');
    let i2 = t2.timeZone;
    void 0 !== i2 && (i2 = Bn(i2));
    const { precision: a2, unit: s2, increment: c2 } = At(o2, n2);
    return Xn(Cn(Io(re(this, b), c2, s2, r2)), i2, a2);
  }
  toJSON() {
    return vt(this, ut), Xn(this, void 0, "auto");
  }
  toLocaleString(e2 = void 0, t2 = void 0) {
    return vt(this, ut), new di(e2, t2).format(this);
  }
  valueOf() {
    qo("Instant");
  }
  toZonedDateTimeISO(e2) {
    vt(this, ut);
    const t2 = Bn(e2);
    return $n(re(this, b), t2, "iso8601");
  }
  static fromEpochMilliseconds(e2) {
    return Cn(xo(qe(e2)));
  }
  static fromEpochNanoseconds(e2) {
    return Cn(Lo(e2));
  }
  static from(e2) {
    return cn(e2);
  }
  static compare(t2, n2) {
    const r2 = cn(t2), o2 = cn(n2), i2 = re(r2, b), a2 = re(o2, b);
    return import_jsbi.default.lessThan(i2, a2) ? -1 : import_jsbi.default.greaterThan(i2, a2) ? 1 : 0;
  }
};
ae(Instant, "Temporal.Instant");
var PlainDate = class {
  constructor(e2, t2, n2, r2 = "iso8601") {
    const o2 = _e(e2), i2 = _e(t2), a2 = _e(n2), s2 = zo(void 0 === r2 ? "iso8601" : Ve(r2));
    xr(o2, i2, a2), yn(this, { year: o2, month: i2, day: a2 }, s2);
  }
  get calendarId() {
    return vt(this, mt), re(this, E);
  }
  get era() {
    return Ni(this, "era");
  }
  get eraYear() {
    return Ni(this, "eraYear");
  }
  get year() {
    return Ni(this, "year");
  }
  get month() {
    return Ni(this, "month");
  }
  get monthCode() {
    return Ni(this, "monthCode");
  }
  get day() {
    return Ni(this, "day");
  }
  get dayOfWeek() {
    return Ni(this, "dayOfWeek");
  }
  get dayOfYear() {
    return Ni(this, "dayOfYear");
  }
  get weekOfYear() {
    return Ni(this, "weekOfYear")?.week;
  }
  get yearOfWeek() {
    return Ni(this, "weekOfYear")?.year;
  }
  get daysInWeek() {
    return Ni(this, "daysInWeek");
  }
  get daysInMonth() {
    return Ni(this, "daysInMonth");
  }
  get daysInYear() {
    return Ni(this, "daysInYear");
  }
  get monthsInYear() {
    return Ni(this, "monthsInYear");
  }
  get inLeapYear() {
    return Ni(this, "inLeapYear");
  }
  with(e2, t2 = void 0) {
    if (vt(this, mt), !Ae(e2)) throw new TypeError("invalid argument");
    bt(e2);
    const n2 = re(this, E);
    let r2 = en(n2, re(this, D));
    return r2 = Rn(n2, r2, tn(n2, e2, ["year", "month", "monthCode", "day"], [], "partial")), pn(Ln(n2, r2, Lt(Zo(t2))), n2);
  }
  withCalendar(e2) {
    vt(this, mt);
    const t2 = kn(e2);
    return pn(re(this, D), t2);
  }
  add(e2, t2 = void 0) {
    return vt(this, mt), vo("add", this, e2, t2);
  }
  subtract(e2, t2 = void 0) {
    return vt(this, mt), vo("subtract", this, e2, t2);
  }
  until(e2, t2 = void 0) {
    return vt(this, mt), co("until", this, e2, t2);
  }
  since(e2, t2 = void 0) {
    return vt(this, mt), co("since", this, e2, t2);
  }
  equals(e2) {
    vt(this, mt);
    const t2 = rn(e2);
    return 0 === Ro(re(this, D), re(t2, D)) && xn(re(this, E), re(t2, E));
  }
  toString(e2 = void 0) {
    return vt(this, mt), er(this, Zt(Zo(e2)));
  }
  toJSON() {
    return vt(this, mt), er(this);
  }
  toLocaleString(e2 = void 0, t2 = void 0) {
    return vt(this, mt), new di(e2, t2).format(this);
  }
  valueOf() {
    qo("PlainDate");
  }
  toPlainDateTime(e2 = void 0) {
    vt(this, mt);
    const t2 = un(e2);
    return wn(xt(re(this, D), t2), re(this, E));
  }
  toZonedDateTime(e2) {
    let t2, n2;
    if (vt(this, mt), Ae(e2)) {
      const r3 = e2.timeZone;
      void 0 === r3 ? t2 = Bn(e2) : (t2 = Bn(r3), n2 = e2.plainTime);
    } else t2 = Bn(e2);
    const r2 = re(this, D);
    let o2;
    return void 0 === n2 ? o2 = _n(t2, r2) : (n2 = hn(n2), o2 = An(t2, xt(r2, re(n2, M)), "compatible")), $n(o2, t2, re(this, E));
  }
  toPlainYearMonth() {
    vt(this, mt);
    const e2 = re(this, E);
    return En(Pn(e2, en(e2, re(this, D)), "constrain"), e2);
  }
  toPlainMonthDay() {
    vt(this, mt);
    const e2 = re(this, E);
    return bn(Un(e2, en(e2, re(this, D)), "constrain"), e2);
  }
  static from(e2, t2 = void 0) {
    return rn(e2, t2);
  }
  static compare(e2, t2) {
    const n2 = rn(e2), r2 = rn(t2);
    return Ro(re(n2, D), re(r2, D));
  }
};
function Ni(e2, t2) {
  vt(e2, mt);
  const n2 = re(e2, D);
  return Qt(e2).isoToDate(n2, { [t2]: true })[t2];
}
ae(PlainDate, "Temporal.PlainDate");
var PlainDateTime = class {
  constructor(e2, t2, n2, r2 = 0, o2 = 0, i2 = 0, a2 = 0, s2 = 0, c2 = 0, d2 = "iso8601") {
    const h2 = _e(e2), u2 = _e(t2), l2 = _e(n2), m2 = void 0 === r2 ? 0 : _e(r2), f2 = void 0 === o2 ? 0 : _e(o2), y2 = void 0 === i2 ? 0 : _e(i2), p2 = void 0 === a2 ? 0 : _e(a2), g2 = void 0 === s2 ? 0 : _e(s2), w2 = void 0 === c2 ? 0 : _e(c2), v2 = zo(void 0 === d2 ? "iso8601" : Ve(d2));
    Ur(h2, u2, l2, m2, f2, y2, p2, g2, w2), gn(this, { isoDate: { year: h2, month: u2, day: l2 }, time: { hour: m2, minute: f2, second: y2, millisecond: p2, microsecond: g2, nanosecond: w2 } }, v2);
  }
  get calendarId() {
    return vt(this, yt), re(this, E);
  }
  get year() {
    return xi(this, "year");
  }
  get month() {
    return xi(this, "month");
  }
  get monthCode() {
    return xi(this, "monthCode");
  }
  get day() {
    return xi(this, "day");
  }
  get hour() {
    return Li(this, "hour");
  }
  get minute() {
    return Li(this, "minute");
  }
  get second() {
    return Li(this, "second");
  }
  get millisecond() {
    return Li(this, "millisecond");
  }
  get microsecond() {
    return Li(this, "microsecond");
  }
  get nanosecond() {
    return Li(this, "nanosecond");
  }
  get era() {
    return xi(this, "era");
  }
  get eraYear() {
    return xi(this, "eraYear");
  }
  get dayOfWeek() {
    return xi(this, "dayOfWeek");
  }
  get dayOfYear() {
    return xi(this, "dayOfYear");
  }
  get weekOfYear() {
    return xi(this, "weekOfYear")?.week;
  }
  get yearOfWeek() {
    return xi(this, "weekOfYear")?.year;
  }
  get daysInWeek() {
    return xi(this, "daysInWeek");
  }
  get daysInYear() {
    return xi(this, "daysInYear");
  }
  get daysInMonth() {
    return xi(this, "daysInMonth");
  }
  get monthsInYear() {
    return xi(this, "monthsInYear");
  }
  get inLeapYear() {
    return xi(this, "inLeapYear");
  }
  with(e2, t2 = void 0) {
    if (vt(this, yt), !Ae(e2)) throw new TypeError("invalid argument");
    bt(e2);
    const n2 = re(this, E), r2 = re(this, T);
    let o2 = { ...en(n2, r2.isoDate), ...r2.time };
    return o2 = Rn(n2, o2, tn(n2, e2, ["year", "month", "monthCode", "day"], ["hour", "minute", "second", "millisecond", "microsecond", "nanosecond"], "partial")), wn(on(n2, o2, Lt(Zo(t2))), n2);
  }
  withPlainTime(e2 = void 0) {
    vt(this, yt);
    const t2 = un(e2);
    return wn(xt(re(this, T).isoDate, t2), re(this, E));
  }
  withCalendar(e2) {
    vt(this, yt);
    const t2 = kn(e2);
    return wn(re(this, T), t2);
  }
  add(e2, t2 = void 0) {
    return vt(this, yt), bo("add", this, e2, t2);
  }
  subtract(e2, t2 = void 0) {
    return vt(this, yt), bo("subtract", this, e2, t2);
  }
  until(e2, t2 = void 0) {
    return vt(this, yt), ho("until", this, e2, t2);
  }
  since(e2, t2 = void 0) {
    return vt(this, yt), ho("since", this, e2, t2);
  }
  round(e2) {
    if (vt(this, yt), void 0 === e2) throw new TypeError("options parameter is required");
    const t2 = "string" == typeof e2 ? Fo("smallestUnit", e2) : Zo(e2), n2 = Ft(t2), r2 = Ut(t2, "halfExpand"), o2 = Wt(t2, "smallestUnit", "time", qt, ["day"]), i2 = { day: 1, hour: 24, minute: 60, second: 60, millisecond: 1e3, microsecond: 1e3, nanosecond: 1e3 }[o2];
    Ht(n2, i2, 1 === i2);
    const a2 = re(this, T);
    return wn(1 === n2 && "nanosecond" === o2 ? a2 : Co(a2, n2, o2, r2), re(this, E));
  }
  equals(e2) {
    vt(this, yt);
    const t2 = an(e2);
    return 0 === jo(re(this, T), re(t2, T)) && xn(re(this, E), re(t2, E));
  }
  toString(e2 = void 0) {
    vt(this, yt);
    const t2 = Zo(e2), n2 = Zt(t2), r2 = zt(t2), o2 = Ut(t2, "trunc"), i2 = Wt(t2, "smallestUnit", "time", void 0);
    if ("hour" === i2) throw new RangeError('smallestUnit must be a time unit other than "hour"');
    const { precision: a2, unit: s2, increment: c2 } = At(i2, r2), d2 = Co(re(this, T), c2, s2, o2);
    return Br(d2), nr(d2, re(this, E), a2, n2);
  }
  toJSON() {
    return vt(this, yt), nr(re(this, T), re(this, E), "auto");
  }
  toLocaleString(e2 = void 0, t2 = void 0) {
    return vt(this, yt), new di(e2, t2).format(this);
  }
  valueOf() {
    qo("PlainDateTime");
  }
  toZonedDateTime(e2, t2 = void 0) {
    vt(this, yt);
    const n2 = Bn(e2), r2 = Pt(Zo(t2));
    return $n(An(n2, re(this, T), r2), n2, re(this, E));
  }
  toPlainDate() {
    return vt(this, yt), pn(re(this, T).isoDate, re(this, E));
  }
  toPlainTime() {
    return vt(this, yt), Tn(re(this, T).time);
  }
  static from(e2, t2 = void 0) {
    return an(e2, t2);
  }
  static compare(e2, t2) {
    const n2 = an(e2), r2 = an(t2);
    return jo(re(n2, T), re(r2, T));
  }
};
function xi(e2, t2) {
  vt(e2, yt);
  const n2 = re(e2, T).isoDate;
  return Qt(e2).isoToDate(n2, { [t2]: true })[t2];
}
function Li(e2, t2) {
  return vt(e2, yt), re(e2, T).time[t2];
}
ae(PlainDateTime, "Temporal.PlainDateTime");
var Duration = class _Duration {
  constructor(e2 = 0, t2 = 0, n2 = 0, r2 = 0, o2 = 0, i2 = 0, a2 = 0, s2 = 0, c2 = 0, d2 = 0) {
    const h2 = void 0 === e2 ? 0 : Ge(e2), u2 = void 0 === t2 ? 0 : Ge(t2), l2 = void 0 === n2 ? 0 : Ge(n2), m2 = void 0 === r2 ? 0 : Ge(r2), f2 = void 0 === o2 ? 0 : Ge(o2), y2 = void 0 === i2 ? 0 : Ge(i2), p2 = void 0 === a2 ? 0 : Ge(a2), g2 = void 0 === s2 ? 0 : Ge(s2), w2 = void 0 === c2 ? 0 : Ge(c2), v2 = void 0 === d2 ? 0 : Ge(d2);
    zr(h2, u2, l2, m2, f2, y2, p2, g2, w2, v2), te(this), oe(this, Y, h2), oe(this, R, u2), oe(this, S, l2), oe(this, j, m2), oe(this, k, f2), oe(this, N, y2), oe(this, x, p2), oe(this, L, g2), oe(this, P, w2), oe(this, U, v2);
  }
  get years() {
    return vt(this, lt), re(this, Y);
  }
  get months() {
    return vt(this, lt), re(this, R);
  }
  get weeks() {
    return vt(this, lt), re(this, S);
  }
  get days() {
    return vt(this, lt), re(this, j);
  }
  get hours() {
    return vt(this, lt), re(this, k);
  }
  get minutes() {
    return vt(this, lt), re(this, N);
  }
  get seconds() {
    return vt(this, lt), re(this, x);
  }
  get milliseconds() {
    return vt(this, lt), re(this, L);
  }
  get microseconds() {
    return vt(this, lt), re(this, P);
  }
  get nanoseconds() {
    return vt(this, lt), re(this, U);
  }
  get sign() {
    return vt(this, lt), Mr(this);
  }
  get blank() {
    return vt(this, lt), 0 === Mr(this);
  }
  with(e2) {
    vt(this, lt);
    const t2 = kt(e2), { years: n2 = re(this, Y), months: r2 = re(this, R), weeks: o2 = re(this, S), days: i2 = re(this, j), hours: a2 = re(this, k), minutes: s2 = re(this, N), seconds: c2 = re(this, x), milliseconds: d2 = re(this, L), microseconds: h2 = re(this, P), nanoseconds: u2 = re(this, U) } = t2;
    return new _Duration(n2, r2, o2, i2, a2, s2, c2, d2, h2, u2);
  }
  negated() {
    return vt(this, lt), Sr(this);
  }
  abs() {
    return vt(this, lt), new _Duration(Math.abs(re(this, Y)), Math.abs(re(this, R)), Math.abs(re(this, S)), Math.abs(re(this, j)), Math.abs(re(this, k)), Math.abs(re(this, N)), Math.abs(re(this, x)), Math.abs(re(this, L)), Math.abs(re(this, P)), Math.abs(re(this, U)));
  }
  add(e2) {
    return vt(this, lt), go("add", this, e2);
  }
  subtract(e2) {
    return vt(this, lt), go("subtract", this, e2);
  }
  round(e2) {
    if (vt(this, lt), void 0 === e2) throw new TypeError("options parameter is required");
    const t2 = Jt(this), n2 = "string" == typeof e2 ? Fo("smallestUnit", e2) : Zo(e2);
    let r2 = Wt(n2, "largestUnit", "datetime", void 0, ["auto"]), { plainRelativeTo: o2, zonedRelativeTo: i2 } = _t(n2);
    const a2 = Ft(n2), s2 = Ut(n2, "halfExpand");
    let c2 = Wt(n2, "smallestUnit", "datetime", void 0), d2 = true;
    c2 || (d2 = false, c2 = "nanosecond");
    const h2 = Gt(t2, c2);
    let u2 = true;
    if (r2 || (u2 = false, r2 = h2), "auto" === r2 && (r2 = h2), !d2 && !u2) throw new RangeError("at least one of smallestUnit or largestUnit is required");
    if (Gt(r2, c2) !== r2) throw new RangeError(`largestUnit ${r2} cannot be smaller than smallestUnit ${c2}`);
    const l2 = { hour: 24, minute: 60, second: 60, millisecond: 1e3, microsecond: 1e3, nanosecond: 1e3 }[c2];
    if (void 0 !== l2 && Ht(a2, l2, false), a2 > 1 && "date" === Vt(c2) && r2 !== c2) throw new RangeError("For calendar units with roundingIncrement > 1, use largestUnit = smallestUnit");
    if (i2) {
      let e3 = Ar(this);
      const t3 = re(i2, $), n3 = re(i2, E), o3 = re(i2, b);
      return e3 = io(o3, po(o3, t3, n3, e3), t3, n3, r2, a2, c2, s2), "date" === Vt(r2) && (r2 = "hour"), _r(e3, r2);
    }
    if (o2) {
      let e3 = qr(this);
      const t3 = fo({ deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 }, e3.time), n3 = re(o2, D), i3 = re(o2, E), d3 = Sn(i3, n3, Nt(e3.date, t3.deltaDays), "constrain");
      return e3 = oo(xt(n3, { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 }), xt(d3, t3), i3, r2, a2, c2, s2), _r(e3, r2);
    }
    if (Kt(t2)) throw new RangeError(`a starting point is required for ${t2}s balancing`);
    if (Kt(r2)) throw new RangeError(`a starting point is required for ${r2}s balancing`);
    let m2 = qr(this);
    if ("day" === c2) {
      const { quotient: e3, remainder: t3 } = m2.time.divmod(Se);
      let n3 = m2.date.days + e3 + Yo(t3, "day");
      n3 = Eo(n3, a2, s2), m2 = Jr({ years: 0, months: 0, weeks: 0, days: n3 }, TimeDuration.ZERO);
    } else m2 = Jr({ years: 0, months: 0, weeks: 0, days: 0 }, $o(m2.time, a2, c2, s2));
    return _r(m2, r2);
  }
  total(t2) {
    if (vt(this, lt), void 0 === t2) throw new TypeError("options argument is required");
    const n2 = "string" == typeof t2 ? Fo("unit", t2) : Zo(t2);
    let { plainRelativeTo: r2, zonedRelativeTo: o2 } = _t(n2);
    const i2 = Wt(n2, "unit", "datetime", qt);
    if (o2) {
      const e2 = Ar(this), t3 = re(o2, $), n3 = re(o2, E), r3 = re(o2, b);
      return (function(e3, t4, n4, r4, o3) {
        return "time" === Vt(o3) ? Yo(TimeDuration.fromEpochNsDiff(t4, e3), o3) : ro(eo(e3, t4, n4, r4, o3), t4, zn(n4, e3), n4, r4, o3);
      })(r3, po(r3, t3, n3, e2), t3, n3, i2);
    }
    if (r2) {
      const t3 = qr(this);
      let n3 = fo({ deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 }, t3.time);
      const o3 = re(r2, D), a3 = re(r2, E), s2 = Sn(a3, o3, Nt(t3.date, n3.deltaDays), "constrain");
      return (function(t4, n4, r3, o4) {
        if (0 == jo(t4, n4)) return 0;
        Br(t4), Br(n4);
        const i3 = Qr(t4, n4, r3, o4);
        return "nanosecond" === o4 ? import_jsbi.default.toNumber(i3.time.totalNs) : ro(i3, pr(n4), t4, null, r3, o4);
      })(xt(o3, { deltaDays: 0, hour: 0, minute: 0, second: 0, millisecond: 0, microsecond: 0, nanosecond: 0 }), xt(s2, n3), a3, i2);
    }
    const a2 = Jt(this);
    if (Kt(a2)) throw new RangeError(`a starting point is required for ${a2}s total`);
    if (Kt(i2)) throw new RangeError(`a starting point is required for ${i2}s total`);
    return Yo(qr(this).time, i2);
  }
  toString(e2 = void 0) {
    vt(this, lt);
    const t2 = Zo(e2), n2 = zt(t2), r2 = Ut(t2, "trunc"), o2 = Wt(t2, "smallestUnit", "time", void 0);
    if ("hour" === o2 || "minute" === o2) throw new RangeError('smallestUnit must be a time unit other than "hours" or "minutes"');
    const { precision: i2, unit: a2, increment: s2 } = At(o2, n2);
    if ("nanosecond" === a2 && 1 === s2) return Qn(this, i2);
    const c2 = Jt(this);
    let d2 = Ar(this);
    const h2 = $o(d2.time, s2, a2, r2);
    return d2 = Jr(d2.date, h2), Qn(_r(d2, Gt(c2, "second")), i2);
  }
  toJSON() {
    return vt(this, lt), Qn(this, "auto");
  }
  toLocaleString(e2 = void 0, t2 = void 0) {
    if (vt(this, lt), "function" == typeof Intl.DurationFormat) {
      const n2 = new Intl.DurationFormat(e2, t2);
      return ji.call(n2, this);
    }
    return console.warn("Temporal.Duration.prototype.toLocaleString() requires Intl.DurationFormat."), Qn(this, "auto");
  }
  valueOf() {
    qo("Duration");
  }
  static from(e2) {
    return sn(e2);
  }
  static compare(t2, n2, r2 = void 0) {
    const o2 = sn(t2), i2 = sn(n2), a2 = Zo(r2), { plainRelativeTo: s2, zonedRelativeTo: c2 } = _t(a2);
    if (re(o2, Y) === re(i2, Y) && re(o2, R) === re(i2, R) && re(o2, S) === re(i2, S) && re(o2, j) === re(i2, j) && re(o2, k) === re(i2, k) && re(o2, N) === re(i2, N) && re(o2, x) === re(i2, x) && re(o2, L) === re(i2, L) && re(o2, P) === re(i2, P) && re(o2, U) === re(i2, U)) return 0;
    const d2 = Jt(o2), h2 = Jt(i2), u2 = Ar(o2), l2 = Ar(i2);
    if (c2 && ("date" === Vt(d2) || "date" === Vt(h2))) {
      const t3 = re(c2, $), n3 = re(c2, E), r3 = re(c2, b), o3 = po(r3, t3, n3, u2), i3 = po(r3, t3, n3, l2);
      return Bo(import_jsbi.default.toNumber(import_jsbi.default.subtract(o3, i3)));
    }
    let m2 = u2.date.days, f2 = l2.date.days;
    if (Kt(d2) || Kt(h2)) {
      if (!s2) throw new RangeError("A starting point is required for years, months, or weeks comparison");
      m2 = Rr(u2.date, s2), f2 = Rr(l2.date, s2);
    }
    const y2 = u2.time.add24HourDays(m2), p2 = l2.time.add24HourDays(f2);
    return y2.cmp(p2);
  }
};
ae(Duration, "Temporal.Duration");
var PlainMonthDay = class {
  constructor(e2, t2, n2 = "iso8601", r2 = 1972) {
    const o2 = _e(e2), i2 = _e(t2), a2 = zo(void 0 === n2 ? "iso8601" : Ve(n2)), s2 = _e(r2);
    xr(s2, o2, i2), vn(this, { year: s2, month: o2, day: i2 }, a2);
  }
  get monthCode() {
    return Pi(this, "monthCode");
  }
  get day() {
    return Pi(this, "day");
  }
  get calendarId() {
    return vt(this, gt), re(this, E);
  }
  with(e2, t2 = void 0) {
    if (vt(this, gt), !Ae(e2)) throw new TypeError("invalid argument");
    bt(e2);
    const n2 = re(this, E);
    let r2 = en(n2, re(this, D), "month-day");
    return r2 = Rn(n2, r2, tn(n2, e2, ["year", "month", "monthCode", "day"], [], "partial")), bn(Un(n2, r2, Lt(Zo(t2))), n2);
  }
  equals(e2) {
    vt(this, gt);
    const t2 = dn(e2);
    return 0 === Ro(re(this, D), re(t2, D)) && xn(re(this, E), re(t2, E));
  }
  toString(e2 = void 0) {
    return vt(this, gt), rr(this, Zt(Zo(e2)));
  }
  toJSON() {
    return vt(this, gt), rr(this);
  }
  toLocaleString(e2 = void 0, t2 = void 0) {
    return vt(this, gt), new di(e2, t2).format(this);
  }
  valueOf() {
    qo("PlainMonthDay");
  }
  toPlainDate(e2) {
    if (vt(this, gt), !Ae(e2)) throw new TypeError("argument should be an object");
    const t2 = re(this, E);
    return pn(Ln(t2, Rn(t2, en(t2, re(this, D), "month-day"), tn(t2, e2, ["year"], [], [])), "constrain"), t2);
  }
  static from(e2, t2 = void 0) {
    return dn(e2, t2);
  }
};
function Pi(e2, t2) {
  vt(e2, gt);
  const n2 = re(e2, D);
  return Qt(e2).isoToDate(n2, { [t2]: true })[t2];
}
function Ui(e2) {
  return zn(e2, Po());
}
ae(PlainMonthDay, "Temporal.PlainMonthDay");
var Bi = { instant: () => Cn(Po()), plainDateTimeISO: (e2 = Uo()) => wn(Ui(Bn(e2)), "iso8601"), plainDateISO: (e2 = Uo()) => pn(Ui(Bn(e2)).isoDate, "iso8601"), plainTimeISO: (e2 = Uo()) => Tn(Ui(Bn(e2)).time), timeZoneId: () => Uo(), zonedDateTimeISO: (e2 = Uo()) => {
  const t2 = Bn(e2);
  return $n(Po(), t2, "iso8601");
}, [Symbol.toStringTag]: "Temporal.Now" };
Object.defineProperty(Bi, Symbol.toStringTag, { value: "Temporal.Now", writable: false, enumerable: false, configurable: true });
var PlainTime = class _PlainTime {
  constructor(e2 = 0, t2 = 0, n2 = 0, r2 = 0, o2 = 0, i2 = 0) {
    const a2 = void 0 === e2 ? 0 : _e(e2), s2 = void 0 === t2 ? 0 : _e(t2), c2 = void 0 === n2 ? 0 : _e(n2), d2 = void 0 === r2 ? 0 : _e(r2), h2 = void 0 === o2 ? 0 : _e(o2), u2 = void 0 === i2 ? 0 : _e(i2);
    Pr(a2, s2, c2, d2, h2, u2), Dn(this, { hour: a2, minute: s2, second: c2, millisecond: d2, microsecond: h2, nanosecond: u2 });
  }
  get hour() {
    return vt(this, ft), re(this, M).hour;
  }
  get minute() {
    return vt(this, ft), re(this, M).minute;
  }
  get second() {
    return vt(this, ft), re(this, M).second;
  }
  get millisecond() {
    return vt(this, ft), re(this, M).millisecond;
  }
  get microsecond() {
    return vt(this, ft), re(this, M).microsecond;
  }
  get nanosecond() {
    return vt(this, ft), re(this, M).nanosecond;
  }
  with(e2, t2 = void 0) {
    if (vt(this, ft), !Ae(e2)) throw new TypeError("invalid argument");
    bt(e2);
    const n2 = nn(e2, "partial"), r2 = nn(this);
    let { hour: o2, minute: i2, second: a2, millisecond: s2, microsecond: c2, nanosecond: d2 } = Object.assign(r2, n2);
    const h2 = Lt(Zo(t2));
    return { hour: o2, minute: i2, second: a2, millisecond: s2, microsecond: c2, nanosecond: d2 } = jt(o2, i2, a2, s2, c2, d2, h2), new _PlainTime(o2, i2, a2, s2, c2, d2);
  }
  add(e2) {
    return vt(this, ft), Do("add", this, e2);
  }
  subtract(e2) {
    return vt(this, ft), Do("subtract", this, e2);
  }
  until(e2, t2 = void 0) {
    return vt(this, ft), uo("until", this, e2, t2);
  }
  since(e2, t2 = void 0) {
    return vt(this, ft), uo("since", this, e2, t2);
  }
  round(e2) {
    if (vt(this, ft), void 0 === e2) throw new TypeError("options parameter is required");
    const t2 = "string" == typeof e2 ? Fo("smallestUnit", e2) : Zo(e2), n2 = Ft(t2), r2 = Ut(t2, "halfExpand"), o2 = Wt(t2, "smallestUnit", "time", qt);
    return Ht(n2, { hour: 24, minute: 60, second: 60, millisecond: 1e3, microsecond: 1e3, nanosecond: 1e3 }[o2], false), Tn(Oo(re(this, M), n2, o2, r2));
  }
  equals(e2) {
    vt(this, ft);
    const t2 = hn(e2);
    return 0 === So(re(this, M), re(t2, M));
  }
  toString(e2 = void 0) {
    vt(this, ft);
    const t2 = Zo(e2), n2 = zt(t2), r2 = Ut(t2, "trunc"), o2 = Wt(t2, "smallestUnit", "time", void 0);
    if ("hour" === o2) throw new RangeError('smallestUnit must be a time unit other than "hour"');
    const { precision: i2, unit: a2, increment: s2 } = At(o2, n2);
    return tr(Oo(re(this, M), s2, a2, r2), i2);
  }
  toJSON() {
    return vt(this, ft), tr(re(this, M), "auto");
  }
  toLocaleString(e2 = void 0, t2 = void 0) {
    return vt(this, ft), new di(e2, t2).format(this);
  }
  valueOf() {
    qo("PlainTime");
  }
  static from(e2, t2 = void 0) {
    return hn(e2, t2);
  }
  static compare(e2, t2) {
    const n2 = hn(e2), r2 = hn(t2);
    return So(re(n2, M), re(r2, M));
  }
};
ae(PlainTime, "Temporal.PlainTime");
var PlainYearMonth = class {
  constructor(e2, t2, n2 = "iso8601", r2 = 1) {
    const o2 = _e(e2), i2 = _e(t2), a2 = zo(void 0 === n2 ? "iso8601" : Ve(n2)), s2 = _e(r2);
    xr(o2, i2, s2), Mn(this, { year: o2, month: i2, day: s2 }, a2);
  }
  get year() {
    return Zi(this, "year");
  }
  get month() {
    return Zi(this, "month");
  }
  get monthCode() {
    return Zi(this, "monthCode");
  }
  get calendarId() {
    return vt(this, pt), re(this, E);
  }
  get era() {
    return Zi(this, "era");
  }
  get eraYear() {
    return Zi(this, "eraYear");
  }
  get daysInMonth() {
    return Zi(this, "daysInMonth");
  }
  get daysInYear() {
    return Zi(this, "daysInYear");
  }
  get monthsInYear() {
    return Zi(this, "monthsInYear");
  }
  get inLeapYear() {
    return Zi(this, "inLeapYear");
  }
  with(e2, t2 = void 0) {
    if (vt(this, pt), !Ae(e2)) throw new TypeError("invalid argument");
    bt(e2);
    const n2 = re(this, E);
    let r2 = en(n2, re(this, D), "year-month");
    return r2 = Rn(n2, r2, tn(n2, e2, ["year", "month", "monthCode"], [], "partial")), En(Pn(n2, r2, Lt(Zo(t2))), n2);
  }
  add(e2, t2 = void 0) {
    return vt(this, pt), To("add", this, e2, t2);
  }
  subtract(e2, t2 = void 0) {
    return vt(this, pt), To("subtract", this, e2, t2);
  }
  until(e2, t2 = void 0) {
    return vt(this, pt), lo("until", this, e2, t2);
  }
  since(e2, t2 = void 0) {
    return vt(this, pt), lo("since", this, e2, t2);
  }
  equals(e2) {
    vt(this, pt);
    const t2 = ln(e2);
    return 0 === Ro(re(this, D), re(t2, D)) && xn(re(this, E), re(t2, E));
  }
  toString(e2 = void 0) {
    return vt(this, pt), or(this, Zt(Zo(e2)));
  }
  toJSON() {
    return vt(this, pt), or(this);
  }
  toLocaleString(e2 = void 0, t2 = void 0) {
    return vt(this, pt), new di(e2, t2).format(this);
  }
  valueOf() {
    qo("PlainYearMonth");
  }
  toPlainDate(e2) {
    if (vt(this, pt), !Ae(e2)) throw new TypeError("argument should be an object");
    const t2 = re(this, E);
    return pn(Ln(t2, Rn(t2, en(t2, re(this, D), "year-month"), tn(t2, e2, ["day"], [], [])), "constrain"), t2);
  }
  static from(e2, t2 = void 0) {
    return ln(e2, t2);
  }
  static compare(e2, t2) {
    const n2 = ln(e2), r2 = ln(t2);
    return Ro(re(n2, D), re(r2, D));
  }
};
function Zi(e2, t2) {
  vt(e2, pt);
  const n2 = re(e2, D);
  return Qt(e2).isoToDate(n2, { [t2]: true })[t2];
}
ae(PlainYearMonth, "Temporal.PlainYearMonth");
var Fi = di.prototype.resolvedOptions;
var ZonedDateTime = class {
  constructor(e2, t2, n2 = "iso8601") {
    if (arguments.length < 1) throw new TypeError("missing argument: epochNanoseconds is required");
    const r2 = Lo(e2);
    let o2 = Ve(t2);
    const { tzName: i2, offsetMinutes: a2 } = Rt(o2);
    if (void 0 === a2) {
      const e3 = hr(i2);
      if (!e3) throw new RangeError(`unknown time zone ${i2}`);
      o2 = e3.identifier;
    } else o2 = mr(a2);
    On(this, r2, o2, zo(void 0 === n2 ? "iso8601" : Ve(n2)));
  }
  get calendarId() {
    return vt(this, wt), re(this, E);
  }
  get timeZoneId() {
    return vt(this, wt), re(this, $);
  }
  get year() {
    return zi(this, "year");
  }
  get month() {
    return zi(this, "month");
  }
  get monthCode() {
    return zi(this, "monthCode");
  }
  get day() {
    return zi(this, "day");
  }
  get hour() {
    return Ai(this, "hour");
  }
  get minute() {
    return Ai(this, "minute");
  }
  get second() {
    return Ai(this, "second");
  }
  get millisecond() {
    return Ai(this, "millisecond");
  }
  get microsecond() {
    return Ai(this, "microsecond");
  }
  get nanosecond() {
    return Ai(this, "nanosecond");
  }
  get era() {
    return zi(this, "era");
  }
  get eraYear() {
    return zi(this, "eraYear");
  }
  get epochMilliseconds() {
    return vt(this, wt), No(re(this, b), "floor");
  }
  get epochNanoseconds() {
    return vt(this, wt), ko(re(this, b));
  }
  get dayOfWeek() {
    return zi(this, "dayOfWeek");
  }
  get dayOfYear() {
    return zi(this, "dayOfYear");
  }
  get weekOfYear() {
    return zi(this, "weekOfYear")?.week;
  }
  get yearOfWeek() {
    return zi(this, "weekOfYear")?.year;
  }
  get hoursInDay() {
    vt(this, wt);
    const e2 = re(this, $), t2 = Hi(this).isoDate, n2 = Or(t2.year, t2.month, t2.day + 1), r2 = _n(e2, t2), o2 = _n(e2, n2);
    return Yo(TimeDuration.fromEpochNsDiff(o2, r2), "hour");
  }
  get daysInWeek() {
    return zi(this, "daysInWeek");
  }
  get daysInMonth() {
    return zi(this, "daysInMonth");
  }
  get daysInYear() {
    return zi(this, "daysInYear");
  }
  get monthsInYear() {
    return zi(this, "monthsInYear");
  }
  get inLeapYear() {
    return zi(this, "inLeapYear");
  }
  get offset() {
    return vt(this, wt), Hn(Fn(re(this, $), re(this, b)));
  }
  get offsetNanoseconds() {
    return vt(this, wt), Fn(re(this, $), re(this, b));
  }
  with(e2, t2 = void 0) {
    if (vt(this, wt), !Ae(e2)) throw new TypeError("invalid zoned-date-time-like");
    bt(e2);
    const n2 = re(this, E), r2 = re(this, $), o2 = Fn(r2, re(this, b)), i2 = Hi(this);
    let a2 = { ...en(n2, i2.isoDate), ...i2.time, offset: Hn(o2) };
    a2 = Rn(n2, a2, tn(n2, e2, ["year", "month", "monthCode", "day"], ["hour", "minute", "second", "millisecond", "microsecond", "nanosecond", "offset"], "partial"));
    const s2 = Zo(t2), c2 = Pt(s2), d2 = Bt(s2, "prefer"), h2 = on(n2, a2, Lt(s2)), u2 = sr(a2.offset);
    return $n(mn(h2.isoDate, h2.time, "option", u2, r2, c2, d2, false), r2, n2);
  }
  withPlainTime(e2 = void 0) {
    vt(this, wt);
    const t2 = re(this, $), n2 = re(this, E), r2 = Hi(this).isoDate;
    let o2;
    return o2 = void 0 === e2 ? _n(t2, r2) : An(t2, xt(r2, re(hn(e2), M)), "compatible"), $n(o2, t2, n2);
  }
  withTimeZone(e2) {
    vt(this, wt);
    const t2 = Bn(e2);
    return $n(re(this, b), t2, re(this, E));
  }
  withCalendar(e2) {
    vt(this, wt);
    const t2 = kn(e2);
    return $n(re(this, b), re(this, $), t2);
  }
  add(e2, t2 = void 0) {
    return vt(this, wt), Mo("add", this, e2, t2);
  }
  subtract(e2, t2 = void 0) {
    return vt(this, wt), Mo("subtract", this, e2, t2);
  }
  until(e2, t2 = void 0) {
    return vt(this, wt), mo("until", this, e2, t2);
  }
  since(e2, t2 = void 0) {
    return vt(this, wt), mo("since", this, e2, t2);
  }
  round(t2) {
    if (vt(this, wt), void 0 === t2) throw new TypeError("options parameter is required");
    const n2 = "string" == typeof t2 ? Fo("smallestUnit", t2) : Zo(t2), r2 = Ft(n2), o2 = Ut(n2, "halfExpand"), i2 = Wt(n2, "smallestUnit", "time", qt, ["day"]), a2 = { day: 1, hour: 24, minute: 60, second: 60, millisecond: 1e3, microsecond: 1e3, nanosecond: 1e3 }[i2];
    if (Ht(r2, a2, 1 === a2), "nanosecond" === i2 && 1 === r2) return $n(re(this, b), re(this, $), re(this, E));
    const s2 = re(this, $), c2 = re(this, b), d2 = Hi(this);
    let h2;
    if ("day" === i2) {
      const t3 = d2.isoDate, n3 = Or(t3.year, t3.month, t3.day + 1), r3 = _n(s2, t3), i3 = _n(s2, n3), a3 = import_jsbi.default.subtract(i3, r3);
      h2 = TimeDuration.fromEpochNsDiff(c2, r3).round(a3, o2).addToEpochNs(r3);
    } else {
      const e2 = Co(d2, r2, i2, o2), t3 = Fn(s2, c2);
      h2 = mn(e2.isoDate, e2.time, "option", t3, s2, "compatible", "prefer", false);
    }
    return $n(h2, s2, re(this, E));
  }
  equals(t2) {
    vt(this, wt);
    const n2 = fn(t2), r2 = re(this, b), o2 = re(n2, b);
    return !!import_jsbi.default.equal(import_jsbi.default.BigInt(r2), import_jsbi.default.BigInt(o2)) && !!Zn(re(this, $), re(n2, $)) && xn(re(this, E), re(n2, E));
  }
  toString(e2 = void 0) {
    vt(this, wt);
    const t2 = Zo(e2), n2 = Zt(t2), r2 = zt(t2), o2 = (function(e3) {
      return Ho(e3, "offset", ["auto", "never"], "auto");
    })(t2), i2 = Ut(t2, "trunc"), a2 = Wt(t2, "smallestUnit", "time", void 0);
    if ("hour" === a2) throw new RangeError('smallestUnit must be a time unit other than "hour"');
    const s2 = (function(e3) {
      return Ho(e3, "timeZoneName", ["auto", "never", "critical"], "auto");
    })(t2), { precision: c2, unit: d2, increment: h2 } = At(a2, r2);
    return ir(this, c2, n2, s2, o2, { unit: d2, increment: h2, roundingMode: i2 });
  }
  toLocaleString(e2 = void 0, t2 = void 0) {
    vt(this, wt);
    const n2 = Zo(t2), r2 = /* @__PURE__ */ Object.create(null);
    if ((function(e3, t3, n3, r3) {
      if (null == t3) return;
      const o3 = Reflect.ownKeys(t3);
      for (let i3 = 0; i3 < o3.length; i3++) {
        const a3 = o3[i3];
        if (!n3.some(((e4) => Object.is(e4, a3))) && Object.prototype.propertyIsEnumerable.call(t3, a3)) {
          const n4 = t3[a3];
          r3, e3[a3] = n4;
        }
      }
    })(r2, n2, ["timeZone"]), void 0 !== n2.timeZone) throw new TypeError("ZonedDateTime toLocaleString does not accept a timeZone option");
    if (void 0 === r2.year && void 0 === r2.month && void 0 === r2.day && void 0 === r2.era && void 0 === r2.weekday && void 0 === r2.dateStyle && void 0 === r2.hour && void 0 === r2.minute && void 0 === r2.second && void 0 === r2.fractionalSecondDigits && void 0 === r2.timeStyle && void 0 === r2.dayPeriod && void 0 === r2.timeZoneName && (r2.timeZoneName = "short"), r2.timeZone = re(this, $), ar(r2.timeZone)) throw new RangeError("toLocaleString does not currently support offset time zones");
    const o2 = new di(e2, r2), i2 = Fi.call(o2).calendar, a2 = re(this, E);
    if ("iso8601" !== a2 && "iso8601" !== i2 && !xn(i2, a2)) throw new RangeError(`cannot format ZonedDateTime with calendar ${a2} in locale with calendar ${i2}`);
    return o2.format(Cn(re(this, b)));
  }
  toJSON() {
    return vt(this, wt), ir(this, "auto");
  }
  valueOf() {
    qo("ZonedDateTime");
  }
  startOfDay() {
    vt(this, wt);
    const e2 = re(this, $);
    return $n(_n(e2, Hi(this).isoDate), e2, re(this, E));
  }
  getTimeZoneTransition(e2) {
    vt(this, wt);
    const t2 = re(this, $);
    if (void 0 === e2) throw new TypeError("options parameter is required");
    const n2 = Ho("string" == typeof e2 ? Fo("direction", e2) : Zo(e2), "direction", ["next", "previous"], qt);
    if (void 0 === n2) throw new TypeError("direction option is required");
    if (ar(t2) || "UTC" === t2) return null;
    const r2 = re(this, b), o2 = "next" === n2 ? wr(t2, r2) : vr(t2, r2);
    return null === o2 ? null : $n(o2, t2, re(this, E));
  }
  toInstant() {
    return vt(this, wt), Cn(re(this, b));
  }
  toPlainDate() {
    return vt(this, wt), pn(Hi(this).isoDate, re(this, E));
  }
  toPlainTime() {
    return vt(this, wt), Tn(Hi(this).time);
  }
  toPlainDateTime() {
    return vt(this, wt), wn(Hi(this), re(this, E));
  }
  static from(e2, t2 = void 0) {
    return fn(e2, t2);
  }
  static compare(t2, n2) {
    const r2 = fn(t2), o2 = fn(n2), i2 = re(r2, b), a2 = re(o2, b);
    return import_jsbi.default.lessThan(import_jsbi.default.BigInt(i2), import_jsbi.default.BigInt(a2)) ? -1 : import_jsbi.default.greaterThan(import_jsbi.default.BigInt(i2), import_jsbi.default.BigInt(a2)) ? 1 : 0;
  }
};
function Hi(e2) {
  return zn(re(e2, $), re(e2, b));
}
function zi(e2, t2) {
  vt(e2, wt);
  const n2 = Hi(e2).isoDate;
  return Qt(e2).isoToDate(n2, { [t2]: true })[t2];
}
function Ai(e2, t2) {
  return vt(e2, wt), Hi(e2).time[t2];
}
ae(ZonedDateTime, "Temporal.ZonedDateTime");
var qi = Object.freeze({ __proto__: null, Duration, Instant, Now: Bi, PlainDate, PlainDateTime, PlainMonthDay, PlainTime, PlainYearMonth, ZonedDateTime });
var Wi = class LegacyDateImpl {
  toTemporalInstant() {
    return Cn(xo(Date.prototype.valueOf.call(this)));
  }
}.prototype.toTemporalInstant;
var _i = [Instant, PlainDate, PlainDateTime, Duration, PlainMonthDay, PlainTime, PlainYearMonth, ZonedDateTime];
for (const e2 of _i) {
  const t2 = Object.getOwnPropertyDescriptor(e2, "prototype");
  (t2.configurable || t2.enumerable || t2.writable) && (t2.configurable = false, t2.enumerable = false, t2.writable = false, Object.defineProperty(e2, "prototype", t2));
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/date-engine/timezone-data.js
var timezoneData = {
  aliases: {
    "Africa/Abidjan": 0,
    "Africa/Accra": 0,
    "Africa/Addis_Ababa": 1,
    "Africa/Algiers": 2,
    "Africa/Asmara": 1,
    "Africa/Asmera": 1,
    "Africa/Bamako": 0,
    "Africa/Bangui": 3,
    "Africa/Banjul": 0,
    "Africa/Bissau": 4,
    "Africa/Blantyre": 5,
    "Africa/Brazzaville": 3,
    "Africa/Bujumbura": 5,
    "Africa/Cairo": 6,
    "Africa/Casablanca": 7,
    "Africa/Ceuta": 8,
    "Africa/Conakry": 0,
    "Africa/Dakar": 0,
    "Africa/Dar_es_Salaam": 1,
    "Africa/Djibouti": 1,
    "Africa/Douala": 3,
    "Africa/El_Aaiun": 9,
    "Africa/Freetown": 0,
    "Africa/Gaborone": 5,
    "Africa/Harare": 5,
    "Africa/Johannesburg": 10,
    "Africa/Juba": 11,
    "Africa/Kampala": 1,
    "Africa/Khartoum": 12,
    "Africa/Kigali": 5,
    "Africa/Kinshasa": 3,
    "Africa/Lagos": 3,
    "Africa/Libreville": 3,
    "Africa/Lome": 0,
    "Africa/Luanda": 3,
    "Africa/Lubumbashi": 5,
    "Africa/Lusaka": 5,
    "Africa/Malabo": 3,
    "Africa/Maputo": 5,
    "Africa/Maseru": 10,
    "Africa/Mbabane": 10,
    "Africa/Mogadishu": 1,
    "Africa/Monrovia": 13,
    "Africa/Nairobi": 1,
    "Africa/Ndjamena": 14,
    "Africa/Niamey": 3,
    "Africa/Nouakchott": 0,
    "Africa/Ouagadougou": 0,
    "Africa/Porto-Novo": 3,
    "Africa/Sao_Tome": 15,
    "Africa/Timbuktu": 0,
    "Africa/Tripoli": 16,
    "Africa/Tunis": 17,
    "Africa/Windhoek": 18,
    "America/Adak": 19,
    "America/Anchorage": 20,
    "America/Anguilla": 21,
    "America/Antigua": 21,
    "America/Araguaina": 22,
    "America/Argentina/Buenos_Aires": 23,
    "America/Argentina/Catamarca": 24,
    "America/Argentina/ComodRivadavia": 24,
    "America/Argentina/Cordoba": 25,
    "America/Argentina/Jujuy": 26,
    "America/Argentina/La_Rioja": 27,
    "America/Argentina/Mendoza": 28,
    "America/Argentina/Rio_Gallegos": 29,
    "America/Argentina/Salta": 30,
    "America/Argentina/San_Juan": 31,
    "America/Argentina/San_Luis": 32,
    "America/Argentina/Tucuman": 33,
    "America/Argentina/Ushuaia": 34,
    "America/Aruba": 21,
    "America/Asuncion": 35,
    "America/Atikokan": 36,
    "America/Atka": 19,
    "America/Bahia": 37,
    "America/Bahia_Banderas": 38,
    "America/Barbados": 39,
    "America/Belem": 40,
    "America/Belize": 41,
    "America/Blanc-Sablon": 21,
    "America/Boa_Vista": 42,
    "America/Bogota": 43,
    "America/Boise": 44,
    "America/Buenos_Aires": 23,
    "America/Cambridge_Bay": 45,
    "America/Campo_Grande": 46,
    "America/Cancun": 47,
    "America/Caracas": 48,
    "America/Catamarca": 24,
    "America/Cayenne": 49,
    "America/Cayman": 36,
    "America/Chicago": 50,
    "America/Chihuahua": 51,
    "America/Ciudad_Juarez": 52,
    "America/Coral_Harbour": 36,
    "America/Cordoba": 25,
    "America/Costa_Rica": 53,
    "America/Coyhaique": 54,
    "America/Creston": 55,
    "America/Cuiaba": 56,
    "America/Curacao": 21,
    "America/Danmarkshavn": 57,
    "America/Dawson": 58,
    "America/Dawson_Creek": 59,
    "America/Denver": 60,
    "America/Detroit": 61,
    "America/Dominica": 21,
    "America/Edmonton": 62,
    "America/Eirunepe": 63,
    "America/El_Salvador": 64,
    "America/Ensenada": 65,
    "America/Fort_Nelson": 66,
    "America/Fort_Wayne": 67,
    "America/Fortaleza": 68,
    "America/Glace_Bay": 69,
    "America/Godthab": 70,
    "America/Goose_Bay": 71,
    "America/Grand_Turk": 72,
    "America/Grenada": 21,
    "America/Guadeloupe": 21,
    "America/Guatemala": 73,
    "America/Guayaquil": 74,
    "America/Guyana": 75,
    "America/Halifax": 76,
    "America/Havana": 77,
    "America/Hermosillo": 78,
    "America/Indiana/Indianapolis": 67,
    "America/Indiana/Knox": 79,
    "America/Indiana/Marengo": 80,
    "America/Indiana/Petersburg": 81,
    "America/Indiana/Tell_City": 82,
    "America/Indiana/Vevay": 83,
    "America/Indiana/Vincennes": 84,
    "America/Indiana/Winamac": 85,
    "America/Indianapolis": 67,
    "America/Inuvik": 86,
    "America/Iqaluit": 87,
    "America/Jamaica": 88,
    "America/Jujuy": 26,
    "America/Juneau": 89,
    "America/Kentucky/Louisville": 90,
    "America/Kentucky/Monticello": 91,
    "America/Knox_IN": 79,
    "America/Kralendijk": 21,
    "America/La_Paz": 92,
    "America/Lima": 93,
    "America/Los_Angeles": 94,
    "America/Louisville": 90,
    "America/Lower_Princes": 21,
    "America/Maceio": 95,
    "America/Managua": 96,
    "America/Manaus": 97,
    "America/Marigot": 21,
    "America/Martinique": 98,
    "America/Matamoros": 99,
    "America/Mazatlan": 100,
    "America/Mendoza": 28,
    "America/Menominee": 101,
    "America/Merida": 102,
    "America/Metlakatla": 103,
    "America/Mexico_City": 104,
    "America/Miquelon": 105,
    "America/Moncton": 106,
    "America/Monterrey": 107,
    "America/Montevideo": 108,
    "America/Montreal": 109,
    "America/Montserrat": 21,
    "America/Nassau": 109,
    "America/New_York": 110,
    "America/Nipigon": 109,
    "America/Nome": 111,
    "America/Noronha": 112,
    "America/North_Dakota/Beulah": 113,
    "America/North_Dakota/Center": 114,
    "America/North_Dakota/New_Salem": 115,
    "America/Nuuk": 70,
    "America/Ojinaga": 116,
    "America/Panama": 36,
    "America/Pangnirtung": 87,
    "America/Paramaribo": 117,
    "America/Phoenix": 55,
    "America/Port-au-Prince": 118,
    "America/Port_of_Spain": 21,
    "America/Porto_Acre": 119,
    "America/Porto_Velho": 120,
    "America/Puerto_Rico": 21,
    "America/Punta_Arenas": 121,
    "America/Rainy_River": 122,
    "America/Rankin_Inlet": 123,
    "America/Recife": 124,
    "America/Regina": 125,
    "America/Resolute": 126,
    "America/Rio_Branco": 119,
    "America/Rosario": 25,
    "America/Santa_Isabel": 65,
    "America/Santarem": 127,
    "America/Santiago": 128,
    "America/Santo_Domingo": 129,
    "America/Sao_Paulo": 130,
    "America/Scoresbysund": 131,
    "America/Shiprock": 60,
    "America/Sitka": 132,
    "America/St_Barthelemy": 21,
    "America/St_Johns": 133,
    "America/St_Kitts": 21,
    "America/St_Lucia": 21,
    "America/St_Thomas": 21,
    "America/St_Vincent": 21,
    "America/Swift_Current": 134,
    "America/Tegucigalpa": 135,
    "America/Thule": 136,
    "America/Thunder_Bay": 109,
    "America/Tijuana": 65,
    "America/Toronto": 109,
    "America/Tortola": 21,
    "America/Vancouver": 137,
    "America/Virgin": 21,
    "America/Whitehorse": 138,
    "America/Winnipeg": 122,
    "America/Yakutat": 139,
    "America/Yellowknife": 62,
    "Antarctica/Casey": 140,
    "Antarctica/Davis": 141,
    "Antarctica/DumontDUrville": 142,
    "Antarctica/Macquarie": 143,
    "Antarctica/Mawson": 144,
    "Antarctica/McMurdo": 145,
    "Antarctica/Palmer": 146,
    "Antarctica/Rothera": 147,
    "Antarctica/South_Pole": 145,
    "Antarctica/Syowa": 148,
    "Antarctica/Troll": 149,
    "Antarctica/Vostok": 150,
    "Arctic/Longyearbyen": 151,
    "Asia/Aden": 148,
    "Asia/Almaty": 152,
    "Asia/Amman": 153,
    "Asia/Anadyr": 154,
    "Asia/Aqtau": 155,
    "Asia/Aqtobe": 156,
    "Asia/Ashgabat": 157,
    "Asia/Ashkhabad": 157,
    "Asia/Atyrau": 158,
    "Asia/Baghdad": 159,
    "Asia/Bahrain": 160,
    "Asia/Baku": 161,
    "Asia/Bangkok": 162,
    "Asia/Barnaul": 163,
    "Asia/Beirut": 164,
    "Asia/Bishkek": 165,
    "Asia/Brunei": 166,
    "Asia/Calcutta": 167,
    "Asia/Chita": 168,
    "Asia/Choibalsan": 169,
    "Asia/Chongqing": 170,
    "Asia/Chungking": 170,
    "Asia/Colombo": 171,
    "Asia/Dacca": 172,
    "Asia/Damascus": 173,
    "Asia/Dhaka": 172,
    "Asia/Dili": 174,
    "Asia/Dubai": 175,
    "Asia/Dushanbe": 176,
    "Asia/Famagusta": 177,
    "Asia/Gaza": 178,
    "Asia/Harbin": 170,
    "Asia/Hebron": 179,
    "Asia/Ho_Chi_Minh": 180,
    "Asia/Hong_Kong": 181,
    "Asia/Hovd": 182,
    "Asia/Irkutsk": 183,
    "Asia/Istanbul": 184,
    "Asia/Jakarta": 185,
    "Asia/Jayapura": 186,
    "Asia/Jerusalem": 187,
    "Asia/Kabul": 188,
    "Asia/Kamchatka": 189,
    "Asia/Karachi": 190,
    "Asia/Kashgar": 191,
    "Asia/Kathmandu": 192,
    "Asia/Katmandu": 192,
    "Asia/Khandyga": 193,
    "Asia/Kolkata": 167,
    "Asia/Krasnoyarsk": 194,
    "Asia/Kuala_Lumpur": 195,
    "Asia/Kuching": 166,
    "Asia/Kuwait": 148,
    "Asia/Macao": 196,
    "Asia/Macau": 196,
    "Asia/Magadan": 197,
    "Asia/Makassar": 198,
    "Asia/Manila": 199,
    "Asia/Muscat": 175,
    "Asia/Nicosia": 200,
    "Asia/Novokuznetsk": 201,
    "Asia/Novosibirsk": 202,
    "Asia/Omsk": 203,
    "Asia/Oral": 204,
    "Asia/Phnom_Penh": 162,
    "Asia/Pontianak": 205,
    "Asia/Pyongyang": 206,
    "Asia/Qatar": 160,
    "Asia/Qostanay": 207,
    "Asia/Qyzylorda": 208,
    "Asia/Rangoon": 209,
    "Asia/Riyadh": 148,
    "Asia/Saigon": 180,
    "Asia/Sakhalin": 210,
    "Asia/Samarkand": 211,
    "Asia/Seoul": 212,
    "Asia/Shanghai": 170,
    "Asia/Singapore": 195,
    "Asia/Srednekolymsk": 213,
    "Asia/Taipei": 214,
    "Asia/Tashkent": 215,
    "Asia/Tbilisi": 216,
    "Asia/Tehran": 217,
    "Asia/Tel_Aviv": 187,
    "Asia/Thimbu": 218,
    "Asia/Thimphu": 218,
    "Asia/Tokyo": 219,
    "Asia/Tomsk": 220,
    "Asia/Ujung_Pandang": 198,
    "Asia/Ulaanbaatar": 169,
    "Asia/Ulan_Bator": 169,
    "Asia/Urumqi": 191,
    "Asia/Ust-Nera": 221,
    "Asia/Vientiane": 162,
    "Asia/Vladivostok": 222,
    "Asia/Yakutsk": 223,
    "Asia/Yangon": 209,
    "Asia/Yekaterinburg": 224,
    "Asia/Yerevan": 225,
    "Atlantic/Azores": 226,
    "Atlantic/Bermuda": 227,
    "Atlantic/Canary": 228,
    "Atlantic/Cape_Verde": 229,
    "Atlantic/Faeroe": 230,
    "Atlantic/Faroe": 230,
    "Atlantic/Jan_Mayen": 151,
    "Atlantic/Madeira": 231,
    "Atlantic/Reykjavik": 0,
    "Atlantic/South_Georgia": 232,
    "Atlantic/St_Helena": 0,
    "Atlantic/Stanley": 233,
    "Australia/ACT": 234,
    "Australia/Adelaide": 235,
    "Australia/Brisbane": 236,
    "Australia/Broken_Hill": 237,
    "Australia/Canberra": 234,
    "Australia/Currie": 238,
    "Australia/Darwin": 239,
    "Australia/Eucla": 240,
    "Australia/Hobart": 238,
    "Australia/LHI": 241,
    "Australia/Lindeman": 242,
    "Australia/Lord_Howe": 241,
    "Australia/Melbourne": 243,
    "Australia/NSW": 234,
    "Australia/North": 239,
    "Australia/Perth": 244,
    "Australia/Queensland": 236,
    "Australia/South": 235,
    "Australia/Sydney": 234,
    "Australia/Tasmania": 238,
    "Australia/Victoria": 243,
    "Australia/West": 244,
    "Australia/Yancowinna": 237,
    "Brazil/Acre": 119,
    "Brazil/DeNoronha": 112,
    "Brazil/East": 130,
    "Brazil/West": 97,
    CET: 245,
    CST6CDT: 246,
    "Canada/Atlantic": 76,
    "Canada/Central": 122,
    "Canada/Eastern": 109,
    "Canada/Mountain": 62,
    "Canada/Newfoundland": 133,
    "Canada/Pacific": 137,
    "Canada/Saskatchewan": 125,
    "Canada/Yukon": 138,
    "Chile/Continental": 128,
    "Chile/EasterIsland": 247,
    Cuba: 77,
    EET: 248,
    EST: 36,
    EST5EDT: 249,
    Egypt: 6,
    Eire: 250,
    "Etc/GMT": 251,
    "Etc/GMT+0": 251,
    "Etc/GMT+1": 252,
    "Etc/GMT+10": 253,
    "Etc/GMT+11": 254,
    "Etc/GMT+12": 255,
    "Etc/GMT+2": 256,
    "Etc/GMT+3": 257,
    "Etc/GMT+4": 258,
    "Etc/GMT+5": 259,
    "Etc/GMT+6": 260,
    "Etc/GMT+7": 261,
    "Etc/GMT+8": 262,
    "Etc/GMT+9": 263,
    "Etc/GMT-0": 251,
    "Etc/GMT-1": 264,
    "Etc/GMT-10": 265,
    "Etc/GMT-11": 266,
    "Etc/GMT-12": 267,
    "Etc/GMT-13": 268,
    "Etc/GMT-14": 269,
    "Etc/GMT-2": 270,
    "Etc/GMT-3": 271,
    "Etc/GMT-4": 272,
    "Etc/GMT-5": 273,
    "Etc/GMT-6": 274,
    "Etc/GMT-7": 275,
    "Etc/GMT-8": 276,
    "Etc/GMT-9": 277,
    "Etc/GMT0": 251,
    "Etc/Greenwich": 251,
    "Etc/UCT": 278,
    "Etc/UTC": 278,
    "Etc/Universal": 278,
    "Etc/Zulu": 278,
    "Europe/Amsterdam": 245,
    "Europe/Andorra": 279,
    "Europe/Astrakhan": 280,
    "Europe/Athens": 248,
    "Europe/Belfast": 281,
    "Europe/Belgrade": 282,
    "Europe/Berlin": 151,
    "Europe/Bratislava": 283,
    "Europe/Brussels": 245,
    "Europe/Bucharest": 284,
    "Europe/Budapest": 285,
    "Europe/Busingen": 286,
    "Europe/Chisinau": 287,
    "Europe/Copenhagen": 151,
    "Europe/Dublin": 250,
    "Europe/Gibraltar": 288,
    "Europe/Guernsey": 281,
    "Europe/Helsinki": 289,
    "Europe/Isle_of_Man": 281,
    "Europe/Istanbul": 184,
    "Europe/Jersey": 281,
    "Europe/Kaliningrad": 290,
    "Europe/Kiev": 291,
    "Europe/Kirov": 292,
    "Europe/Kyiv": 291,
    "Europe/Lisbon": 293,
    "Europe/Ljubljana": 282,
    "Europe/London": 281,
    "Europe/Luxembourg": 245,
    "Europe/Madrid": 294,
    "Europe/Malta": 295,
    "Europe/Mariehamn": 289,
    "Europe/Minsk": 296,
    "Europe/Monaco": 297,
    "Europe/Moscow": 298,
    "Europe/Nicosia": 200,
    "Europe/Oslo": 151,
    "Europe/Paris": 297,
    "Europe/Podgorica": 282,
    "Europe/Prague": 283,
    "Europe/Riga": 299,
    "Europe/Rome": 300,
    "Europe/Samara": 301,
    "Europe/San_Marino": 300,
    "Europe/Sarajevo": 282,
    "Europe/Saratov": 302,
    "Europe/Simferopol": 303,
    "Europe/Skopje": 282,
    "Europe/Sofia": 304,
    "Europe/Stockholm": 151,
    "Europe/Tallinn": 305,
    "Europe/Tirane": 306,
    "Europe/Tiraspol": 287,
    "Europe/Ulyanovsk": 307,
    "Europe/Uzhgorod": 291,
    "Europe/Vaduz": 286,
    "Europe/Vatican": 300,
    "Europe/Vienna": 308,
    "Europe/Vilnius": 309,
    "Europe/Volgograd": 310,
    "Europe/Warsaw": 311,
    "Europe/Zagreb": 282,
    "Europe/Zaporozhye": 291,
    "Europe/Zurich": 286,
    GB: 281,
    "GB-Eire": 281,
    GMT: 251,
    "GMT+0": 251,
    "GMT-0": 251,
    GMT0: 251,
    Greenwich: 251,
    HST: 312,
    Hongkong: 181,
    Iceland: 0,
    "Indian/Antananarivo": 1,
    "Indian/Chagos": 313,
    "Indian/Christmas": 162,
    "Indian/Cocos": 209,
    "Indian/Comoro": 1,
    "Indian/Kerguelen": 314,
    "Indian/Mahe": 175,
    "Indian/Maldives": 314,
    "Indian/Mauritius": 315,
    "Indian/Mayotte": 1,
    "Indian/Reunion": 175,
    Iran: 217,
    Israel: 187,
    Jamaica: 88,
    Japan: 219,
    Kwajalein: 316,
    Libya: 16,
    MET: 245,
    MST: 55,
    MST7MDT: 317,
    "Mexico/BajaNorte": 65,
    "Mexico/BajaSur": 100,
    "Mexico/General": 104,
    NZ: 145,
    "NZ-CHAT": 318,
    Navajo: 60,
    PRC: 170,
    PST8PDT: 319,
    "Pacific/Apia": 320,
    "Pacific/Auckland": 145,
    "Pacific/Bougainville": 321,
    "Pacific/Chatham": 318,
    "Pacific/Chuuk": 142,
    "Pacific/Easter": 247,
    "Pacific/Efate": 322,
    "Pacific/Enderbury": 323,
    "Pacific/Fakaofo": 324,
    "Pacific/Fiji": 325,
    "Pacific/Funafuti": 326,
    "Pacific/Galapagos": 327,
    "Pacific/Gambier": 328,
    "Pacific/Guadalcanal": 329,
    "Pacific/Guam": 330,
    "Pacific/Honolulu": 312,
    "Pacific/Johnston": 312,
    "Pacific/Kanton": 323,
    "Pacific/Kiritimati": 331,
    "Pacific/Kosrae": 332,
    "Pacific/Kwajalein": 316,
    "Pacific/Majuro": 326,
    "Pacific/Marquesas": 333,
    "Pacific/Midway": 334,
    "Pacific/Nauru": 335,
    "Pacific/Niue": 336,
    "Pacific/Norfolk": 337,
    "Pacific/Noumea": 338,
    "Pacific/Pago_Pago": 334,
    "Pacific/Palau": 339,
    "Pacific/Pitcairn": 340,
    "Pacific/Pohnpei": 329,
    "Pacific/Ponape": 329,
    "Pacific/Port_Moresby": 142,
    "Pacific/Rarotonga": 341,
    "Pacific/Saipan": 330,
    "Pacific/Samoa": 334,
    "Pacific/Tahiti": 342,
    "Pacific/Tarawa": 326,
    "Pacific/Tongatapu": 343,
    "Pacific/Truk": 142,
    "Pacific/Wake": 326,
    "Pacific/Wallis": 326,
    "Pacific/Yap": 142,
    Poland: 311,
    Portugal: 293,
    ROC: 214,
    ROK: 212,
    Singapore: 195,
    Turkey: 184,
    UCT: 278,
    "US/Alaska": 20,
    "US/Aleutian": 19,
    "US/Arizona": 55,
    "US/Central": 50,
    "US/East-Indiana": 67,
    "US/Eastern": 110,
    "US/Hawaii": 312,
    "US/Indiana-Starke": 79,
    "US/Michigan": 61,
    "US/Mountain": 60,
    "US/Pacific": 94,
    "US/Samoa": 334,
    UTC: 278,
    Universal: 278,
    "W-SU": 298,
    WET: 293,
    Zulu: 278
  },
  files: [
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAgAAAAj/////kuaSSAH///w4AAAAAAAAAARMTVQAR01UAApHTVQwCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAABAAAABT/////i//R/P////+x7tpY/////7TH4ND/////we2tWP/////MbHrUAQIBAwIAACKEAAAAACMoAAQAACowAAoAACasAA5MTVQAKzAyMzAARUFUACswMjQ1AApFQVQtMwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiAAAABgAAABr/////a8mbJP////+RYFBP/////5tHePD/////m9cscP////+cvJFw/////53ASPD/////non+cP////+foCrw/////6BgpfD/////oYAM8P////+iLhLw/////6N6TPD/////pDWB8P////+kuAZw/////8b/BnD/////x1i6gP/////H2gmg/////8+SNBD/////0IoAAP/////RchYQ/////9JOJHD/////1EsHcP/////lztMA//////NcsPAAAAAAAnjB8AAAAAADQ8jwAAAAAA3P1wAAAAAADq1E8AAAAAAPeFoAAAAAABBoWRAAAAAAEnZDcAAAAAATZkKAAAAAABRffBAAAAAAFU9fAAEDAgMCAwIDAgMCAwIDAgMFBAUEBQMFAwIDAgUEBQMCAwUAAALcAAAAAAIxAAQAAA4QAQgAAAAAAA0AABwgAREAAA4QABZMTVQAUE1UAFdFU1QAV0VUAENFU1QAQ0VUAApDRVQtMQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAABAAAABL/////hqtw0f////+MUGAA/////5aqQ9H/////oVHveAEAAgMAAAMvAAAAAAAAAAQAAAcIAAgAAA4QAA5MTVQAR01UACswMDMwAFdBVAAKV0FULTEK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAwAAAAz/////kuackAAAAAAJZ2EQAQL///FkAAD///HwAAQAAAAAAAhMTVQALTAxAEdNVAAKR01UMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAgAAAAj/////jULVdgEAAB6KAAAAABwgAARMTVQAQ0FUAApDQVQtMgo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAAwAAAA3/////fb1Nq//////Ik7Tg/////8j6e9D/////yfzv4P/////Kx+jQ/////8vLrmD/////zN8p0P/////NrOHg/////87G9ND/////z49m4P/////QqXnQ/////9GEYOD/////0oqtUP/////oNmNg/////+j0LVD/////6gu5YP/////q1WDQ/////+vs+vD/////7LVtAP/////tz3/w/////+6X8gD/////77CzcP/////weSWA//////GR5vD/////8lpZAP/////zcxpw//////Q7jID/////9VWfcP/////2HhGA//////c20vD/////9/9FAP/////5GAZw//////nhygD/////+vk58P/////7wv2A//////zbvvD//////aWCgP/////+vPJw//////+GtgAAAAAAAJ4l8AAAAAABZ+mAAAAAAAJ/WXAAAAAAA0kdAAAAAAAEYd5wAAAAAAUrogAAAAAABkMR8AAAAAAHDNWAAAAAAAgkRXAAAAAACO4JAAAAAAAKBXjwAAAAAArPPIAAAAAAC+f98AAAAAAMscGAAAAAAA3JMXAAAAAADpL1AAAAAAAPqmTwAAAAABB0KIAAAAAAEYuYcAAAAAASVVwAAAAAABNuHXAAAAAAFDfhAAAAAAAVT1DwAAAAABYZFIAAAAAAF6CT8AAAAAAX+kgAAAAAABlwo/AAAAAAGdt7gAAAAAAa9DzwAAAAABu+AIAAAAAAHNVwcAAAAAAdnzQAAAAAAB62o/AAAAAAH4BngAAAAAAgl9dwAAAAACFhmwAAAAAAInpccAAAAAAjRCAAAAAAACRiJ3AAAAAAJSVTgAAAAAAmPMNwAAAAACcGhwAAAAAAKB328AAAAAAo57qAAAAAACoAe/AAAAAAKso/gAAAAAAr4a9wAAAAACyrcwAAAAAALcLi8AAAAAAujKaAAAAAAC+gE+AAAAAAMGsM0AAAAAAxf/XgAAAAADJK7tAAAAAAM1/X4AAAAAA0KtDQAAAAADU/ueAAAAAANgqy0AAAAAA3KNZgAAAAADfzz1AAAAAAOQi4YAAAAAA507FQAAAAADrommAAAAAAO7OTUAAAAAA8yHxgAAAAAD2TdVAAAAAAPqheYAAAAAA/c1dQAAAAAECReuAAAAAAQVxz0AAAAABCcVzgAAAAAEM8VdAAAAAARFE+4AAAAABFEv1QAAAAAEYxIOAAAAAARuBqUAAAAABIEQLgAAAAAEi3EdAAAAAASfDk4AAAAABKjblQAAAAAEvaAWAAAAAATGG90AAAAABMiVjgAAAAAEyk+lAAAAAAU3U44AAAAABTrInQAAAAAFPavGAAAAAAVCSCUAAAAABkSvBgAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgEAAB1VAAAAACowAQQAABwgAAlMTVQARUVTVABFRVQACkVFVC0yRUVTVCxNNC41LjUvMCxNMTAuNS40LzI0Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABIAAAABQAAAAz/////llH5nP/////G/xSA/////8dYrHD/////x9ntgP/////SoTLw/////9s1pAD/////2+4n8P/////7JXJA//////vC73AAAAAACGuEgAAAAAAIxm3wAAAAAAvoDAAAAAAADGFH8AAAAAANyT+AAAAAAA6O8nAAAAAAD9NRgAAAAAAQJ6NwAAAAABq3pgAAAAAAHhhv8AAAAABIQeaAAAAAAEi7InAAAAAASiMaAAAAAABKjdVwAAAAAEvcwIAAAAAATF3lcAAAAABNl7iAAAAAAE40jPAAAAAAT5ygoAAAAABQCLugAAAAAFAxmiAAAAAAUGenoAAAAABRfIKgAAAAAFHYy6AAAAAAUgWeoAAAAABSbHOgAAAAAFM3eqAAAAAAU64hoAAAAABT3EYgAAAAAFRMVaAAAAAAVRdcoAAAAABVfOAgAAAAAFWrBKAAAAAAViw3oAAAAABW9z6gAAAAAFdTh6AAAAAAV4GsIAAAAABYFVQgAAAAAFjXIKAAAAAAWSD0oAAAAABZWFOgAAAAAFn1NiAAAAAAWrcCoAAAAABa95wgAAAAAFslwKAAAAAAW9UYIAAAAABczkOgAAAAAFz8aCAAAAAAXpuwoAAAAABe0w+gAAAAAGByWCAAAAAAYKB8oAAAAABiP8UgAAAAAGJ3JCAAAAAAZBZsoAAAAABkRJEgAAAAAGXtFCAAAAAAZhs4oAAAAABnuoEgAAAAAGfx4CAAAAAAaZEooAAAAABpv00gAAAAAGqvMBACAQIBAgECAQIBAgECAQIBAgMCAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgEDBAMEAwQDBAMEAwQDBAMEAwL///jkAAAAAA4QAQQAAAAAAAgAAA4QAAQAAAAAAQhMTVQAKzAxACswMAAKPCswMD4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAArAAAABQAAABb/////fja1AP////+e1nVw/////5+hbmD/////qgXvcP////+q524A/////63Jp/D/////rqcyAP////+voE9w/////7CHFAD/////sYl6AP////+ycDCA//////slckD/////+8LvcAAAAAAIa4SAAAAAAAjGbfAAAAAAC+gMAAAAAAAMYUfwAAAAAA3JP4AAAAAADo7ycAAAAAAP01GAAAAAABAno3AAAAAAGremAAAAAAAejJAQAAAAAB98gRAAAAAAIGxyEAAAAAAhXGMQAAAAACJMVBAAAAAAIzxFEAAAAAAkLDYQAAAAACUcJxAAAAAAJgwYEAAAAAAnBUOQAAAAACf1NJAAAAAAKOUlkAAAAAAp1RaQAAAAACrFB5AAAAAAK7T4kAAAAAAspOmQAAAAAC2U2pAAAAAALoTLkAAAAAAvdLyQAAAAADBkrZAAAAAAMV3ZEAECAQIBAgECAQIBAgECAQIBAgECAQMEAwQDBAMEAwQDBAMEAwQDBAMEAwT///sEAAAAAAAAAAQAAA4QAQgAAA4QAA0AABwgARFMTVQAV0VUAFdFU1QAQ0VUAENFU1QACkNFVC0xQ0VTVCxNMy41LjAsTTEwLjUuMC8zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9AAAABgAAABD/////vEjw4AAAAAAL0bCQAAAAAAvoDAAAAAAADGFH8AAAAAANyT+AAAAAAA6O8nAAAAAAD9NRgAAAAAAQJ6NwAAAAAEhB5oAAAAAASLsicAAAAABKIxoAAAAAAEqN1XAAAAAAS9zAgAAAAABMXeVwAAAAAE2XuIAAAAAATjSM8AAAAABPnKCgAAAAAFAIu6AAAAAAUDGaIAAAAABQZ6egAAAAAFF8gqAAAAAAUdjLoAAAAABSBZ6gAAAAAFJsc6AAAAAAUzd6oAAAAABTriGgAAAAAFPcRiAAAAAAVExVoAAAAABVF1ygAAAAAFV84CAAAAAAVasEoAAAAABWLDegAAAAAFb3PqAAAAAAV1OHoAAAAABXgawgAAAAAFgVVCAAAAAAWNcgoAAAAABZIPSgAAAAAFlYU6AAAAAAWfU2IAAAAABatwKgAAAAAFr3nCAAAAAAWyXAoAAAAABb1RggAAAAAFzOQ6AAAAAAXPxoIAAAAABem7CgAAAAAF7TD6AAAAAAYHJYIAAAAABgoHygAAAAAGI/xSAAAAAAYnckIAAAAABkFmygAAAAAGREkSAAAAAAZe0UIAAAAABmGzigAAAAAGe6gSAAAAAAZ/HgIAAAAABpkSigAAAAAGm/TSAAAAAAaq8wEAEDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIFBAUEBQQFBAUEBQQFBAUEBQP///OgAAD///HwAAQAAA4QAQgAAAAAAAwAAAAAAQwAAA4QAAhMTVQALTAxACswMQArMDAACjwrMDA+MAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGAAAABAAAAAn/////bXtBQP////+CRs9o/////8yujID/////zZ5vcP/////Ojm6A/////89+UXABAwIDAgMAABpAAAAAABUYAAQAACowAQQAABwgAARMTVQAU0FTVAAKU0FTVC0yCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAAAABAAAABH/////tqPa3AAAAAAAnhfgAAAAAAF6NFAAAAAAAn354AAAAAADW2fQAAAAAARgfuAAAAAABT3s0AAAAAAGQGDgAAAAAAcfIFAAAAAACCBC4AAAAAAJAFPQAAAAAAoAJOAAAAAACuGHUAAAAAAL4AbgAAAAAAzEDFAAAAAADb/o4AAAAAAOpT/QAAAAAA+pBWAAAAAAEIZzUAAAAAARiOdgAAAAABJnptAAAAAAE2jJYAAAAAAUSivQAAAAABVIq2AAAAAAFitfUAAAAAAXKI1gAAAAABgMktAAAAAAGQhvYAAAAAAZ7cZQAAAAABrxi+AAAAAAG9BLUAAAAAAc0W3gAAAAAB2xftAAAAAAOIBFIAAAAABgFxpQAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAwIAAB2kAAAAACowAQQAABwgAAkAACowAA1MTVQAQ0FTVABDQVQARUFUAApDQVQtMgo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAAAABAAAABH/////tqPaAAAAAAAAnhfgAAAAAAF6NFAAAAAAAn354AAAAAADW2fQAAAAAARgfuAAAAAABT3s0AAAAAAGQGDgAAAAAAcfIFAAAAAACCBC4AAAAAAJAFPQAAAAAAoAJOAAAAAACuGHUAAAAAAL4AbgAAAAAAzEDFAAAAAADb/o4AAAAAAOpT/QAAAAAA+pBWAAAAAAEIZzUAAAAAARiOdgAAAAABJnptAAAAAAE2jJYAAAAAAUSivQAAAAABVIq2AAAAAAFitfUAAAAAAXKI1gAAAAABgMktAAAAAAGQhvYAAAAAAZ7cZQAAAAABrxi+AAAAAAG9BLUAAAAAAc0W3gAAAAAB2xftAAAAAAOIBFIAAAAABZ+ORQAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAwIAAB6AAAAAACowAQQAABwgAAkAACowAA1MTVQAQ0FTVABDQVQARUFUAApDQVQtMgo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAAAABAAAAAz/////WnqmnP////+gX2ycAAAAAAPKWm4BAgP///XkAAD///XkAAT///WSAAQAAAAAAAhMTVQATU1UAEdNVAAKR01UMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAAAAAwAAAA3/////kuaAZAAAAAASZnFwAAAAABMm3mABAgEAAA4cAAAAAA4QAAQAABwgAQhMTVQAV0FUAFdBU1QACldBVC0xCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAABAAAAAz/////Xjz9MP////+S5o6AAAAAAFpJiBAAAAAAXCq7kAECAwIAAAZQAAD///djAAAAAAAAAAQAAA4QAAhMTVQAR01UAFdBVAAKR01UMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAAABAAAABH/////ofLBJP/////du7EQ/////94jrWD/////4XjSEP/////h52Xg/////+UvP3D/////5anM4P/////rTsbwAAAAABaSQmAAAAAAFwj3cAAAAAAX+ivgAAAAABjqKvAAAAAAGdtfYAAAAAAazK/wAAAAABu95GAAAAAAHLR68AAAAAAdnxfgAAAAAB6TC3AAAAAAH4LuYAAAAAAgcEpwAAAAACFhfuAAAAAAIlLPcAAAAAAjRAPgAAAAACQ0AvAAAAAAJSU3YAAAAAAmQLfwAAAAADJO8WAAAAAAM0Q2cAAAAAA0NWrgAAAAAFCdmQAAAAAAUVTZgAAAAABSabSAAgECAQIBAgMCAQIBAgECAQIBAgECAQIBAgMCAQMCAQMAAAxcAAAAABwgAQQAAA4QAAkAABwgAA1MTVQAQ0VTVABDRVQARUVUAApFRVQtMgo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiAAAABAAAABH/////WUYT9P////+RYFBP/////8Y6iOD/////x1ieYP/////H2yLg/////8riVOD/////y61p8P/////M50sQ/////82pF5D/////zcIWAP/////NzLAQ/////86iNQD/////z5I0EP/////QiePg/////9FyFhD/////0k4WYAAAAAANx9/wAAAAAA6JrHAAAAAAD6pk8AAAAAAQdBpwAAAAACKjOvAAAAAAIzwo8AAAAAAkLBnwAAAAACUcCvAAAAAAJjzDcAAAAAAnBSdwAAAAAEJ0DfAAAAAAQzyAAAAAAABEJeeQAAAAAEVD/RAAAAAARgXJkAAAAABHI98QAAAAAEfu5hAAAAAASQPBEAEDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMAAAmMAAAAAAIxAAQAABwgAQgAAA4QAA1MTVQAUE1UAENFU1QAQ0VUAApDRVQtMQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1AAAABgAAABf/////bXtLeP////+CRs9o/////8yujID/////zZ5vcAAAAAAmBqfgAAAAAC2Mx2AAAAAALmkcEAAAAAAvfekAAAAAADBI/hAAAAAAMWcFgAAAAAAyKOAQAAAAADNG54AAAAAANBH8kAAAAAA1JsmAAAAAADXx3pAAAAAANwargAAAAAA30cCQAAAAADjmjYAAAAAAObGikAAAAAA6xm+AAAAAADuRhJAAAAAAPK+MAAAAAAA9cWaQAAAAAD6PbgAAAAAAP1qDEAAAAABAb1AAAAAAAEE6ZRAAAAAAQk8yAAAAAABDGkcQAAAAAEQvFAAAAAAARPopEAAAAABGDvYAAAAAAEbaCxAAAAAAR/gSgAAAAABIwyeQAAAAAEnX9IAAAAAASqMJkAAAAABLt9aAAAAAAEyC65AAAAAATZe4gAAAAABOYs2QAAAAAE93moAAAAAAUEKvkAAAAABRYLcAAAAAAFIikZAAAAAAU0CZAAAAAABUC64QAAAAAFUgewAAAAAAVeuQEAAAAABXAF0AAAAAAFfLchAAAAAAWOA/AAAAAABZq1QQAQIDAgUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUAABAIAAAAABUYAAQAABwgAAoAACowAQoAAA4QAQ8AABwgABNMTVQAKzAxMzAAU0FTVABXQVQAQ0FUAApDQVQtMgo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABUAAAACgAAACH/////P8L90f////99h1pe/////8uJRND/////0iP0cP/////SYVBA//////rSVbD//////rhxUP//////qFRAAAAAAACYU1AAAAAAAYg2QAAAAAACeDVQAAAAAANxUsAAAAAABGFR0AAAAAAFUTTAAAAAAAZBM9AAAAAABzEWwAAAAAAHjW3QAAAAAAkQ+MAAAAAACa3pUAAAAAAK8NrAAAAAAAvg2dAAAAAADNn3QAAAAAANwLvQAAAAAA652UAAAAAAD6nYUAAAAAAQmbtAAAAAABGJulAAAAAAEnmdQAAAAAATaZxQAAAAABRZf0AAAAAAFUl+UAAAAAAWOWFAAAAAABcpYFAAAAAAGCJ9wAAAAAAZCUJQAAAAABoCX8AAAAAAGisiIAAAAAAa8lDAAAAAABviM7AAAAAAHNIywAAAAAAdwhWwAAAAAB6yFMAAAAAAH6H3sAAAAAAgdkdAAAAAACGB2bAAAAAAIlYpQAAAAAAjavYwAAAAACQ2C0AAAAAAJUrYMAAAAAAmFe1AAAAAACcqujAAAAAAJ/8JwAAAAAApCpwwAAAAACne68AAAAAAKup+MAAAAAArvs3AAAAAACzTmrAAAAAALZ6vwAAAAAAus3ywAAAAAC9+kcAAAAAAMJNesAAAAAAxZ65AAAAAADJzQLAAAAAAM0eQQAAAAAA0UyKwAAAAADUnckAAAAAANjMEsAAAAAA3B1RAAAAAADgcITAAAAAAOOc2QAAAAAA5/AMwAAAAADrHGEAAAAAAO9vlMAAAAAA8sDTAAAAAAD27xzAAAAAAPpAWwAAAAAA/m6kwAAAAAEBv+MAAAAAAQYTFsAAAAABCT9rAAAAAAENkp7AAAAAARC+8wAAAAABFRImwAAAAAEXz70ABAgMEAgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgcJCAkICQgJCAkICQgJCAkICQgJCAkICQgJCAkICQgJCAkICQgJCAkICQgJCAkICQgAAKviAAD//1piAAD//2VQAAT//3NgAQj//3NgAQz//2VQABD//3NgART//3NgABj//4FwAR3//3NgABlMTVQATlNUAE5XVABOUFQAQlNUAEJEVABBSFNUAEhEVAAKSFNUMTBIRFQsTTMuMi4wLE0xMS4xLjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABUAAAACgAAACj/////P8L90f////99h0FI/////8uJNsD/////0iP0cP/////SYUIw//////rSR6D//////rhjQP//////qEYwAAAAAACYRUAAAAAAAYgoMAAAAAACeCdAAAAAAANxRLAAAAAABGFDwAAAAAAFUSawAAAAAAZBJcAAAAAABzEIsAAAAAAHjV/AAAAAAAkQ6rAAAAAACa3bQAAAAAAK8MywAAAAAAvgy8AAAAAADNnpMAAAAAANwK3AAAAAAA65yzAAAAAAD6nKQAAAAAAQma0wAAAAABGJrEAAAAAAEnmPMAAAAAATaY5AAAAAABRZcTAAAAAAFUlwQAAAAAAWOVMwAAAAABcpUkAAAAAAGCJvsAAAAAAZCTRAAAAAABoCUbAAAAAAGisUEAAAAAAa8kKwAAAAABviJaAAAAAAHNIksAAAAAAdwgegAAAAAB6yBrAAAAAAH6HpoAAAAAAgdjkwAAAAACGBy6AAAAAAIlYbMAAAAAAjauggAAAAACQ1/TAAAAAAJUrKIAAAAAAmFd8wAAAAACcqrCAAAAAAJ/77sAAAAAApCo4gAAAAACne3bAAAAAAKupwIAAAAAArvr+wAAAAACzTjKAAAAAALZ6hsAAAAAAus26gAAAAAC9+g7AAAAAAMJNQoAAAAAAxZ6AwAAAAADJzMqAAAAAAM0eCMAAAAAA0UxSgAAAAADUnZDAAAAAANjL2oAAAAAA3B0YwAAAAADgcEyAAAAAAOOcoMAAAAAA5+/UgAAAAADrHCjAAAAAAO9vXIAAAAAA8sCawAAAAAD27uSAAAAAAPpAIsAAAAAA/m5sgAAAAAEBv6rAAAAAAQYS3oAAAAABCT8ywAAAAAENkmaAAAAAARC+usAAAAABFRHugAAAAAEXz4TABAgMEAgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgcJCAkICQgJCAkICQgJCAkICQgJCAkICQgJCAkICQgJCAkICQgJCAkICQgJCAkICQgAAMT4AAD//3N4AAD//3NgAAT//4FwAQj//4FwAQz//3NgABD//4FwARX//4FwABr//4+AAR7//4FwACNMTVQAQVNUAEFXVABBUFQAQUhTVABBSERUAFlTVABBS0RUAEFLU1QACkFLU1Q5QUtEVCxNMy4yLjAsTTExLjEuMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAABAAAABD/////euaVuf/////L9jLA/////9Ij9HD/////0mDt0AEDAgH//8IHAAD//8fAAAT//9XQAQj//9XQAQxMTVQAQVNUAEFQVABBV1QACkFTVDQK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzAAAAAwAAAAz/////lqp0MP////+4D0ng/////7j9QKD/////ufE0MP////+63nQg/////9o4rjD/////2uv6MP/////cGeGw/////9y5WSD/////3fsVMP/////em94g/////9/dmjD/////4FQzIP/////0l/+w//////UFXiD/////9sBkMP/////3Dh6g//////hRLDD/////+MfFIP/////6CtKw//////qo+KD/////++wGMP/////8i32gAAAAAB3JjjAAAAAAHnjXoAAAAAAfoDWwAAAAACAzz6AAAAAAIYFpMAAAAAAiC8igAAAAACNYELAAAAAAI+JwIAAAAAAlN/KwAAAAACXUxyAAAAAAMIB5MAAAAAAxHU2gAAAAADJXILAAAAAAMwZqIAAAAAA0OFQwAAAAADT4wSAAAAAANiAfMAAAAAA2z2igAAAAADf2xrAAAAAAOLiFIAAAAAA53+MwAAAAADqPLKAAAAAAO8j/sAAAAAA8bw6gAAAAAD3EkTAAAAAAPk7woAAAAABQg2UwAAAAAFEgOaACAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQL//9LQAAD//+PgAQT//9XQAAhMTVQALTAyAC0wMwAKPC0wMz4zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9AAAABgAAABT/////cpyoTP////+iko8w/////7Z7UkD/////txrJsP////+4Ho9A/////7jUcDD/////uhd9wP////+6taOw/////7v4sUD/////vJbXMP////+92eTA/////754CrD/////v7sYQP/////AWo+w/////8GdnUD/////wjvDMP/////DftDA/////8Qc9rD/////xWAEQP/////F/iow/////8dBN8D/////x+CvMP/////IgZRA/////8pNobD/////yu6GwP/////OTf8w/////86w7cD/////0yk1sP/////UQ2TA//////Q9CDD/////9J/2wP/////1BWww//////YyEED/////9uafsP/////4E0PA//////jH0zD/////+fR3QP/////60zaw//////vDNcD//////LxTMP/////9rFJA//////6cNTD//////4w0QAAAAAAHo0qwAAAAAAgkb6AAAAAAI5S1sAAAAAAkEJSgAAAAACU38rAAAAAAJfB2oAAAAAAnIQ8wAAAAACfQWKAAAAAAKQDxMAAAAAApsDqgAAAAACrg0zAAAAAAK5lXIAAAAAA39sawAAAAADi/KrAAAAAAR3cJsAAAAABH3H8gAAAAAEj6orAAAAAASbxhIAECAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgUEBQQFBAUEBQQFBAUDBQQFBAX//8k0AAD//8PQAAT//8fAAAj//9XQAQz//+PgARD//9XQAAxMTVQAQ01UAC0wNAAtMDMALTAyAAo8LTAzPjMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9AAAABgAAABT/////cpyvLP////+iko8w/////7Z7UkD/////txrJsP////+4Ho9A/////7jUcDD/////uhd9wP////+6taOw/////7v4sUD/////vJbXMP////+92eTA/////754CrD/////v7sYQP/////AWo+w/////8GdnUD/////wjvDMP/////DftDA/////8Qc9rD/////xWAEQP/////F/iow/////8dBN8D/////x+CvMP/////IgZRA/////8pNobD/////yu6GwP/////OTf8w/////86w7cD/////0yk1sP/////UQ2TA//////Q9CDD/////9J/2wP/////1BWww//////YyEED/////9uafsP/////4E0PA//////jH0zD/////+fR3QP/////60zaw//////vDNcD//////LxTMP/////9rFJA//////6cNTD//////4w0QAAAAAAHo0qwAAAAAAgkb6AAAAAAI5S1sAAAAAAkEJSgAAAAACU38rAAAAAAJfB2oAAAAAAnIQ8wAAAAACfQWKAAAAAAKQD/QAAAAAApsDqgAAAAACrg0zAAAAAAK5lXIAAAAAA39sawAAAAADi/KrAAAAAAQLvxMAAAAABA1QvAAAAAAEd3CbAAAAAAR9x/IAECAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgUEBQQFBAUEAgQFBAUDBQIFBAX//8JUAAD//8PQAAT//8fAAAj//9XQAQz//+PgARD//9XQAAxMTVQAQ01UAC0wNAAtMDMALTAyAAo8LTAzPjMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9AAAABgAAABT/////cpytsP////+iko8w/////7Z7UkD/////txrJsP////+4Ho9A/////7jUcDD/////uhd9wP////+6taOw/////7v4sUD/////vJbXMP////+92eTA/////754CrD/////v7sYQP/////AWo+w/////8GdnUD/////wjvDMP/////DftDA/////8Qc9rD/////xWAEQP/////F/iow/////8dBN8D/////x+CvMP/////IgZRA/////8pNobD/////yu6GwP/////OTf8w/////86w7cD/////0yk1sP/////UQ2TA//////Q9CDD/////9J/2wP/////1BWww//////YyEED/////9uafsP/////4E0PA//////jH0zD/////+fR3QP/////60zaw//////vDNcD//////LxTMP/////9rFJA//////6cNTD//////4w0QAAAAAAHo0qwAAAAAAgkb6AAAAAAI5S1sAAAAAAkEJSgAAAAACU38rAAAAAAJfB2oAAAAAAnIQ8wAAAAACfQWKAAAAAAKQD/QAAAAAApsDqgAAAAACrg0zAAAAAAK5lXIAAAAAA39sawAAAAADi/KrAAAAAAR3cJsAAAAABH3H8gAAAAAEj6orAAAAAASbxhIAECAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgUEBQQFBAUEAgQFBAUDBQQFBAX//8PQAAD//8PQAAT//8fAAAj//9XQAQz//+PgARD//9XQAAxMTVQAQ01UAC0wNAAtMDMALTAyAAo8LTAzPjMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA7AAAABgAAABT/////cpyuuP////+iko8w/////7Z7UkD/////txrJsP////+4Ho9A/////7jUcDD/////uhd9wP////+6taOw/////7v4sUD/////vJbXMP////+92eTA/////754CrD/////v7sYQP/////AWo+w/////8GdnUD/////wjvDMP/////DftDA/////8Qc9rD/////xWAEQP/////F/iow/////8dBN8D/////x+CvMP/////IgZRA/////8pNobD/////yu6GwP/////OTf8w/////86w7cD/////0yk1sP/////UQ2TA//////Q9CDD/////9J/2wP/////1BWww//////YyEED/////9uafsP/////4E0PA//////jH0zD/////+fR3QP/////60zaw//////vDNcD//////LxTMP/////9rFJA//////6cNTD//////4w0QAAAAAAHo0qwAAAAAAgkb6AAAAAAI5S1sAAAAAAkEJSgAAAAACU38rAAAAAAJfB2oAAAAAAnKlfAAAAAACfi27AAAAAAKO6KQAAAAAApsDqgAAAAACrg0zAAAAAAK5lXIAAAAAA39sawAAAAADi/KrAAAAAAR3cJsAAAAABH3H8gAQIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCBQQFBAUEAgMCBAUEBQMFBAX//8LIAAD//8PQAAT//8fAAAj//9XQAQz//+PgARD//9XQAAxMTVQAQ01UAC0wNAAtMDMALTAyAAo8LTAzPjMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+AAAABgAAABT/////cpywLP////+iko8w/////7Z7UkD/////txrJsP////+4Ho9A/////7jUcDD/////uhd9wP////+6taOw/////7v4sUD/////vJbXMP////+92eTA/////754CrD/////v7sYQP/////AWo+w/////8GdnUD/////wjvDMP/////DftDA/////8Qc9rD/////xWAEQP/////F/iow/////8dBN8D/////x+CvMP/////IgZRA/////8pNobD/////yu6GwP/////OTf8w/////86w7cD/////0yk1sP/////UQ2TA//////Q9CDD/////9J/2wP/////1BWww//////YyEED/////9uafsP/////4E0PA//////jH0zD/////+fR3QP/////60zaw//////vDNcD//////LxTMP/////9rFJA//////6cNTD//////4w0QAAAAAAHo0qwAAAAAAgkb6AAAAAAI5S1sAAAAAAkEJSgAAAAACU38rAAAAAAJfB2oAAAAAAnIQ8wAAAAACfNtaAAAAAAKCYmQAAAAAApAPEwAAAAACmwOqAAAAAAKuDTMAAAAAArmVcgAAAAADf2xrAAAAAAOL8qsAAAAABAu/EwAAAAAEDVC8AAAAAAR3cJsAAAAABH3H8gAQIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCBQQFBAUEBQQCBQQFBAUDBQIFBAX//8FUAAD//8PQAAT//8fAAAj//9XQAQz//+PgARD//9XQAAxMTVQAQ01UAC0wNAAtMDMALTAyAAo8LTAzPjMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9AAAABgAAABT/////cpyyBP////+iko8w/////7Z7UkD/////txrJsP////+4Ho9A/////7jUcDD/////uhd9wP////+6taOw/////7v4sUD/////vJbXMP////+92eTA/////754CrD/////v7sYQP/////AWo+w/////8GdnUD/////wjvDMP/////DftDA/////8Qc9rD/////xWAEQP/////F/iow/////8dBN8D/////x+CvMP/////IgZRA/////8pNobD/////yu6GwP/////OTf8w/////86w7cD/////0yk1sP/////UQ2TA//////Q9CDD/////9J/2wP/////1BWww//////YyEED/////9uafsP/////4E0PA//////jH0zD/////+fR3QP/////60zaw//////vDNcD//////LxTMP/////9rFJA//////6cNTD//////4w0QAAAAAAHo0qwAAAAAAgkb6AAAAAAI5S1sAAAAAAkEJSgAAAAACU38rAAAAAAJfB2oAAAAAAnGTRAAAAAACfNw7AAAAAAKPpnwAAAAAApsEiwAAAAACrg4UAAAAAAK5lXIAAAAAA39sawAAAAADi/KrAAAAAAQLATsAAAAABBVj7AAAAAAEd3CbAAAAAAR9x/IAECAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgUEBQQFBAIDAgMCBAUDBQIFBAX//798AAD//8PQAAT//8fAAAj//9XQAQz//+PgARD//9XQAAxMTVQAQ01UAC0wNAAtMDMALTAyAAo8LTAzPjMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9AAAABgAAABT/////cpyyZP////+iko8w/////7Z7UkD/////txrJsP////+4Ho9A/////7jUcDD/////uhd9wP////+6taOw/////7v4sUD/////vJbXMP////+92eTA/////754CrD/////v7sYQP/////AWo+w/////8GdnUD/////wjvDMP/////DftDA/////8Qc9rD/////xWAEQP/////F/iow/////8dBN8D/////x+CvMP/////IgZRA/////8pNobD/////yu6GwP/////OTf8w/////86w7cD/////0yk1sP/////UQ2TA//////Q9CDD/////9J/2wP/////1BWww//////YyEED/////9uafsP/////4E0PA//////jH0zD/////+fR3QP/////60zaw//////vDNcD//////LxTMP/////9rFJA//////6cNTD//////4w0QAAAAAAHo0qwAAAAAAgkb6AAAAAAI5S1sAAAAAAkEJSgAAAAACU38rAAAAAAJfB2oAAAAAAnIQ8wAAAAACfQWKAAAAAAKQDxMAAAAAApsDqgAAAAACrg0zAAAAAAK5lXIAAAAAA39sawAAAAADi/KrAAAAAAQLvxMAAAAABA1QvAAAAAAEd3CbAAAAAAR9x/IAECAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgUEBQQFBAUEBQQFBAUDBQIFBAX//78cAAD//8PQAAT//8fAAAj//9XQAQz//+PgARD//9XQAAxMTVQAQ01UAC0wNAAtMDMALTAyAAo8LTAzPjMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA7AAAABgAAABT/////cpyu1P////+iko8w/////7Z7UkD/////txrJsP////+4Ho9A/////7jUcDD/////uhd9wP////+6taOw/////7v4sUD/////vJbXMP////+92eTA/////754CrD/////v7sYQP/////AWo+w/////8GdnUD/////wjvDMP/////DftDA/////8Qc9rD/////xWAEQP/////F/iow/////8dBN8D/////x+CvMP/////IgZRA/////8pNobD/////yu6GwP/////OTf8w/////86w7cD/////0yk1sP/////UQ2TA//////Q9CDD/////9J/2wP/////1BWww//////YyEED/////9uafsP/////4E0PA//////jH0zD/////+fR3QP/////60zaw//////vDNcD//////LxTMP/////9rFJA//////6cNTD//////4w0QAAAAAAHo0qwAAAAAAgkb6AAAAAAI5S1sAAAAAAkEJSgAAAAACU38rAAAAAAJfB2oAAAAAAnIQ8wAAAAACfQWKAAAAAAKQD/QAAAAAApsDqgAAAAACrg0zAAAAAAK5lXIAAAAAA39sawAAAAADi/KrAAAAAAR3cJsAAAAABH3H8gAQIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCBQQFBAUEBQQCBAUEBQMFBAX//8KsAAD//8PQAAT//8fAAAj//9XQAQz//+PgARD//9XQAAxMTVQAQ01UAC0wNAAtMDMALTAyAAo8LTAzPjMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+AAAABgAAABT/////cpyxvP////+iko8w/////7Z7UkD/////txrJsP////+4Ho9A/////7jUcDD/////uhd9wP////+6taOw/////7v4sUD/////vJbXMP////+92eTA/////754CrD/////v7sYQP/////AWo+w/////8GdnUD/////wjvDMP/////DftDA/////8Qc9rD/////xWAEQP/////F/iow/////8dBN8D/////x+CvMP/////IgZRA/////8pNobD/////yu6GwP/////OTf8w/////86w7cD/////0yk1sP/////UQ2TA//////Q9CDD/////9J/2wP/////1BWww//////YyEED/////9uafsP/////4E0PA//////jH0zD/////+fR3QP/////60zaw//////vDNcD//////LxTMP/////9rFJA//////6cNTD//////4w0QAAAAAAHo0qwAAAAAAgkb6AAAAAAI5S1sAAAAAAkEJSgAAAAACU38rAAAAAAJfB2oAAAAAAnIQ8wAAAAACfNtaAAAAAAKCYmQAAAAAApAPEwAAAAACmwOqAAAAAAKuDTMAAAAAArmVcgAAAAADf2xrAAAAAAOL8qsAAAAABAup+wAAAAAEEDMEAAAAAAR3cJsAAAAABH3H8gAQIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCBQQFBAUEBQQCBQQFBAUDBQIFBAX//7/EAAD//8PQAAT//8fAAAj//9XQAQz//+PgARD//9XQAAxMTVQAQ01UAC0wNAAtMDMALTAyAAo8LTAzPjMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+AAAABgAAABT/////cpyvtP////+iko8w/////7Z7UkD/////txrJsP////+4Ho9A/////7jUcDD/////uhd9wP////+6taOw/////7v4sUD/////vJbXMP////+92eTA/////754CrD/////v7sYQP/////AWo+w/////8GdnUD/////wjvDMP/////DftDA/////8Qc9rD/////xWAEQP/////F/iow/////8dBN8D/////x+CvMP/////IgZRA/////8pNobD/////yu6GwP/////OTf8w/////86w7cD/////0yk1sP/////UQ2TA//////Q9CDD/////9J/2wP/////1BWww//////YyEED/////9uafsP/////4E0PA//////jH0zD/////+fR3QP/////60zaw//////vDNcD//////LxTMP/////9rFJA//////6cNTD//////4w0QAAAAAAHo0qwAAAAAAgkb6AAAAAAI5S1sAAAAAAkEJSgAAAAACU38rAAAAAAJf2loAAAAAAnGTRAAAAAACfNw7AAAAAAKEcbwAAAAAA39sawAAAAADi/KrAAAAAAQLqfsAAAAABBAzBAAAAAAEd3CbAAAAAAR5P8oAAAAABH01KwAAAAAEjxdkAAAAAASbM0sAAAAABK0VhAAQIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCBQQFBAUEAgMCBQMFAgUEAwIDAgX//8HMAAD//8PQAAT//8fAAAj//9XQAQz//+PgARD//9XQAAxMTVQAQ01UAC0wNAAtMDMALTAyAAo8LTAzPjMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/AAAABgAAABT/////cpyupP////+iko8w/////7Z7UkD/////txrJsP////+4Ho9A/////7jUcDD/////uhd9wP////+6taOw/////7v4sUD/////vJbXMP////+92eTA/////754CrD/////v7sYQP/////AWo+w/////8GdnUD/////wjvDMP/////DftDA/////8Qc9rD/////xWAEQP/////F/iow/////8dBN8D/////x+CvMP/////IgZRA/////8pNobD/////yu6GwP/////OTf8w/////86w7cD/////0yk1sP/////UQ2TA//////Q9CDD/////9J/2wP/////1BWww//////YyEED/////9uafsP/////4E0PA//////jH0zD/////+fR3QP/////60zaw//////vDNcD//////LxTMP/////9rFJA//////6cNTD//////4w0QAAAAAAHo0qwAAAAAAgkb6AAAAAAI5S1sAAAAAAkEJSgAAAAACU38rAAAAAAJfB2oAAAAAAnIQ8wAAAAACfQWKAAAAAAKQD/QAAAAAApsDqgAAAAACrg0zAAAAAAK5lXIAAAAAA39sawAAAAADi/KrAAAAAAQLvxMAAAAABAy9FAAAAAAEd3CbAAAAAAR9x/IAAAAABI+qKwAAAAAEm8YSABAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIFBAUEBQQFBAIEBQQFAwUCBQQFBAX//8LcAAD//8PQAAT//8fAAAj//9XQAQz//+PgARD//9XQAAxMTVQAQ01UAC0wNAAtMDMALTAyAAo8LTAzPjMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9AAAABgAAABT/////cpyxiP////+iko8w/////7Z7UkD/////txrJsP////+4Ho9A/////7jUcDD/////uhd9wP////+6taOw/////7v4sUD/////vJbXMP////+92eTA/////754CrD/////v7sYQP/////AWo+w/////8GdnUD/////wjvDMP/////DftDA/////8Qc9rD/////xWAEQP/////F/iow/////8dBN8D/////x+CvMP/////IgZRA/////8pNobD/////yu6GwP/////OTf8w/////86w7cD/////0yk1sP/////UQ2TA//////Q9CDD/////9J/2wP/////1BWww//////YyEED/////9uafsP/////4E0PA//////jH0zD/////+fR3QP/////60zaw//////vDNcD//////LxTMP/////9rFJA//////6cNTD//////4w0QAAAAAAHo0qwAAAAAAgkb6AAAAAAI5S1sAAAAAAkEJSgAAAAACU38rAAAAAAJfB2oAAAAAAnIQ8wAAAAACfQWKAAAAAAKQDxMAAAAAApsDqgAAAAACrg0zAAAAAAK5lXIAAAAAA39sawAAAAADi/KrAAAAAAQLlOMAAAAABA1QvAAAAAAEd3CbAAAAAAR9x/IAECAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgUEBQQFBAUEBQQFBAUDBQIFBAX//7/4AAD//8PQAAT//8fAAAj//9XQAQz//+PgARD//9XQAAxMTVQAQ01UAC0wNAAtMDMALTAyAAo8LTAzPjMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABoAAAABQAAABD/////aYcRkP////+4F/WQAAAAAAUr2kAAAAAAB/zwsAAAAAAKz3TAAAAAAAuXyrAAAAAADLH5wAAAAAANeP4wAAAAAA6TLUAAAAAAD1oxsAAAAAAQdGDAAAAAABFkQ7AAAAAAElWUQAAAAAATRsiwAAAAABQ4GUAAAAAAFSf8MAAAAAAWGUzAAAAAABcJL7AAAAAAF/qAQAAAAAAY6mMwAAAAABnbs8AAAAAAGszoMAAAAAAbvjjAAAAAAByuG7AAAAAAHZ9sQAAAAAAej08wAAAAAB+An8AAAAAAIHCCsAAAAAAhYdNAAAAAACJTB7AAAAAAI0RYQAAAAAAkNDswAAAAACVBO0AAAAAAJhVusAAAAAAnBr9AAAAAACf2ojAAAAAAKO6KQAAAAAApsEiwAAAAACrPvcAAAAAAK7kJMAAAAAAsq6tAAAAAAC1wDLAAAAAALozewAAAAAAvT+6wAAAAADBuEkAAAAAAMTZoMAAAAAAyVy7AAAAAADMPsrAAAAAANDcQwAAAAAA0+M8wAAAAADYW8sAAAAAANuHrsAAAAAA39tTAAAAAADjBzbAAAAAAOda2wAAAAAA6oa+wAAAAADu/00AAAAAAPK+2MAAAAAA9cZDAAAAAAD6PmDAAAAAAP1qtQAAAAABAb3owAAAAAEFx7kAAAAAAQjOssAAAAABDUdBAAAAAAEQTjrAAAAAARTGyQAAAAABF83CwAAAAAEcazsAAAAAAR9NSsAAAAABI+rDAAAAAAEmzNLAAAAAAStqSwAAAAABLwTswAAAAAEyn/8AAAAAATaEdMAAAAABOh+HAAAAAAE+A/zAAAAAAUHD+QAAAAABRTmwwAAAAAFJQ4EAAAAAAUy5OMAAAAABUMMJAAAAAAFUOMDAAAAAAVhCkQAAAAABW90ywAAAAAFfwhkAAAAAAWNcusAAAAABZ0GhAAAAAAFq3ELAAAAAAW7mEwAAAAABclvKwAAAAAF2ZZsAAAAAAXnbUsAAAAABfeUjAAAAAAGBf8TAAAAAAYVkqwAAAAABiP9MwAAAAAGM5DMAAAAAAZB+1MAAAAABlGO7AAAAAAGX/lzAAAAAAZwILQAAAAABnDdqwAQIDAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAP//8nwAAD//8nwAAT//8fAAAj//9XQAAz//9XQAQxMTVQAQU1UAC0wNAAtMDMACjwtMDM+Mwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAwAAAAz/////aYcmEP////+L9GHoAQL//7VwAAD//7UYAAT//7mwAAhMTVQAQ01UAEVTVAAKRVNUNQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9AAAAAwAAAAz/////lqprHP////+4D0ng/////7j9QKD/////ufE0MP////+63nQg/////9o4rjD/////2uv6MP/////cGeGw/////9y5WSD/////3fsVMP/////em94g/////9/dmjD/////4FQzIP/////0l/+w//////UFXiD/////9sBkMP/////3Dh6g//////hRLDD/////+MfFIP/////6CtKw//////qo+KD/////++wGMP/////8i32gAAAAAB3JjjAAAAAAHnjXoAAAAAAfoDWwAAAAACAzz6AAAAAAIYFpMAAAAAAiC8igAAAAACNYELAAAAAAI+JwIAAAAAAlN/KwAAAAACXUxyAAAAAAJyEPMAAAAAAnveOgAAAAACkA8TAAAAAAKZSLIAAAAAAq6g2wAAAAACtrMqAAAAAALMC1MAAAAAAtZsQgAAAAAC6glzAAAAAAL0amIAAAAAAwgHkwAAAAADEdTaAAAAAAMlcgsAAAAAAzBmogAAAAADQ4VDAAAAAANPjBIAAAAAA2IB8wAAAAADbPaKAAAAAAN/bGsAAAAAA4uIUgAAAAADnf4zAAAAAAOo8soAAAAAA7yP+wAAAAADxvDqAAAAAAPcSRMAAAAAA+TvCgAAAAAE6aSLAAAAAAT0mSIAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQL//9vkAAD//+PgAQT//9XQAAhMTVQALTAyAC0wMwAKPC0wMz4zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9AAAABQAAABT/////pbbocP////+v8Stw/////7ZmVmD/////t0E9cP////+4DDZg/////7j9hvD/////y+pxYAAAAAAxZ4QQAAAAADJzFoAAAAAAM0dmEAAAAAA0UviAAAAAADUnSBAAAAAANjLagAAAAAA3ByoQAAAAADgb9wAAAAAAOOcMEAAAAAA5+9kAAAAAADr1EpAAAAAAO7bRAAAAAAA8sAqQAAAAAD27nQAAAAAAPo/skAAAAAA/m38AAAAAAEBvzpAAAAAAQYSbgAAAAABCT7CQAAAAAENkfYAAAAAARC+SkAAAAABFRF+AAAAAAEYPdJAAAAAARyRBgAAAAABH+JEQAAAAAEkEI4AAAAAASdhzEAAAAABK5AWAAAAAAEu4VRAAAAAATM0T8AAAAABNmCkAAAAAAE6s9fAAAAAAT3gLAAAAAABQjNfwAAAAAFFhJ4AAAAAAUmy58AAAAABTQQmAAAAAAFRMm/AAAAAAVSDrgAAAAABWLH3wAAAAAFcAzYAAAAAAWBWacAAAAABY4K+AAAAAAFn1fHAAAAAAWsCRgAAAAABb1V5wAAAAAFyprgAAAAAAXbVAcAAAAABeiZAAAAAAAF+VInAAAAAAYGlyAAAAAABhfj7wAAAAAGJJVAAAAAAAY14g8AECAQMBAgEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAL//51UAAD//52QAAT//6ugAAj//6ugAQz//7mwARBMTVQATVNUAENTVABNRFQAQ0RUAApDU1Q2Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPAAAABAAAABL/////kkCpZf/////L48vQ/////8yUguD/////zdYi0P/////OfE3g/////8+bptD/////0GVqYAAAAAAOAPLgAAAAAA6UjNAAAAAAD5cA4AAAAAAQdG7QAAAAABF24uAAAAAAElRQ0AAAAAATX/9gAAAAABQwPlACAQIBAgMCAQIBAgECAQL//8gbAAD//9XQAQT//8fAAAj//87IAQxMTVQAQURUAEFTVAAtMDMzMAAKQVNUNAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdAAAAAwAAAAz/////lqp0dP////+4D0ng/////7j9QKD/////ufE0MP////+63nQg/////9o4rjD/////2uv6MP/////cGeGw/////9y5WSD/////3fsVMP/////em94g/////9/dmjD/////4FQzIP/////0l/+w//////UFXiD/////9sBkMP/////3Dh6g//////hRLDD/////+MfFIP/////6CtKw//////qo+KD/////++wGMP/////8i32gAAAAAB3JjjAAAAAAHnjXoAAAAAAfoDWwAAAAACAzz6AAAAAAIYFpMAAAAAAiC8igAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQL//9KMAAD//+PgAQT//9XQAAhMTVQALTAyAC0wMwAKPC0wMz4zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABiAAAABgAAABr/////k17ZsP////+fnzvg/////6BFUdj/////oX8d4P////+iLm5Y/////6Ne/+D/////pA5QWP////+lPuHg/////6XuMlj/////pyf+YP////+nzhRY/////6kH4GD/////qa32WP////+q58Jg/////6uXEtj/////rMekYP////+tdvTY/////66nhmD/////r1bW2P////+wh2hg/////7E2uNj/////snCE4P////+zFprY/////7RQZuD/////tPZ82P////+2MEjg/////7bfmVj/////uBAq4P////+4v3tY/////7nwDOD/////up9dWP////+72Slg/////7x/P1j/////vbkLYP////++XyFY/////7+Y7WD/////wD8DWP/////BeM9g/////8IoH9j/////w1ixYP/////ECAHY/////8U4k2D/////xefj2P/////HIa/g/////8fHxdj/////yQGR4P/////Jp6fY/////8rhc+D/////y5DEWP/////MQCLg/////9Ij9HD/////0sZxUP/////WKfpg/////9bZStj/////2AncYP/////YuSzY/////9npvmD/////2pkO2P/////b0trg/////9x48Nj/////3bK84P/////eWNLY/////9+SnuD/////4EHvWP/////hcoDg/////+Ih0Vj/////41Ji4P/////kAbNY/////+UyROD/////5eGVWP/////nG2Fg/////+fBd1j/////6PtDYP/////poVlY/////+rbJWD/////64p12P/////suwdg/////+1qV9j/////7prpYP/////vSjnY//////CEBeD/////8Sob2P/////yY+fg//////MJ/dj/////9EPJ4P/////06d/Y//////Yjq+D/////9tL8WP/////4A43g//////iy3lj/////+eNv4P/////6ksBY//////vMjGD//////HKiWAAAAAAHYttgAAAAAAe50FAAAAAAGGFxYAAAAAAYqzdQAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgMEAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgUCBQL//61QAAD//7KoAQT//6ugAAr//7mwAQ7//7mwARL//7mwARZMTVQALTA1MzAAQ1NUAENXVABDUFQAQ0RUAApDU1Q2Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAhAAAAAwAAAAz/////lqp/4P////+4D1fw/////7j9TrD/////ufFCQP////+63oIw/////9o4vED/////2uwIQP/////cGe/A/////9y5ZzD/////3fsjQP/////em+ww/////9/dqED/////4FRBMP/////0mA3A//////UFbDD/////9sByQP/////3Diyw//////hROkD/////+MfTMP/////6CuDA//////qpBrD/////++wUQP/////8i4uwAAAAAB3JnEAAAAAAHnjlsAAAAAAfoEPAAAAAACAz3bAAAAAAIYF3QAAAAAAiC9awAAAAADf21MAAAAAAOLiTMAAAAAA53/FAAAAAADnpHbACAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQL//8cgAAD//9XQAQT//8fAAAhMTVQALTAzAC0wNAAKPC0wND40Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAABAAAABD/////Xpw08P////+YWFVwAAAAACoCIdAAAAAAK3SJQAEDAgP//7qQAAD//7qQAAT//8fAAQj//7mwAAxMTVQAQk1UAC0wNAAtMDUACjwtMDU+NQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABaAAAABwAAABz/////XgQawP////+epkig/////5+7FZD/////oIYqoP////+hmveQ/////6hGTCD/////y4kMkP/////SI/Rw/////9JhGAD/////+vh1EP/////76FgA//////zYVxD//////cg6AP/////+uDkQ//////+oHAAAAAAAAJgbEAAAAAABh/4AAAAAAAJ3/RAAAAAAA3EagAAAAAAEYRmQAAAAAAVQ/IAAAAAABkD7kAAAAAAHMN6AAAAAAAeyH5AAAAAACRDAgAAAAAAJrbEQAAAAAArwooAAAAAAC+ChkAAAAAAM2b8AAAAAAA3Ag5AAAAAADrmhAAAAAAAPqaAQAAAAABCZgwAAAAAAEYmCEAAAAAASeWUAAAAAABNpZBAAAAAAFFlHAAAAAAAVSUYQAAAAABY5KQAAAAAAFykoEAAAAAAYIkWAAAAAABkJChAAAAAAGgIngAAAAAAa8iaQAAAAABviCYAAAAAAHNIIkAAAAAAdweuAAAAAAB6x6pAAAAAAH6HNgAAAAAAgdh0QAAAAACGBr4AAAAAAIlX/EAAAAAAjaswAAAAAACQ14RAAAAAAJUquAAAAAAAmFcMQAAAAACcqkAAAAAAAJ/7fkAAAAAApCnIAAAAAACnewZAAAAAAKupUAAAAAAArvqOQAAAAACzTcIAAAAAALZ6FkAAAAAAus1KAAAAAAC9+Z5AAAAAAMJM0gAAAAAAxZ4QQAAAAADJzFoAAAAAAM0dmEAAAAAA0UviAAAAAADUnSBAAAAAANjLagAAAAAA3ByoQAAAAADgb9wAAAAAAOOcMEAAAAAA5+9kAAAAAADrG7hAAAAAAO9u7AAAAAAA8sAqQAAAAAD27nQAAAAAAPo/skAAAAAA/m38AAAAAAEBvzpAAAAAAQYSbgAAAAABCT7CQAAAAAENkfYAAAAAARC+SkAAAAABFRF+AAAAAAEXzxRACAQIBAgUDBAUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQb//5MPAAD//52QAQT//4+AAAj//6ugAQz//6ugARD//52QABT//6ugARhMTVQAUERUAFBTVABNV1QATVBUAE1TVABNRFQACk1TVDdNRFQsTTMuMi4wLE0xMS4xLjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABMAAAACAAAACD/////ofLNgP/////LiQyQ/////9Ij9HD/////0mEYAAAAAAAEYRmQAAAAAAVQ/IAAAAAABkD7kAAAAAAHMN6AAAAAAAgg3ZAAAAAACRDAgAAAAAAKAL+QAAAAAArwooAAAAAAC+ChkAAAAAAM2b8AAAAAAA3Ag5AAAAAADrmhAAAAAAAPqaAQAAAAABCZgwAAAAAAEYmCEAAAAAASeWUAAAAAABNpZBAAAAAAFFlHAAAAAAAVSUYQAAAAABY5KQAAAAAAFykoEAAAAAAYIkWAAAAAABkJChAAAAAAGgIngAAAAAAa8iaQAAAAABviCYAAAAAAHNIIkAAAAAAdweuAAAAAAB6x6pAAAAAAH6HNgAAAAAAgdh0QAAAAACGBr4AAAAAAIlX/EAAAAAAjaswAAAAAACQ14RAAAAAAJUquAAAAAAAmFcMQAAAAACcqkAAAAAAAJ/7fkAAAAAApCnIAAAAAACnewZAAAAAAKupUAAAAAAArvqOQAAAAACzTcIAAAAAALZ6FkAAAAAAus1KAAAAAAC9+Z5AAAAAAMJM0gAAAAAAxZ4QQAAAAADJzFoAAAAAAM0dmEAAAAAA0UviAAAAAADUnSBAAAAAANjLagAAAAAA3ByoQAAAAADgb9wAAAAAAOOb+AAAAAAA5+8rwAAAAADoE6VAAAAAAOsbuEAAAAAA727sAAAAAADywCpAAAAAAPbudAAAAAAA+j+yQAAAAAD+bfwAAAAAAQG/OkAAAAABBhJuAAAAAAEJPsJAAAAAAQ2R9gAAAAABEL5KQAAAAAEVEX4AAAAAARfPFEAMBAgMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEBgUHBgQDBAMEAwQDBAMEAwQAAAAAAAD//6ugAQT//6ugAQj//52QAAz//6ugARD//7mwART//6ugABj//7mwABwtMDAATVdUAE1QVABNU1QATURUAENEVABDU1QARVNUAApNU1Q3TURULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABbAAAAAwAAAAz/////lqp6NP////+4D1fw/////7j9TrD/////ufFCQP////+63oIw/////9o4vED/////2uwIQP/////cGe/A/////9y5ZzD/////3fsjQP/////em+ww/////9/dqED/////4FRBMP/////0mA3A//////UFbDD/////9sByQP/////3Diyw//////hROkD/////+MfTMP/////6CuDA//////qpBrD/////++wUQP/////8i4uwAAAAAB3JnEAAAAAAHnjlsAAAAAAfoEPAAAAAACAz3bAAAAAAIYF3QAAAAAAiC9awAAAAACNYHsAAAAAAI+J+MAAAAAAlOADAAAAAACXU1TAAAAAAJyEdQAAAAAAnvfGwAAAAACkA/0AAAAAAKZSZMAAAAAAq6hvAAAAAACtrQLAAAAAALMDDQAAAAAAtZtIwAAAAAC6gpUAAAAAAL0a0MAAAAAAwgIdAAAAAADEdW7AAAAAAMlcuwAAAAAAzBngwAAAAADQ4YkAAAAAANPjPMAAAAAA2IC1AAAAAADbPdrAAAAAAN/bUwAAAAAA4uJMwAAAAADnf8UAAAAAAOo86sAAAAAA7yQ3AAAAAADxvHLAAAAAAPcSfQAAAAAA+Tv6wAAAAAD+SDEAAAAAAQC7gsAAAAABBhwZAAAAAAEIX/TAAAAAAQ1HQQAAAAABD998wAAAAAEVNYcAAAAAAReD7sAAAAABHEZRAAAAAAEe3ozAAAAAASPqwwAAAAABJl4UwAAAAAEraksAAAAAAS4ChsAAAAABMunTAAAAAAE1gg7AAAAAATppWwAAAAABPSaAwAAAAAFCDc0AAAAAAUSBHsAAAAABSY1VAAAAAAFMAKbAAAAAAVEM3QAAAAABU6UYwAAAAAFYjGUAAAAAAVskoMAAAAABYAvtAAAAAAFipCjAAAAAAWeLdQAAAAABaiOwwAAAAAFvebsAAAAAAXGjOMAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQL//8zMAAD//9XQAQT//8fAAAhMTVQALTAzAC0wNAAKPC0wND40Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAArAAAABQAAABT/////pbbaYAAAAAAWiuYAAAAAABh3zNAAAAAAMWd2AAAAAAAycwhwAAAAADNHWAAAAAAANFLqcAAAAAA1JyvwAAAAADXEAGAAAAAANjLMcAAAAAA3BxwAAAAAADgb6PAAAAAAOOb+AAAAAAA5+8rwAAAAADr1BIAAAAAAO7bC8AAAAAA8r/yAAAAAAD27jvAAAAAAPo/egAAAAAA/m3DwAAAAAEBvwIAAAAAAQYSNcAAAAABCT6KAAAAAAENkb3AAAAAARC+EgAAAAABFRFFwAAAAAEYPZoAAAAAARyQzcAAAAABH+IMAAAAAAEkEFXAAAAAASdhlAAAAAABK4/dwAAAAAEu4RwAAAAAATM0T8AAAAABNmCkAAAAAAE6s9fAAAAAAT3gLAAAAAABQjNfwAAAAAFFhJ4AAAAAAUmy58AAAAABTQQmAAAAAAFRMm/AAAAAAVM3dAAECAQMBAwIEAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQL//66oAAD//6ugAAT//7mwAAj//7mwAQz//8fAARBMTVQAQ1NUAEVTVABDRFQARURUAApFU1Q1Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAABAAAABL/////aYcaQP////+THiw8//////aY7EgAAAAAR1uScAAAAABXJalwAQIDAgP//8FAAAD//8FEAAT//8C4AAj//8fAAA5MTVQAQ01UAC0wNDMwAC0wNAAKPC0wND40Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAwAAAAz/////kfQrkP/////7wzXAAQL//87wAAD//8fAAAT//9XQAAhMTVQALTA0AC0wMwAKPC0wMz4zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACvAAAABgAAABj/////XgP+oP////+epiyA/////5+6+XD/////oIYOgP////+hmttw/////6LLdAD/////o4P38P////+kRdKA/////6Vj2fD/////plPZAP////+nFZdw/////6gzuwD/////qP6z8P////+qE50A/////6relfD/////q/N/AP////+svnfw/////63TYQD/////rp5Z8P////+vs0MA/////7B+O/D/////sZxfgP////+yZ1hw/////7N8QYD/////tEc6cP////+1XCOA/////7YnHHD/////tzwFgP////+4Bv5w/////7kb54D/////uebgcP////+7BQQA/////7vGwnD/////vOTmAP////+9r97w/////77EyAD/////v4/A8P/////AWtYA/////8GwPHD/////woSMAP/////DT4Tw/////8RkbgD/////xS9m8P/////GTYqA/////8cPSPD/////yC1sgP/////I+GVw/////8oNToD/////ythHcP/////LiP6A/////9Ij9HD/////0mEJ8P/////TdfMA/////9RA6/D/////1VXVAP/////WIM3w/////9c1twD/////2ACv8P/////ZFZkA/////9ngkfD/////2v61gP/////bwHPw/////9zel4D/////3amQcP/////evnmA/////9+JcnD/////4J5bgP/////haVRw/////+J+PYD/////40k2cP/////kXh+A/////+VXPPD/////5kc8AP/////nNx7w/////+gnHgD/////6RcA8P/////qBwAA/////+r24vD/////6+biAP/////s1sTw/////+3GxAD/////7r/hcP/////vr+CA//////Cfw3D/////8Y/CgP/////yf6Vw//////NvpID/////9F+HcP/////1T4aA//////Y/aXD/////9y9ogP/////4KIXw//////kPSoD/////+ghn8P/////6+GcA//////voSfD//////NhJAP/////9yCvw//////64KwD//////6gN8AAAAAAAmA0AAAAAAAGH7/AAAAAAAnfvAAAAAAADcQxwAAAAAARhC4AAAAAABVDucAAAAAAGQO2AAAAAAAcw0HAAAAAAB40ngAAAAAAJELJwAAAAAAmtowAAAAAACvCUcAAAAAAL4JOAAAAAAAzZsPAAAAAADcB1gAAAAAAOuZLwAAAAAA+pkgAAAAAAEJl08AAAAAARiXQAAAAAABJ5VvAAAAAAE2lWAAAAAAAUWTjwAAAAABVJOAAAAAAAFjka8AAAAAAXKRoAAAAAABgiN3AAAAAAGQj8AAAAAAAaAhlwAAAAABryGIAAAAAAG+H7cAAAAAAc0fqAAAAAAB3B3XAAAAAAHrHcgAAAAAAfob9wAAAAACB2DwAAAAAAIYGhcAAAAAAiVfEAAAAAACNqvfAAAAAAJDXTAAAAAAAlSp/wAAAAACYVtQAAAAAAJyqB8AAAAAAn/tGAAAAAACkKY/AAAAAAKd6zgAAAAAAq6kXwAAAAACu+lYAAAAAALNNicAAAAAAtnneAAAAAAC6zRHAAAAAAL35ZgAAAAAAwkyZwAAAAADFndgAAAAAAMnMIcAAAAAAzR1gAAAAAADRS6nAAAAAANSc6AAAAAAA2MsxwAAAAADcHHAAAAAAAOBvo8AAAAAA45v4AAAAAADn7yvAAAAAAOsbgAAAAAAA726zwAAAAADyv/IAAAAAAPbuO8AAAAAA+j96AAAAAAD+bcPAAAAAAQG/AgAAAAABBhI1wAAAAAEJPooAAAAAAQ2RvcAAAAABEL4SAAAAAAEVEUXAAAAAARfO3AAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIDAgECAQIBAgECAQIEBQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgH//63UAAD//7mwAQT//6ugAAj//7mwAAz//7mwARD//7mwARRMTVQAQ0RUAENTVABFU1QAQ1dUAENQVAAKQ1NUNkNEVCxNMy4yLjAsTTExLjEuMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8AAAABQAAABT/////pbbocP////+v8Stw/////7ZmVmD/////t0E9cP////+4DDZg/////7j9hvAAAAAAMWd2AAAAAAAycwhwAAAAADNHWAAAAAAANFLqcAAAAAA1J0gQAAAAADYy2oAAAAAANwcqEAAAAAA4G/cAAAAAADjnDBAAAAAAOfvZAAAAAAA69RKQAAAAADu20QAAAAAAPLAKkAAAAAA9u50AAAAAAD6P7JAAAAAAP5t/AAAAAABAb86QAAAAAEGEm4AAAAAAQk+wkAAAAABDZH2AAAAAAEQvkpAAAAAARURfgAAAAABGD3SQAAAAAEckQYAAAAAAR/iREAAAAABJBCOAAAAAAEnYcxAAAAAASuQFgAAAAABLuFUQAAAAAEzNIgAAAAAATZg3EAAAAABOrQQAAAAAAE94GRAAAAAAUIzmAAAAAABRYTWQAAAAAFJsyAAAAAAAU0EXkAAAAABUTKoAAAAAAFUg+ZAAAAAAViyMAAAAAABXANuQAAAAAFgVqIAAAAAAWOC9kAAAAABZ9YqAAAAAAFrAn5AAAAAAW9VsgAAAAABcqbwQAAAAAF21ToAAAAAAXomeEAAAAABflTCAAAAAAGBpgBAAAAAAYX5NAAAAAABiSWIQAAAAAGNeLwABAgEDAQIEAgQCAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwL//5yMAAD//52QAAT//6ugAAj//6ugAQz//7mwARBMTVQATVNUAENTVABNRFQAQ0RUAApDU1Q2Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9AAAABQAAABT/////pbbocP////+v8Stw/////7ZmVmD/////t0E9cP////+4DDZg/////7j9hvAAAAAAMWd2AAAAAAAycwhwAAAAADNHWAAAAAAANFLqcAAAAAA1J0gQAAAAADYy2oAAAAAANwcqEAAAAAA4G/cAAAAAADjnDBAAAAAAOfvZAAAAAAA69RKQAAAAADu20QAAAAAAPLAKkAAAAAA9u50AAAAAAD6P7JAAAAAAP5t/AAAAAABAb86QAAAAAEGEm4AAAAAAQk+wkAAAAABDZH2AAAAAAEQvkpAAAAAARURfgAAAAABGD3SQAAAAAEckQYAAAAAAR/iREAAAAABJBCOAAAAAAEnYcxAAAAAASuQFgAAAAABLnKWQAAAAAEzWXIAAAAAATXyHkAAAAABOtj6AAAAAAE9caZAAAAAAUJYggAAAAABRPEuQAAAAAFJ2AoAAAAAAUxwtkAAAAABUVeSAAAAAAFT8D5AAAAAAVjXGgAAAAABW5SwQAAAAAFge4wAAAAAAWMUOEAAAAABZ/sUAAAAAAFqk8BAAAAAAW96nAAAAAABchNIQAAAAAF2+iQAAAAAAXmS0EAAAAABfnmsAAAAAAGBN0JAAAAAAYYeHgAAAAABiLbKQAAAAAGNeLwAAAAAAY4bxYAECAQMBAgQCBAIDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAgH//5wsAAD//52QAAT//6ugAAj//6ugAQz//7mwARBMTVQATVNUAENTVABNRFQAQ0RUAApNU1Q3TURULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKAAAABAAAABH/////aYcqTf////+j6BZNAAAAABE2SWAAAAAAEbduUAAAAAATFitgAAAAABOXUFAAAAAAJ5fgYAAAAAAobrbQAAAAACl3wmAAAAAAKcLZ0AEDAgMCAwIDAgP//7EzAAD//7EzAAT//7mwAQn//6ugAA1MTVQAU0pNVABDRFQAQ1NUAApDU1Q2Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACFAAAABwAAABT/////aYcfEP////+PMEdF/////5tc5VD/////n3zixf////+hAHHA/////7Bed8X/////sXc9QP////+yQQDQ/////7NYcMD/////tCI0UP////+1OaRA/////7YDZ9D/////txrXwP////+35JtQ/////7j9XMD/////uccgUP/////MHG5A/////8xs59D/////1BfjQP/////VM1XA/////9V2kkD//////dE8QP/////+kvqw///////MzcAAAAAAAHLcsAAAAAABdVDAAAAAAAJASbAAAAAAA1UywAAAAAAEICuwAAAAAAU+T0AAAAAABgANsAAAAAAHC7xAAAAAAAff77AAAAAACP4TQAAAAAAJv9GwAAAAAArd9UAAAAAAC6juMAAAAAAMvddAAAAAAA2I0DAAAAAADp25QAAAAAAPaLIwAAAAABCG1cAAAAAAEUiUMAAAAAASZrfAAAAAABModjAAAAAAFEaZwAAAAAAVEZKwAAAAABYme8AAAAAAFvF0sAAAAAAYBl3AAAAAABjRVrAAAAAAGeY/wAAAAAAasTiwAAAAABvPXEAAAAAAHJEasAAAAAAdrz5AAAAAAB5w/LAAAAAAH48gQAAAAAAgfwMwAAAAACFvAkAAAAAAIjn7MAAAAAAjTuRAAAAAACQZ3TAAAAAAJTgAwAAAAAAl+b8wAAAAACby+MAAAAAAJ9mhMAAAAAAo98TAAAAAACnCvbAAAAAAKtemwAAAAAArop+wAAAAACy3iMAAAAAALYKBsAAAAAAul2rAAAAAAC9iY7AAAAAAMICHQAAAAAAxQkWwAAAAADJgaUAAAAAAMz3XMAAAAAA0QEtAAAAAADULRDAAAAAANg24QAAAAAA3BtWwAAAAADgAD0AAAAAAOMsIMAAAAAA56SvAAAAAADqq6jAAAAAAO8kNwAAAAAA8iswwAAAAAD2o78AAAAAAPmquMAAAAAA/iNHAAAAAAEBTyrAAAAAAQWizwAAAAABCM6ywAAAAAENIlcAAAAAARBOOsAAAAABFMbJAAAAAAEXzcLAAAAAARxGUQAAAAABH7wIwAAAAAEjxdkAAAAAASbxvMAAAAABK0VhAAAAAAEu4ALAAAAAATLE6QAAAAABNxgcwAAAAAE5QgsAAAAAAT5yusAAAAABQQtnAAAAAAFF8kLAAAAAAUiv2QAAAAABTXHKwAAAAAFQL2EAAAAAAVzfmMAAAAABXr+zAAAAAAFkXyDAAAAAAWY/OwAAAAABa96owAAAAAFtvsMAAAAAAXKlnsAAAAABddHzAAAAAAF6JSbAAAAAAX1RewAAAAABgaSuwAAAAAGE0QMAAAAAAYkkNsAAAAABjHV1AAAAAAGQo77AAAAAAZPQEwAAAAABmEgwwAAAAAGbdIUAAAAAAZ9uEsAECAQMBBAIEAgQCBAIEAgMCAwQCAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQb//7xwAAD//727AAT//7mwAAj//8fAAAz//8fAAQz//9XQARD//9XQABBMTVQAU01UAC0wNQAtMDQALTAzAAo8LTAzPjMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALAAAABAAAABD/////XgQMsP////+epjqQ/////5+7B4D/////oIYckP////+hmumA/////8uJDJD/////zxffHP/////Pj+Ws/////9CBGhz/////+vh1EP/////76FgAAgECAQIDAgMCAQL//5buAAD//6ugAQT//52QAAj//6ugAQxMTVQATURUAE1TVABNV1QACk1TVDcK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABZAAAAAwAAAAz/////lqp7lP////+4D1fw/////7j9TrD/////ufFCQP////+63oIw/////9o4vED/////2uwIQP/////cGe/A/////9y5ZzD/////3fsjQP/////em+ww/////9/dqED/////4FRBMP/////0mA3A//////UFbDD/////9sByQP/////3Diyw//////hROkD/////+MfTMP/////6CuDA//////qpBrD/////++wUQP/////8i4uwAAAAAB3JnEAAAAAAHnjlsAAAAAAfoEPAAAAAACAz3bAAAAAAIYF3QAAAAAAiC9awAAAAACNYHsAAAAAAI+J+MAAAAAAlOADAAAAAACXU1TAAAAAAJyEdQAAAAAAnvfGwAAAAACkA/0AAAAAAKZSZMAAAAAAq6hvAAAAAACtrQLAAAAAALMDDQAAAAAAtZtIwAAAAAC6gpUAAAAAAL0a0MAAAAAAwgIdAAAAAADEdW7AAAAAAMlcuwAAAAAAzBngwAAAAADQ4YkAAAAAANPjPMAAAAAA2IC1AAAAAADbPdrAAAAAAN/bUwAAAAAA4uJMwAAAAADnf8UAAAAAAOo86sAAAAAA7yQ3AAAAAADxvHLAAAAAAPcSfQAAAAAA+Tv6wAAAAAEGHBkAAAAAAQhf9MAAAAABDUdBAAAAAAEP33zAAAAAARU1hwAAAAABF4PuwAAAAAEcRlEAAAAAAR7ejMAAAAABI+rDAAAAAAEmXhTAAAAAAStqSwAAAAABLgKGwAAAAAEy6dMAAAAAATWCDsAAAAABOmlbAAAAAAE9JoDAAAAAAUINzQAAAAABRIEewAAAAAFJjVUAAAAAAUwApsAAAAABUQzdAAAAAAFTpRjAAAAAAViMZQAAAAABWySgwAAAAAFgC+0AAAAAAWKkKMAAAAABZ4t1AAAAAAFqI7DAAAAAAW95uwAAAAABcaM4wAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQL//8tsAAD//9XQAQT//8fAAAhMTVQALTAzAC0wNAAKPC0wND40Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiAAAABAAAABD/////m4BJAAAAAAATTXxQAAAAABQz+pAAAAAAFSPrkAAAAAAWE9yQAAAAABcDzZAAAAAAF/O+kAAAAAAY46+QAAAAABnToJAAAAAAGsORkAAAAAAbvL0QAAAAABysrhAAAAAAHZyfEAAAAAAejJAQAAAAAB98gRAAAAAAIGxyEAAAAAAhXGMQAAAAACJMVBAAAAAAIzxFEAAAAAAkLDYQAAAAACUcJxAAAAAAJgwYEAAAAAAnBUOQAAAAACf1NJAAAAAAKOUlkAAAAAAp1RaQAAAAACrFB5AAAAAAK7T4kAAAAAAspOmQAAAAAC2U2pAAAAAALoTLkAAAAAAvdLyQAAAAADBkrZAAAAAAMOdOMAECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQP//+6AAAD//9XQAAT//+PgAQgAAAAAAAxMTVQALTAzAC0wMgBHTVQACkdNVDAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABdAAAACQAAACX/////fYaOtP////+euMuw/////5+7I6D/////oNAMsP////+hotKA/////8uJKLD/////0iP0cP/////SYTQg//////cvdpD/////+CiiEAAAAAAHMOyQAAAAABNpciAAAAAAFFlVEAAAAAAVSVQgAAAAABY5NxAAAAAAFyk2IAAAAAAYIlOQAAAAABkJGCAAAAAAGgI1kAAAAAAa8jSgAAAAABviF5AAAAAAHNIWoAAAAAAdwfmQAAAAAB6x+KAAAAAAH6HbkAAAAAAgdisgAAAAACGBvZAAAAAAIlYNIAAAAAAjatoQAAAAACQ17yAAAAAAJUq8EAAAAAAmFdEgAAAAACcqnhAAAAAAJ/7toAAAAAApCoAQAAAAACnez6AAAAAAKupiEAAAAAArvrGgAAAAACzTfpAAAAAALZ6ToAAAAAAus2CQAAAAAC9+daAAAAAAMJNCkAAAAAAxZ5IgAAAAADJzJJAAAAAAM0d0IAAAAAA0UwaQAAAAADUnViAAAAAANjLokAAAAAA3BzggAAAAADgcBRAAAAAAOOcaIAAAAAA5++cQAAAAADrG/CAAAAAAO9vJEAAAAAA8sBigAAAAAD27qxAAAAAAPo/6oAAAAAA/m40QAAAAAEBv3KAAAAAAQYSpkAAAAABCT76gAAAAAENki5AAAAAARC+goAAAAABFRG2QAAAAAEXz0yAAAAAARy2KEAAAAABH07UgAAAAAEkNbBAAAAAASbOXIAAAAABK7U4QAAAAAEucs6AAAAAATNZqkAAAAABNfJWgAAAAAE62TJAAAAAAT1x3oAAAAABQli6QAAAAAFE8WaAAAAAAUnYQkAAAAABTHDugAAAAAFRV8pAAAAAAVPwdoAAAAABWNdSQAAAAAFblOiAAAAAAWB7xEAAAAABYxRwgAAAAAFn+0xAAAAAAWqT+IAAAAABb3rUQAAAAAFyE4CAAAAAAXb6XEAAAAABeZMIgAAAAAF+eXPACAQIBAgMEAgUCBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwj//31MAAD//4+AAQT//4FwAAj//4+AAQz//4+AARD//52QART//4+AABn//52QAR3//52QACFMTVQAWURUAFlTVABZV1QAWVBUAFlERFQAUFNUAFBEVABNU1QACk1TVDcK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA6AAAABgAAABj/////Xj10OP////+euL2g/////5+7FZD/////y4kaoP/////SI/Rw/////9JhJhD/////1VXxIP/////WIOoQ/////9c10yD/////2ADMEP/////ZFbUg/////9ngrhD/////2v7RoP/////bwJAQ/////9zes6D/////3amskP/////evpWg/////9+JjpD/////4J53oP/////haXCQ/////+J+WaD/////40lSkP/////kXjug/////+UpNJD/////5kdYIP/////nElEQ/////+gnOiD/////6PIzEP/////qBxwg/////+rSFRD/////6+b+IP/////ssfcQ/////+3G4CD/////7pHZEP/////vr/yg//////BxuxD/////8Y/eoP/////yf8GQ//////NvwKD/////9F+jkP/////1T6Kg//////Y/hZD/////9y+EoP/////4KKIQ//////kPZqD/////+giEEP/////6+IMg//////voZhD//////NhlIP/////9yEgQ//////64RyD//////6gqEAAAAAAAmCkgAAAAAAGIDBAAAAAAAngLIAAAAAADcSiQAAAAAARhJ6AAAAAABQHwkAIBAgMEAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQX//49IAAD//52QAQT//4+AAAj//52QAQz//52QARD//52QABRMTVQAUERUAFBTVABQV1QAUFBUAE1TVAAKTVNUNwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABhAAAABQAAABT/////XgQMsP////+epjqQ/////5+7B4D/////oIYckP////+hmumA/////6Jl/pD/////o4QGAP////+kReCQ/////6SPpoD/////y4kMkP/////SI/Rw/////9JhGAD/////9y92kP/////4KJQA//////kPWJD/////+gh2AP/////6+HUQ//////voWAD//////NhXEP/////9yDoA//////64ORD//////6gcAAAAAAAAmBsQAAAAAAGH/gAAAAAAAnf9EAAAAAADcRqAAAAAAARhGZAAAAAABVD8gAAAAAAGQPuQAAAAAAcw3oAAAAAAB401kAAAAAAJEMCAAAAAAAmtsRAAAAAACvCigAAAAAAL4KGQAAAAAAzZvwAAAAAADcCDkAAAAAAOuaEAAAAAAA+poBAAAAAAEJmDAAAAAAARiYIQAAAAABJ5ZQAAAAAAE2lkEAAAAAAUWUcAAAAAABVJRhAAAAAAFjkpAAAAAAAXKSgQAAAAABgiRYAAAAAAGQkKEAAAAAAaAieAAAAAABryJpAAAAAAG+IJgAAAAAAc0giQAAAAAB3B64AAAAAAHrHqkAAAAAAfoc2AAAAAACB2HRAAAAAAIYGvgAAAAAAiVf8QAAAAACNqzAAAAAAAJDXhEAAAAAAlSq4AAAAAACYVwxAAAAAAJyqQAAAAAAAn/t+QAAAAACkKcgAAAAAAKd7BkAAAAAAq6lQAAAAAACu+o5AAAAAALNNwgAAAAAAtnoWQAAAAAC6zUoAAAAAAL35nkAAAAAAwkzSAAAAAADFnhBAAAAAAMnMWgAAAAAAzR2YQAAAAADRS+IAAAAAANSdIEAAAAAA2MtqAAAAAADcHKhAAAAAAOBv3AAAAAAA45wwQAAAAADn72QAAAAAAOsbuEAAAAAA727sAAAAAADywCpAAAAAAPbudAAAAAAA+j+yQAAAAAD+bfwAAAAAAQG/OkAAAAABBhJuAAAAAAEJPsJAAAAAAQ2R9gAAAAABEL5KQAAAAAEVEX4AAAAAARfPFEAIBAgECAQIBAgMEAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgH//52UAAD//6ugAQT//52QAAj//6ugAQz//6ugARBMTVQATURUAE1TVABNV1QATVBUAApNU1Q3TURULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAABgAAABj/////hb0iW/////+ZPJQA/////8uI8HD/////0iP0cP/////SYPvg/////9c1qPD/////2ACh4P/////7M5CM//////voO+D//////Ng68P/////9yB3gAAAAAAZA33AAAAAABzDCYAAAAAAHjRlwAAAAAAkQpGAAAAAACgCjcAAAAAAK8IZgAAAAAAvghXAAAAAADNmi4AAAAAANwGdwAAAAAA65hOAAAAAAD6mD8AAAAAAQmWbgAAAAABGJZfAAAAAAEnlI4AAAAAATaUfwAAAAABRZKuAAAAAAFUkp8AAAAAAWOQzgAAAAABcpC/AAAAAAGCIpYAAAAAAZCO3wAAAAABoCC2AAAAAAGvIKcAAAAAAb4e1gAAAAABzR7HAAAAAAHcHPYAAAAAAesc5wAAAAAB+hsWAAAAAAIHYA8AAAAAAhgZNgAAAAACJV4vAAAAAAI2qv4AAAAAAkNcTwAAAAACVKkeAAAAAAJhWm8AAAAAAnKnPgAAAAACf+w3AAAAAAKQpV4AAAAAAp3qVwAAAAACrqN+AAAAAAK76HcAAAAAAs01RgAAAAAC2eaXAAAAAALrM2YAAAAAAvfktwAAAAADCTGGAAAAAAMWdn8AAAAAAycvpgAAAAADNHSfAAAAAANFLcYAAAAAA1JyvwAAAAADYyvmAAAAAANwcN8AAAAAA4G9rgAAAAADjm7/AAAAAAOfu84AAAAAA6xtHwAAAAADvbnuAAAAAAPK/ucAAAAAA9u4DgAAAAAD6P0HAAAAAAP5ti4AAAAABAb7JwAAAAAEGEf2AAAAAAQk+UcAAAAABDZGFgAAAAAEQvdnAAAAAARURDYAAAAABF86jwAQIDBAIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgX//7IlAAD//6ugAAT//7mwAAj//8fAAQz//8fAARD//8fAARRMTVQAQ1NUAEVTVABFV1QARVBUAEVEVAAKRVNUNUVEVCxNMy4yLjAsTTExLjEuMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAABgAAABj/////iN7O4P////+euK+Q/////5+7B4D/////oJiRkP////+g0oWA/////6KK6JD/////o4QGAP////+kasqQ/////6U1w4D/////plPnEP////+nFaWA/////6gzyRD/////qP7CAP/////LiQyQ/////9Ij9HD/////0mEYAP/////VVeMQ/////9Yg3AAAAAAABGEZkAAAAAAFUPyAAAAAAAZA+5AAAAAABzDegAAAAAAIIN2QAAAAAAkQwIAAAAAACgC/kAAAAAAK8KKAAAAAAAvgoZAAAAAADNm/AAAAAAANwIOQAAAAAA65oQAAAAAAD6mgEAAAAAAQmYMAAAAAABGJghAAAAAAEnllAAAAAAATaWQQAAAAABRZRwAAAAAAFUlGEAAAAAAWOSkAAAAAABcpKBAAAAAAGCJFgAAAAAAZCQoQAAAAABoCJ4AAAAAAGvImkAAAAAAb4gmAAAAAABzSCJAAAAAAHcHrgAAAAAAeseqQAAAAAB+hzYAAAAAAIHYdEAAAAAAhga+AAAAAACJV/xAAAAAAI2rMAAAAAAAkNeEQAAAAACVKrgAAAAAAJhXDEAAAAAAnKpAAAAAAACf+35AAAAAAKQpyAAAAAAAp3sGQAAAAACrqVAAAAAAAK76jkAAAAAAs03CAAAAAAC2ehZAAAAAALrNSgAAAAAAvfmeQAAAAADCTNIAAAAAAMWeEEAAAAAAycxaAAAAAADNHZhAAAAAANFL4gAAAAAA1J0gQAAAAADYy2oAAAAAANwcqEAAAAAA4G/cAAAAAADjnDBAAAAAAOfvZAAAAAAA6xu4QAAAAADvbuwAAAAAAPLAKkAAAAAA9u50AAAAAAD6P7JAAAAAAP5t/AAAAAABAb86QAAAAAEGEm4AAAAAAQk+wkAAAAABDZH2AAAAAAEQvkpAAAAAARURfgAAAAABF88UQAAAAAEctfAAAAAAAR9OnEAAAAABJDV4AAAAAAEmziRAAAAAASu1AAAAAAABLnKWQAAAAAEzWXIAAAAAATXyHkAAAAABOtj6AAAAAAE9caZAAAAAAUJYggAAAAABRPEuQAAAAAFJ2AoAAAAAAUxwtkAAAAABUVeSAAAAAAFT8D5AAAAAAVjXGgAAAAABW5SwQAAAAAFge4wAAAAAAWMUOEAAAAABZ/sUAAAAAAFqk8BAAAAAAW96nAAAAAABchNIQAAAAAF2+iQAAAAAAXmS0EAAAAABfnmsAAAAAAGBN0JAAAAAAYYeHgAAAAABiLbKQAAAAAGNnaYAAAAAAZA2UkAAAAABlR0uAAAAAAGXtdpAAAAAAZyctgAAAAABnzViQAAAAAGkHD4AAAAAAaa06kAAAAABq5vGAAgECAQIBAgECAQIBAgMEAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQX//5WgAAD//6ugAQT//52QAAj//6ugAQz//6ugARD//6ugABRMTVQATURUAE1TVABNV1QATVBUAENTVAAKQ1NUNgo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAhAAAABAAAAAz/////lqqIgP////+4D2YA/////7j9XMD/////ufFQUP////+63pBA/////9o4ylD/////2uwWUP/////cGf3Q/////9y5dUD/////3fsxUP/////em/pA/////9/dtlD/////4FRPQP/////0mBvQ//////UFekD/////9sCAUP/////3DjrA//////hRSFD/////+MfhQP/////6Cu7Q//////qpFMD/////++wiUP/////8i5nAAAAAAB3JqlAAAAAAHnjzwAAAAAAfoFHQAAAAACAz68AAAAAAIYGFUAAAAAAiC+TAAAAAACzA0VAAAAAALWbgQAAAAABIYH9QAAAAAFJ/BMACAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAwL//76AAAD//8fAAQT//7mwAAj//8fAAARMTVQALTA0AC0wNQAKPC0wNT41Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAwAAAAz/////o9WmIAAAAAAgmtzgAAAAACFcm1AAAAAAInq+4AAAAAAjPH1QAgECAQL//6xgAAD//7mwAQT//6ugAAhMTVQAQ0RUAENTVAAKQ1NUNgo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACEAAAABgAAABj/////pbbocP////+peU9w/////6/xOYD/////tmZkcP////+3GxAA/////7gK8vD/////y+qNgP/////SI/Rw/////9KdrvD/////1xtZAP/////YkbTw/////9sABwD/////28Bz8P/////c3rOg/////92prJD/////3r6VoP/////fiY6Q/////+CeaZD/////4WlwkP/////ifkuQ/////+NJUpD/////5F4tkP/////lKTSQ/////+ZHShD/////5xJREP/////oJywQ/////+jyMxD/////6gcOEP/////q0hUQ/////+vm8BD/////7LH3EP/////txtIQ/////+6R2RD/////76/ukP/////wcbsQ//////GP0JD/////8n/BkP/////zb7KQ//////Rfo5D/////9U+UkP/////2P4WQ//////cvdpD/////+CiiEP/////5D1iQ//////oIhBD/////+viDIP/////76GYQ//////zYZSD//////chIEP/////+uEcg//////+oKhAAAAAAAJgpIAAAAAABiAwQAAAAAAJ4CyAAAAAAA3EokAAAAAAEYSegAAAAAAVRCpAAAAAABkEJoAAAAAAHMOyQAAAAAAeNQ6AAAAAACRDOkAAAAAAJrb8gAAAAAArwsJAAAAAAC+CvoAAAAAAM2c0QAAAAAA3AkaAAAAAADrmvEAAAAAAPqa4gAAAAABCZkRAAAAAAEYmQIAAAAAASeXMQAAAAABNpciAAAAAAFFlVEAAAAAAVSVQgAAAAABY5NxAAAAAAFyk2IAAAAAAYIlOQAAAAABkJGCAAAAAAGgI1kAAAAAAa8jSgAAAAABviF5AAAAAAHNIWoAAAAAAdwfmQAAAAAB6x+KAAAAAAH6HbkAAAAAAgdisgAAAAACGBvZAAAAAAIlYNIAAAAAAjatoQAAAAACQ17yAAAAAAJUq8EAAAAAAmFdEgAAAAACcqnhAAAAAAJ/7toAAAAAApCoAQAAAAACnez6AAAAAAKupiEAAAAAArvrGgAAAAACzTfpAAAAAALZ6ToAAAAAAus2CQAAAAAC9+daAAAAAAMJNCkAAAAAAxZ5IgAAAAADJzJJAAAAAAM0d0IAAAAAA0UwaQAAAAADUnViAAAAAANjLokAAAAAA3BzggAAAAADgcBRAAAAAAOOcaIAAAAAA5++cQAAAAADrG/CAAAAAAO9vJEAAAAAA8sBigAAAAAD27qxAAAAAAPo/6oAAAAAA/m40QAAAAAEBv3KAAAAAAQYSpkAAAAABCT76gAAAAAENki5AAAAAARC+goAAAAABFRG2QAAAAAEYPgqAAAAAARyRPkAAAAABH+J8gAAAAAEkEMZAAAAAASdiBIAAAAABK5BOQAAAAAEs9q4ABAgECAwIEBQIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgL//5JMAAD//52QAAT//4+AAAj//52QAQz//52QARD//52QARRMTVQATVNUAFBTVABQRFQAUFdUAFBQVAAKUFNUOFBEVCxNMy4yLjAsTTExLjEuMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACPAAAABgAAABj/////Xj12h/////+euL2g/////5+7FZD/////y4kaoP/////SI/Rw/////9JhJhD/////1VXxIP/////WIOoQ/////9c10yD/////2ADMEP/////ZFbUg/////9ngrhD/////2v7RoP/////bwJAQ/////9zes6D/////3amskP/////evpWg/////9+JjpD/////4J53oP/////haXCQ/////+J+WaD/////40lSkP/////kXjug/////+UpNJD/////5kdYIP/////nElEQ/////+gnOiD/////6PIzEP/////qBxwg/////+rSFRD/////6+b+IP/////ssfcQ/////+3G4CD/////7pHZEP/////vr/yg//////BxuxD/////8Y/eoP/////yf8GQ//////NvwKD/////9F+jkP/////1T6Kg//////Y/hZD/////9y+EoP/////4KKIQ//////kPZqD/////+giEEP/////6+IMg//////voZhD//////NhlIP/////9yEgQ//////64RyD//////6gqEAAAAAAAmCkgAAAAAAGIDBAAAAAAAngLIAAAAAADcSiQAAAAAARhJ6AAAAAABVEKkAAAAAAGQQmgAAAAAAcw7JAAAAAACCDroAAAAAAJEM6QAAAAAAoAzaAAAAAACvCwkAAAAAAL4K+gAAAAAAzZzRAAAAAADcCRoAAAAAAOua8QAAAAAA+priAAAAAAEJmREAAAAAARiZAgAAAAABJ5cxAAAAAAE2lyIAAAAAAUWVUQAAAAABVJVCAAAAAAFjk3EAAAAAAXKTYgAAAAABgiU5AAAAAAGQkYIAAAAAAaAjWQAAAAABryNKAAAAAAG+IXkAAAAAAc0hagAAAAAB3B+ZAAAAAAHrH4oAAAAAAfoduQAAAAACB2KyAAAAAAIYG9kAAAAAAiVg0gAAAAACNq2hAAAAAAJDXvIAAAAAAlSrwQAAAAACYV0SAAAAAAJyqeEAAAAAAn/u2gAAAAACkKgBAAAAAAKd7PoAAAAAAq6mIQAAAAACu+saAAAAAALNN+kAAAAAAtnpOgAAAAAC6zYJAAAAAAL351oAAAAAAwk0KQAAAAADFnkiAAAAAAMnMkkAAAAAAzR3QgAAAAADRTBpAAAAAANSdWIAAAAAA2MuiQAAAAADcHOCAAAAAAOBwFEAAAAAA45xogAAAAADn75xAAAAAAOsb8IAAAAAA728kQAAAAADywGKAAAAAAPburEAAAAAA+j/qgAAAAAD+bjRAAAAAAQG/coAAAAABBhKmQAAAAAEJPvqAAAAAAQ2SLkAAAAABEL6CgAAAAAEVEbZAAAAAARfPTIAAAAABHLYoQAAAAAEfTtSAAAAAASQ1sEAAAAABJs5cgAAAAAErtThAAAAAAS5yzoAAAAABM1mqQAAAAAE18laAAAAAATrZMkAAAAABPXHegAAAAAFCWLpAAAAAAUTxZoAAAAABSdhCQAAAAAFMcO6AAAAAAVFXykAAAAABU/B2gAgECAwQCAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgX//4z5AAD//52QAQT//4+AAAj//52QAQz//52QARD//52QABRMTVQAUERUAFBTVABQV1QAUFBUAE1TVAAKTVNUNwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmAAAABwAAABz/////XgP+oP////+epiyA/////5+6+XD/////oIYOgP////+hmttw/////8pXIoD/////ythHcP/////LiP6A/////9Ij9HD/////0mEJ8P/////TdfMA/////9RA6/D/////1VXVAP/////WIM3w/////9c1twD/////2ACv8P/////ZFZkA/////9ngkfD/////2v61gP/////bwHPw/////9zel4D/////3amQcP/////evnmA/////9+JcnD/////4J5bgP/////haVRw/////+J+PYD/////40k2cP/////kXh+A/////+jyFvD/////6gcAAP/////+uBzw//////+n/+AAAAAAAJf+8AAAAAABh+HgAAAAAEQvdnAAAAAARURDYAAAAABF86jwAgECAQIBAgMEAgECAQIBAgECAQIBAgECAQIBAgUCBQYFBgUGBQb//686AAD//7mwAQT//6ugAAj//7mwAQz//7mwARD//7mwABT//8fAARhMTVQAQ0RUAENTVABDV1QAQ1BUAEVTVABFRFQACkVTVDVFRFQsTTMuMi4wLE0xMS4xLjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAnAAAAAwAAAAz/////lqprGP////+4D0ng/////7j9QKD/////ufE0MP////+63nQg/////9o4rjD/////2uv6MP/////cGeGw/////9y5WSD/////3fsVMP/////em94g/////9/dmjD/////4FQzIP/////0l/+w//////UFXiD/////9sBkMP/////3Dh6g//////hRLDD/////+MfFIP/////6CtKw//////qo+KD/////++wGMP/////8i32gAAAAAB3JjjAAAAAAHnjXoAAAAAAfoDWwAAAAACAzz6AAAAAAIYFpMAAAAAAiC8igAAAAACNYELAAAAAAI+JwIAAAAAAlN/KwAAAAACXUxyAAAAAAN/bGsAAAAAA4uIUgAAAAADnf4zAAAAAAOfJKIAAAAAA7yP+wAAAAADxvDqACAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQL//9voAAD//+PgAQT//9XQAAhMTVQALTAyAC0wMwAKPC0wMz4zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABPAAAABQAAABT/////gPGoNP////+euIVg/////5+63VD/////y4jiYP/////SI/Rw/////9Jg7dD/////4J4/YP/////haThQAAAAAARg72AAAAAABVDSUAAAAAAGQNFgAAAAAAcwtFAAAAAACCCzYAAAAAAJEJZQAAAAAAoAlWAAAAAACvB4UAAAAAAL4HdgAAAAAAzZlNAAAAAADcBZYAAAAAAOuXbQAAAAAA+pdeAAAAAAEJlY0AAAAAARiVfgAAAAABJ5OtAAAAAAE2k54AAAAAAUWRzQAAAAABVJG+AAAAAAFjj+0AAAAAAXKP3gAAAAABgiG1AAAAAAGQjf4AAAAAAaAf1QAAAAABrx/GAAAAAAG+HfUAAAAAAc0d5gAAAAAB3BwVAAAAAAHrHAYAAAAAAfoaNQAAAAACB18uAAAAAAIYGFUAAAAAAiVdTgAAAAACNqodAAAAAAJDW24AAAAAAlSoPQAAAAACYVmOAAAAAAJypl0AAAAAAn/rVgAAAAACkKR9AAAAAAKd6XYAAAAAAq6inQAAAAACu+eWAAAAAALNNGUAAAAAAtnltgAAAAAC6zKFAAAAAAL349YAAAAAAwkwpQAAAAADFnWeAAAAAAMnLsUAAAAAAzRzvgAAAAADRSzlAAAAAANScd4AAAAAA2MrBQAAAAADcG/+AAAAAAOBvM0AAAAAA45uHgAAAAADn7rtAAAAAAOsbD4AAAAAA725DQAAAAADyv4GAAAAAAPbty0AAAAAA+j8JgAAAAAD+bVNAAAAAAQG+kYAAAAABBhHFQAAAAAEJPhmAAAAAAQ2RTUAAAAABEL2hgAAAAAEVENVAAAAAARfOa4AIBAgMEAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgH//8fMAAD//9XQAQT//8fAAAj//9XQAQz//9XQARBMTVQAQURUAEFTVABBV1QAQVBUAApBU1Q0QURULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABZAAAABAAAAAz/////m4BoAAAAAAATTXxQAAAAABQz+pAAAAAAFSPrkAAAAAAWE9yQAAAAABcDzZAAAAAAF/O+kAAAAAAY46+QAAAAABnToJAAAAAAGsORkAAAAAAbvL0QAAAAABysrhAAAAAAHZyfEAAAAAAejJAQAAAAAB98gRAAAAAAIGxyEAAAAAAhXGMQAAAAACJMVBAAAAAAIzxFEAAAAAAkLDYQAAAAACUcJxAAAAAAJgwYEAAAAAAnBUOQAAAAACf1NJAAAAAAKOUlkAAAAAAp1RaQAAAAACrFB5AAAAAAK7T4kAAAAAAspOmQAAAAAC2U2pAAAAAALoTLkAAAAAAvdLyQAAAAADBkrZAAAAAAMV3ZEAAAAAAycrQQAAAAADM9uxAAAAAANFKWEAAAAAA1HZ0QAAAAADYyeBAAAAAANv1/EAAAAAA4G5SQAAAAADjdYRAAAAAAOft2kAAAAAA6vUMQAAAAADvbWJAAAAAAPKZfkAAAAAA9uzqQAAAAAD6GQZAAAAAAP5sckAAAAABAZiOQAAAAAEGEORAAAAAAQkYFkAAAAABDZBsQAAAAAEQl55AAAAAARUP9EAAAAABGBcmQAAAAAEcj3xAAAAAAR+7mEAAAAABJA8EQAAAAAEnOyBAAAAAASuOjEAAAAABLrqoQAAAAAEzMv5AAAAAATY6MEAAAAABOrKGQAAAAAE9ubhAAAAAAUIyDkAAAAABRV4qQAAAAAFJsZZAAAAAAUzdskAAAAABUTEeQAAAAAFUXTpAAAAAAViwpkAAAAABW9zCQAAAAAFgVRhAAAAAAWNcSkAAAAABZ9SgQAAAAAFq29JAAAAAAW9UKEAAAAABcoBEQAAAAAF207BAAAAAAXn/zEAAAAABflM4QAAAAAGBf1RAAAAAAYX3qkAAAAABiP7cQAAAAAGNdzJAAAAAAZB+ZEAAAAABlPa6QAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAwP//8+AAAD//9XQAAT//+PgAQj//+PgAAhMTVQALTAzAC0wMgAKPC0wMj4yPC0wMT4sTTMuNS4wLy0xLE0xMC41LjAvMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACYAAAACgAAACH/////Xj08JP////+euH6M/////5+61nz/////vp5NbP/////AuDE4/////8F576j/////wpgTOP/////DWdGo/////8R39Tj/////xTmzqP/////GYRG4/////8cZlaj/////yEDzuP/////JArIo/////8og1bj/////yuKUKP/////MALe4/////9Ij9HD/////0mDmyP/////TiETY/////9RKA0j/////1Wgm2P/////WKeVI/////9dICNj/////2AnHSP/////ZJ+rY/////9npqUj/////2xEHWP/////b0sXI/////9zedFj/////3altSP/////evlZY/////9+JT0j/////4J44WP/////haTFI/////+J+Glj/////40kTSP/////kXfxY/////+Uo9Uj/////5kcY2P/////nEhHI/////+gm+tj/////6PHzyP/////qBtzY/////+rR1cj/////6+a+2P/////ssbfI/////+3GoNj/////7r++SP/////vr71Y//////CfoEj/////8Y+fWP/////yf4JI//////NvgVj/////9F9kSP/////1T2NY//////Y/Rkj/////9y9FWP/////4KGLI//////jaa1j/////+Q8uYP/////6CEvQ//////r4SuD/////++gt0P/////82Czg//////3ID9D//////rgO4P//////p/HQAAAAAACX8OAAAAAAAYfT0AAAAAACd9LgAAAAAANw8FAAAAAABGDvYAAAAAAFUNJQAAAAAAZA0WAAAAAABzC0UAAAAAAIILNgAAAAAAkQllAAAAAACgCVYAAAAAAK8HhQAAAAAAvgd2AAAAAADNmU0AAAAAANwFlgAAAAAA65dtAAAAAAD6l14AAAAAAQmVjQAAAAABGJV+AAAAAAEnk60AAAAAATaTngAAAAABRZHNAAAAAAFUkb4AAAAAAWOP7QAAAAABco/eAAAAAAGCIbUAAAAAAZCN/gAAAAABoB/VAAAAAAGvH8YAAAAAAb4d9QAAAAABzR3mAAAAAAHcHBUAAAAAAescBgAAAAAB+ho1AAAAAAIHXW/AAAAAAhgWlsAAAAACJVuPwAAAAAI2p33AAAAAAkNZr8AAAAACVKZ+wAAAAAJhV8/AAAAAAnKknsAAAAACf+mXwAAAAAKQor7AAAAAAp3nt8AAAAACrqDewAAAAAK75dfAAAAAAs0ypsAAAAAC2eP3wAAAAALrMMbAAAAAAvfiF8AAAAADCS7mwAAAAAMWc9/AAAAAAyctBsAAAAADNHH/wAAAAANFKybAAAAAA1JwH8AAAAADYylGwAAAAANwbj/AAAAAA4G7DsAAAAADjmxfwAAAAAOfuS7AAAAAA6xqf8AAAAADvbdOwAAAAAPK/EfAAAAAA9u1bsAAAAAD6PpnwAAAAAP5s47AAAAABAb4h8AAAAAEGEVWwAAAAAQk9qfAAAAABDZDdsAAAAAEQvTHwAAAAARUQZbAAAAABF8378AAAAAEctNewAAAAAR9Ng/AAAAABJDRfsAAAAAEmzQvwAAAAASuz57AAAAABLnF98AAAAAEzWFmwAAAAATXxBfAAAAABOr2CwAQIBAwQDBAMEAwQDBAMEAwYFAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMIBwgHCAcIBwgHCAcIBwgHCAcIBwgHCAcIBwgHCAcIBwgHCAcIBwgHCAcIBwgJCAcIBwgHCAcIBwgHCAcIBwgHCAcIBwgHCAcIBwgHCAcIBwgHCAcIBwgHCAcIBwf//8dcAAD//86UAAT//9ykAQj//87IAAT//9zYAQj//9zYAQz//9zYARD//9XQART//8fAABj//+PgARxMTVQATlNUAE5EVABOUFQATldUAEFEVABBU1QAQUREVAAKQVNUNEFEVCxNMy4yLjAsTTExLjEuMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABMAAAABQAAABT/////aYceMP////+TD7T+AAAAABGJZfAAAAAAEnlI4AAAAAATaUfwAAAAABRZKuAAAAAAFUkp8AAAAAAWOQzgAAAAABcpC/AAAAAAGCIpYAAAAAAZCO3wAAAAABoCC2AAAAAAGvIKcAAAAAAb4e1gAAAAABzR7HAAAAAAHcHPYAAAAAAesc5wAAAAAB+hsWAAAAAAIHYA8AAAAAAhgZNgAAAAACJV4vAAAAAAI2qv4AAAAAAkNcTwAAAAACVKkeAAAAAAJhWm8AAAAAAnKnPgAAAAACf+w3AAAAAAKQpV4AAAAAAp3qVwAAAAACrqN+AAAAAAK76HcAAAAAAs01RgAAAAAC2eaXAAAAAALrM2YAAAAAAvfktwAAAAADCTGGAAAAAAMWdn8AAAAAAycvpgAAAAADNHSfAAAAAANFLcYAAAAAA1JyvwAAAAADYyvmAAAAAANwcN8AAAAAA4G9rgAAAAADjm7/AAAAAAOfu84AAAAAA6xtHwAAAAADvbnuAAAAAAPK/ucAAAAAA9u4DgAAAAAD6P0HAAAAAAP5ti4AAAAABAb7JwAAAAAEGEf2AAAAAAQk+UcAAAAABDZGFgAAAAAEQvdnAAAAAARURDYAAAAABF86jwAAAAAEctX+AAAAAAR9OK8AAAAABJDUHgAAAAAEmzbPAAAAAASu0j4AAAAABLnIlwAAAAAEzWQGAAAAAATXxrcAAAAABOtiJgAAAAAE9cTXAAAAAAUJYEYAAAAABRPC9wAAAAAFJ15mAAAAAAUxwRcAAAAABUVchgAAAAAFT783AAAAAAWqTT8AECAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCBAP//71QAAD//7gCAAT//7mwAAj//8fAAQz//8fAABBMTVQAS01UAEVTVABFRFQAQVNUAApFU1Q1RURULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJAAAAAwAAAAz/////n53q3AAAAAAHVaxgAAAAAAfNltAAAAAAGSx4YAAAAAAZz+RQAAAAACfq7uAAAAAAKMhc0AAAAABEVFJgAAAAAEUfS1ACAQIBAgECAQL//6skAAD//7mwAQT//6ugAAhMTVQAQ0RUAENTVAAKQ1NUNgo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAABAAAABD/////aYcmWP////+2pEIYAAAAACsW/NAAAAAAK3HmQAEDAgP//7UoAAD//7ZoAAT//8fAAQj//7mwAAxMTVQAUU1UAC0wNAAtMDUACjwtMDU+NQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAABAAAABL/////kh0Ph/////+Y2XtAAAAAAAp/BbwAAAAAKdVAwAECAwH//8l5AAD//8fAAAT//8tEAAj//9XQAA5MTVQALTA0AC0wMzQ1AC0wMwAKPC0wND40Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACnAAAABQAAABT/////gPGroP////+a5N7A/////5vWEzD/////nriFYP////+fut1Q/////6KdF0D/////ozCxMP////+kelZA/////6UbHzD/////plOgwP////+m/FKw/////6g8vUD/////qNw0sP////+qHJ9A/////6rNOjD/////q/yBQP////+sv5Ew/////63u2ED/////roz+MP////+vvEVA/////7B/VTD/////sa6cQP////+yS3Cw/////7OOfkD/////tCS7MP////+1bmBA/////7YVwLD/////t05CQP////+4CBew/////7kk6cD/////uef5sP////+7BMvA/////7vRFjD/////vQBdQP////+9nTGw/////77ytED/////v5DaMP/////A0+fA/////8FeRzD/////wo2OQP/////DUJ4w/////8RtcED/////xTCAMP/////GcjxA/////8cQYjD/////yDZuwP/////I+X6w/////8oWUMD/////ytlgsP/////LiOJg/////9Ij9HD/////0mDt0P/////Tddbg/////9RAz9D/////1VW44P/////WILHQ/////9c1muD/////2ACT0P/////ZFXzg/////9ngddD/////3N57YP/////dqXRQ/////96+XWD/////34lWUP/////gnj9g/////+FpOFD/////4n4hYP/////jSRpQ/////+ZHH+D/////5xIY0P/////oJwHg/////+jx+tD/////6gbj4P/////q0dzQ/////+vmxeD/////7LG+0P/////xj6Zg//////J/iVD/////82+IYP/////0X2tQ//////VPamD/////9j9NUP/////3L0xg//////goadD/////+Q8uYP/////6CEvQ//////r4SuD/////++gt0P/////82Czg//////3ID9D//////rgO4P//////p/HQAAAAAACX8OAAAAAAAYfT0AAAAAACd9LgAAAAAANw8FAAAAAABGDvYAAAAAAFUNJQAAAAAAZA0WAAAAAABzC0UAAAAAAIILNgAAAAAAkQllAAAAAACgCVYAAAAAAK8HhQAAAAAAvgd2AAAAAADNmU0AAAAAANwFlgAAAAAA65dtAAAAAAD6l14AAAAAAQmVjQAAAAABGJV+AAAAAAEnk60AAAAAATaTngAAAAABRZHNAAAAAAFUkb4AAAAAAWOP7QAAAAABco/eAAAAAAGCIbUAAAAAAZCN/gAAAAABoB/VAAAAAAGvH8YAAAAAAb4d9QAAAAABzR3mAAAAAAHcHBUAAAAAAescBgAAAAAB+ho1AAAAAAIHXy4AAAAAAhgYVQAAAAACJV1OAAAAAAI2qh0AAAAAAkNbbgAAAAACVKg9AAAAAAJhWY4AAAAAAnKmXQAAAAACf+tWAAAAAAKQpH0AAAAAAp3pdgAAAAACrqKdAAAAAAK755YAAAAAAs00ZQAAAAAC2eW2AAAAAALrMoUAAAAAAvfj1gAAAAADCTClAAAAAAMWdZ4AAAAAAycuxQAAAAADNHO+AAAAAANFLOUAAAAAA1Jx3gAAAAADYysFAAAAAANwb/4AAAAAA4G8zQAAAAADjm4eAAAAAAOfuu0AAAAAA6xsPgAAAAADvbkNAAAAAAPK/gYAAAAAA9u3LQAAAAAD6PwmAAAAAAP5tU0AAAAABAb6RgAAAAAEGEcVAAAAAAQk+GYAAAAABDZFNQAAAAAEQvaGAAAAAARUQ1UAAAAABF85rgAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgMEAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgH//8RgAAD//9XQAQT//8fAAAj//9XQAQz//9XQARBMTVQAQURUAEFTVABBV1QAQVBUAApBU1Q0QURULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABqAAAABAAAABD/////aYcouP////+sYsKA/////7HTlFD/////snRdQP/////IW2bQ/////8jTUUD/////yjtI0P/////KvG3A/////8wkZVD/////zJxPwP/////RxAtQ/////9I79cD/////06PtUP/////UG9fA//////dgBdD/////9/99QP/////5PUTQ//////njU8D/////+ts70P/////7p4ZA//////zFqdD//////YdoQP/////+uADQ//////+n48AAAAAAAJfi0AAAAAABh8XAAAAAAAJ3xNAAAAAAA3DiQAAAAAAEYOFQAAAAAAU1FMAAAAAABkDDUAAAAAAHFkhAAAAAAAggpVAAAAAACPd7wAAAAAAKAIdQAAAAAArwakAAAAAAC+BpUAAAAAAM2YbAAAAAAA3AS1AAAAAADrlowAAAAAAPsqJQAAAAABB9m0AAAAAAEVHq0AAAAAASZrfAAAAAABMxzNAAAAAAFEaZwAAAAAAVW4LQAAAAABYme8AAAAAAFztk0AAAAAAYBl3AAAAAABkbRtAAAAAAGeY/wAAAAAAa+yjQAAAAABvPXEAAAAAAHNsK0AAAAAAdrz5AAAAAAB56U1AAAAAAH48gQAAAAAAgWjVQAAAAACFvAkAAAAAAIkNR0AAAAAAjTuRAAAAAACQjM9AAAAAAJS7GQAAAAAAmFYrQAAAAACcX4sAAAAAAJ/6nUAAAAAAo99LQAAAAACneiVAAAAAAKte00AAAAAArvmtQAAAAACy3ltAAAAAALZ5NUAAAAAAul3jQAAAAAC9+L1AAAAAAMHda0AAAAAAxZ0vQAAAAADJXPNAAAAAAM0ct0AAAAAA0QFlQAAAAADUd1VAAAAAANjKwUAAAAAA2/bdQAAAAADgbzNAAAAAAOObT0AAAAAA5+67QAAAAADrGtdAAAAAAO9uQ0AAAAAA8r9JQAAAAAD27ctAAAAAAPo+0UAAAAAA/m1TQAAAAAEBmW9AAAAAARUQ1UAAAAABF84zQAAAAAEckF1AAAAAAR9ypUAAAAABJA/lQAAAAAEmzUNAAAAAASuPbUAAAAABLnG1QAAAAAEzM99AAAAAATYWJ0AAAAABOv07QAAAAAE934NAAAAAAUJX2UAEDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgP//7LIAAD//7LAAAT//8fAAQj//7mwAAxMTVQASE1UAENEVABDU1QACkNTVDVDRFQsTTMuMi4wLzAsTTExLjEuMC8xCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANAAAABAAAABD/////pbbocP////+v8Stw/////7ZmVmD/////t0E9cP////+4DDZg/////7j9hvD/////y+pxYAAAAAAxZ4QQAAAAADJzFoAAAAAAM0dmEAAAAAA0UviAAAAAADUnSBAAAAAANjLagAECAQMBAgEDAQMBAwH//5f4AAD//52QAAT//6ugAAj//6ugAQxMTVQATVNUAENTVABNRFQACk1TVDcK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABdAAAABgAAABj/////XgP+oP////+epiyA/////5+6+XD/////oIYOgP////+hmttw/////8uI/oD/////0iP0cP/////SYQnw/////9VV1QD/////1iDN8P/////XNbcA/////9gAr/D/////2RWZAP/////Z4JHw/////9r+tYD/////28Bz8P/////c3peA/////92pkHD/////3r55gP/////fiXJw/////+CeW4D/////4WlUcP/////ifj2A/////+NJNnD/////5F4fgP/////lVzzw/////+ZHPAD/////5zce8P/////oJx4A/////+jyFvD/////6gcAAP/////q0fjw/////+vm4gD/////7NbE8P/////txsQA/////+6/4XD/////76/ggP/////wn8Nw//////GPwoD/////9F+HcP/////6+GcA//////voSfD//////NhJAP/////9yCvw//////64KwD//////6gN8AAAAAAAmA0AAAAAAAGH7/AAAAAAAnfvAAAAAAADcQxwAAAAAARhC4AAAAAABVDucAAAAAAGQO2AAAAAAAcw0HAAAAAAB40ngAAAAAAJELJwAAAAAAmtowAAAAAACvCUcAAAAAAL4JOAAAAAAAzZsPAAAAAADcB1gAAAAAAOuZLwAAAAAA+pkgAAAAAAEJl08AAAAAARiXQAAAAAABJ5VvAAAAAAE2lWAAAAAAAUWTjwAAAAABVJOAAAAAAAFjka8AAAAAAXKRoAAAAAABgiN3AAAAAAGQj8AAAAAAAaAhlwAAAAABryGIAAAAAAG+H7cAAAAAAc0fqAAAAAAB3B3XAAAAAAHrHcgAAAAAAfob9wAAAAACB2DwAAAAAAIYGhcAAAAAAiVfEAAAAAACNqvfAAAAAAJDXTAAAAAAAlSp/wAAAAACYVtQAAAAAAJyqB8AAAAAAn/tGAAAAAACkKY/AAAAAARC92cAAAAABFRFFwAAAAAEXztwACAQIBAgMEAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgUCAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQUBAgH//67KAAD//7mwAQT//6ugAAj//7mwAQz//7mwARD//7mwABRMTVQAQ0RUAENTVABDV1QAQ1BUAEVTVAAKQ1NUNkNEVCxNMy4yLjAsTTExLjEuMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAqAAAABwAAABz/////XgP+oP////+epiyA/////5+6+XD/////oIYOgP////+hmttw/////8uI/oD/////0iP0cP/////SYQnw/////9zel4D/////3amQcP/////ifj2A/////+NJNnD/////5F4fgP/////lKRhw/////+ZHPAD/////5xI08P/////oJx4A/////+jyFvD/////6gcAAP/////q0fjw/////+vm4gD/////7LHa8P/////txsQA/////+6RvPD/////76/ggP/////+uBzw//////+n/+AAAAAAAJf+8AAAAAABh+HgAAAAAAJ34PAAAAAAA3D+YAAAAAAEYP1wAAAAAAVQ4GAAAAAABkDfcAAAAAAHMMJgAAAAAAeNGXAAAAAACRCycAAAAAAJrZTwAAAAAArwhmAAAAAARC92cAAAAABFRENgAAAAAEXzqPACAQIBAgMEAgECAQIBAgECAQIBAgECAQIFBgUGBQYFBgUGBQEFBgUGBQb//68NAAD//7mwAQT//6ugAAj//7mwAQz//7mwARD//7mwABT//8fAARhMTVQAQ0RUAENTVABDV1QAQ1BUAEVTVABFRFQACkVTVDVFRFQsTTMuMi4wLE0xMS4xLjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4AAAABgAAABj/////XgP+oP////+epiyA/////5+6+XD/////oIYOgP////+hmttw/////8uI/oD/////0iP0cP/////SYQnw/////+RnPeD/////5SkYcP/////mRzwA/////+cSNPD/////6CceAP/////o8hbw/////+oHAAD/////6tH48P/////r5uIA/////+yx2vD/////7cbEAP/////ukbzw/////++v4ID/////8J/DcP/////xj8KA//////J/pXD/////82+kgP/////0X4dw//////VPhoD/////9j9pcP/////3L2iA//////oIZ/D/////+vhnAP/////76Enw//////zYSQD//////cgr8P/////+uCsA//////+oDfAAAAAAAJgNAAAAAAABh+/wAAAAAAJ37wAAAAAAA3EMcAAAAAAEYQuAAAAAAAVQ7nAAAAAABkDtgAAAAAAHMNBwAAAAAAeNJ4AAAAAACRCycAAAAAAJraMAAAAAAArwlHAAAAAAC+CTgAAAAAAM2bDwAAAAAA3AdYAAAAAADrmS8AAAAABEL3ZwAAAAAEVEUXAAAAAARfO3AAAAAABHLW3wAgECAQIDBAIBAgECAQIBAgECAQIBAgECAQIBAgUCAQIBAgECAQIBAgECAQIBAgECAQIBBQECAQX//64tAAD//7mwAQT//6ugAAj//7mwAQz//7mwARD//7mwABRMTVQAQ0RUAENTVABDV1QAQ1BUAEVTVAAKRVNUNUVEVCxNMy4yLjAsTTExLjEuMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlAAAABwAAABz/////XgP+oP////+epiyA/////5+6+XD/////oIYOgP////+hmttw/////8uI/oD/////0iP0cP/////SYQnw/////+RnPeD/////5SkYcP/////mRzwA/////+cSNPD/////6CceAP/////o8hbw/////+oHAAD/////6tH48P/////r5uIA/////+yx2vD/////7cbEAP/////ukbzw/////++v4ID/////8J/DcP/////xj8KA//////J/pXD/////82+kgP/////0X4dw//////VPhoD/////++hJ8P/////82EkA//////3IK/D//////rgrAP//////p//gAAAAAACX/vAAAAAAAYfh4AAAAABEL3ZwAAAAAEVEUXAAAAAARfO3AAIBAgECAwQCAQIBAgECAQIBAgECAQIBAgECBQIBAgYFBgUBAgH//66pAAD//7mwAQT//6ugAAj//7mwAQz//7mwARD//7mwABT//8fAARhMTVQAQ0RUAENTVABDV1QAQ1BUAEVTVABFRFQACkNTVDZDRFQsTTMuMi4wLE0xMS4xLjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAABwAAABz/////XgP+oP////+epiyA/////5+6+XD/////oIYOgP////+hmttw/////8uI/oD/////0iP0cP/////SYQnw/////+J+PYD//////rgc8P//////p//gAAAAAACX/vAAAAAAAYfh4AAAAAACd+DwAAAAAANw/mAAAAAABGD9cAAAAAAFUOBgAAAAAEQvdnAAAAAARURDYAAAAABF86jwAgECAQIDBAIFBgUGBQYFBgUGBQb//7BAAAD//7mwAQT//6ugAAj//7mwAQz//7mwARD//7mwABT//8fAARhMTVQAQ0RUAENTVABDV1QAQ1BUAEVTVABFRFQACkVTVDVFRFQsTTMuMi4wLE0xMS4xLjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAApAAAABwAAABz/////XgP+oP////+epiyA/////5+6+XD/////oIYOgP////+hmttw/////8uI/oD/////0iP0cP/////SYQnw/////9N18wD/////1EDr8P/////gnluA/////+FpVHD/////4n49gP/////jSTZw/////+RnPeD/////5SkYcP/////mRzwA/////+cSNPD/////6CceAP/////o8hbw/////+oHAAD/////6tH48P/////r5uIA/////+yx2vD/////7cbEAP/////uv+Fw/////++v4ID/////8HGe8P/////xj8KA//////J/pXD/////82+kgP/////0X4dw//////VPhoD//////rgc8P//////p//gAAAAAACX/vAAAAAAAYfh4AAAAABEL3ZwAAAAAEVEUXAAAAAARfO3AAAAAABHLW3wAgECAQIDBAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIFBgUGBQECAQX//63xAAD//7mwAQT//6ugAAj//7mwAQz//7mwARD//7mwABT//8fAARhMTVQAQ0RUAENTVABDV1QAQ1BUAEVTVABFRFQACkVTVDVFRFQsTTMuMi4wLE0xMS4xLjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAuAAAABwAAABz/////XgP+oP////+epiyA/////5+6+XD/////oIYOgP////+hmttw/////8uI/oD/////0iP0cP/////SYQnw/////9N18wD/////1EDr8P/////VVdUA/////9YgzfD/////1zW3AP/////YAK/w/////9kVmQD/////2eCR8P/////a/rWA/////9vAc/D/////3N6XgP/////dqZBw/////96+eYD/////34lycP/////gnluA/////+FpVHD/////4n49gP/////jSTZw/////+ReH4D/////5Vc88P/////mRzwA/////+c3HvD/////6CceAP/////o8hbw/////+oHAAD/////6tH48P/////r5uIA/////+yx2vD/////7cbEAP/////ukbzw/////++v4ID//////rgc8P//////p//gAAAAAACX/vAAAAAAAYfh4AAAAABEL3ZwAAAAAEVEUXAAAAAARfO3AAIBAgECAwQCAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECBQYFBgUBAgb//67PAAD//7mwAQT//6ugAAj//7mwAQz//7mwARD//7mwABT//8fAARhMTVQAQ0RUAENTVABDV1QAQ1BUAEVTVABFRFQACkVTVDVFRFQsTTMuMi4wLE0xMS4xLjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABvAAAABgAAABj/////4AZOgAAAAAAEYSegAAAAAAVRCpAAAAAABkEJoAAAAAAHMOyQAAAAAAgg66AAAAAACRDOkAAAAAAKAM2gAAAAAArwsJAAAAAAC+CvoAAAAAAM2c0QAAAAAA3AkaAAAAAADrmvEAAAAAAPqa4gAAAAABCZkRAAAAAAEYmQIAAAAAASeWUAAAAAABNpZBAAAAAAFFlHAAAAAAAVSUYQAAAAABY5KQAAAAAAFykoEAAAAAAYIkWAAAAAABkJChAAAAAAGgIngAAAAAAa8iaQAAAAABviCYAAAAAAHNIIkAAAAAAdweuAAAAAAB6x6pAAAAAAH6HNgAAAAAAgdh0QAAAAACGBr4AAAAAAIlX/EAAAAAAjaswAAAAAACQ14RAAAAAAJUquAAAAAAAmFcMQAAAAACcqkAAAAAAAJ/7fkAAAAAApCnIAAAAAACnewZAAAAAAKupUAAAAAAArvqOQAAAAACzTcIAAAAAALZ6FkAAAAAAus1KAAAAAAC9+Z5AAAAAAMJM0gAAAAAAxZ4QQAAAAADJzFoAAAAAAM0dmEAAAAAA0UviAAAAAADUnSBAAAAAANjLagAAAAAA3ByoQAAAAADgb9wAAAAAAOOcMEAAAAAA5+9kAAAAAADrG7hAAAAAAO9u7AAAAAAA8sAqQAAAAAD27nQAAAAAAPo/skAAAAAA/m38AAAAAAEBvzpAAAAAAQYSbgAAAAABCT7CQAAAAAENkfYAAAAAARC+SkAAAAABFRF+AAAAAAEXzxRAAAAAARy18AAAAAABH06cQAAAAAEkNXgAAAAAASbOJEAAAAABK7UAAAAAAAEucpZAAAAAATNZcgAAAAABNfIeQAAAAAE62PoAAAAAAT1xpkAAAAABQliCAAAAAAFE8S5AAAAAAUnYCgAAAAABTHC2QAAAAAFRV5IAAAAAAVPwPkAAAAABWNcaAAAAAAFblLBAAAAAAWB7jAAAAAABYxQ4QAAAAAFn+xQAAAAAAWqTwEAAAAABb3qcAAAAAAFyE0hAAAAAAXb6JAAAAAABeZLQQAAAAAF+eawAAAAAAYE3QkAAAAABhh4eAAAAAAGItspAAAAAAY2dpgAAAAABkDZSQAAAAAGVHS4AAAAAAZe12kAAAAABnJy2AAAAAAGfNWJAAAAAAaQcPgAAAAABprTqQAAAAAGrm8YACAQIBAgECAQIBAgECAQIEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAUAAAAAAAD//52QAQT//4+AAAj//52QAAz//6ugARD//6ugABQtMDAAUERUAFBTVABNU1QATURUAENTVAAKQ1NUNgo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABKAAAABwAAABz/////zGyhgP/////SI/Rw/////9Jg++AAAAAABGD9cAAAAAAFUOBgAAAAAAZA33AAAAAABzDCYAAAAAAIIMFwAAAAAAkQpGAAAAAACgCjcAAAAAAK8IZgAAAAAAvghXAAAAAADNmi4AAAAAANwGdwAAAAAA65hOAAAAAAD6mD8AAAAAAQmWbgAAAAABGJZfAAAAAAEnlI4AAAAAATaUfwAAAAABRZKuAAAAAAFUkp8AAAAAAWOQzgAAAAABcpC/AAAAAAGCIpYAAAAAAZCO3wAAAAABoCC2AAAAAAGvIKcAAAAAAb4e1gAAAAABzR7HAAAAAAHcHPYAAAAAAesc5wAAAAAB+hsWAAAAAAIHYA8AAAAAAhgZNgAAAAACJV4vAAAAAAI2qv4AAAAAAkNcTwAAAAACVKkeAAAAAAJhWm8AAAAAAnKnPgAAAAACf+w3AAAAAAKQpV4AAAAAAp3qVwAAAAACrqN+AAAAAAK76HcAAAAAAs01RgAAAAAC2eaXAAAAAALrM2YAAAAAAvfktwAAAAADCTGGAAAAAAMWdn8AAAAAAycvpgAAAAADNHSfAAAAAANFLcYAAAAAA1JyvwAAAAADYyvmAAAAAANwcN8AAAAAA4G9rgAAAAADjm/gAAAAAAOfvK8AAAAAA6xtHwAAAAADvbnuAAAAAAPK/ucAAAAAA9u4DgAAAAAD6P0HAAAAAAP5ti4AAAAABAb7JwAAAAAEGEf2AAAAAAQk+UcAAAAABDZGFgAAAAAEQvdnAAAAAARURDYAAAAABF86jwBAECAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwUGAgMCAwIDAgMCAwIDAgMAAAAAAAD//8fAAQT//7mwAAj//8fAAQz//8fAARD//6ugABT//7mwARgtMDAARVBUAEVTVABFRFQARVdUAENTVABDRFQACkVTVDVFRFQsTTMuMi4wLE0xMS4xLjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWAAAABAAAABD/////aYcjfv////+TD7T+AAAAAAeNGXAAAAAACRCkYAAAAAAJrZTwAAAAAArwhmAAAAAAC+CFcAAAAAAM2aLgAAAAAA3AZ3AAAAAADrmE4AAAAAAPqYPwAAAAABCZZuAAAAAAEYll8AAAAAASeUjgAAAAABNpR/AAAAAAFFkq4AAAAAAVSSnwAAAAABY5DOAAAAAAFykL8AAAAAAYIilgAAAAABkI7fAAAAAAGgILYAECAwIDAgMCAwIDAgMCAwIDAgMCAwL//7gCAAD//7gCAAT//7mwAAj//8fAAQxMTVQAS01UAEVTVABFRFQACkVTVDUK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABTAAAACgAAACb/////P8L90f////99hzLF/////8uJGqD/////0iP0cP/////SYSYQ//////64RyD//////6gqEAAAAAAAmCkgAAAAAAGIDBAAAAAAAngLIAAAAAADcSiQAAAAAARhJ6AAAAAABVEKkAAAAAAGQQmgAAAAAAcw7JAAAAAAB41DoAAAAAAJEM6QAAAAAAmtvyAAAAAACvCwkAAAAAAL4K+gAAAAAAzZzRAAAAAADcCRoAAAAAAOua8QAAAAAA+priAAAAAAEJmREAAAAAARiZAgAAAAABJ5cxAAAAAAE2lyIAAAAAAUWWMgAAAAABVJVCAAAAAAFjk3EAAAAAAXKTYgAAAAABgiU5AAAAAAGQkYIAAAAAAaAjWQAAAAABorFBAAAAAAGvJCsAAAAAAb4iWgAAAAABzSJLAAAAAAHcIHoAAAAAAesgawAAAAAB+h6aAAAAAAIHY5MAAAAAAhgcugAAAAACJWGzAAAAAAI2roIAAAAAAkNf0wAAAAACVKyiAAAAAAJhXfMAAAAAAnKqwgAAAAACf++7AAAAAAKQqOIAAAAAAp3t2wAAAAACrqcCAAAAAAK76/sAAAAAAs04ygAAAAAC2eobAAAAAALrNuoAAAAAAvfoOwAAAAADCTUKAAAAAAMWegMAAAAAAyczKgAAAAADNHgjAAAAAANFMUoAAAAAA1J2QwAAAAADYy9qAAAAAANwdGMAAAAAA4HBMgAAAAADjnKDAAAAAAOfv1IAAAAAA6xwowAAAAADvb1yAAAAAAPLAmsAAAAAA9u7kgAAAAAD6QCLAAAAAAP5ubIAAAAABAb+qwAAAAAEGEt6AAAAAAQk/MsAAAAABDZJmgAAAAAEQvrrAAAAAARUR7oAAAAABF8+EwAQIDBAIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBgIFAgUCBQcJCAkICQgJCAkICQgJCAkICQgJCAkICQgJCAkICQgJCAkICQgJCAkICQgJCAkICQgAANN7AAD//4H7AAD//4+AAAT//52QAQj//52QAQz//52QARD//4+AART//4FwABj//4+AARz//4FwACFMTVQAUFNUAFBXVABQUFQAUERUAFlEVABZU1QAQUtEVABBS1NUAApBS1NUOUFLRFQsTTMuMi4wLE0xMS4xLjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB1AAAABwAAABz/////XgP+oP////+epiyA/////5+6+XD/////oIYOgP////+hmttw/////6Rz9wD/////pRYRcP/////KDU6A/////8rYR3D/////y4j+gP/////SI/Rw/////9JhCfD/////03XXHP/////TpAlw/////9r+tYD/////28Bz8P/////c3peA/////92pkHD/////3r55gP/////fiXJw/////+CeW4D/////4WlUcP/////ifj2A/////+NJNnD/////5F4fgP/////lKRhw/////+ZHPAD/////5zce8P/////oJx4A/////+kXAPD/////6gcAAP/////q9uLw/////+vm4gD/////7NbE8P/////txsQA/////+6/4XD/////76/ggP/////wHpBw//////zYOvD//////cgd4P/////+uBzw//////+n/+AAAAAAAJf+8AAAAAABh+HgAAAAAAJ34PAAAAAAA3D+YAAAAAAEYP1wAAAAAAVQ4GAAAAAABkDfcAAAAAAHMMJgAAAAAAeNGXAAAAAACRCycAAAAAAJrZTwAAAAAArwhmAAAAAAC+CFcAAAAAAM2aLgAAAAAA3AZ3AAAAAADrmE4AAAAAAPqYPwAAAAABCZZuAAAAAAEYll8AAAAAASeUjgAAAAABNpR/AAAAAAFFkq4AAAAAAVSSnwAAAAABY5DOAAAAAAFykL8AAAAAAYIilgAAAAABkI7fAAAAAAGgILYAAAAAAa8gpwAAAAABvh7WAAAAAAHNHscAAAAAAdwc9gAAAAAB6xznAAAAAAH6GxYAAAAAAgdgDwAAAAACGBk2AAAAAAIlXi8AAAAAAjaq/gAAAAACQ1xPAAAAAAJUqR4AAAAAAmFabwAAAAACcqc+AAAAAAJ/7DcAAAAAApClXgAAAAACnepXAAAAAAKuo34AAAAAArvodwAAAAACzTVGAAAAAALZ5pcAAAAAAuszZgAAAAAC9+S3AAAAAAMJMYYAAAAAAxZ2fwAAAAADJy+mAAAAAAM0dJ8AAAAAA0UtxgAAAAADUnK/AAAAAANjK+YAAAAAA3Bw3wAAAAADgb2uAAAAAAOObv8AAAAAA5+7zgAAAAADrG0fAAAAAAO9ue4AAAAAA8r+5wAAAAAD27gOAAAAAAPo/QcAAAAAA/m2LgAAAAAEBvsnAAAAAAQYR/YAAAAABCT5RwAAAAAENkYWAAAAAARC92cAAAAABFRENgAAAAAEXzqPACAQIBAgECAQIDBAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBBQYFBgUGBQYFBgUGBQEFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQb//6+aAAD//7mwAQT//6ugAAj//7mwAQz//7mwARD//7mwABT//8fAARhMTVQAQ0RUAENTVABDV1QAQ1BUAEVTVABFRFQACkVTVDVFRFQsTTMuMi4wLE0xMS4xLjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABXAAAABwAAABz/////XgP+oP////+epiyA/////5+6+XD/////oIYOgP////+hmttw/////8uI/oD/////0iP0cP/////SYQnw//////zYSQD//////cgr8P/////+uCsA//////+oDfAAAAAAAJgNAAAAAAABh+/wAAAAAAJ37wAAAAAAA3EMcAAAAAAEYQuAAAAAAAVQ7nAAAAAABkDtgAAAAAAHMNBwAAAAAAeNJ4AAAAAACRCycAAAAAAJraMAAAAAAArwlHAAAAAAC+CTgAAAAAAM2bDwAAAAAA3AdYAAAAAADrmS8AAAAAAPqZIAAAAAABCZdPAAAAAAEYl0AAAAAAASeVbwAAAAABNpVgAAAAAAFFk48AAAAAAVSTgAAAAAABY5GvAAAAAAFykaAAAAAAAYIjdwAAAAABkI/AAAAAAAGgIZcAAAAAAa8hiAAAAAABvh+3AAAAAAHNH6gAAAAAAdwd1wAAAAAB6x3IAAAAAAH6G/cAAAAAAgdg8AAAAAACGBoXAAAAAAIlXxAAAAAAAjar3wAAAAACQ10wAAAAAAJUqf8AAAAAAmFbUAAAAAACcqgfAAAAAAJ/7RgAAAAAApCmPwAAAAACnes4AAAAAAKupF8AAAAAArvpWAAAAAACzTYnAAAAAALZ53gAAAAAAus0RwAAAAAC9+WYAAAAAAMJMmcAAAAAAxZ3YAAAAAADJzCHAAAAAAM0dYAAAAAAA0UupwAAAAADUnOgAAAAAANjLMcAAAAAA3BxwAAAAAADgb6PAAAAAAOOb+AAAAAAA5+8rwAAAAADrG0fAAAAAAO9ue4AAAAAA8r+5wAAAAAD27gOAAAAAAPo/QcAAAAAA/m2LgAAAAAEBvsnAAAAAAQYR/YAAAAABCT5RwAAAAAENkYWAAAAAARC92cAAAAABFRENgAAAAAEXzqPACAQIBAgMEAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBBgUGBQYFBgUGBQYFBgX//7B0AAD//7mwAQT//6ugAAj//7mwAQz//7mwARD//8fAART//7mwABhMTVQAQ0RUAENTVABDV1QAQ1BUAEVEVABFU1QACkVTVDVFRFQsTTMuMi4wLE0xMS4xLjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAAAABAAAABD/////aYcbZP////+4Hpbk/////7ju1dQBAgP//8AcAAD//8AcAAT//84sAQj//8fAAAxMTVQAQ01UAEJTVAAtMDQACjwtMDQ+NAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAABAAAAAz/////aYcjvP////+MdEDU/////8PPSlD/////xEXjQP/////FL0rQ/////8YfLcD/////xw8s0P/////H/w/AAAAAAB4YxFAAAAAAHo9dQAAAAAAf+ffQAAAAACBwkMAAAAAAJZ7j0AAAAAAmFXzAAAAAAC0lA1AAAAAALZucQAEDAgMCAwIDAgMCAwIDAgP//7fEAAD//7esAAD//8fAAQT//7mwAAhMTVQALTA0AC0wNQAKPC0wNT41Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB9AAAABQAAABT/////XgQawP////+epkig/////5+7FZD/////oIYqoP////+hmveQ/////8uJGqD/////0iP0cP/////SYSYQ/////9b+dFz/////2ICtkP/////a/sOQ/////9vAkBD/////3N6lkP/////dqayQ/////96+h5D/////34mOkP/////gnmmQ/////+FpcJD/////4n5LkP/////jSVKQ/////+ReLZD/////5Sk0kP/////mR0oQ/////+cSURD/////6CcsEP/////o8jMQ/////+oHDhD/////6tIVEP/////r5vAQ/////+yx9xD/////7cbSEP/////ukdkQ/////++v7pD/////8HG7EP/////xj9CQ//////J/wZD/////82+ykP/////0X6OQ//////VPlJD/////9j+FkP/////3L3aQ//////goohD/////+Q9YkP/////6CIQQ//////r4gyD/////++hmEP/////82GUg//////3ISBD//////rhHIP//////qCoQAAAAAACYKSAAAAAAAYgMEAAAAAACeAsgAAAAAANxKJAAAAAABGEnoAAAAAAFUQqQAAAAAAZBCaAAAAAABzDskAAAAAAHjUOgAAAAAAkQzpAAAAAACa2/IAAAAAAK8LCQAAAAAAvgr6AAAAAADNnNEAAAAAANwJGgAAAAAA65rxAAAAAAD6muIAAAAAAQmZEQAAAAABGJkCAAAAAAEnlzEAAAAAATaXIgAAAAABRZVRAAAAAAFUlUIAAAAAAWOTcQAAAAABcpNiAAAAAAGCJTkAAAAAAZCRggAAAAABoCNZAAAAAAGvI0oAAAAAAb4heQAAAAABzSFqAAAAAAHcH5kAAAAAAesfigAAAAAB+h25AAAAAAIHYrIAAAAAAhgb2QAAAAACJWDSAAAAAAI2raEAAAAAAkNe8gAAAAACVKvBAAAAAAJhXRIAAAAAAnKp4QAAAAACf+7aAAAAAAKQqAEAAAAAAp3s+gAAAAACrqYhAAAAAAK76xoAAAAAAs036QAAAAAC2ek6AAAAAALrNgkAAAAAAvfnWgAAAAADCTQpAAAAAAMWeSIAAAAAAycySQAAAAADNHdCAAAAAANFMGkAAAAAA1J1YgAAAAADYy6JAAAAAANwc4IAAAAAA4HAUQAAAAADjnGiAAAAAAOfvnEAAAAAA6xvwgAAAAADvbyRAAAAAAPLAYoAAAAAA9u6sQAAAAAD6P+qAAAAAAP5uNEAAAAABAb9ygAAAAAEGEqZAAAAAAQk++oAAAAABDZIuQAAAAAEQvoKAAAAAARURtkAAAAABF89MgAgECAQIDBAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgH//5EmAAD//52QAQT//4+AAAj//52QAQz//52QARBMTVQAUERUAFBTVABQV1QAUFBUAApQU1Q4UERULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAApAAAAAwAAAAz/////lqpofP////+4D0ng/////7j9QKD/////ufE0MP////+63nQg/////9o4rjD/////2uv6MP/////cGeGw/////9y5WSD/////3fsVMP/////em94g/////9/dmjD/////4FQzIP/////0l/+w//////UFXiD/////9sBkMP/////3Dh6g//////hRLDD/////+MfFIP/////6CtKw//////qo+KD/////++wGMP/////8i32gAAAAAB3JjjAAAAAAHnjXoAAAAAAfoDWwAAAAACAzz6AAAAAAIYFpMAAAAAAiC8igAAAAACNYELAAAAAAI+JwIAAAAAAlN/KwAAAAACXUxyAAAAAAMIB5MAAAAAAxHU2gAAAAADf2xrAAAAAAOLiFIAAAAAA53+MwAAAAADnySiAAAAAAO8j/sAAAAAA8bw6gAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQL//96EAAD//+PgAQT//9XQAAhMTVQALTAyAC0wMwAKPC0wMz4zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAABQAAABT/////aYcsZP////+9LUjoAAAAAAZDdGAAAAAACaQ+UAAAAAARUfjgAAAAABHUb1AAAAAAEzHa4AAAAAATtFFQAAAAAClhkSAAAAAAKsFLUAAAAAArQ93gAAAAADLJ71AAAAAAQljA4AAAAABDP2lQAAAAAERUboAAAAAARR9ZYAECAwIEAgQCAwIDAgQCBAL//68cAAD//68YAAT//6ugAAj//7mwAAz//7mwARBMTVQATU1UAENTVABFU1QAQ0RUAApDU1Q2Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfAAAAAwAAAAz/////lqp/RP////+4D1fw/////7j9TrD/////ufFCQP////+63oIw/////9o4vED/////2uwIQP/////cGe/A/////9y5ZzD/////3fsjQP/////em+ww/////9/dqED/////4FRBMP/////0mA3A//////UFbDD/////9sByQP/////3Diyw//////hROkD/////+MfTMP/////6CuDA//////qpBrD/////++wUQP/////8i4uwAAAAAB3JnEAAAAAAHnjlsAAAAAAfoEPAAAAAACAz3bAAAAAAIYF3QAAAAAAiC9awAAAAACzAw0AAAAAALWbSMAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQL//8e8AAD//9XQAQT//8fAAAhMTVQALTAzAC0wNAAKPC0wND40Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAABAAAABH/////aYcUxP////+Ro8hEAAAAABNNbkAAAAAAFDQWsAECAwL//8a8AAD//8a8AAT//8fAAAn//9XQAQ1MTVQARkZNVABBU1QAQURUAApBU1Q0Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAAAAwAAAAz/////pbbaYAAAAAAiVfEAAAAAACNqvfAAAAAAMWd2AAAAAAAycwhwAAAAADNHWAAAAAAANFLqcAAAAAA1JzoAAAAAADYyzHAAAAAANwccAAAAAAA4G+jwAAAAADjm/gAAAAAAOfvK8AAAAAA69QSAAAAAADu2wvAAAAAAPK/8gAAAAAA9u47wAAAAAD6P3oAAAAAAP5tw8AAAAABAb8CAAAAAAEGEjXAAAAAAQk+igAAAAABDZG9wAAAAAEQvhIAAAAAARURRcAAAAABGD2aAAAAAAEckM3AAAAAAR/iDAAAAAABJBBVwAAAAAEnYZQAAAAAASuP3cAAAAABLPY9gAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQH//6SYAAD//6ugAAT//7mwAQhMTVQAQ1NUAENEVAAKQ1NUNkNEVCxNMy4yLjAsTTExLjEuMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9AAAABAAAABD/////pbbocP////+v8Stw/////7ZmVmD/////t0E9cP////+4DDZg/////7j9hvD/////y+pxYAAAAAAxZ4QQAAAAADJzFoAAAAAAM0dmEAAAAAA0UviAAAAAADUnSBAAAAAANjLagAAAAAA3ByoQAAAAADgb9wAAAAAAOOcMEAAAAAA5+9kAAAAAADr1EpAAAAAAO7bRAAAAAAA8sAqQAAAAAD27nQAAAAAAPo/skAAAAAA/m38AAAAAAEBvzpAAAAAAQYSbgAAAAABCT7CQAAAAAENkfYAAAAAARC+SkAAAAABFRF+AAAAAAEYPdJAAAAAARyRBgAAAAABH+JEQAAAAAEkEI4AAAAAASdhzEAAAAABK5AWAAAAAAEu4VRAAAAAATM0iAAAAAABNmDcQAAAAAE6tBAAAAAAAT3gZEAAAAABQjOYAAAAAAFFhNZAAAAAAUmzIAAAAAABTQReQAAAAAFRMqgAAAAAAVSD5kAAAAABWLIwAAAAAAFcA25AAAAAAWBWogAAAAABY4L2QAAAAAFn1ioAAAAAAWsCfkAAAAABb1WyAAAAAAFypvBAAAAAAXbVOgAAAAABeiZ4QAAAAAF+VMIAAAAAAYGmAEAAAAABhfk0AAAAAAGJJYhAAAAAAY14vAAECAQMBAgEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwH//5w8AAD//52QAAT//6ugAAj//6ugAQxMTVQATVNUAENTVABNRFQACk1TVDcK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABSAAAABgAAABj/////YXdJY/////+epiyA/////5+6+XD/////oIYOgP////+hmttw/////8uI/oD/////0iP0cP/////SYQnw/////9N18wD/////1EDr8P/////5D0qA//////oIZ/D//////rgrAAAAAAAGQN9wAAAAAAcw0HAAAAAAB40ngAAAAAAJELJwAAAAAAmtowAAAAAACvCUcAAAAAAL4JOAAAAAAAzZsPAAAAAADcB1gAAAAAAOuZLwAAAAAA+pkgAAAAAAEJl08AAAAAARiXQAAAAAABJ5VvAAAAAAE2lWAAAAAAAUWTjwAAAAABVJOAAAAAAAFjka8AAAAAAXKRoAAAAAABgiN3AAAAAAGQj8AAAAAAAaAhlwAAAAABryGIAAAAAAG+H7cAAAAAAc0fqAAAAAAB3B3XAAAAAAHrHcgAAAAAAfob9wAAAAACB2DwAAAAAAIYGhcAAAAAAiVfEAAAAAACNqvfAAAAAAJDXTAAAAAAAlSp/wAAAAACYVtQAAAAAAJyqB8AAAAAAn/tGAAAAAACkKY/AAAAAAKd6zgAAAAAAq6kXwAAAAACu+lYAAAAAALNNicAAAAAAtnneAAAAAAC6zRHAAAAAAL35ZgAAAAAAwkyZwAAAAADFndgAAAAAAMnMIcAAAAAAzR1gAAAAAADRS6nAAAAAANSc6AAAAAAA2MsxwAAAAADcHHAAAAAAAOBvo8AAAAAA45v4AAAAAADn7yvAAAAAAOsbgAAAAAAA726zwAAAAADyv/IAAAAAAPbuO8AAAAAA+j96AAAAAAD+bcPAAAAAAQG/AgAAAAABBhI1wAAAAAEJPooAAAAAAQ2RvcAAAAABEL4SAAAAAAEVEUXAAAAAARfO3AAIBAgECAwQCAQIBAgUBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgH//63dAAD//7mwAQT//6ugAAj//7mwAQz//7mwARD//7mwABRMTVQAQ0RUAENTVABDV1QAQ1BUAEVTVAAKQ1NUNkNEVCxNMy4yLjAsTTExLjEuMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA5AAAABAAAABD/////pbbaYAAAAAAWiuYAAAAAABgk2nAAAAAAMWd2AAAAAAAycwhwAAAAADNHWAAAAAAANFLqcAAAAAA1JzoAAAAAADYyzHAAAAAANwccAAAAAAA4G+jwAAAAADjm/gAAAAAAOfvK8AAAAAA69QSAAAAAADu2wvAAAAAAPK/8gAAAAAA9u47wAAAAAD6P3oAAAAAAP5tw8AAAAABAb8CAAAAAAEGEjXAAAAAAQk+igAAAAABDZG9wAAAAAEQvhIAAAAAARURRcAAAAABGD2aAAAAAAEckM3AAAAAAR/iDAAAAAABJBBVwAAAAAEnYZQAAAAAASuP3cAAAAABLuEcAAAAAAEzNE/AAAAAATZgpAAAAAABOrPXwAAAAAE94CwAAAAAAUIzX8AAAAABRYSeAAAAAAFJsufAAAAAAU0EJgAAAAABUTJvwAAAAAFUg64AAAAAAVix98AAAAABXAM2AAAAAAFgVmnAAAAAAWOCvgAAAAABZ9XxwAAAAAFrAkYAAAAAAW9VecAAAAABcqa4AAAAAAF21QHAAAAAAXomQAAAAAABflSJwAAAAAGBpcgAAAAAAYX4+8AAAAABiSVQAAAAAAGNeIPABAgEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwH//6v8AAD//6ugAAT//7mwAAj//7mwAQxMTVQAQ1NUAEVTVABDRFQACkNTVDYK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAArAAAACAAAAB7/////P8L90f////99hzAa/////8uJGqD/////0iP0cP/////SYSYQ//////64RyD//////6gqEAAAAAAAmCkgAAAAAAGIDBAAAAAAAngLIAAAAAADcSiQAAAAAARhJ6AAAAAABVEKkAAAAAAGQQmgAAAAAAcw7JAAAAAAB41DoAAAAAAJEM6QAAAAAAmtvyAAAAAACvCwkAAAAAAL4K+gAAAAAAzZzRAAAAAADcCRoAAAAAAOua8QAAAAAA+priAAAAAAEJmREAAAAAARiZAgAAAAABJ5cxAAAAAAE2lyIAAAAAAUWVUQAAAAABVJVCAAAAAAFjk3EAAAAAAXKTYgAAAAABgiU5AAAAAAGQkYIAAAAAAaAjWQAAAAAFY14qAAAAAAVuVIMAAAAABYHv8gAAAAAFjFKjAAAAAAWf7hIAAAAABapQwwAAAAAFvewyAAAAAAXERGoAECAwQCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBgcGBwYHAgYAANYmAAD//4SmAAD//4+AAAT//52QAQj//52QAQz//52QARD//4FwABT//4+AARlMTVQAUFNUAFBXVABQUFQAUERUAEFLU1QAQUtEVAAKQUtTVDlBS0RULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABEAAAABgAAABj/////pbbocP////+v8Stw/////7ZmVmD/////t0E9cP////+4DDZg/////7j9hvD/////xd6wYP/////GlzRQ/////8lV8eD/////yerdUP/////PAsbg/////8+3VlD/////2pkV4P/////bdoPQAAAAADFndgAAAAAAMnMIcAAAAAAzR1gAAAAAADRS6nAAAAAANSc6AAAAAAA2MsxwAAAAADcHHAAAAAAAOBvo8AAAAAA45v4AAAAAADn7yvAAAAAAOvUEgAAAAAA7tsLwAAAAADyv/IAAAAAAPbuO8AAAAAA+j96AAAAAAD+bcPAAAAAAQG/AgAAAAABBhI1wAAAAAEJPooAAAAAAQ2RvcAAAAABEL4SAAAAAAEVEUXAAAAAARg9mgAAAAABHJDNwAAAAAEf4gwAAAAAASQQVcAAAAABJ2GUAAAAAAErj93AAAAAAS7hHAAAAAABMzRPwAAAAAE2YKQAAAAAATqz18AAAAABPeAsAAAAAAFCM1/AAAAAAUWEngAAAAABSbLnwAAAAAFNBCYAAAAAAVEyb8AAAAABVIOuAAAAAAFYsffAAAAAAVwDNgAAAAABYFZpwAAAAAFjgr4AAAAAAWfV8cAAAAABawJGAAAAAAFvVXnAAAAAAXKmuAAAAAABdtUBwAAAAAF6JkAAAAAAAX5UicAAAAABgaXIAAAAAAGF+PvAAAAAAYklUAAAAAABjXiDwAQIBAwECBAIEAgUCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAL//6MMAAD//52QAAT//6ugAAj//6ugAQz//7mwARD//7mwARRMTVQATVNUAENTVABNRFQAQ0RUAENXVAAKQ1NUNgo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAArAAAABAAAABD/////kd8XKAAAAAATbmPAAAAAACB15NAAAAAAIYF3QAAAAAAiVcbQAAAAACNqk8AAAAAAJDWo0AAAAAAlSnXAAAAAACYVitAAAAAAJypXwAAAAAAn/qdQAAAAACkKOcAAAAAAKd6JUAAAAAAq6hvAAAAAACu+a1AAAAAALNM4QAAAAAAtnk1QAAAAAC6zGkAAAAAAL34vUAAAAAAwkvxAAAAAADFnS9AAAAAAMnLeQAAAAAAzRy3QAAAAADRSwEAAAAAANScP0AAAAAA2MqJAAAAAADcG8dAAAAAAOBu+wAAAAAA45tPQAAAAADn7oMAAAAAAOsa10AAAAAA724LAAAAAADyv0lAAAAAAPbtkwAAAAAA+j7RQAAAAAD+bRsAAAAAAQG+WUAAAAABBhGNAAAAAAEJPeFAAAAAAQ2RFQAAAAABEL1pQAAAAAEVEJ0AAAAAARfOM0AECAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgP//8tYAAD//8fAAAT//9XQAAj//+PgAQxMTVQAQVNUAC0wMwAtMDIACjwtMDM+MzwtMDI+LE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACSAAAABgAAABj/////Xh7tvP////+A8bZQ/////564hWD/////n7rdUP////+7PDjQ/////7u0I0D/////vRwa0P////+9lAVA/////777/ND/////v3PnQP/////A297Q/////8FTyUD/////wrvA0P/////DM6tA/////8SbotD/////xRONQP/////GcPjQ/////8cNzUD/////yEjx0P/////I7a9A/////8oWXtD/////ytbLwP/////LiOJg/////9Ij9HD/////0mDt0P/////Tddbg/////9RAz9D/////1VW44P/////WILHQ/////9c1muD/////2ACT0P/////ZFXzg/////9ngddD/////2v6ZYP/////bwFfQ/////9zee2D/////3al0UP/////evl1g/////9+JVlD/////4J4/YP/////haThQ/////+J+IWD/////40kaUP/////kXgNg/////+Uo/FD/////5kcf4P/////nEhjQ/////+gnAeD/////6Rbk0P/////qBuPg/////+r2xtD/////6+bF4P/////s1qjQ/////+3Gp+D/////7r/FUP/////vr8Rg//////Cfp1D/////8Y+mYP/////yf4lQ//////NviGD/////9F9rUP/////1T2pg//////Y/TVD/////9y9MYP/////4KGnQ//////kPLmD/////+ghL0P/////6+Erg//////voLdD//////Ngs4P/////9yA/Q//////64DuD//////6fx0AAAAAAAl/DgAAAAAAGH09AAAAAAAnfS4AAAAAADcPBQAAAAAARg72AAAAAABVDSUAAAAAAIILNgAAAAAAkQllAAAAAACgCVYAAAAAAK8HhQAAAAAAvgd2AAAAAADNmU0AAAAAANwFlgAAAAAA65dtAAAAAAD6l14AAAAAAQmVjQAAAAABGJV+AAAAAAEnk60AAAAAATaTngAAAAABRZHNAAAAAAFUkb4AAAAAAWOP7QAAAAABco/eAAAAAAGCIbUAAAAAAZCN/gAAAAABoB/VAAAAAAGvH8YAAAAAAb4d9QAAAAABzR3mAAAAAAHcHBUAAAAAAescBgAAAAAB+ho1AAAAAAIHXy4AAAAAAhgYVQAAAAACJV1OAAAAAAI2qh0AAAAAAkNbbgAAAAACVKg9AAAAAAJhWY4AAAAAAnKmXQAAAAACf+tWAAAAAAKQpH0AAAAAAp3pdgAAAAACrqKdAAAAAAK75dfAAAAAAs0ypsAAAAAC2eP3wAAAAALrMMbAAAAAAvfiF8AAAAADCS7mwAAAAAMWc9/AAAAAAyctBsAAAAADNHH/wAAAAANFKybAAAAAA1JwH8AAAAADYylGwAAAAANwbj/AAAAAA4G7DsAAAAADjmxfwAAAAAOfuS7AAAAAA6xqf8AAAAADvbdOwAAAAAPK/EfAAAAAA9u1bsAAAAAD6PpnwAAAAAP5s47AAAAABAb4h8AAAAAEGEVWwAAAAAQk9qfAAAAABDZDdsAAAAAEQvTHwAAAAARUQZbAAAAABFmIdAAQMCAwIDAgMCAwIDAgMCAwIDAgMCAwQFAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwP//8NEAAD//7mwAAT//9XQAQj//8fAAAz//9XQARD//9XQARRMTVQARVNUAEFEVABBU1QAQVdUAEFQVAAKQVNUNEFEVCxNMy4yLjAsTTExLjEuMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+AAAABQAAABT/////pbbaYP////+v8Stw/////7ZmVmD/////t0E9cP////+4DDZg/////7j9hvAAAAAAIlXxAAAAAAAjar3wAAAAADFndgAAAAAAMnMIcAAAAAAzR1gAAAAAADRS6nAAAAAANSc6AAAAAAA2MsxwAAAAADcHHAAAAAAAOBvo8AAAAAA45v4AAAAAADn7yvAAAAAAOvUEgAAAAAA7tsLwAAAAADyv/IAAAAAAPbuO8AAAAAA+j96AAAAAAD+bcPAAAAAAQG/AgAAAAABBhI1wAAAAAEJPooAAAAAAQ2RvcAAAAABEL4SAAAAAAEVEUXAAAAAARg9mgAAAAABHJDNwAAAAAEf4gwAAAAAASQQVcAAAAABJ2GUAAAAAAErj93AAAAAAS7hHAAAAAABMzRPwAAAAAE2YKQAAAAAATqz18AAAAABPeAsAAAAAAFCM1/AAAAAAUWEngAAAAABSbLnwAAAAAFNBCYAAAAAAVEyb8AAAAABVIOuAAAAAAFYsffAAAAAAVwDNgAAAAABYFZpwAAAAAFjgr4AAAAAAWfV8cAAAAABawJGAAAAAAFvVXnAAAAAAXKmuAAAAAABdtUBwAAAAAF6JkAAAAAAAX5UicAAAAABgaXIAAAAAAGF+PvAAAAAAYklUAAAAAABjXiDwAQIBAwECBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAIEAgQCBAL//6H0AAD//52QAAT//6ugAAj//6ugAQz//7mwARBMTVQATVNUAENTVABNRFQAQ0RUAApDU1Q2Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABWAAAACQAAACb/////jDTlM/////+ikoez/////6j/20D/////qfEPsP////+q4lk4/////6vSQzD/////rMOMuP////+ts3aw/////7v0tbj/////vL+1sP////+91Je4/////76fl7D/////v7R5uP/////Af3mw/////8GUW7j/////wl9bsP/////DfXg4/////8Q/PbD/////xV1aOP/////GHx+w/////8cYUjj/////yAg8MP/////JHR44/////8noHjD/////youfOP/////NHsYw/////82VZij/////7AuFsP/////s8jUo/////+1FSrD/////7YXWIP/////3E3Kw//////f6GyD//////P4+MP/////99hEoAAAAAACWdTAAAAAAANhSIAAAAAAEV4qwAAAAAATGOqAAAAAAB5YbsAAAAAAH39qYAAAAAAjGnygAAAAACVpOMAAAAAAJ23MgAAAAAA0aEjAAAAAADX+HoAAAAAAO538wAAAAAA9faaAAAAAAENnWMAAAAAARP0ugAAAAABGJLbAAAAAAEzGioAAAAAAhw1QwAAAAACIneCAAAAAAI6HksAAAAAAkEJSgAAAAACVKZ7AAAAAAJec8IAAAAAAnIQ8wAAAAACfQWKAAAAAAKQorsAAAAAApsDqgAAAAACrg0zAAAAAAK5AcoAAAAABBTPYwAAAAAEJGL8AAAAAAQ0ij0AAAAABEE5zAAAAAAEUfS1AAAAAARfN+wAAAAABHCGfQAAAAAEfTYMAAAAAASOhJ0AAAAABJs0LAAAAAAErIK9AAAAAAS5xfQAAAAABMqA3QAAAAAE18QUAAAAAATofv0AAAAABPXCNAAAAAAFBxDFAAAAAAUTwFQAAAAABSUO5QAAAAAFMb50AAAAAAVDDQUAAAAABU+8lAAQIEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAYFBgUHBQcFBgUHBQcFCAYFBwUHBQcFBwUHBQcFBwUHBQcFBwUHBQcFBwUHBQcFBwUHBQcFBwUHBQcFBwX//8tNAAD//8tNAAT//8fAAAj//87IAAz//9XQARL//9XQABL//9zYARb//+PgARz//+roASBMTVQATU1UAC0wNAAtMDMzMAAtMDMALTAyMzAALTAyAC0wMTMwAAo8LTAzPjMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACsAAAABQAAABT/////cu547P////+euJNw/////5+662D/////oIcuyP////+hmrFA/////6KUBvD/////o1WpQP////+khl3w/////6UoeGD/////pmY/8P////+nDE7g/////6hGIfD/////qOww4P////+qHMlw/////6rVTWD/////q/yrcP////+stS9g/////63cjXD/////rpURYP////+vvG9w/////7B+LeD/////sZxRcP////+yZ0pg/////7N8M3D/////tEcsYP////+1XBVw/////7YnDmD/////tzv3cP////+4BvBg/////7klE/D/////uebSYP////+7BPXw/////7vP7uD/////vOTX8P////+9r9Dg/////77EufD/////v4+y4P/////ApJvw/////8FvlOD/////woR98P/////DT3bg/////8RkX/D/////xS9Y4P/////GTXxw/////8cPOuD/////yC1ecP/////LiPBw/////9Ij9HD/////0mD74P/////TdeTw/////9RA3eD/////1VXG8P/////WIL/g/////9c1qPD/////2ACh4P/////ZFYrw/////9ozkmD/////2v6ncP/////cE3Rg/////9zeiXD/////3amCYP/////evmtw/////9+JZGD/////4J5NcP/////haUZg/////+J+L3D/////40koYP/////kXhFw/////+UpCmD/////5kct8P/////nEibg/////+gnD/D/////6Rby4P/////qBvHw/////+r21OD/////6+bT8P/////s1rbg/////+3GtfD/////7r/TYP/////vr9Jw//////CftWD/////8Y+0cP/////yf5dg//////NvlnD/////9F95YP/////1T3hw//////Y/W2D/////9y9acP/////4KHfg//////kPPHD/////+ghZ4P/////6+Fjw//////voO+D//////Ng68P/////9yB3g//////64HPD//////6f/4AAAAAAAl/7wAAAAAAGH4eAAAAAAAnfg8AAAAAADcP5gAAAAAARg/XAAAAAABVDgYAAAAAAGQN9wAAAAAAcwwmAAAAAACCDBcAAAAAAJEKRgAAAAAAoAo3AAAAAACvCGYAAAAAAL4IVwAAAAAAzZouAAAAAADcBncAAAAAAOuYTgAAAAAA+pg/AAAAAAEJlm4AAAAAARiWXwAAAAABJ5SOAAAAAAE2lH8AAAAAAUWSrgAAAAABVJKfAAAAAAFjkM4AAAAAAXKQvwAAAAABgiKWAAAAAAGQjt8AAAAAAaAgtgAAAAABryCnAAAAAAG+HtYAAAAAAc0exwAAAAAB3Bz2AAAAAAHrHOcAAAAAAfobFgAAAAACB2APAAAAAAIYGTYAAAAAAiVeLwAAAAACNqr+AAAAAAJDXE8AAAAAAlSpHgAAAAACYVpvAAAAAAJypz4AAAAAAn/sNwAAAAACkKVeAAAAAAKd6lcAAAAAAq6jfgAAAAACu+h3AAAAAALNNUYAAAAAAtnmlwAAAAAC6zNmAAAAAAL35LcAAAAAAwkxhgAAAAADFnZ/AAAAAAMnL6YAAAAAAzR0nwAAAAADRS3GAAAAAANScr8AAAAAA2Mr5gAAAAADcHDfAAAAAAOBva4AAAAAA45u/wAAAAADn7vOAAAAAAOsbR8AAAAAA7257gAAAAADyv7nAAAAAAPbuA4AAAAAA+j9BwAAAAAD+bYuAAAAAAQG+ycAAAAABBhH9gAAAAAEJPlHAAAAAAQ2RhYAAAAABEL3ZwAAAAAEVEQ2AAAAAARfOo8AIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgEDBAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgH//7WUAAD//8fAAQT//7mwAAj//8fAAQz//8fAARBMTVQARURUAEVTVABFV1QARVBUAApFU1Q1RURULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACvAAAABQAAABT/////XgPwkP////+eph5w/////5+662D/////oIYAcP////+hms1g/////6Jl4nD/////o4Pp4P////+kaq5w/////6U1p2D/////plPK8P////+nFYlg/////6gzrPD/////qP6l4P////+qE47w/////6reh+D/////q/Nw8P////+svmng/////63TUvD/////rp5L4P////+vszTw/////7B+LeD/////sZxRcP////+yZ0pg/////7N8M3D/////tEcsYP////+1XBVw/////7YnDmD/////tzv3cP////+4BvBg/////7kb2XD/////uebSYP////+7BPXw/////7vGtGD/////vOTX8P////+9r9Dg/////77EufD/////v4+y4P/////ApJvw/////8FvlOD/////woR98P/////DT3bg/////8RkX/D/////xS9Y4P/////GTXxw/////8cPOuD/////yC1ecP/////I+Fdg/////8oNQHD/////ytg5YP/////LiPBw/////9Ij9HD/////0mD74P/////TdeTw/////9RA3eD/////1VXG8P/////WIL/g/////9c1qPD/////2ACh4P/////ZFYrw/////9ngg+D/////2v6ncP/////bwGXg/////9zeiXD/////3amCYP/////evmtw/////9+JZGD/////4J5NcP/////haUZg/////+J+L3D/////40koYP/////kXhFw/////+VXLuD/////5kct8P/////nNxDg/////+gnD/D/////6Rby4P/////qBvHw/////+r21OD/////6+bT8P/////s1rbg/////+3GtfD/////7r/TYP/////vr9Jw//////CftWD/////8Y+0cP/////yf5dg//////NvlnD/////9F95YP/////1T3hw//////Y/W2D/////9y9acP/////4KHfg//////kPPHD/////+ghZ4P/////6+Fjw//////voO+D//////Ng68P/////9yB3g//////64HPD//////6f/4AAAAAAAl/7wAAAAAAGH4eAAAAAAAnfg8AAAAAADcP5gAAAAAARg/XAAAAAABVDgYAAAAAAGQN9wAAAAAAcwwmAAAAAAB40ZcAAAAAAJEKRgAAAAAAmtlPAAAAAACvCGYAAAAAAL4IVwAAAAAAzZouAAAAAADcBncAAAAAAOuYTgAAAAAA+pg/AAAAAAEJlm4AAAAAARiWXwAAAAABJ5SOAAAAAAE2lH8AAAAAAUWSrgAAAAABVJKfAAAAAAFjkM4AAAAAAXKQvwAAAAABgiKWAAAAAAGQjt8AAAAAAaAgtgAAAAABryCnAAAAAAG+HtYAAAAAAc0exwAAAAAB3Bz2AAAAAAHrHOcAAAAAAfobFgAAAAACB2APAAAAAAIYGTYAAAAAAiVeLwAAAAACNqr+AAAAAAJDXE8AAAAAAlSpHgAAAAACYVpvAAAAAAJypz4AAAAAAn/sNwAAAAACkKVeAAAAAAKd6lcAAAAAAq6jfgAAAAACu+h3AAAAAALNNUYAAAAAAtnmlwAAAAAC6zNmAAAAAAL35LcAAAAAAwkxhgAAAAADFnZ/AAAAAAMnL6YAAAAAAzR0nwAAAAADRS3GAAAAAANScr8AAAAAA2Mr5gAAAAADcHDfAAAAAAOBva4AAAAAA45u/wAAAAADn7vOAAAAAAOsbR8AAAAAA7257gAAAAADyv7nAAAAAAPbuA4AAAAAA+j9BwAAAAAD+bYuAAAAAAQG+ycAAAAABBhH9gAAAAAEJPlHAAAAAAQ2RhYAAAAABEL3ZwAAAAAEVEQ2AAAAAARfOo8AIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIDBAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgH//7qeAAD//8fAAQT//7mwAAj//8fAAQz//8fAARBMTVQARURUAEVTVABFV1QARVBUAApFU1Q1RURULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABUAAAACgAAACb/////P8L90f////99h0/S/////8uJRND/////0iP0cP/////SYVBA//////rSVbD//////rhxUP//////qFRAAAAAAACYU1AAAAAAAYg2QAAAAAACeDVQAAAAAANxUsAAAAAABGFR0AAAAAAFUTTAAAAAAAZBM9AAAAAABzEWwAAAAAAHjW3QAAAAAAkQ+MAAAAAACa3pUAAAAAAK8NrAAAAAAAvg2dAAAAAADNn3QAAAAAANwLvQAAAAAA652UAAAAAAD6nYUAAAAAAQmbtAAAAAABGJulAAAAAAEnmdQAAAAAATaZxQAAAAABRZf0AAAAAAFUl+UAAAAAAWOWFAAAAAABcpYFAAAAAAGCJ9wAAAAAAZCUJQAAAAABoCX8AAAAAAGisUEAAAAAAa8kKwAAAAABviJaAAAAAAHNIksAAAAAAdwgegAAAAAB6yBrAAAAAAH6HpoAAAAAAgdjkwAAAAACGBy6AAAAAAIlYbMAAAAAAjauggAAAAACQ1/TAAAAAAJUrKIAAAAAAmFd8wAAAAACcqrCAAAAAAJ/77sAAAAAApCo4gAAAAACne3bAAAAAAKupwIAAAAAArvr+wAAAAACzTjKAAAAAALZ6hsAAAAAAus26gAAAAAC9+g7AAAAAAMJNQoAAAAAAxZ6AwAAAAADJzMqAAAAAAM0eCMAAAAAA0UxSgAAAAADUnZDAAAAAANjL2oAAAAAA3B0YwAAAAADgcEyAAAAAAOOcoMAAAAAA5+/UgAAAAADrHCjAAAAAAO9vXIAAAAAA8sCawAAAAAD27uSAAAAAAPpAIsAAAAAA/m5sgAAAAAEBv6rAAAAAAQYS3oAAAAABCT8ywAAAAAENkmaAAAAAARC+usAAAAABFRHugAAAAAEXz4TABAgMEAgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgcJCAkICQgJCAkICQgJCAkICQgJCAkICQgJCAkICQgJCAkICQgJCAkICQgJCAkICQgAALZuAAD//2TuAAD//2VQAAT//3NgAQj//3NgAQz//2VQABD//3NgART//4FwABj//4+AARz//4FwACFMTVQATlNUAE5XVABOUFQAQlNUAEJEVABZU1QAQUtEVABBS1NUAApBS1NUOUFLRFQsTTMuMi4wLE0xMS4xLjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAnAAAAAwAAAAz/////lqplZP////+4DzvQ/////7j9MpD/////ufEmIP////+63mYQ/////9o4oCD/////2uvsIP/////cGdOg/////9y5SxD/////3fsHIP/////em9AQ/////9/djCD/////4FQlEP/////0l/Gg//////UFUBD/////9sBWIP/////3DhCQ//////hRHiD/////+Me3EP/////6CsSg//////qo6pD/////++v4IP/////8i2+QAAAAAB3JgCAAAAAAHnjJkAAAAAAfoCegAAAAACAzwZAAAAAAIYFbIAAAAAAiC7qQAAAAACNYAqAAAAAAI+JiEAAAAAAlN+SgAAAAACXUuRAAAAAAN/a4oAAAAAA4uHcQAAAAADnf1SAAAAAAOekBkAAAAAA7yPGgAAAAADxvAJACAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQL//+GcAAD///HwAQT//+PgAAhMTVQALTAxAC0wMgAKPC0wMj4yCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABgAAAABgAAABj/////XgQMsP////+epjqQ/////5+7B4D/////oIYckP////+hmumA/////8uJDJD/////0iP0cP/////SYRgA//////r4dRD/////++hYAP/////82FcQ//////3IOgD//////rg5EP//////qBwAAAAAAACYGxAAAAAAAYf+AAAAAAACd/0QAAAAAANxGoAAAAAABGEZkAAAAAAFUPyAAAAAAAZA+5AAAAAABzDegAAAAAAHjTWQAAAAAAkQwIAAAAAACa2xEAAAAAAK8KKAAAAAAAvgoZAAAAAADNm/AAAAAAANwIOQAAAAAA65oQAAAAAAD6mgEAAAAAAQmYMAAAAAABGJghAAAAAAEnllAAAAAAATaWQQAAAAABRZRwAAAAAAFUlGEAAAAAAWOSkAAAAAABcpKBAAAAAAGCJFgAAAAAAZCQoQAAAAABoCJ4AAAAAAGvImkAAAAAAb4gmAAAAAABzSCJAAAAAAHcHrgAAAAAAeseqQAAAAAB+hzYAAAAAAIHYdEAAAAAAhga+AAAAAACJV/xAAAAAAI2rMAAAAAAAkNeEQAAAAACVKrgAAAAAAJhXDEAAAAAAnKpAAAAAAACf+35AAAAAAKQpyAAAAAAAp3sGQAAAAACrqVAAAAAAAK76jkAAAAAAs03CAAAAAAC2ehZAAAAAALrNSgAAAAAAvfmeQAAAAADCTNIAAAAAAMWeEEAAAAAAycxaAAAAAADNHZhAAAAAANFL4gAAAAAA1J0gQAAAAADYy2oAAAAAANwcqEAAAAAA4G/cAAAAAADjnDBAAAAAAOfvZAAAAAAA6xu4QAAAAADvbuwAAAAAAPLAKkAAAAAA9u50AAAAAAD6P7JAAAAAAP5t/AAAAAABAb86QAAAAAEGEm4AAAAAAQk+wkAAAAABDZH2AAAAAAEQvkpAAAAAARURfgAAAAABF88UQAAAAAEctfAAAAAAAR9OnEAAAAABJDV4AAAAAAEmziRAAAAAASu1AAAAAAABLnKWQAAAAAEzWXIACAQIBAgMEAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQX//6CVAAD//6ugAQT//52QAAj//6ugAQz//6ugARD//6ugABRMTVQATURUAE1TVABNV1QATVBUAENTVAAKQ1NUNkNEVCxNMy4yLjAsTTExLjEuMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABZAAAABwAAABz/////XgQMsP////+epjqQ/////5+7B4D/////oIYckP////+hmumA/////8uJDJD/////0iP0cP/////SYRgA//////r4dRD/////++hYAP/////82FcQ//////3IOgD//////rg5EP//////qBwAAAAAAACYGxAAAAAAAYf+AAAAAAACd/0QAAAAAANxGoAAAAAABGEZkAAAAAAFUPyAAAAAAAZA+5AAAAAABzDegAAAAAAHjTWQAAAAAAkQwIAAAAAACa2xEAAAAAAK8KKAAAAAAAvgoZAAAAAADNm/AAAAAAANwIOQAAAAAA65oQAAAAAAD6mgEAAAAAAQmYMAAAAAABGJghAAAAAAEnllAAAAAAATaWQQAAAAABRZRwAAAAAAFUlGEAAAAAAWOSkAAAAAABcpKBAAAAAAGCJFgAAAAAAZCQoQAAAAABoCJ4AAAAAAGvImkAAAAAAb4gmAAAAAABzSCJAAAAAAHcHrgAAAAAAeseqQAAAAAB+hzYAAAAAAIHYdEAAAAAAhga+AAAAAACJV/xAAAAAAI2rMAAAAAAAkNeEQAAAAACVKrgAAAAAAJhXDEAAAAAAnKpAAAAAAACf+35AAAAAAKQpyAAAAAAAp3sGQAAAAACrqVAAAAAAAK76VgAAAAAAs02JwAAAAAC2ed4AAAAAALrNEcAAAAAAvflmAAAAAADCTJnAAAAAAMWd2AAAAAAAycwhwAAAAADNHWAAAAAAANFLqcAAAAAA1JzoAAAAAADYyzHAAAAAANwccAAAAAAA4G+jwAAAAADjm/gAAAAAAOfvK8AAAAAA6xuAAAAAAADvbrPAAAAAAPK/8gAAAAAA9u47wAAAAAD6P3oAAAAAAP5tw8AAAAABAb8CAAAAAAEGEjXAAAAAAQk+igAAAAABDZG9wAAAAAEQvhIAAAAAARURRcAAAAABF87cAAgECAQIDBAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgEGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgX//6EIAAD//6ugAQT//52QAAj//6ugAQz//6ugARD//7mwART//6ugABhMTVQATURUAE1TVABNV1QATVBUAENEVABDU1QACkNTVDZDRFQsTTMuMi4wLE0xMS4xLjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABZAAAABwAAABz/////XgQMsP////+epjqQ/////5+7B4D/////oIYckP////+hmumA/////8uJDJD/////0iP0cP/////SYRgA//////r4dRD/////++hYAP/////82FcQ//////3IOgD//////rg5EP//////qBwAAAAAAACYGxAAAAAAAYf+AAAAAAACd/0QAAAAAANxGoAAAAAABGEZkAAAAAAFUPyAAAAAAAZA+5AAAAAABzDegAAAAAAHjTWQAAAAAAkQwIAAAAAACa2xEAAAAAAK8KKAAAAAAAvgoZAAAAAADNm/AAAAAAANwIOQAAAAAA65oQAAAAAAD6mgEAAAAAAQmYMAAAAAABGJghAAAAAAEnllAAAAAAATaWQQAAAAABRZRwAAAAAAFUlGEAAAAAAWOSkAAAAAABcpKBAAAAAAGCJFgAAAAAAZCQoQAAAAABoCJ4AAAAAAGvImkAAAAAAb4gmAAAAAABzSCJAAAAAAHcHrgAAAAAAeseqQAAAAAB+hzYAAAAAAIHYdEAAAAAAhga+AAAAAACJV/xAAAAAAI2rMAAAAAAAkNeEQAAAAACVKrgAAAAAAJhXDEAAAAAAnKpAAAAAAACf+35AAAAAAKQpyAAAAAAAp3sGQAAAAACrqVAAAAAAAK76jkAAAAAAs03CAAAAAAC2ehZAAAAAALrNSgAAAAAAvfmeQAAAAADCTNIAAAAAAMWeEEAAAAAAycxaAAAAAADNHZhAAAAAANFL4gAAAAAA1J0gQAAAAADYy2oAAAAAANwcqEAAAAAA4G/cAAAAAADjnDBAAAAAAOfvZAAAAAAA6xu4QAAAAADvbuwAAAAAAPLAKkAAAAAA9u50AAAAAAD6P7JAAAAAAP5t/AAAAAABAb8CAAAAAAEGEjXAAAAAAQk+igAAAAABDZG9wAAAAAEQvhIAAAAAARURRcAAAAABF87cAAgECAQIDBAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBBgUGBQYFBgX//6DtAAD//6ugAQT//52QAAj//6ugAQz//6ugARD//7mwART//6ugABhMTVQATURUAE1TVABNV1QATVBUAENEVABDU1QACkNTVDZDRFQsTTMuMi4wLE0xMS4xLjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9AAAABQAAABT/////pbbocP////+v8Stw/////7ZmVmD/////t0E9cP////+4DDZg/////7j9hvAAAAAAMWd2AAAAAAAycwhwAAAAADNHWAAAAAAANFLqcAAAAAA1J0gQAAAAADYy2oAAAAAANwcqEAAAAAA4G/cAAAAAADjnDBAAAAAAOfvZAAAAAAA69RKQAAAAADu20QAAAAAAPLAKkAAAAAA9u50AAAAAAD6P7JAAAAAAP5t/AAAAAABAb86QAAAAAEGEm4AAAAAAQk+wkAAAAABDZH2AAAAAAEQvkpAAAAAARURfgAAAAABGD3SQAAAAAEckQYAAAAAAR/iREAAAAABJBCOAAAAAAEnYcxAAAAAASuQFgAAAAABLnKWQAAAAAEzWXIAAAAAATXyHkAAAAABOtj6AAAAAAE9caZAAAAAAUJYggAAAAABRPEuQAAAAAFJ2AoAAAAAAUxwtkAAAAABUVeSAAAAAAFT8D5AAAAAAVjXGgAAAAABW5SwQAAAAAFge4wAAAAAAWMUOEAAAAABZ/sUAAAAAAFqk8BAAAAAAW96nAAAAAABchNIQAAAAAF2+iQAAAAAAXmS0EAAAAABfnmsAAAAAAGBN0JAAAAAAYYeHgAAAAABiLbKQAAAAAGNeLwAAAAAAY4bxYAECAQMBAgQCBAIDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAgL//54cAAD//52QAAT//6ugAAj//6ugAQz//7mwARBMTVQATVNUAENTVABNRFQAQ0RUAApDU1Q2Q0RULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAABQAAABL/////kQWOuP////++KkvE/////9JiLLQAAAAAG74xuAECAwT//8xIAAD//8w8AAT//8xMAAT//87IAAj//9XQAA5MTVQAUE1UAC0wMzMwAC0wMwAKPC0wMz4zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtAAAABAAAABH/////aYcfUP////+cbnH8AAAAABkbRtAAAAAAGgHvQAAAAAAa8e5QAAAAABvh0UAAAAAAHNHQUAAAAAAdwbNAAAAAAB6xslAAAAAAH6GVQAAAAAAgkZRQAAAAACGBd0AAAAAAIlXU4AAAAAAjaq/gAAAAACQ1tuAAAAAAJUqR4AAAAAAmFZjgAAAAACcqc+AAAAAAJ/61YAAAAAApClXgAAAAACnel2AAAAAAKuo34AAAAAArvnlgAAAAACzTVGAAAAAALZ5bYAAAAAAuszZgAAAAAC9+PWAAAAAAMJMYYAAAAAAxZ1ngAAAAADJy+mAAAAAAM0c74AAAAAA0UtxgAAAAAEJPeFAAAAAAQ2RFQAAAAABEL1pQAAAAAEVEJ0AAAAAAT1xNcAAAAABQlgRgAAAAAFE8L3AAAAAAUnXmYAAAAABTHBFwAAAAAFRVyGAAAAAAVPvzcAAAAABWNapgAAAAAFjE8fABAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwL//7wwAAD//7xEAAT//8fAAQn//7mwAA1MTVQAUFBNVABFRFQARVNUAApFU1Q1RURULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfAAAABAAAAAz/////lqqGkP////+4D2YA/////7j9XMD/////ufFQUP////+63pBA/////9o4ylD/////2uwWUP/////cGf3Q/////9y5dUD/////3fsxUP/////em/pA/////9/dtlD/////4FRPQP/////0mBvQ//////UFekD/////9sCAUP/////3DjrA//////hRSFD/////+MfhQP/////6Cu7Q//////qpFMD/////++wiUP/////8i5nAAAAAAB3JqlAAAAAAHnjzwAAAAAAfoFHQAAAAACAz68AAAAAAIYGFUAAAAAAiC+TAAAAAAEhgf1AAAAAAUn8EwAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAwL//8BwAAD//8fAAQT//7mwAAj//8fAAARMTVQALTA0AC0wNQAKPC0wNT41Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdAAAAAwAAAAz/////lqqC6P////+4D1fw/////7j9TrD/////ufFCQP////+63oIw/////9o4vED/////2uwIQP/////cGe/A/////9y5ZzD/////3fsjQP/////em+ww/////9/dqED/////4FRBMP/////0mA3A//////UFbDD/////9sByQP/////3Diyw//////hROkD/////+MfTMP/////6CuDA//////qpBrD/////++wUQP/////8i4uwAAAAAB3JnEAAAAAAHnjlsAAAAAAfoEPAAAAAACAz3bAAAAAAIYF3QAAAAAAiC9awAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQL//8QYAAD//9XQAQT//8fAAAhMTVQALTAzAC0wNAAKPC0wND40Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB1AAAABwAAABT/////aYcd/P////+PMEdF/////5tc5VD/////n3zixf////+hAHHA/////7Bed8X/////sXc9QP////+yQQDQ/////7NYcMD/////tCI0UP////+1OaRA/////7YDZ9D/////txrXwP////+35JtQ/////7j9XMD/////uccgUP/////MHG5A/////8xs59D/////1BfjQP/////VM1XA/////9V2kkD//////dE8QP/////+kvqw///////MzcAAAAAAAHLcsAAAAAABdVDAAAAAAAJASbAAAAAAA1UywAAAAAAEICuwAAAAAAU+T0AAAAAABgANsAAAAAAHC7xAAAAAAAff77AAAAAACP4TQAAAAAAJv9GwAAAAAArd9UAAAAAAC6juMAAAAAAMvddAAAAAAA2I0DAAAAAADp25QAAAAAAPaLIwAAAAABCG1cAAAAAAEUiUMAAAAAASZrfAAAAAABModjAAAAAAFEaZwAAAAAAVEZKwAAAAABYme8AAAAAAFvF0sAAAAAAYBl3AAAAAABjRVrAAAAAAGeY/wAAAAAAasTiwAAAAABvPXEAAAAAAHJEasAAAAAAdrz5AAAAAAB5w/LAAAAAAH48gQAAAAAAgfwMwAAAAACFvAkAAAAAAIjn7MAAAAAAjTuRAAAAAACQZ3TAAAAAAJTgAwAAAAAAl+b8wAAAAACby+MAAAAAAJ9mhMAAAAAAo98TAAAAAACnCvbAAAAAAKtemwAAAAAArop+wAAAAACy3iMAAAAAALYKBsAAAAAAul2rAAAAAAC9iY7AAAAAAMICHQAAAAAAxQkWwAAAAADJgaUAAAAAAMz3XMAAAAAA0QEtAAAAAADULRDAAAAAANg24QAAAAAA3BtWwAAAAADgAD0AAAAAAOMsIMAAAAAA56SvAAAAAADqq6jAAAAAAO8kNwAAAAAA8iswwAAAAAD2o78AAAAAAPmquMAAAAAA/iNHAAAAAAEBTyrAAAAAAQWizwAAAAABCM6ywAAAAAENIlcAAAAAARBOOsAAAAABFMbJAAAAAAEXzcLAAAAAARxGUQAAAAABH7wIwAAAAAEjxdkAAAAAASbxvMAAAAABK0VhAAAAAAEu4ALAAAAAATLE6QAAAAABNxgcwAAAAAE5QgsAAAAAAT5yusAAAAABQQtnAAAAAAFF8kLAAAAAAUiv2QAAAAABTXHKwAAAAAFQL2EAAAAAAVzfmMAAAAABXr+zAAAAAAFhDhrABAgEDAQQCBAIEAgQCBAIDAgMEAgMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQb//72EAAD//727AAT//7mwAAj//8fAAAz//8fAAQz//9XQARD//9XQABBMTVQAU01UAC0wNQAtMDQALTAzAAo8LTAzPjMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB9AAAABQAAABT/////ZOSwlP////+bAfvg/////5vDulD/////nrihgP////+fuvlw/////8KgO4D/////w0+E8P/////LiP6A/////9Ij9HD/////0mEJ8P/////TiGgA/////9RTYPD/////1VXVAP/////WIM3w/////9c1twD/////2ACv8P/////ZFZkA/////9ngkfD/////2wAHAP/////byFzw/////9zel4D/////3amQcP/////evnmA/////9+JcnD/////4J5bgP/////haVRw/////+J+PYD/////40k2cP/////kXh+A/////+UpGHD/////5kc8AP/////nEjTw/////+gnHgD/////6PIW8P/////qBwAA/////+rR+PD/////6+biAP/////s1sTw/////+3GxAD/////7pG88P/////zb6SA//////QxYvD/////+Q9KgP/////6CHYA//////r4ZwD/////++hYAP/////82EkA//////3IOgD//////rgrAP//////qBwAAAAAAACYDQAAAAAAAYf+AAAAAAACd+8AAAAAAANxGoAAAAAABGELgAAAAAAFUPyAAAAAAAZA7YAAAAAABzDegAAAAAAIIM+AAAAAAAkQwIAAAAAACgCxgAAAAAAK8KKAAAAAAAvgk4AAAAAADNm/AAAAAAANwHWAAAAAAA65oQAAAAAAD6mSAAAAAAAQmYMAAAAAABGJdAAAAAAAEnllAAAAAAATaVYAAAAAABRZRwAAAAAAFUk4AAAAAAAWOSkAAAAAABcpGgAAAAAAGCJFgAAAAAAZCPwAAAAAABoCJ4AAAAAAGvIYgAAAAAAb4gmAAAAAABzR+oAAAAAAHcHrgAAAAAAesdyAAAAAAB+hzYAAAAAAIHYPAAAAAAAhga+AAAAAACJV8QAAAAAAI2rMAAAAAAAkNdMAAAAAACVKrgAAAAAAJhW1AAAAAAAnKpAAAAAAACf+0YAAAAAAKQpyAAAAAAAp3rOAAAAAACrqVAAAAAAAK76VgAAAAAAs03CAAAAAAC2ed4AAAAAALrNSgAAAAAAvflmAAAAAADCTNIAAAAAAMWd2AAAAAAAycxaAAAAAADNHWAAAAAAANFL4gAAAAAA1JzoAAAAAADYy2oAAAAAANwccAAAAAAA4G/cAAAAAADjm/gAAAAAAOfvZAAAAAAA6xuAAAAAAADvbuwAAAAAAPK/8gAAAAAA9u50AAAAAAD6P3oAAAAAAP5t/AAAAAABAb8CAAAAAAEGEm4AAAAAAQk+igAAAAABDZH2AAAAAAEQvhIAAAAAARURRcAAAAABF87cAAgECAQIBAgMEAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgH//6TsAAD//7mwAQT//6ugAAj//7mwAQz//7mwARBMTVQAQ0RUAENTVABDV1QAQ1BUAApDU1Q2Q0RULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABIAAAABAAAABD/////54xuAAAAAAAEYQuAAAAAAAVQ7nAAAAAABkDtgAAAAAAHMNBwAAAAAAggz4AAAAAACRCycAAAAAAKALGAAAAAAArwlHAAAAAAC+CTgAAAAAAM2bDwAAAAAA3AdYAAAAAADrmS8AAAAAAPqZIAAAAAABCZdPAAAAAAEYl0AAAAAAASeVbwAAAAABNpVgAAAAAAFFk48AAAAAAVSTgAAAAAABY5GvAAAAAAFykaAAAAAAAYIjdwAAAAABkI/AAAAAAAGgIZcAAAAAAa8hiAAAAAABvh+3AAAAAAHNH6gAAAAAAdwd1wAAAAAB6x3IAAAAAAH6G/cAAAAAAgdg8AAAAAACGBoXAAAAAAIlXxAAAAAAAjar3wAAAAACQ10wAAAAAAJUqf8AAAAAAmFbUAAAAAACcqgfAAAAAAJ/7RgAAAAAApCmPwAAAAACnes4AAAAAAKupF8AAAAAArvpWAAAAAACzTYnAAAAAALZ53gAAAAAAus0RwAAAAAC9+WYAAAAAAMJMmcAAAAAAxZ3YAAAAAADJzCHAAAAAAM0dYAAAAAAA0UupwAAAAADUnOgAAAAAANjLMcAAAAAA3BxwAAAAAADgb6PAAAAAAOOb+AAAAAAA5+8rwAAAAADrG4AAAAAAAO9us8AAAAAA8r/yAAAAAAD27jvAAAAAAPo/egAAAAAA/m3DwAAAAAEBvwIAAAAAAQYSNcAAAAABCT6KAAAAAAENkb3AAAAAARC+EgAAAAABFRFFwAAAAAEXztwACAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAwECAQIBAgECAQIBAgEAAAAAAAD//7mwAQT//6ugAAj//7mwAAwtMDAAQ0RUAENTVABFU1QACkNTVDZDRFQsTTMuMi4wLE0xMS4xLjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAnAAAAAwAAAAz/////lqpnuP////+4D0ng/////7j9QKD/////ufE0MP////+63nQg/////9o4rjD/////2uv6MP/////cGeGw/////9y5WSD/////3fsVMP/////em94g/////9/dmjD/////4FQzIP/////0l/+w//////UFXiD/////9sBkMP/////3Dh6g//////hRLDD/////+MfFIP/////6CtKw//////qo+KD/////++wGMP/////8i32gAAAAAB3JjjAAAAAAHnjXoAAAAAAfoDWwAAAAACAzz6AAAAAAIYFpMAAAAAAiC8igAAAAACNYELAAAAAAI+JwIAAAAAAlN/KwAAAAACXUxyAAAAAAN/bGsAAAAAA4uIUgAAAAADnf4zAAAAAAOekPoAAAAAA7yP+wAAAAADxvDqACAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQL//99IAAD//+PgAQT//9XQAAhMTVQALTAyAC0wMwAKPC0wMz4zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1AAAABgAAABj/////hv2THP////+euK+Q/////5+7B4D/////tWVP8P////+2MEjg/////7dFMfD/////uBAq4P////+5JRPw/////7nwDOD/////uw4wcP////+7z+7g/////7zuEnD/////vbkLYP/////Ccgjw/////8Nh6+D/////xFHq8P/////FOJNg/////8YxzPD/////xyGv4P/////IGulw/////8kKzGD/////yfrLcP/////K6q5g/////8uJDJD/////0iP0cP/////SYRgA/////9NjjBD/////1FNvAP/////VVeMQ/////9Yg3AD/////1zXFEP/////YAL4A/////9kVpxD/////2eCgAP/////a/sOQ/////9vAggD/////3N6lkP/////dqZ6A/////96+h5D/////34mAgP/////gnmmQ/////+FpYoD/////4n5LkP/////jSUSA/////+ReLZD/////5SkmgP/////mR0oQ/////+cSQwD/////6CcsEP/////o8iUA/////+vm8BD/////7NbTAP/////txtIQAgECAQIBAgECAQIBAgECAQIBAgECAQIDBAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgX//53kAAD//6ugAQT//52QAAj//6ugAQz//6ugARD//6ugABRMTVQATURUAE1TVABNV1QATVBUAENTVAAKQ1NUNgo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABIAAAABAAAABD/////1fuBgAAAAAAEYQuAAAAAAAVQ7nAAAAAABkDtgAAAAAAHMNBwAAAAAAggz4AAAAAACRCycAAAAAAKALGAAAAAAArwlHAAAAAAC+CTgAAAAAAM2bDwAAAAAA3AdYAAAAAADrmS8AAAAAAPqZIAAAAAABCZdPAAAAAAEYl0AAAAAAASeVbwAAAAABNpVgAAAAAAFFk48AAAAAAVSTgAAAAAABY5GvAAAAAAFykaAAAAAAAYIjdwAAAAABkI/AAAAAAAGgIZcAAAAAAa8hiAAAAAABvh+3AAAAAAHNH6gAAAAAAdwd1wAAAAAB6x3IAAAAAAH6G/cAAAAAAgdg8AAAAAACGBoXAAAAAAIlXxAAAAAAAjar3wAAAAACQ10wAAAAAAJUqf8AAAAAAmFbUAAAAAACcqgfAAAAAAJ/7RgAAAAAApCmPwAAAAACnes4AAAAAAKupF8AAAAAArvpWAAAAAACzTYnAAAAAALZ53gAAAAAAus0RwAAAAAC9+WYAAAAAAMJMmcAAAAAAxZ3YAAAAAADJzCHAAAAAAM0dYAAAAAAA0UupwAAAAADUnOgAAAAAANjLMcAAAAAA3BxwAAAAAADgb6PAAAAAAOOb+AAAAAAA5+8rwAAAAADrG4AAAAAAAO9us8AAAAAA8r/yAAAAAAD27jvAAAAAAPo/egAAAAAA/m3DwAAAAAEBvwIAAAAAAQYSNcAAAAABCT6KAAAAAAENkb3AAAAAARC+EgAAAAABFRFFwAAAAAEXztwACAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAwECAQIBAgECAQIBAwEAAAAAAAD//7mwAQT//6ugAAj//7mwAAwtMDAAQ0RUAENTVABFU1QACkNTVDZDRFQsTTMuMi4wLE0xMS4xLjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeAAAABAAAAAz/////lqp6SP////+4D1fw/////7j9TrD/////ufFCQP////+63oIw/////9o4vED/////2uwIQP/////cGe/A/////9y5ZzD/////3fsjQP/////em+ww/////9/dqED/////4FRBMP/////0mA3A//////UFbDD/////9sByQP/////3Diyw//////hROkD/////+MfTMP/////6CuDA//////qpBrD/////++wUQP/////8i4uwAAAAAB3JnEAAAAAAHnjlsAAAAAAfoEPAAAAAACAz3bAAAAAAIYF3QAAAAAAiC9awAAAAAEhgcUACAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgP//8y4AAD//9XQAQT//8fAAAj//9XQAARMTVQALTAzAC0wNAAKPC0wMz4zCg==",
    "VFppZjMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACCAAAABgAAABT/////aYcdxf////+PMEdF/////5tc5VD/////n3zixf////+hAHHA/////7Bed8X/////sXc9QP////+yQQDQ/////7NYcMD/////tCI0UP////+1OaRA/////7YDZ9D/////txrXwP////+35JtQ/////7j9XMD/////uccgUP/////MHG5A/////8xs59D/////09yPwP/////UF9Uw/////9UzVcD/////1XaSQP/////90TxA//////6S+rD//////8zNwAAAAAAActywAAAAAAF1UMAAAAAAAkBJsAAAAAADVTLAAAAAAAQgK7AAAAAABT5PQAAAAAAGAA2wAAAAAAcLvEAAAAAAB9/vsAAAAAAI/hNAAAAAAAm/0bAAAAAACt31QAAAAAALqO4wAAAAAAy910AAAAAADYjQMAAAAAAOnblAAAAAAA9osjAAAAAAEIbVwAAAAAARSJQwAAAAABJmt8AAAAAAEyh2MAAAAAAURpnAAAAAABURkrAAAAAAFiZ7wAAAAAAW8XSwAAAAABgGXcAAAAAAGNFWsAAAAAAZ5j/AAAAAABqxOLAAAAAAG89cQAAAAAAckRqwAAAAAB2vPkAAAAAAHnD8sAAAAAAfjyBAAAAAACB/AzAAAAAAIW8CQAAAAAAiOfswAAAAACNO5EAAAAAAJBndMAAAAAAlOADAAAAAACX5vzAAAAAAJvL4wAAAAAAn2aEwAAAAACj3xMAAAAAAKcK9sAAAAAAq16bAAAAAACuin7AAAAAALLeIwAAAAAAtgoGwAAAAAC6XasAAAAAAL2JjsAAAAAAwgIdAAAAAADFCRbAAAAAAMmBpQAAAAAAzPdcwAAAAADRAS0AAAAAANQtEMAAAAAA2DbhAAAAAADcG1bAAAAAAOAAPQAAAAAA4ywgwAAAAADnpK8AAAAAAOqrqMAAAAAA7yQ3AAAAAADyKzDAAAAAAPajvwAAAAAA+aq4wAAAAAD+I0cAAAAAAQFPKsAAAAABBaLPAAAAAAEIzrLAAAAAAQ0iVwAAAAABEE46wAAAAAEUxskAAAAAARfNwsAAAAABHEZRAAAAAAEfvAjAAAAAASPF2QAAAAABJvG8wAAAAAErRWEAAAAAAS7gAsAAAAABMsTpAAAAAAE3GBzAAAAAATlCCwAAAAABPnK6wAAAAAFBC2cAAAAAAUXyQsAAAAABSK/ZAAAAAAFNccrAAAAAAVAvYQAAAAABXN+YwAAAAAFev7MAAAAAAWRfIMAAAAABZj87AAAAAAFr3qjAAAAAAW2+wwAAAAABcqWewAAAAAF10fMAAAAAAXolJsAAAAABfVF7AAAAAAGBpK7AAAAAAYTRAwAAAAABiSQ2wAAAAAGMdXUAAAAAAZCjvsAECAQMBBAIEAgQCBAIEAgMCAwUEAgMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQMFAwUDBQP//727AAD//727AAT//7mwAAj//8fAAAz//8fAAQz//9XQARBMTVQAU01UAC0wNQAtMDQALTAzAAo8LTA0PjQ8LTAzPixNOS4xLjYvMjQsTTQuMS42LzI0Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARAAAABgAAABv/////aYcdCP////+630Jg//////oIS9D/////+qfDQP//////p/HQAAAAAABDe8gAAAAAAYfT0AAAAAAB+n9IAAAAAANw8FAAAAAAA90ESAAAAAAFUNJQAAAAAAW/iUgAAAAABzC0UAAAAAAHoLzIAAAAAAkQllAAAAAAOfu84AAAAAA6KeFgAQMCAwQDBAMEAwQDBAMFAwX//754AAD//75gAAT//8fAAQn//7mwAA3//8C4ARH//8fAABdMTVQAU0RNVABFRFQARVNUAC0wNDMwAEFTVAAKQVNUNAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABbAAAAAwAAAAz/////lqpytP////+4D0ng/////7j9QKD/////ufE0MP////+63nQg/////9o4rjD/////2uv6MP/////cGeGw/////9y5WSD/////3fsVMP/////em94g/////9/dmjD/////4FQzIP/////0Wgkw//////UFXiD/////9sBkMP/////3Dh6g//////hRLDD/////+MfFIP/////6CtKw//////qo+KD/////++wGMP/////8i32gAAAAAB3JjjAAAAAAHnjXoAAAAAAfoDWwAAAAACAzz6AAAAAAIYFpMAAAAAAiC8igAAAAACNYELAAAAAAI+JwIAAAAAAlN/KwAAAAACXUxyAAAAAAJyEPMAAAAAAnveOgAAAAACkA8TAAAAAAKZSLIAAAAAAq6g2wAAAAACtrMqAAAAAALMC1MAAAAAAtZsQgAAAAAC6glzAAAAAAL0amIAAAAAAwgHkwAAAAADEdTaAAAAAAMlcgsAAAAAAzBmogAAAAADQ4VDAAAAAANPjBIAAAAAA2IB8wAAAAADbPaKAAAAAAN/bGsAAAAAA4uIUgAAAAADnf4zAAAAAAOo8soAAAAAA7yP+wAAAAADxvDqAAAAAAPcSRMAAAAAA+TvCgAAAAAD+R/jAAAAAAQC7SoAAAAABBhvgwAAAAAEIX7yAAAAAAQ1HCMAAAAABD99EgAAAAAEVNU7AAAAAAReDtoAAAAABHEYYwAAAAAEe3lSAAAAAASPqisAAAAABJl3cgAAAAAErahLAAAAAAS4CToAAAAABMumawAAAAAE1gdaAAAAAATppIsAAAAABPSZIgAAAAAFCDZTAAAAAAUSA5oAAAAABSY0cwAAAAAFMAG6AAAAAAVEMpMAAAAABU6TggAAAAAFYjCzAAAAAAVskaIAAAAABYAu0wAAAAAFio/CAAAAAAWeLPMAAAAABaiN4gAAAAAFveYLAAAAAAXGjAIAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQL//9RMAAD//+PgAQT//9XQAAhMTVQALTAyAC0wMwAKPC0wMz4zCg==",
    "VFppZjMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABaAAAABQAAABD/////m4BMGAAAAAATTW5AAAAAABQ0JMAAAAAAFSP5oAAAAAAWE9yQAAAAABcDzZAAAAAAF/O+kAAAAAAY46+QAAAAABnToJAAAAAAGsORkAAAAAAbvL0QAAAAABysrhAAAAAAHZyfEAAAAAAejJAQAAAAAB98gRAAAAAAIGxyEAAAAAAhXGMQAAAAACJMVBAAAAAAIzxFEAAAAAAkLDYQAAAAACUcJxAAAAAAJgwYEAAAAAAnBUOQAAAAACf1NJAAAAAAKOUlkAAAAAAp1RaQAAAAACrFB5AAAAAAK7T4kAAAAAAspOmQAAAAAC2U2pAAAAAALoTLkAAAAAAvdLyQAAAAADBkrZAAAAAAMV3ZEAAAAAAycrQQAAAAADM9uxAAAAAANFKWEAAAAAA1HZ0QAAAAADYyeBAAAAAANv1/EAAAAAA4G5SQAAAAADjdYRAAAAAAOft2kAAAAAA6vUMQAAAAADvbWJAAAAAAPKZfkAAAAAA9uzqQAAAAAD6GQZAAAAAAP5sckAAAAABAZiOQAAAAAEGEORAAAAAAQkYFkAAAAABDZBsQAAAAAEQl55AAAAAARUP9EAAAAABGBcmQAAAAAEcj3xAAAAAAR+7mEAAAAABJA8EQAAAAAEnOyBAAAAAASuOjEAAAAABLrqoQAAAAAEzMv5AAAAAATY6MEAAAAABOrKGQAAAAAE9ubhAAAAAAUIyDkAAAAABRV4qQAAAAAFJsZZAAAAAAUzdskAAAAABUTEeQAAAAAFUXTpAAAAAAViwpkAAAAABW9zCQAAAAAFgVRhAAAAAAWNcSkAAAAABZ9SgQAAAAAFq29JAAAAAAW9UKEAAAAABcoBEQAAAAAF207BAAAAAAXn/zEAAAAABflM4QAAAAAGBf1RAAAAAAYX3qkAAAAABiP7cQAAAAAGNdzJAAAAAAZB+ZEAAAAABlPa6QAAAAAGYItZABAgEEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwL//+toAAD//+PgAAT///HwAQj///HwAAgAAAAAAQxMTVQALTAyAC0wMQArMDAACjwtMDI+MjwtMDE+LE0zLjUuMC8tMSxNMTAuNS4wLzAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABTAAAACQAAACL/////P8L90f////99hzOZ/////8uJGqD/////0iP0cP/////SYSYQ//////64RyD//////6gqEAAAAAAAmCkgAAAAAAGIDBAAAAAAAngLIAAAAAADcSiQAAAAAARhJ6AAAAAABVEKkAAAAAAGQQmgAAAAAAcw7JAAAAAAB41DoAAAAAAJEM6QAAAAAAmtvyAAAAAACvCwkAAAAAAL4K+gAAAAAAzZzRAAAAAADcCRoAAAAAAOua8QAAAAAA+priAAAAAAEJmREAAAAAARiZAgAAAAABJ5cxAAAAAAE2lyIAAAAAAUWVUQAAAAABVJVCAAAAAAFjk3EAAAAAAXKTYgAAAAABgiU5AAAAAAGQkYIAAAAAAaAjWQAAAAABorFBAAAAAAGvJCsAAAAAAb4iWgAAAAABzSJLAAAAAAHcIHoAAAAAAesgawAAAAAB+h6aAAAAAAIHY5MAAAAAAhgcugAAAAACJWGzAAAAAAI2roIAAAAAAkNf0wAAAAACVKyiAAAAAAJhXfMAAAAAAnKqwgAAAAACf++7AAAAAAKQqOIAAAAAAp3t2wAAAAACrqcCAAAAAAK76/sAAAAAAs04ygAAAAAC2eobAAAAAALrNuoAAAAAAvfoOwAAAAADCTUKAAAAAAMWegMAAAAAAyczKgAAAAADNHgjAAAAAANFMUoAAAAAA1J2QwAAAAADYy9qAAAAAANwdGMAAAAAA4HBMgAAAAADjnKDAAAAAAOfv1IAAAAAA6xwowAAAAADvb1yAAAAAAPLAmsAAAAAA9u7kgAAAAAD6QCLAAAAAAP5ubIAAAAABAb+qwAAAAAEGEt6AAAAAAQk/MsAAAAABDZJmgAAAAAEQvrrAAAAAARUR7oAAAAABF8+EwAQIDBAIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQYIBwgHCAcIBwgHCAcIBwgHCAcIBwgHCAcIBwgHCAcIBwgHCAcIBwgHCAcIBwgHCAcAANKnAAD//4EnAAD//4+AAAT//52QAQj//52QAQz//52QARD//4FwABT//4+AARj//4FwAB1MTVQAUFNUAFBXVABQUFQAUERUAFlTVABBS0RUAEFLU1QACkFLU1Q5QUtEVCxNMy4yLjAsTTExLjEuMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC7AAAACAAAABn/////Xj007P////+cz2IM/////52k5vz/////nrh+jP////+futZ8/////6C2iNz/////oTj/TP////+ilRlc/////6OE/Ez/////pHT7XP////+lZN5M/////6ZeF9z/////p0TATP////+oPfnc/////6kkokz/////qh3b3P////+rBIRM/////6v9vdz/////rORmTP////+t3Z/c/////67Ngsz/////r72B3P////+wrWTM/////7Gmnlz/////so1GzP////+zhoBc/////7RtKMz/////tWZiXP////+2TQrM/////7dGRFz/////uCzszP////+5JiZc/////7oWCUz/////uw9C3P////+79etM/////7zvJNz/////vdXNTP////++nk1s/////77PBqj/////v7WvGP/////AuDE4/////8F576j/////wpgTOP/////DWdGo/////8R39Tj/////xTmzqP/////GYRG4/////8cZlaj/////yEDzuP/////JArIo/////8og1bj/////yuKUKP/////MALe4/////9Ij9HD/////0mDmyP/////TiETY/////9RKA0j/////1Wgm2P/////WKeVI/////9dICNj/////2AnHSP/////ZJ+rY/////9npqUj/////2xEHWP/////b0sXI/////9zedFj/////3altSP/////evlZY/////9+JT0j/////4J44WP/////haTFI/////+J+Glj/////40kTSP/////kXfxY/////+Uo9Uj/////5kcY2P/////nEhHI/////+gm+tj/////6PHzyP/////qBtzY/////+rR1cj/////6+a+2P/////ssbfI/////+3GoNj/////7r++SP/////vr71Y//////CfoEj/////8Y+fWP/////yf4JI//////NvgVj/////9F9kSP/////1T2NY//////Y/Rkj/////9y9FWP/////4KGLI//////kPJ1j/////+ghEyP/////6+EPY//////voJsj//////Ngl2P/////9yAjI//////64B9j//////6fqyAAAAAAAl+nYAAAAAAGHzMgAAAAAAnfL2AAAAAADcOlIAAAAAARg6FgAAAAABVDLSAAAAAAGQMpYAAAAAAcwrUgAAAAACCCsWAAAAAAJEI9IAAAAAAoAjlgAAAAACvBxSAAAAAAL4HBYAAAAAAzZjcgAAAAADcBSWAAAAAAOuW/IAAAAAA+pbtgAAAAAEJlRyAAAAAARiVDYAAAAABJ5M8gAAAAAE2ky2AAAAAAUWRXIAAAAABVJFNgAAAAAFjj3yAAAAAAXKPbYAAAAABgiFEgAAAAAGQjY2AAAAAAaAfZIAAAAABrx9VgAAAAAG+HYSAAAAAAc0ddYAAAAAB3BukgAAAAAHrG5WAAAAAAfoZxIAAAAACB1z/QAAAAAIYFiZAAAAAAiVbH0AAAAACNqcNQAAAAAJDWT9AAAAAAlSmDkAAAAACYVdfQAAAAAJypC5AAAAAAn/pJ0AAAAACkKJOQAAAAAKd50dAAAAAAq6gbkAAAAACu+VnQAAAAALNMjZAAAAAAtnjh0AAAAAC6zBWQAAAAAL34adAAAAAAwkudkAAAAADFnNvQAAAAAMnLJZAAAAAAzRxj0AAAAADRSq2QAAAAANSb69AAAAAA2Mo1kAAAAADcG3PQAAAAAOBup5AAAAAA45r70AAAAADn7i+QAAAAAOsag9AAAAAA7223kAAAAADyvvXQAAAAAPbtP5AAAAAA+j590AAAAAD+bMeQAAAAAQG+BdAAAAABBhE5kAAAAAEJPY3QAAAAAQ2QwZAAAAABEL0V0AAAAAEVEEmQAAAAARfN39AAAAABHLS7kAAAAAEfTWfQAAAAASQ0Q5AAAAABJszv0AAAAAErs8uQAAAAAS5xYdAAAAABM1g9kAAAAAE18OnQAAAAATq9ZqAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIEAwQDBAMEAwQDBAMEAwQGBQQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQHBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwP//86UAAD//9ykAQT//86UAAj//9zYAQT//87IAAj//9zYAQz//9zYARD//+roARRMTVQATkRUAE5TVABOUFQATldUAE5ERFQACk5TVDM6MzBORFQsTTMuMi4wLE0xMS4xLjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXAAAABgAAABj/////hv2WGP////+euK+Q/////5+7B4D/////y4kMkP/////SI/Rw/////9JhGAD/////03YBEP/////UU28A/////9VV4xD/////1iDcAP/////XNcUQ/////9gAvgD/////2RWnEP/////Z4KAA/////+gnLBD/////6RcPAP/////r5vAQ/////+zW0wD/////7cbSEP/////ukcsA/////++v7pD/////8HGtAAAAAAAEYRmQAgECAwQCAQIBAgECAQIBAgECAQIBAgX//5roAAD//6ugAQT//52QAAj//6ugAQz//6ugARD//6ugABRMTVQATURUAE1TVABNV1QATVBUAENTVAAKQ1NUNgo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAAAAwAAAAz/////pExLRAAAAAAgmtzgAAAAACFcm1AAAAAAInq+4AAAAAAjPH1QAAAAAERdjOAAAAAARNbI0AIBAgECAQL//648AAD//7mwAQT//6ugAAhMTVQAQ0RUAENTVAAKQ1NUNgo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiAAAAAwAAAAz/////m4B3/AAAAAAn9XrgAAAAACjlXdAAAAAAKdVc4AAAAAAqxT/QAAAAACu+eWAAAAAALNNGUAAAAAAtnltgAAAAAC6zKFAAAAAAL349YAAAAAAwkwpQAAAAADFnWeAAAAAAMnLsUAAAAAAzRzvgAAAAADRSzlAAAAAANScd4AAAAAA2MrBQAAAAADcG/+AAAAAAOBvM0AAAAAA45uHgAAAAADn7rtAAAAAAOsbD4AAAAAA725DQAAAAADyv4GAAAAAAPbty0AAAAAA+j8JgAAAAAD+bVNAAAAAAQG+kYAAAAABBhHFQAAAAAEJPhmAAAAAAQ2RTUAAAAABEL2hgAAAAAEVENVAAAAAARfOa4AIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgH//7+EAAD//9XQAQT//8fAAAhMTVQAQURUAEFTVAAKQVNUNEFEVCxNMy4yLjAsTTExLjEuMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACoAAAABgAAABj/////Xj127P////+euL2g/////5+7FZD/////y4kaoP/////SI/Rw/////9JhJhD/////03YPIP/////UQQgQ/////9VV8SD/////1iDqEP/////XNdMg/////9gAzBD/////2RW1IP/////Z4K4Q/////9r+0aD/////28CQEP/////c3rOg/////92prJD/////3r6VoP/////fiY6Q/////+Ced6D/////4WlwkP/////iflmg/////+NJUpD/////5F47oP/////lKTSQ/////+ZHWCD/////5xJREP/////oJzog/////+jyMxD/////6gccIP/////q0hUQ/////+vm/iD/////7LH3EP/////txuAg/////+6R2RD/////76/8oP/////wcbsQ//////GP3qD/////8n/BkP/////zb8Cg//////Rfo5D/////9U+ioP/////2P4WQ//////cvhKD/////+CiiEP/////5D2ag//////oIhBD/////+viDIP/////76GYQ//////zYZSD//////chIEP/////+uEcg//////+oKhAAAAAAAJgpIAAAAAABiAwQAAAAAAJ4CyAAAAAAA3EokAAAAAAEYSegAAAAAAVRCpAAAAAABkEJoAAAAAAHMOyQAAAAAAgg66AAAAAACRDOkAAAAAAKAM2gAAAAAArwsJAAAAAAC+CvoAAAAAAM2c0QAAAAAA3AkaAAAAAADrmvEAAAAAAPqa4gAAAAABCZkRAAAAAAEYmQIAAAAAASeXMQAAAAABNpciAAAAAAFFlVEAAAAAAVSVQgAAAAABY5NxAAAAAAFyk2IAAAAAAYIlOQAAAAABkJGCAAAAAAGgI1kAAAAAAa8jSgAAAAABviF5AAAAAAHNIWoAAAAAAdwfmQAAAAAB6x+KAAAAAAH6HbkAAAAAAgdisgAAAAACGBvZAAAAAAIlYNIAAAAAAjatoQAAAAACQ17yAAAAAAJUq8EAAAAAAmFdEgAAAAACcqnhAAAAAAJ/7toAAAAAApCoAQAAAAACnez6AAAAAAKupiEAAAAAArvrGgAAAAACzTfpAAAAAALZ6ToAAAAAAus2CQAAAAAC9+daAAAAAAMJNCkAAAAAAxZ5IgAAAAADJzJJAAAAAAM0d0IAAAAAA0UwaQAAAAADUnViAAAAAANjLokAAAAAA3BzggAAAAADgcBRAAAAAAOOcaIAAAAAA5++cQAAAAADrG/CAAAAAAO9vJEAAAAAA8sBigAAAAAD27qxAAAAAAPo/6oAAAAAA/m40QAAAAAEBv3KAAAAAAQYSpkAAAAABCT76gAAAAAENki5AAAAAARC+goAAAAABFRG2QAAAAAEXz0yAAAAAARy2KEAAAAABH07UgAAAAAEkNbBAAAAAASbOXIAAAAABK7U4QAAAAAEucs6AAAAAATNZqkAAAAABNfJWgAAAAAE62TJAAAAAAT1x3oAAAAABQli6QAAAAAFE8WaAAAAAAUnYQkAAAAABTHDugAAAAAFRV8pAAAAAAVPwdoAAAAABWNdSQAAAAAFblOiAAAAAAWB7xEAAAAABYxRwgAAAAAFn+0xAAAAAAWqT+IAAAAABb3rUQAAAAAFyE4CAAAAAAXb6XEAAAAABeZMIgAAAAAF+eeRAAAAAAYE3eoAAAAABhh5WQAAAAAGItwKAAAAAAY2d3kAAAAABkDaKgAAAAAGVHWZAAAAAAZe2EoAAAAABnJzuQAAAAAGfNZqAAAAAAaQcdkAAAAABprUigAAAAAGrm/5ACAQIDBAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQX//4yUAAD//52QAQT//4+AAAj//52QAQz//52QARD//52QABRMTVQAUERUAFBTVABQV1QAUFBUAE1TVAAKTVNUNwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABdAAAACQAAACX/////fYaKnP////+euMuw/////5+7I6D/////oNAMsP////+hotKA/////8uJKLD/////0iP0cP/////SYTQg//////cvdpD/////+CiiEP/////4xYSQAAAAABNpciAAAAAAFFlVEAAAAAAVSVQgAAAAABY5NxAAAAAAFyk2IAAAAAAYIlOQAAAAABkJGCAAAAAAGgI1kAAAAAAa8jSgAAAAABviF5AAAAAAHNIWoAAAAAAdwfmQAAAAAB6x+KAAAAAAH6HbkAAAAAAgdisgAAAAACGBvZAAAAAAIlYNIAAAAAAjatoQAAAAACQ17yAAAAAAJUq8EAAAAAAmFdEgAAAAACcqnhAAAAAAJ/7toAAAAAApCoAQAAAAACnez6AAAAAAKupiEAAAAAArvrGgAAAAACzTfpAAAAAALZ6ToAAAAAAus2CQAAAAAC9+daAAAAAAMJNCkAAAAAAxZ5IgAAAAADJzJJAAAAAAM0d0IAAAAAA0UwaQAAAAADUnViAAAAAANjLokAAAAAA3BzggAAAAADgcBRAAAAAAOOcaIAAAAAA5++cQAAAAADrG/CAAAAAAO9vJEAAAAAA8sBigAAAAAD27qxAAAAAAPo/6oAAAAAA/m40QAAAAAEBv3KAAAAAAQYSpkAAAAABCT76gAAAAAENki5AAAAAARC+goAAAAABFRG2QAAAAAEXz0yAAAAAARy2KEAAAAABH07UgAAAAAEkNbBAAAAAASbOXIAAAAABK7U4QAAAAAEucs6AAAAAATNZqkAAAAABNfJWgAAAAAE62TJAAAAAAT1x3oAAAAABQli6QAAAAAFE8WaAAAAAAUnYQkAAAAABTHDugAAAAAFRV8pAAAAAAVPwdoAAAAABWNdSQAAAAAFblOiAAAAAAWB7xEAAAAABYxRwgAAAAAFn+0xAAAAAAWqT+IAAAAABb3rUQAAAAAFyE4CAAAAAAXb6XEAAAAABeZMIgAAAAAF+eXPACAQIBAgMEAgUCBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwj//4FkAAD//4+AAQT//4FwAAj//4+AAQz//4+AARD//52QART//4+AABn//52QAR3//52QACFMTVQAWURUAFlTVABZV1QAWVBUAFlERFQAUFNUAFBEVABNU1QACk1TVDcK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABTAAAACAAAAB7/////P8L90f////99hze//////8uJKLD/////0iP0cP/////SYTQg//////64VTD//////6g4IAAAAAAAmDcwAAAAAAGIGiAAAAAAAngZMAAAAAADcTagAAAAAARhNbAAAAAABVEYoAAAAAAGQRewAAAAAAcw+qAAAAAAB41RsAAAAAAJENygAAAAAAmtzTAAAAAACvC+oAAAAAAL4L2wAAAAAAzZ2yAAAAAADcCfsAAAAAAOub0gAAAAAA+pvDAAAAAAEJmfIAAAAAARiZ4wAAAAABJ5gSAAAAAAE2mAMAAAAAAUWWMgAAAAABVJYjAAAAAAFjlFIAAAAAAXKUQwAAAAABgiYaAAAAAAGQkmMAAAAAAaAkOgAAAAABorFBAAAAAAGvJCsAAAAAAb4iWgAAAAABzSJLAAAAAAHcIHoAAAAAAesgawAAAAAB+h6aAAAAAAIHY5MAAAAAAhgcugAAAAACJWGzAAAAAAI2roIAAAAAAkNf0wAAAAACVKyiAAAAAAJhXfMAAAAAAnKqwgAAAAACf++7AAAAAAKQqOIAAAAAAp3t2wAAAAACrqcCAAAAAAK76/sAAAAAAs04ygAAAAAC2eobAAAAAALrNuoAAAAAAvfoOwAAAAADCTUKAAAAAAMWegMAAAAAAyczKgAAAAADNHgjAAAAAANFMUoAAAAAA1J2QwAAAAADYy9qAAAAAANwdGMAAAAAA4HBMgAAAAADjnKDAAAAAAOfv1IAAAAAA6xwowAAAAADvb1yAAAAAAPLAmsAAAAAA9u7kgAAAAAD6QCLAAAAAAP5ubIAAAAABAb+qwAAAAAEGEt6AAAAAAQk/MsAAAAABDZJmgAAAAAEQvrrAAAAAARUR7oAAAAABF8+EwAQIDBAIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYAAM6BAAD//30BAAD//4FwAAT//4+AAQj//4+AAQz//4+AARD//4+AART//4FwABlMTVQAWVNUAFlXVABZUFQAWURUAEFLRFQAQUtTVAAKQUtTVDlBS0RULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARAAAAAwAAAAz//////h7MgAAAAABK2gYgAAAAAEuPyvAAAAAATqmcIAAAAABPQ82QAAAAAFgKO4AAAAAAWqQPEAAAAABbuRRAAAAAAFyNHYAAAAAAXZZFMAAAAABeY8UAAAAAAF94oDwAAAAAYEy3UAAAAABhWII8AAAAAGIsmVAAAAAAYzhkPAAAAABkCLEAAQIBAgECAQIBAgECAQIBAgEAAAAAAAAAAHCAAAQAAJqwAAgtMDAAKzA4ACsxMQAKPCswOD4tOAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAAAAwAAAAz/////55xAAP/////2R98Q//////5HqwAAAAAAStoUMAAAAABLl/pAAAAAAE6pqjAAAAAAT0P3wAEAAQIBAgEAAAAAAAAAAGJwAAQAAEZQAAgtMDAAKzA3ACswNQAKPCswNz4tNwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAwAAAA3/////VrZaCP////9y7aSQAQIAAIn4AAAAAInwAAQAAIygAAlMTVQAUE1NVAArMTAACjwrMTA+LTEwCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABbAAAAAwAAAA7/////fAUWAP////+b1XiA/////5y8LwD/////oIe0YP/////XDGgA//////vCjQD//////LJ+AP/////9x1kA//////52sID//////6c7AAAAAAAAVpKAAAAAAAGHHQAAAAAAAj+vAAAAAAADcDmAAAAAAAQNHAAAAAAABVAbgAAAAAAF9jiAAAAAAAcv/YAAAAAAB9YagAAAAAAJD9+AAAAAAAm1/IAAAAAACu/BgAAAAAALnxkAAAAAAAzY3gAAAAAADX77AAAAAAAOuMAAAAAAAA9e3QAAAAAAEJiiAAAAAAARPr8AAAAAABJ4hAAAAAAAEx6hAAAAAAAUWGYAAAAAABT+gwAAAAAAFjhIAAAAAAAXA08AAAAAABghZIAAAAAAGOMxAAAAAAAaAUaAAAAAABqnY4AAAAAAG+EogAAAAAAch0WAAAAAAB3BCoAAAAAAHmcngAAAAAAfl7IAAAAAACBZfoAAAAAAIYDOgAAAAAAiQpsAAAAAACNp6wAAAAAAJCJ9AAAAAAAlSc0AAAAAACYCXwAAAAAAJymvAAAAAAAn9LYAAAAAACjt4YAAAAAAKdSYAAAAAAAqzcOAAAAAACu0egAAAAAALK2lgAAAAAAtlFwAAAAAAC6Nh4AAAAAAL3Q+AAAAAAAwbWmAAAAAADFdWoAAAAAAMlaGAAAAAAAzPTyAAAAAADQ2aAAAAAAANR0egAAAAAA2FkoAAAAAADb9AIAAAAAAN/YsAAAAAAA43OKAAAAAADmn6YAAAAAAOrzEgAAAAAA7vyqAAAAAADyl4QAAAAAAPZ8MgAAAAAA+hcMAAAAAAD9+7oAAAAAAQGWlAAAAAABBXtCAAAAAAEJFhwAAAAAAQz6ygAAAAABELqOAAAAAAEUelIAAAAAARgVLAAAAAABHB7EAAAAAAEf3ogAAAAAASOeTAAAAAABJ14QAAAAAAErHdQAAAAAATR3T0AECAQABAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgIAAAAAAAAAAIygAAQAAJqwAQktMDAAQUVTVABBRURUAApBRVNULTEwQUVEVCxNMTAuMS4wLE00LjEuMC8zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAwAAAAz/////4iAygAAAAABK2iJAAQIAAAAAAAAAAFRgAAQAAEZQAAgtMDAAKzA2ACswNQAKPCswNT4tNQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABgAAAABgAAABP/////QbdMqP////+wtLLo/////7FRh1j/////snjlaP////+zQ+Vg/////7RYx2j/////tSPHYP////+2OKlo/////7cDqWD/////uBiLaP////+47MXg/////7n4bWj/////usyn4P////+72E9o/////7zj6OD/////va726P////++w8rg/////7+O2Oj/////wKOs4P/////Bbrro/////8KDjuD/////w06c6P/////EY3Dg/////8Uufuj/////xkyNYP/////HDmDo/////8gsb2D/////yPd9aP/////S2ppAAAAAAAkY/eAAAAAACayl4AAAAAAK76VgAAAAAAue/OAAAAAADNjB4AAAAAANft7gAAAAAA64o+AAAAAAD17A4AAAAAAQmIXgAAAAABE+ouAAAAAAEnhn4AAAAAATHoTgAAAAABRYSeAAAAAAFP5m4AAAAAAWOCvgAAAAABbng2AAAAAAGCFIYAAAAAAYx2VgAAAAABoBKmAAAAAAGqdHYAAAAAAb4QxgAAAAAByHKWAAAAAAHcDuYAAAAAAeZwtgAAAAAB+g0GAAAAAAIEbtYAAAAAAhgLJgAAAAACIwCeAAAAAAI2nO4AAAAAAkD+vgAAAAACUuAWAAAAAAJgJC4AAAAAAnDeNgAAAAACfiJOAAAAAAKO3FYAAAAAApwgbgAAAAACrNp2AAAAAAK6sjYAAAAAAsrYlgAAAAAC2LBWAAAAAALo1rYAAAAAAvaudgAAAAADBtTWAAAAAAMUrJYAAAAAAyVmngAAAAADMqq2AAAAAANDZL4AAAAAA1Co1gAAAAADYWLeAAAAAANvOp4AAAAAA39g/gAAAAADjTi+AAAAAAOdXx4AAAAAA6s23gAAAAADu/DmAAAAAAPJNP4AAAAAA9nvBgAAAAAD5zMeAAAAAAP37SYAAAAABAXE5gAAAAAEFetGAAAAAAQjwwYAAAAABDPpZgAAAAAEQcEmAAAAAARR54YAAAAABF+/RgAAAAAEb+WmACAQIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQAAKPYAAAAAK/IAQQAAKG4AAkAAKjAAQQAALbQAQ4AAKjAAARMTVQATlpTVABOWk1UAE5aRFQACk5aU1QtMTJOWkRULE05LjUuMCxNNC4xLjAvMwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABSAAAABQAAABD/////9pitAP/////25p+w//////gTQ8D/////+MfTMP/////59HdA//////rTNrD/////+8M1wP/////8vFMw//////2sUkD//////pw1MP//////jDRAAAAAAAejSrAAAAAACCRvoAAAAAAXMLywAAAAABgGXcAAAAAAGNFWsAAAAAAZ5j/AAAAAABqxOLAAAAAAG89cQAAAAAAckRqwAAAAAB2vPkAAAAAAHnD8sAAAAAAfjyBAAAAAACB/AzAAAAAAIW8CQAAAAAAiOfswAAAAACNO5EAAAAAAJBndMAAAAAAlOADAAAAAACX5vzAAAAAAJvL4wAAAAAAn2aEwAAAAACj3xMAAAAAAKcK9sAAAAAAq16bAAAAAACuin7AAAAAALLeIwAAAAAAtgoGwAAAAAC6XasAAAAAAL2JjsAAAAAAwgIdAAAAAADFCRbAAAAAAMmBpQAAAAAAzPdcwAAAAADRAS0AAAAAANQtEMAAAAAA2DbhAAAAAADcG1bAAAAAAOAAPQAAAAAA4ywgwAAAAADnpK8AAAAAAOqrqMAAAAAA7yQ3AAAAAADyKzDAAAAAAPajvwAAAAAA+aq4wAAAAAD+I0cAAAAAAQFPKsAAAAABBaLPAAAAAAEIzrLAAAAAAQ0iVwAAAAABEE46wAAAAAEUxskAAAAAARfNwsAAAAABHEZRAAAAAAEfvAjAAAAAASPF2QAAAAABJvG8wAAAAAErRWEAAAAAAS7gAsAAAAABMsTpAAAAAAE3GBzAAAAAATlCCwAAAAABPnK6wAAAAAFBC2cAAAAAAUXyQsAAAAABSK/ZAAAAAAFNccrAAAAAAVAvYQAAAAABXN+YwAAAAAFev7MAAAAAAWEOGsAIBAgECAQIBAgEEAwQBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgQAAAAAAAD//8fAAAT//9XQAQj//+PgAQz//9XQAAgtMDAALTA0AC0wMwAtMDIACjwtMDM+Mwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAgAAAAgAAAAADQItAAEAAAAAAAD//9XQAAQtMDAALTAzAAo8LTAzPjMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAgAAAAj/////1Rs2tAEAACvMAAAAACowAARMTVQAKzAzAAo8KzAzPi0zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAgAAAAgAAAAAQg1HAAEAAAAAAAAAAAAAAAQtMDAAKzAwAAo8KzAwPjA8KzAyPi0yLE0zLjUuMC8xLE0xMC41LjAvMwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAwAAAAz/////6ViJgAAAAAAtTTkQAAAAAC61hQAAAAAAZX9FMAEAAQIAAAAAAAAAAGJwAAQAAEZQAAgtMDAAKzA3ACswNQAKPCswNT4tNQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8AAAABAAAABL/////b6Jh+P////+bDBdg/////5vV2vD/////nNmukP////+dpLWQ/////565kJD/////n4SXkP/////ICXGQ/////8znSxD/////zakXkP/////OokMQ/////8+SNBD/////0IIlEP/////RchYQ/////9G2lgD/////0li+gP/////SoU8Q/////9NjG5D/////1EsjkP/////VOdEg/////9Vn55D/////1ahzAP/////WKbQQ/////9csGhD/////2AmWEP/////ZAsGQ/////9npeBAAAAAAE01EEAAAAAAUM/qQAAAAABUj65AAAAAAFhPckAAAAAAXA82QAAAAABfzvpAAAAAAGOOvkAAAAAAZ06CQAAAAABrDkZAAAAAAG7y9EAAAAAAcrK4QAAAAAB2cnxAAAAAAHoyQEAAAAAAffIEQAAAAACBschAAAAAAIVxjEAAAAAAiTFQQAAAAACM8RRAAAAAAJCw2EAAAAAAlHCcQAAAAACYMGBAAAAAAJwVDkAAAAAAn9TSQAAAAACjlJZAAAAAAKdUWkAAAAAAqxQeQAAAAACu0+JAAAAAALKTpkAAAAAAtlNqQAAAAAC6Ey5AAAAAAL3S8kAAAAAAwZK2QAAAAADFd2RACAQIBAgECAQIBAgECAQMBAgECAQMBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgEAAAyIAAAAABwgAQQAAA4QAAkAACowAQ1MTVQAQ0VTVABDRVQAQ0VNVAAKQ0VULTFDRVNULE0zLjUuMCxNMTAuNS4wLzMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0AAAABQAAABD/////qhl73P////+1o+8wAAAAABUnfaAAAAAAFhiyEAAAAAAXCLEgAAAAABf55ZAAAAAAGOnkoAAAAAAZ2xkQAAAAABrMaaAAAAAAG7x2wAAAAAAcrGfAAAAAAB2cWMAAAAAAHoxJwAAAAAAffDrAAAAAACBsK8AAAAAAIVwcwAAAAAAiTA3AAAAAACM7/sAAAAAAJCvvwAAAAAAlG+DAAAAAACYL0cAAAAAAJwT9QAAAAAAn9O5AAAAAACjk7VAAAAAAKXiVUAAAAAAp1NBAAAAAACrEwUAAAAAAK7SyQAAAAAAspKNAAAAAAC2UlEAAAAAALoSFQAAAAAAvdHZAAAAAADBkZ0AAAAAAMV2SwAAAAAAycm3AAAAAADM9dMAAAAAANFJPwAAAAAA1HVbAAAAAADYyMcAAAAAANv04wAAAAAA4G05AAAAAADjdGsAAAAAAOfswQAAAAAA6vPzAAAAAADvbEkAAAAAAPKYZQAAAAAA9uvRAAAAAAD6F+0AAAAAAP5rWQAAAAABAZd1AAAAAAEGD8sAAAAAAZeDGIAEDAgMCAwIDAgMCAwIDAgMCAwIDAgMEAQMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwEAAEgkAAAAAEZQAAQAAGJwAQgAAFRgAAwAAFRgAQxMTVQAKzA1ACswNwArMDYACjwrMDU+LTUK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABXAAAABAAAABH/////tqPW0AAAAAAGcnngAAAAAAcMq1AAAAAACCQ3YAAAAAAI7d7QAAAAAAoFauAAAAAACs8SUAAAAAAL5+/gAAAAAAzaddAAAAAADckjYAAAAAAOksrQAAAAAA+pBWAAAAAAEHKs0AAAAAAcrdVgAAAAAB2fCdAAAAAAHpL9YAAAAAAfguBQAAAAACBy32AAAAAAIWLCUAAAAAAiUsFgAAAAACNL3tAAAAAAJGS8YAAAAAAlK8DQAAAAACY3b2AAAAAAJwui0AAAAAAoC3PgAAAAACjiSlAAAAAAKeS+YAAAAAAqy2bQAAAAACu7ZeAAAAAALKtI0AAAAAAtm0fgAAAAAC54tdAAAAAAL4RkYAAAAAAwWKXgAAAAADFkRmAAAAAAMkHCYAAAAAAzRChgAAAAADQhpGAAAAAANSQKYAAAAAA2AYZgAAAAADd6k2AAAAAAN+qi4AAAAAA44nzgAAAAADnTv2AAAAAAOsJe4AAAAAA7s6FgAAAAADyjkmAAAAAAPZODYAAAAAA+g3RgAAAAAD+YT2AAAAAAQGNWYAAAAABBbvbgAAAAAEJMcuAAAAAAQzxj4AAAAABELFTgAAAAAEVBL+AAAAAARgw24AAAAABHIRHgAAAAAEfsGOAAAAAASQouYAAAAABJy/rgAAAAAErqEGAAAAAAS6vc4AAAAABMyfJgAAAAAE2U+WAAAAAATqnUYAAAAABPdNtgAAAAAFKzXlAAAAAAUzSfYAAAAABUUrTgAAAAAFUUgWAAAAAAVjKW4AAAAABW/Z3gAAAAAFgSeOAAAAAAWN1/4AAAAABZ8lrgAAAAAFq9YeAAAAAAW9I84AAAAABcnUPgAAAAAF2yHuAAAAAAXn0l4AAAAABfmztgAAAAAGBdB+AAAAAAYXsdYAAAAABiF//gAAAAAGNa/2ACAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQMAACGwAAAAACowAQQAABwgAAkAACowAA1MTVQARUVTVABFRVQAKzAzAAo8KzAzPi0zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAABwAAABT/////qhkdnP////+1o4zAAAAAABUnGzAAAAAAFhhPoAAAAAAXCE6wAAAAABf5kTAAAAAAGOmQQAAAAAAZ2sSwAAAAABrMFUAAAAAAG7wiYAAAAAAcrBNgAAAAAB2cBGAAAAAAHov1YAAAAAAfe+ZgAAAAACBr12AAAAAAIVvIYAAAAAAiS7lgAAAAACM7qmAAAAAAJCubYAAAAAAlG4xgAAAAACYLfWAAAAAAJwSo4AAAAAAn9JngAAAAACjkmPAAAAAAKXhA8AAAAAAp1HvgAAAAACrEbOAAAAAAK7Rd4AAAAAAspE7gAAAAAC2UP+AAAAAALoQw4AAAAAAvdCHgAAAAADBkEuAAAAAAMV0+YAAAAAAychlgAAAAADM9IGAAAAAANFH7YAAAAAA1HQJgAAAAADYx3WAAAAAANvzkYAAAAAA4GvngAAAAADjcxmAAAAAAOfrb4AAAAAA6vKhgAAAAADvaveAAAAAAPKXE4AAAAAA9up/gAAAAAD6FpuAAAAAAP5qB4AAAAABAZYjgAAAAAEGDnmAAAAAAQkVq4AAAAABDY4BgAAAAAEQlTOAAAAAARUNiYAAAAABGBS7gAAAAAEcjRGAAAAAAR+5LYAAAAABJAyZgAAAAAEnOLWAAAAAASuMIYAAAAABLrg9gAAAAAEzMMvAAAAAATY3/cAEDAgMEAQQBBAEEAQQBBAEEAQQBBAEFBgEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEFBgEAAKZkAAAAAKjAAAQAAMTgAQgAALbQAAwAALbQAQwAAKjAAQQAAJqwABBMTVQAKzEyACsxNAArMTMAKzExAAo8KzEyPi0xMgo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAyAAAABgAAABD/////qhmU4P////+1o/1AAAAAABYYzjAAAAAAFwixIAAAAAAX+fOgAAAAABjp8rAAAAAAGdsnIAAAAAAazHewAAAAABu8hNAAAAAAHKx10AAAAAAdnGbQAAAAAB6MV9AAAAAAH3xI0AAAAAAgbDnQAAAAACFcKtAAAAAAIkwb0AAAAAAjPAzQAAAAACQr/dAAAAAAJRvu0AAAAAAmC9/QAAAAACcFC1AAAAAAJ/T8UAAAAAAo5PtgAAAAACl4o2AAAAAAKdTeUAAAAAAqxM9QAAAAACu0wFAAAAAALKSxUAAAAAAtlKJQAAAAAC6Ek1AAAAAAL3SSYAAAAAAwZINgAAAAADFdruAAAAAAMnKJ4AAAAAAzPZDgAAAAADRSa+AAAAAANR1y4AAAAAA2Mk3gAAAAADb9VOAAAAAAOBtqYAAAAAA43TbgAAAAADn7TGAAAAAAOr0Y4AAAAAA72y5gAAAAADymNWAAAAAAPbsQYAAAAAA+hhdgAAAAAD+a8mAAAAAAQGX5YAAAAABBhA7gAQIDBAIEAgQCBAIEAgQCBAIEAgQCBQECBAIEAgQBBQEFAQUBBQEFAQUBBQEFAQUBBQIAAC8gAAAAADhAAAQAAEZQAAgAAFRgAAwAAFRgAQwAAEZQAQhMTVQAKzA0ACswNQArMDYACjwrMDU+LTUK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzAAAABgAAABD/////qhmOaP////+1o/1AAAAAABUni7AAAAAAFhjAIAAAAAAXCLEgAAAAABf586AAAAAAGOnysAAAAAAZ2ycgAAAAABrMd7AAAAAAG7yE0AAAAAAcrHXQAAAAAB2cZtAAAAAAHoxX0AAAAAAffEjQAAAAACBsOdAAAAAAIVwq0AAAAAAiTBvQAAAAACM8DNAAAAAAJCv90AAAAAAlG+7QAAAAACYL39AAAAAAJwULUAAAAAAn9PxQAAAAACjk+2AAAAAAKXijYAAAAAAp1N5QAAAAACrEz1AAAAAAK7TAUAAAAAAspLFQAAAAAC2UolAAAAAALoSTUAAAAAAvdIRQAAAAADBkdVAAAAAAMV2g0AAAAAAycnvQAAAAADM9gtAAAAAANFJd0AAAAAA1HWTQAAAAADYyP9AAAAAANv1G0AAAAAA4G1xQAAAAADjdKNAAAAAAOfs+UAAAAAA6vQrQAAAAADvbIFAAAAAAPKYnUAAAAAA9uwJQAAAAAD6GCVAAAAAAP5rkUAAAAABAZetQAAAAAEGEANABAgMEAwIDAgMCAwIDAgMCAwIDAgMCBQECAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIAADWYAAAAADhAAAQAAEZQAAgAAFRgAQwAAFRgAAwAAEZQAQhMTVQAKzA0ACswNQArMDYACjwrMDU+LTUK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZAAAABQAAABD/////qhmNRP////+1o/1AAAAAABUni7AAAAAAFhjAIAAAAAAXCL8wAAAAABf586AAAAAAGOnysAAAAAAZ2ycgAAAAABrMd7AAAAAAG7yE0AAAAAAcrHXQAAAAAB2cZtAAAAAAHoxX0AAAAAAffEjQAAAAACBsOdAAAAAAIVwq0AAAAAAiTBvQAAAAACM8DNAAAAAAJCv90AAAAAAlG+7QAAAAACYL39AAAAAAJwULUAAAAAAn9PxQAAAAACjk+2AAAAAAKXijYAEDAgMCAwIDAgMCAwIDAgMCAwIDAgMEAQMAADa8AAAAADhAAAQAAFRgAQgAAEZQAAwAAEZQAQxMTVQAKzA0ACswNgArMDUACjwrMDU+LTUK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAyAAAABwAAABT/////qhmTUP////+1pAtQAAAAABYYzjAAAAAAFwixIAAAAAAX+fOgAAAAABjp8rAAAAAAGdsnIAAAAAAazHewAAAAABu8hNAAAAAAHKx10AAAAAAdnGbQAAAAAB6MV9AAAAAAH3xI0AAAAAAgbDnQAAAAACFcKtAAAAAAIkwb0AAAAAAjPAzQAAAAACQr/dAAAAAAJRvu0AAAAAAmC9/QAAAAACcFC1AAAAAAJ/T8UAAAAAAo5PtgAAAAACl4o2AAAAAAKdTeUAAAAAAqxM9QAAAAACu0wFAAAAAALKSxUAAAAAAtlKJQAAAAAC6Ek1AAAAAAL3SEUAAAAAAwZHVQAAAAADFdoNAAAAAAMnJ70AAAAAAzPYLQAAAAADRSXdAAAAAANR1k0AAAAAA2Mj/QAAAAADb9RtAAAAAAOBtqYAAAAAA43TbgAAAAADn7TGAAAAAAOr0Y4AAAAAA72y5gAAAAADymNWAAAAAAPbsQYAAAAAA+hhdgAAAAAD+a8mAAAAAAQGX5YAAAAABBhA7gAQIDBAIEAgQCBAIEAgQCBAIEAgQCBQYCBAIEAgQCBAIEAgQCBAIFBgUGBQYFBgUGBQIAADCwAAAAACowAAQAAEZQAAgAAFRgAAwAAFRgAQwAAEZQAQgAADhAABBMTVQAKzAzACswNQArMDYAKzA0AAo8KzA1Pi01Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2AAAABAAAABD/////aYax3P////+eMDzgAAAAABcwaFAAAAAAF/oPwAAAAAAY6L1QAAAAABnbQ0AAAAAAGsyT0AAAAAAbvchAAAAAABytx1AAAAAAHZx04AAAAAAejGXgAAAAAB98VuAAAAAAIGxH4AAAAAAhXDjgAAAAACJMKeAAAAAAIzwa4AAAAAAkLAvgAAAAACUb/OAAAAAAJgvt4AAAAAAnBRlgAAAAACf2eAAAAAAAKOe6gAAAAAAp2P0AAAAAACrKP4AAAAAAK7owgAAAAAAsq3MAAAAAAC2bZAAAAAAALoymgAAAAAAvfJeAAAAAADBt2gAAAAAAMV8cgAAAAAAyUF8AAAAAADNAUAAAAAAANDGSgAAAAAA1IYOAAAAAADYSxgAAAAAANwK3AAAAAAA38/mAAAAAADjlPAAAAAAAOdZ+gAAAAAA6xm+AAAAAADu3sgAAAAAAPKejAAAAAAA9mOWAAAAAAD6I1oAAAAAAP3oZAAAAAABAa1uAAAAAAEFcngAAAAAAQkyPAAAAAABDPdGAAAAAAEQtwoAAAAAARR8FAAAAAABGDvYAAAAAAEcAOIABAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIAACmkAAAAACmgAAQAACowAAgAADhAAQxMTVQAQk1UACswMwArMDQACjwrMDM+LTMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAwAAAAz/////ofKdMAAAAAAEipLAAQIAADBQAAAAADhAAAQAACowAAhMTVQAKzA0ACswMwAKPCswMz4tMwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABCAAAABQAAABD/////qhmVRP/////n2gxQAAAAABUnmcAAAAAAFhjOMAAAAAAXCM1AAAAAABf6AbAAAAAAGOoAwAAAAAAZ2zUwAAAAABrMhcAAAAAAG7yS4AAAAAAcrIPgAAAAAB2cdOAAAAAAHoxl4AAAAAAffFbgAAAAACBsR+AAAAAAIVw44AAAAAAiTCngAAAAACM8GuAAAAAAJCwL4AAAAAAlG/zgAAAAACYL7eAAAAAAJwUZYAAAAAAn9QpgAAAAACjlCXAAAAAAKdT6cAAAAAAqxOtwAAAAADFd2RAAAAAAMnK0EAAAAAAzPa0AAAAAADRSiAAAAAAANR2PAAAAAAA2MmoAAAAAADb9cQAAAAAAOBuGgAAAAAA43VMAAAAAADn7aIAAAAAAOr01AAAAAAA720qAAAAAADymUYAAAAAAPbssgAAAAAA+hjOAAAAAAD+bDoAAAAAAQGYVgAAAAABBhCsAAAAAAEJF94AAAAAAQ2QNAAAAAABEJdmAAAAAAEVD7wAAAAAARgW7gAAAAABHI9EAAAAAAEfu2AAAAAAASQOzAAAAAABJzroAAAAAAErjlQAAAAAAS66cAAAAAABMzLGAAAAAAE2OfgAAAAAATqyTgAAAAABPbmAAAAAAAFCMdYAAAAAAUVd8gAAAAABSbFeAAAAAAFM3XoAAAAAAVEw5gAAAAABVF0CAAAAAAFYsG4ABAwIDAgMCAwIDAgMCAwIDAgMCAwIDBAEEAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMAAC68AAAAACowAAQAAEZQAQgAADhAAAwAADhAAQxMTVQAKzAzACswNQArMDQACjwrMDQ+LTQK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAwAAAAz/////VraFxP////+iamfEAQIAAF48AAAAAF48AAQAAGJwAAhMTVQAQk1UACswNwAKPCswNz4tNwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABDAAAABQAAABD/////odV9/P////+1o+EgAAAAABUnb5AAAAAAFhikAAAAAAAXCKMQAAAAABf514AAAAAAGOnWkAAAAAAZ2wsAAAAAABrMW5AAAAAAG7xosAAAAAAcrFmwAAAAAB2cSrAAAAAAHow7sAAAAAAffCywAAAAACBsHbAAAAAAIVwOsAAAAAAiS/+wAAAAACM78LAAAAAAJCvhsAAAAAAlG9KwAAAAACYLw7AAAAAAJwTvMAAAAAAn9OAwAAAAACjk30AAAAAAKXiHQAAAAAAp1MIwAAAAACrEszAAAAAAK7SkMAAAAAAspJUwAAAAAC2UhjAAAAAALoR3MAAAAAAvdGgwAAAAAC/HTIAAAAAAMGRnQAAAAAAxXZLAAAAAADJybcAAAAAAMz10wAAAAAA0Uk/AAAAAADUdVsAAAAAANjIxwAAAAAA2/TjAAAAAADgbTkAAAAAAON0awAAAAAA5+zBAAAAAADq8/MAAAAAAO9sSQAAAAAA8phlAAAAAAD269EAAAAAAPoX7QAAAAAA/mtZAAAAAAEBl3UAAAAAAQYPywAAAAABCRb9AAAAAAENj1MAAAAAARCWhQAAAAABFQ7bAAAAAAEYFg0AAAAAARyOYwAAAAABH7p/AAAAAAEkDesAAAAAASc6BwAAAAABK41zAAAAAAEuuY8AAAAAATMx5QAAAAABNjkXAAAAAAFRL8zAAAAAAVvbqQAEDAgMCAwIDAgMCAwIDAgMCAwIDAgMEAQMCAwIDAgMCBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEDAQMAAE6EAAAAAFRgAAQAAHCAAQgAAGJwAAwAAGJwAQxMTVQAKzA2ACswOAArMDcACjwrMDc+LTcK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAwAAAA3/////VrbCuP////+iZWPg/////6N7glD/////pE6AYP////+lP7TQ/////6YlJ+D/////pyd/0P////+oKfPg/////6jrslD/////6CqF4P/////o9C1Q/////+oLuWD/////6tVg0P/////r7Ozg/////+y2lFD/////7c9x4P/////umRlQ/////++wpWD/////8HpM0AAAAAAEpl5gAAAAAAUrd9AAAAAABkMD4AAAAAAHDKtQAAAAAAgkN2AAAAAACO3e0AAAAAAKBWrgAAAAAArPElAAAAAAC+fv4AAAAAAMsZdQAAAAAA3JI2AAAAAADpLK0AAAAAAPqQVgAAAAABByrNAAAAAAGvQu4AAAAAAb0ZzQAAAAABzVYmAAAAAAHbLQUAAAAAAetpXgAAAAAB+UA9AAAAAAIJfJYAAAAAAhdTdQAAAAACKjLOAAAAAAI1e8UAAAAAAkZ19gAAAAACU479AAAAAAJjy1YAAAAAAnGiNQAAAAACgd6OAAAAAAKPtW0AAAAAAqAG3gAAAAACrOCdAAAAAAK7TOYAAAAAAspLFQAAAAAC2UsGAAAAAALoSTUAAAAAAvdJJgAAAAADBkdVAAAAAAMV2u4AAAAAAyTZHQAAAAADM9kOAAAAAANC1z0AAAAAA1HXLgAAAAADYNVdAAAAAANv1U4AIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgEAACFIAAAAACowAQQAABwgAAlMTVQARUVTVABFRVQACkVFVC0yRUVTVCxNMy41LjAvMCxNMTAuNS4wLzAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0AAAABQAAABD/////qhl+EP////+1o+8wAAAAABUnfaAAAAAAFhiyEAAAAAAXCLEgAAAAABf55ZAAAAAAGOnkoAAAAAAZ2xkQAAAAABrMaaAAAAAAG7x2wAAAAAAcrGfAAAAAAB2cWMAAAAAAHoxJwAAAAAAffDrAAAAAACBsK8AAAAAAIVwcwAAAAAAiTA3AAAAAACM7/sAAAAAAJCvvwAAAAAAlG+DAAAAAACYL0cAAAAAAJwT9QAAAAAAn9O5AAAAAACi+o8AAAAAAKec3MAAAAAAqxKUgAAAAACvHGTAAAAAALKSHIAAAAAAtpvswAAAAAC6EaSAAAAAAL4bdMAAAAAAwZEsgAAAAADFmvzAAAAAAMk1noAAAAAAzPYnYAAAAADRSVsgAAAAANR1r2AAAAAA2MjjIAAAAADb9TdgAAAAAOBtVSAAAAAA43S/YAAAAADn7N0gAAAAAOr0R2AAAAAA72xlIAAAAADymLlgAAAAAPbr7SAAAAAA+hhBYAAAAAD+a3UgAAAAAQGXyWAAAAABBg/nIAAAAAEJF1FgAAAAAQvuSIAEDAgMCAwIDAgMCAwIDAgMCAwIDAgMEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAMAAEXwAAAAAEZQAAQAAGJwAQgAAFRgAAwAAFRgAQxMTVQAKzA1ACswNwArMDYACjwrMDY+LTYK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASAAAABQAAABj/////rYoGkP////+6Z0eI/////797J4D/////v/MbUP/////BXayA/////8HVoFD/////wz7gAP/////DttPQ/////8UgE4D/////xZgHUP/////HAUcA/////8d5OtD/////yOPMAP/////JW7/Q/////8rE/4D/////yzzzUP/////LkVgA/////9JIbfABAwIDAgMCAwIDAgMCAwIDBAMAAGdwAAAAAGl4AAQAAHUwAQoAAHCAABAAAH6QABRMTVQAKzA3MzAAKzA4MjAAKzA4ACswOQAKPCswOD4tOAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAAABQAAABb/////JroYKP////9D5+sw/////4edvLr/////ytuMKP/////MBXEY/////8yVMqj/////0nQSmAECAwQDBAMAAFLYAAAAAFLQAAQAAEtGAAgAAE1YAAwAAFtoARBMTVQASE1UAE1NVABJU1QAKzA2MzAACklTVC01OjMwCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABCAAAABgAAABD/////odv5oP////+1o8UAAAAAABUnU3AAAAAAFhiH4AAAAAAXCIbwAAAAABf5u2AAAAAAGOm6cAAAAAAZ2u7gAAAAABrMP3AAAAAAG7xMkAAAAAAcrD2QAAAAAB2cLpAAAAAAHowfkAAAAAAffBCQAAAAACBsAZAAAAAAIVvykAAAAAAiS+OQAAAAACM71JAAAAAAJCvFkAAAAAAlG7aQAAAAACYLp5AAAAAAJwTTEAAAAAAn9MQQAAAAACjkwyAAAAAAKXhrIAAAAAAp1KYQAAAAACrElxAAAAAAK7SIEAAAAAAspHkQAAAAAC2UahAAAAAALoRbEAAAAAAvdEwQAAAAADBkPRAAAAAAMV1okAAAAAAyckOQAAAAADM9SpAAAAAANFIlkAAAAAA1HSyQAAAAADYyB5AAAAAANv0OkAAAAAA4GyQQAAAAADjc8JAAAAAAOfsGEAAAAAA6vNKQAAAAADva6BAAAAAAPKXvEAAAAAA9usoQAAAAAD6F0RAAAAAAP5qsEAAAAABAZbMQAAAAAEGDyJAAAAAAQkWVEAAAAABDY6qQAAAAAEQldxAAAAAARUOMkAAAAABGBVkQAAAAAEcjbpAAAAAAR+51kAAAAABJA1CQAAAAAEnOV5AAAAAASuMykAAAAABLrjmQAAAAAEzMTxAAAAAATY4bkAAAAABUS8kAAAAAAFb2ziABAwIDAgMCAwIDAgMCAwIDAgMCAwIDBAEDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMFAQMAAGpgAAAAAHCAAAQAAIygAQgAAH6QAAwAAH6QAQwAAIygAAhMTVQAKzA4ACsxMAArMDkACjwrMDk+LTkK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAyAAAABAAAABD/////htPuTAAAAAAPC9yQAAAAABjpyIAAAAAAGdr88AAAAAAazE2AAAAAABu8MHAAAAAAHKwvgAAAAAAdnBJwAAAAAB6MEYAAAAAAH3v0cAAAAAAga/OAAAAAACFb1nAAAAAAIkvVgAAAAAAjO7hwAAAAACQrt4AAAAAAJRuacAAAAAAmC5mAAAAAACcEtvAAAAAAJ/S2AAAAAAAo5JjwAAAAACnUmAAAAAAAKsR68AAAAAArtHoAAAAAACykXPAAAAAALZRcAAAAAAAuhD7wAAAAAC90PgAAAAAAMGQg8AAAAAAxXVqAAAAAADJNPXAAAAAAMz08gAAAAAA0LR9wAAAAADUdHoAAAAAANg0BcAAAAAA66bOgAAAAADu0rJAAAAAAPKSroAAAAAA9lI6QAAAAAD6EjaAAAAAAP3RwkAAAAABAZG+gAAAAAEFUUpAAAAAAQkRRoAAAAABDNDSQAAAAAEQkM6AAAAAARR1REAAAAABVFZqgAAAAAFYFYXAAAAAAVvV8oAAAAABX5UNwAQMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMAAGQ0AAAAAGJwAAQAAH6QAQgAAHCAAAxMTVQAKzA3ACswOQArMDgACjwrMDg+LTgK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdAAAAAwAAAAz/////fjZDKf////+gl6KA/////6F5BPD/////yFlegP/////JCflw/////8nTvQD/////ywWK8P/////LfEAA/////9I7PvD/////04t7gP/////UQq3w/////9VFIgD/////1ky/8P/////XPL8A/////9gGZnD/////2R3ygP/////ZQXzwAAAAAB66UiAAAAAAH2mbkAAAAAAgfoSgAAAAACFJfZAAAAAAImehIAAAAAAjKV+QAAAAACRHgyAAAAAAJRJ8EAAAAAAmJ2UgAAAAACbyXhAAAAAAKAdHIAAAAAAo0kAQAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIAAHHXAAAAAH6QAQQAAHCAAAhMTVQAQ0RUAENTVAAKQ1NULTgK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAABwAAABj/////VraZJP////+Hnb0c/////8taHCj/////zJUroP/////SdYA4AAAAADGmACgAAAAAMnEAIAAAAABEP+ooAQIDBAIFBgIAAErcAAAAAErkAAQAAE1YAAgAAFRgAQ4AAFtoARIAAFtoABIAAFRgAA5MTVQATU1UACswNTMwACswNgArMDYzMAAKPCswNTMwPi01OjMwCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAAABgAAABz/////aYaGvP/////K24aw/////8wFcRj/////zJUyqP/////dqNKYAAAAAEo7xBAAAAAASzzYkAECAwIEBQQAAFTEAAAAAFLQAAQAAFtoAAgAAE1YAA4AAFRgABQAAGJwARhMTVQASE1UACswNjMwACswNTMwACswNgArMDcACjwrMDY+LTYK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB5AAAABAAAABH/////ofKreP////+igS+A/////6NenXD/////pGERgP////+lPn9w/////6ZA84D/////px5hcP////+oINWA/////6kHffD/////8Y9SAP/////yW5xw//////NzKID/////9Dt+cP/////1Va2A//////YfVPD/////9zbhAP/////3/zbw//////kO2gD/////+eG78P/////6+UgA//////vC73D//////NvNAP/////9pXRw//////69AID//////4an8AAAAAAAnjQAAAAAAAFn23AAAAAAAn9ngAAAAAADSQ7wAAAAAARh7IAAAAAABSuT8AAAAAAGQyAAAAAAAAcMx3AAAAAACCRTgAAAAAAI7frwAAAAAAoFhwAAAAAACs8ucAAAAAAL6AwAAAAAAAyxs3AAAAAADck/gAAAAAAOa1nwAAAAAA+qcwAAAAAAEEyNcAAAAAAY9MUAAAAAABnbbXAAAAAAGtdKAAAAAAAbvfJwAAAAAB5VIwAAAAAAH4rlcAAAAAAgR3oAAAAAACGJGfAAAAAAIjx0AAAAAAAja57wAAAAACQyv4AAAAAAJSVFcAAAAAAmFUSAAAAAACcFJ3AAAAAAJ/Zb4AAAAAAo55BQAAAAACniG2AAAAAAKsoVUAAAAAArsitgAAAAACyjX9AAAAAALZtH4AAAAAAujHxQAAAAAC98e2AAAAAAMG2v0AAAAAAxXwBgAAAAADJQNNAAAAAAMz7iYAAAAAA0MWhQAAAAADUexGAAAAAANhKb0AAAAAA3AprgAAAAADfzz1AAAAAAOOUf4AAAAAA51lRQAAAAADrGU2AAAAAAO7eH0AAAAAA8p4bgAAAAAD2Yu1AAAAAAPoi6YAAAAAA/ee7QAAAAAEBrP2AAAAAAQVxz0AAAAABCTHLgAAAAAEM9p1AAAAAARC2mYAAAAABFEv1QAAAAAEYMNuAAAAAARyo+UAAAAABH9VNgAAAAAEkLcdAAAAAAScv64AAAAABK6gJQAAAAAEu1F2AAAAAATMnkUAAAAABNlPlgAAAAAE6pxlAAAAAAT3TbYAAAAABQiahQAAAAAFFUvWAAAAAAUmmKUAAAAABTNJ9gAAAAAFRSptAAAAAAVRSBYAAAAABWMojQAAAAAFb0Y2AAAAAAWBJq0AAAAABY3X/gAAAAAFnyTNAAAAAAWr1h4AAAAABb0i7QAAAAAFydQ+AAAAAAXbIQ0AAAAABefSXgAAAAAF+bLVAAAAAAYF0H4AAAAABhew9QAAAAAGI86eAAAAAAY1rxUAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQMAACIIAAAAACowAQQAABwgAAkAACowAA1MTVQARUVTVABFRVQAKzAzAAo8KzAzPi0zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAwAAAAz/////kuYeAP/////LmTLwAAAAAAvqMHAAAAAAOcOZAAECAQIAAHW8AAAAAHCAAAQAAH6QAAhMTVQAKzA4ACswOQAKPCswOT4tOQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAgAAAAj/////ofKZqAEAADPYAAAAADhAAARMTVQAKzA0AAo8KzA0Pi00Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYAAAABQAAABD/////qhmDgP////+1o+8wAAAAABUnfaAAAAAAFhiyEAAAAAAXCLEgAAAAABf55ZAAAAAAGOnkoAAAAAAZ2xkQAAAAABrMaaAAAAAAG7x2wAAAAAAcrGfAAAAAAB2cWMAAAAAAHoxJwAAAAAAffDrAAAAAACBsK8AAAAAAIVwcwAAAAAAiTA3AAAAAACM7/sAAAAAAJCvvwAAAAAAlG+DAAAAAACYL0cAAAAAAJwT9QAAAAAAn9O5AAAAAACjKj1ABAwIDAgMCAwIDAgMCAwIDAgMCAwIDBAEAAECAAAAAAEZQAAQAAGJwAQgAAFRgAAwAAFRgAQxMTVQAKzA1ACswNwArMDYACjwrMDU+LTUK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABWAAAABAAAABH/////pXceLAAAAAAJ7a/gAAAAAArdktAAAAAAC/pk4AAAAAAMvsZQAAAAAA2kOWAAAAAADorh0AAAAAAPhBtgAAAAABB1T9AAAAAAEWP9YAAAAAASU+BQAAAAABNNGeAAAAAAFDPCUAAAAAAVI8FgAAAAABYTpFAAAAAAFwOjYAAAAAAX84ZQAAAAABjjhWAAAAAAGdNoUAAAAAAaw2dgAAAAABu8hNAAAAAAHKyD4AAAAAAdnGbQAAAAAB6MZeAAAAAAH3xI0AAAAAAgbEfgAAAAACFcKtAAAAAAIkwp4AAAAAAjPAzQAAAAACQsC+AAAAAAJRvu0AAAAAAmC+3gAAAAACcFC1AAAAAAJ/UKYAAAAAAo5O1QAAAAACnU7GAAAAAAKsTPUAAAAAArtM5gAAAAACyksVAAAAAALZSwYAAAAAAuhJNQAAAAAC90kmAAAAAAMGR1UAAAAAAxXa7gAAAAADJNkdAAAAAAMz2Q4AAAAAA0LXPQAAAAADUdcuAAAAAANjJ4EAAAAAA2/X8QAAAAADgblJAAAAAAON1hEAAAAAA5+3aQAAAAADq9QxAAAAAAO9tYkAAAAAA8pl+QAAAAAD27OpAAAAAAPoZBkAAAAAA/mxyQAAAAAEBmI5AAAAAAQYQ5EAAAAABCRgWQAAAAAENkGxAAAAAARCXnkAAAAABFQ/0QAAAAAEYFyZAAAAAARyPfEAAAAABH7uYQAAAAAEkDwRAAAAAASc7IEAAAAABK46MQAAAAAEuuqhAAAAAATMy/kAAAAABNjowQAAAAAE6soZAAAAAAT25uEAAAAABQjIOQAAAAAFFXipAAAAAAUmxlkAAAAABTN2yQAAAAAFRMR5AAAAAAVRdOkAAAAABWLCmQAAAAAFb3MJAAAAAAV9B/0AAAAABZ9SgQAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAwIAAB/UAAAAACowAQQAABwgAAkAACowAA1MTVQARUVTVABFRVQAKzAzAApFRVQtMkVFU1QsTTMuNS4wLzMsTTEwLjUuMC80Cg==",
    "VFppZjMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE0AAAABQAAABX/////fb1KsP/////IWc8A/////8j6pgD/////yTicgP/////M5euA/////82s/gD/////zscfAP/////Pj4MA/////9CppAD/////0YR9AP/////SiteA/////9NlsID/////1GwLAP/////oNmNg/////+j0LVD/////6gu5YP/////q1WDQ/////+vs+vD/////7LVtAP/////tz3/w/////+6X8gD/////77CzcP/////weSWA//////GR5vD/////8lpZAP/////zcxpw//////Q7jID/////9VWfcP/////2HhGA//////c20vD/////9/9FAP/////5GAZw//////nhygD/////+vk58P/////7J0JQAAAAAAh8i+AAAAAACP2w0AAAAAAJ9upgAAAAAAqmM9AAAAAAE+n8YAAAAAAUIVtgAAAAABr6xmAAAAAAG45uYAAAAAAcvvjgAAAAAB13fNAAAAAAHsz/YAAAAAAfYJlQAAAAACCCsWAAAAAAIUm10AAAAAAiXp7gAAAAACMgXVAAAAAAJFowYAAAAAAlAD9QAAAAACYL7eAAAAAAJtbm0AAAAAAn68/gAAAAACjAA1AAAAAAKdTsYAAAAAAqqR/QAAAAACu7ZeAAAAAALIkB0AAAAAAtm0fgAAAAAC5fqVAAAAAAL3sp4AAAAAAwSMXQAAAAADDnB+AAAAAAMWRGYAAAAAAyQcJgAAAAADNEKGAAAAAANCGkYAAAAAA1JApgAAAAADYBhmAAAAAANxZhYAAAAAA4BkRQAAAAADj/feAAAAAAOe9g0AAAAAA631/gAAAAADvPQtAAAAAAPL9B4AAAAAA9ryTQAAAAAD6fI+AAAAAAP48G0AAAAABAfwXgAAAAAEFcgeAAAAAAQl7n4AAAAABDQbfwAAAAAEQtpmAAAAAARRL9UAAAAABGDtngAAAAAEbob3AAAAAAR+wY4AAAAABItxHQAAAAAEnL+uAAAAAASqA8YAAAAABLrS6cAAAAAExhvdAAAAAATZT5nAAAAABONcJQAAAAAE9022AAAAAAUFuR4AAAAABRVL1gAAAAAFJEoFAAAAAAUzSfYAAAAABUSWxQAAAAAFUV0uAAAAAAVilcYAAAAABW9cLwAAAAAFgTymAAAAAAWNWk8AAAAABZ86xgAAAAAFq1hvAAAAAAW9OOYAAAAABcnUPgAAAAAF2zYlAAAAAAXn53YAAAAABfk1JgAAAAAGBeWWAAAAAAYXsdYAAAAABiP4zgAAAAAGNcXvAAAAAAZExeAAAAAABlPEDwAAAAAGYjBYAAAAAAZxwi8AAAAABn+a0AAAAAAGj8BPAAAAAAaccaAAAAAABq2+bwAAAAAGum/AAAAAAAbMUDcAAAAABtht4AAAAAAG6k5XAAAAAAb2bAAAAAAABwhMdwAAAAAHFP3IAAAAAAcmSpcAAAAABzL76AAAAAAHREi3AAAAAAdQ+ggAAAAAB2LafwAAAAAHbvgoAAAAAAeA2J8AAAAAB4z2SAAAAAAHnta/AAAAAAeq9GgAAAAAB7zU3wAAAAAHyYYwAAAAAAfaP1cAAAAAB+eEUAAAAAAH96nPAAAAAAgFgnAAAAAACBSAnwAAAAAII4CQAAAAAAgx6xcAAAAACEF+sAAAAAAITsHnAAAAAAhSzGAAAAAACFNfJwAAAAAIYBB4AAAAAAhsLF8AAAAACG+jMAAAAAAIcV1HAAAAAAh+DpgAAAAACImW1wAAAAAIjQ2oAAAAAAiPW2cAAAAACJwMuAAAAAAIpm2nAAAAAAiqeCAAAAAACK1ZhwAAAAAIugrYAAAAAAjD2B8AAAAACMdO8AAAAAAIy+tPAAAAAAjYCPgAAAAACOFClwAAAAAI5LloAAAAAAjp6W8AAAAACPYHGAAAAAAI/hlnAAAAAAkCI+AAAAAACQfnjwAAAAAJFJjgAAAAAAkbg98AAAAACR76sAAAAAAJJeWvAAAAAAkylwAAAAAACTharwAAAAAJPGUoAAAAAAlD488AAAAACVCVIAAAAAAJVcUnAAAAAAlZO/gAAAAACWJ1lwAAAAAJbpNAAAAAAAlzL58AAAAACXamcAAAAAAJgHO3AAAAAAmMkWAAAAAACZAGbwAAAAAJlBDoAAAAAAmecdcAAAAACasjKAAAAAAJrXDnAAAAAAmw57gAAAAACbxv9wAAAAAJySFIAAAAAAnKR7cAAAAACc5SMAAAAAAJ2m4XAAAAAAnnH2gAAAAACeeyLwAAAAAJ67yoAAAAAAn4bDcAAAAACgiTeAAAAAAKFv3/AAAAAAol/fAAAAAACjT8HwAAAAAKQtTAAAAAAApS+j8AAAAACmA/OAAAAAAKcPhfAAAAAAp9qbAAAAAACo72fwAAAAAKm6fQAAAAAAqtiEcAAAAACrml8AAAAAAKy4ZnAAAAAArXpBAAAAAACumEhwAAAAAK9aIwAAAAAAsHgqcAAAAACxQz+AAAAAALJYDHAAAAAAsyMhgAAAAAC0N+5wAAAAALUDA4AAAAAAtiEK8AAAAAC24uWAAAAAALgA7PAAAAAAuMLHgAAAAAC515RwAAAAALqr5AAAAAAAu6478AAAAAC8i8YAAAAAAL2E43AAAAAAvmuoAAAAAAC/UlBwAAAAAMBLigAAAAAAwSj38AAAAADBYGUAAAAAAMFpkXAAAAAAwitsAAAAAADC/59wAAAAAMM3DIAAAAAAw0lzcAAAAADEC04AAAAAAMTNDHAAAAAAxQ20AAAAAADFKVVwAAAAAMX0aoAAAAAAxqOz8AAAAADG2yEAAAAAAMcJN3AAAAAAx9RMgAAAAADIcSDwAAAAAMixyIAAAAAAyOkZcAAAAADJtC6AAAAAAMpHyHAAAAAAyohwAAAAAADK0jXwAAAAAMuUEIAAAAAAzB5v8AAAAADMVd0AAAAAAMyyF/AAAAAAzXPygAAAAADN69zwAAAAAM4shIAAAAAAzpH58AAAAADPXQ8AAAAAAM/ChHAAAAAAz/nxgAAAAADQcdvwAAAAANE88QAAAAAA0Zkr8AAAAADR0JkAAAAAANJRvfAAAAAA0xzTAAAAAADTZpjwAAAAANOnQIAAAAAA1DGf8AAAAADU/LUAAAAAANU9QHAAAAAA1XStgAAAAADWGrxwAAAAANbclwAAAAAA1wqtcAAAAADXS1UAAAAAANf6nnAAAAAA2Lx5AAAAAADY4VTwAAAAANkh/IAAAAAA2dqAcAAAAADapZWAAAAAANq3/HAAAAAA2u9pgAAAAADbumJwAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQCAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIAACBQAAAAACowAQQAABwgAAkAACowAQ0AABwgABFMTVQARUVTVABFRVQASURUAElTVAAKRUVULTJFRVNULE0zLjQuNC81MCxNMTAuNC40LzUwCg==",
    "VFppZjMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2AAAABQAAABX/////fb1KGf/////IWc8A/////8j6pgD/////yTicgP/////M5euA/////82s/gD/////zscfAP/////Pj4MA/////9CppAD/////0YR9AP/////SiteA/////9NlsID/////1GwLAP/////oNmNg/////+j0LVD/////6gu5YP/////q1WDQ/////+vs+vD/////7LVtAP/////tz3/w/////+6X8gD/////77CzcP/////weSWA//////GR5vD/////8lpZAP/////zcxpw//////Q7jID/////9VWfcP/////2HhGA//////c20vD/////9/9FAP/////5GAZw//////nhygD/////+vk58P/////7J0JQAAAAAAh8i+AAAAAACP2w0AAAAAAJ9upgAAAAAAqmM9AAAAAAE+n8YAAAAAAUIVtgAAAAABr6xmAAAAAAG45uYAAAAAAcvvjgAAAAAB13fNAAAAAAHsz/YAAAAAAfYJlQAAAAACCCsWAAAAAAIUm10AAAAAAiXp7gAAAAACMgXVAAAAAAJFowYAAAAAAlAD9QAAAAACYL7eAAAAAAJtbm0AAAAAAn68/gAAAAACjAA1AAAAAAKdTsYAAAAAAqqR/QAAAAACu7ZeAAAAAALIkB0AAAAAAtm0fgAAAAAC5fqVAAAAAAL3sp4AAAAAAwSMXQAAAAADDnB+AAAAAAMWRGYAAAAAAyQcJgAAAAADNEKGAAAAAANCGkYAAAAAA1JApgAAAAADYBhmAAAAAANxZhYAAAAAA4BkRQAAAAADj/feAAAAAAOe9g0AAAAAA631/gAAAAADvPQtAAAAAAPL9B4AAAAAA9ryTQAAAAAD6fI+AAAAAAP48G0AAAAABAfwXgAAAAAEFcgeAAAAAAQl7n4AAAAABDQbfwAAAAAEQtpmAAAAAARRL9UAAAAABGDtngAAAAAEbob3AAAAAAR+wY4AAAAABIuwZQAAAAAEnL+uAAAAAASqA8YAAAAABLq9zgAAAAAExhvdAAAAAATZT5nAAAAABONcJQAAAAAE5cC+AAAAAAToTcUAAAAABPdNtgAAAAAFBbkeAAAAAAUVS9YAAAAABSRKBQAAAAAFM0n2AAAAAAVElsUAAAAABVFdLgAAAAAFYpXGAAAAAAVvXC8AAAAABYE8pgAAAAAFjVpPAAAAAAWfOsYAAAAABatYbwAAAAAFvTjmAAAAAAXJ1D4AAAAABds2JQAAAAAF5+d2AAAAAAX5NSYAAAAABgXllgAAAAAGF7HWAAAAAAYj+M4AAAAABjXF7wAAAAAGRMXgAAAAAAZTxA8AAAAABmIwWAAAAAAGccIvAAAAAAZ/mtAAAAAABo/ATwAAAAAGnHGgAAAAAAatvm8AAAAABrpvwAAAAAAGzFA3AAAAAAbYbeAAAAAABupOVwAAAAAG9mwAAAAAAAcITHcAAAAABxT9yAAAAAAHJkqXAAAAAAcy++gAAAAAB0RItwAAAAAHUPoIAAAAAAdi2n8AAAAAB274KAAAAAAHgNifAAAAAAeM9kgAAAAAB57WvwAAAAAHqvRoAAAAAAe81N8AAAAAB8mGMAAAAAAH2j9XAAAAAAfnhFAAAAAAB/epzwAAAAAIBYJwAAAAAAgUgJ8AAAAACCOAkAAAAAAIMesXAAAAAAhBfrAAAAAACE7B5wAAAAAIUsxgAAAAAAhTXycAAAAACGAQeAAAAAAIbCxfAAAAAAhvozAAAAAACHFdRwAAAAAIfg6YAAAAAAiJltcAAAAACI0NqAAAAAAIj1tnAAAAAAicDLgAAAAACKZtpwAAAAAIqnggAAAAAAitWYcAAAAACLoK2AAAAAAIw9gfAAAAAAjHTvAAAAAACMvrTwAAAAAI2Aj4AAAAAAjhQpcAAAAACOS5aAAAAAAI6elvAAAAAAj2BxgAAAAACP4ZZwAAAAAJAiPgAAAAAAkH548AAAAACRSY4AAAAAAJG4PfAAAAAAke+rAAAAAACSXlrwAAAAAJMpcAAAAAAAk4Wq8AAAAACTxlKAAAAAAJQ+PPAAAAAAlQlSAAAAAACVXFJwAAAAAJWTv4AAAAAAlidZcAAAAACW6TQAAAAAAJcy+fAAAAAAl2pnAAAAAACYBztwAAAAAJjJFgAAAAAAmQBm8AAAAACZQQ6AAAAAAJnnHXAAAAAAmrIygAAAAACa1w5wAAAAAJsOe4AAAAAAm8b/cAAAAACckhSAAAAAAJyke3AAAAAAnOUjAAAAAACdpuFwAAAAAJ5x9oAAAAAAnnsi8AAAAACeu8qAAAAAAJ+Gw3AAAAAAoIk3gAAAAAChb9/wAAAAAKJf3wAAAAAAo0/B8AAAAACkLUwAAAAAAKUvo/AAAAAApgPzgAAAAACnD4XwAAAAAKfamwAAAAAAqO9n8AAAAACpun0AAAAAAKrYhHAAAAAAq5pfAAAAAACsuGZwAAAAAK16QQAAAAAArphIcAAAAACvWiMAAAAAALB4KnAAAAAAsUM/gAAAAACyWAxwAAAAALMjIYAAAAAAtDfucAAAAAC1AwOAAAAAALYhCvAAAAAAtuLlgAAAAAC4AOzwAAAAALjCx4AAAAAAudeUcAAAAAC6q+QAAAAAALuuO/AAAAAAvIvGAAAAAAC9hONwAAAAAL5rqAAAAAAAv1JQcAAAAADAS4oAAAAAAMEo9/AAAAAAwWBlAAAAAADBaZFwAAAAAMIrbAAAAAAAwv+fcAAAAADDNwyAAAAAAMNJc3AAAAAAxAtOAAAAAADEzQxwAAAAAMUNtAAAAAAAxSlVcAAAAADF9GqAAAAAAMajs/AAAAAAxtshAAAAAADHCTdwAAAAAMfUTIAAAAAAyHEg8AAAAADIsciAAAAAAMjpGXAAAAAAybQugAAAAADKR8hwAAAAAMqIcAAAAAAAytI18AAAAADLlBCAAAAAAMweb/AAAAAAzFXdAAAAAADMshfwAAAAAM1z8oAAAAAAzevc8AAAAADOLISAAAAAAM6R+fAAAAAAz10PAAAAAADPwoRwAAAAAM/58YAAAAAA0HHb8AAAAADRPPEAAAAAANGZK/AAAAAA0dCZAAAAAADSUb3wAAAAANMc0wAAAAAA02aY8AAAAADTp0CAAAAAANQxn/AAAAAA1Py1AAAAAADVPUBwAAAAANV0rYAAAAAA1hq8cAAAAADW3JcAAAAAANcKrXAAAAAA10tVAAAAAADX+p5wAAAAANi8eQAAAAAA2OFU8AAAAADZIfyAAAAAANnagHAAAAAA2qWVgAAAAADat/xwAAAAANrvaYAAAAAA27picAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgEEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIAACDnAAAAACowAQQAABwgAAkAACowAQ0AABwgABFMTVQARUVTVABFRVQASURUAElTVAAKRUVULTJFRVNULE0zLjQuNC81MCxNMTAuNC40LzUwCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJAAAABQAAABH/////iIxDiv////+RoysK/////8015oD/////0VnOcP/////SOz7w/////9UyuxD/////5LbykP/////tL5gAAAAAAAo9xwABAgMEAgMCAwIAAGP2AAEAAGP2AAAAAGJwAAUAAHCAAAkAAH6QAA1QTE1UACswNwArMDgAKzA5AAo8KzA3Pi03Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABFAAAABQAAABb/////hWljkP/////KTTEw/////8rbkzD/////y0txeP/////SoN6Q/////9Nr14D/////1JNYuP/////VQrA4/////9ZzOrj/////1z5BuP/////YLjK4/////9j5Obj/////2g4UuP/////a2Ru4/////9vt9rj/////3Lj9uP/////dzdi4/////96iGjj/////37b1OP/////ggfw4/////+GWySj/////4k9pOP/////jdqso/////+QvSzj/////5V/HqP/////mDy04/////+c/qaj/////5/hJuP/////pH4uo/////+nYK7j/////6v9tqP/////ruA24/////+zfT6j/////7ZfvuP/////uyGwo/////+930bj/////8KhOKP/////xV7O4//////KIMCj/////80DQOP/////0aBIo//////Ugsjj/////9kf0KP/////3JX44//////gVYSj/////+QVgOP/////59UMo//////rlQjj/////+95fqP/////8zl64//////2+Qaj//////q5AuP//////niOoAAAAAACOIrgAAAAAAX4FqAAAAAACbgS4AAAAAANd56gAAAAABE3muAAAAAAFRwQoAAAAAAY3AzgAAAAABybmKAAAAAAHgz04AAAAAAkGyCgAAAAACfbHOAAAAAAK5qooAAAAAAvWqTgAAAAADMaMKAAAAAARmzk4AAAAABJvbKgBAgMEAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgEAAGsKAAAAAHCAAAQAAH6QAQgAAHeIAQ0AAH6QABJMTVQASEtUAEhLU1QASEtXVABKU1QACkhLVC04Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAyAAAABAAAABD/////htP8lAAAAAAPC+qgAAAAABjp1pAAAAAAGdsLAAAAAAAazFuQAAAAABu8PoAAAAAAHKw9kAAAAAAdnCCAAAAAAB6MH5AAAAAAH3wCgAAAAAAgbAGQAAAAACFb5IAAAAAAIkvjkAAAAAAjO8aAAAAAACQrxZAAAAAAJRuogAAAAAAmC6eQAAAAACcExQAAAAAAJ/TEEAAAAAAo5KcAAAAAACnUphAAAAAAKsSJAAAAAAArtIgQAAAAACykawAAAAAALZRqEAAAAAAuhE0AAAAAAC90TBAAAAAAMGQvAAAAAAAxXWiQAAAAADJNS4AAAAAAMz1KkAAAAAA0LS2AAAAAADUdLJAAAAAANg0PgAAAAAA66cGwAAAAADu0uqAAAAAAPKS5sAAAAAA9lJygAAAAAD6Em7AAAAAAP3R+oAAAAABAZH2wAAAAAEFUYKAAAAAAQkRfsAAAAABDNEKgAAAAAEQkQbAAAAAARR1fIAAAAABVFaiwAAAAAFYFb4AAAAAAVvWKsAAAAABX5VGAAQMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMAAFXsAAAAAFRgAAQAAHCAAQgAAGJwAAxMTVQAKzA2ACswOAArMDcACjwrMDc+LTcK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABCAAAABwAAABT/////VraCP/////+iEg+//////7Wj0xAAAAAAFSdhgAAAAAAWGJXwAAAAABcIlQAAAAAAF/nJcAAAAAAY6ciAAAAAABna/PAAAAAAGsxNgAAAAAAbvFqgAAAAABysS6AAAAAAHZw8oAAAAAAejC2gAAAAAB98HqAAAAAAIGwPoAAAAAAhXACgAAAAACJL8aAAAAAAIzvioAAAAAAkK9OgAAAAACUbxKAAAAAAJgu1oAAAAAAnBOEgAAAAACf00iAAAAAAKOTRMAAAAAApeHkwAAAAACnUtCAAAAAAKsSlIAAAAAArtJYgAAAAACykhyAAAAAALZR4IAAAAAAuhGkgAAAAAC90WiAAAAAAMGRLIAAAAAAxXXagAAAAADJyUaAAAAAAMz1YoAAAAAA0UjOgAAAAADUdOqAAAAAANjIVoAAAAAA2/RygAAAAADgbMiAAAAAAONz+oAAAAAA5+xQgAAAAADq84KAAAAAAO9r2IAAAAAA8pf0gAAAAAD262CAAAAAAPoXfIAAAAAA/mrogAAAAAEBlwSAAAAAAQYPWoAAAAABCRaMgAAAAAENjuKAAAAAARCWFIAAAAABFQ5qgAAAAAEYFZyAAAAAARyN8oAAAAABH7oOgAAAAAEkDXqAAAAAASc5loAAAAABK40CgAAAAAEuuR6AAAAAATMxdIAAAAABNjimgAAAAAFRL1xABAgQDBAMEAwQDBAMEAwQDBAMEAwQDBAUCBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEBgQAAGHBAAAAAGHBAAQAAGJwAAgAAH6QAQwAAHCAABAAAHCAARAAAH6QAAxMTVQASU1UACswNwArMDkAKzA4AAo8KzA4Pi04Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABzAAAABgAAABn/////VrbI2P////+Qi/WY/////5sMF2D/////m9W+0P////+iZWPg/////6N7glD/////pE6AYP////+lP7TQ/////6YlJ+D/////pyd/0P////+qKChg/////6rh/dD/////q/mJ4P////+swzFQ/////8iBP+D/////yQETUP/////JSvVg/////8rOgFD/////y8uuYP/////SawlQ/////9OiOWD/////1EMCUP/////VTA3g/////9Ype9D/////1yvv4P/////YCV3Q/////9kCl2D/////2ek/0P/////a67Pg/////9vSXFD/////3NTQYP/////dsj5Q//////H0uWD/////9GLvUP/////1aAZg//////YfONAAAAAABm6TcAAAAAAHOZpwAAAAAAf7dQAAAAAACRl8cAAAAAAJ0MsAAAAAAAr5XnAAAAAAC7H+gAAAAAAM2UBwAAAAAA2kVYAAAAAADqatcAAAAAAPhDeAAAAAAA/4EVAAAAAAGYmwcAAAAAAZ3LDgAAAAABvm0PAAAAAAHMbv8AAAAAAdmzFwAAAAAB6Mc/AAAAAAH3xk8AAAAAAgbFXwAAAAACFcRvAAAAAAIkw38AAAAAAjPCjwAAAAACQsGfAAAAAAJRwK8AAAAAAmC/vwAAAAACcFJ3AAAAAAJ/UYcAAAAAAo5QlwAAAAACnU+nAAAAAAKsTrcAAAAAArtNxwAAAAACykzXAAAAAALYuD8AAAAAAuhK9wAAAAAC90oHAAAAAAMGSRcAAAAAAxXbzwAAAAADJyl/AAAAAAMz2e8AAAAAA0UnnwAAAAADUdgPAAAAAANjJb8AAAAAA2/WLwAAAAADgbeHAAAAAAON1E8AAAAAA5+1pwAAAAADq9JvAAAAAAO9s8cAAAAAA8pkNwAAAAAD27HnAAAAAAPoYlcAAAAAA/mwBwAAAAAEBmB3AAAAAAQYQc8AAAAABCRelwAAAAAENj/vAAAAAARCXLcAAAAABFQ+DwAAAAAEYFyZAAAAAARyPfEAAAAABH7uYQAAAAAEkDwRAAAAAASc7IEAAAAABK46MQAAAAAEuuqhAAAAAATMy/kAAAAABNj92QAAAAAE6soZAAAAAAT25uEAAAAABQjIOQAAAAAFFXipAAAAAAUmxlkAAAAABTOL4QAAAAAFRMR5AAAAAAVRdOkAAAAABWPp6QAAAAAFb3MJAAAAAAV88uUAEDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCBAUEAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgQAABsoAAAAABtoAAQAACowAQgAABwgAA0AACowABEAADhAARVMTVQASU1UAEVFU1QARUVUACswMwArMDQACjwrMDM+LTMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAABwAAACD/////P2ZJYP////+peIXg/////7oW3mD/////y7+DiP/////SVu5w/////9c8xgj/////2v8mAP/////0tb6IAQIDBAMFAwYAAGQgAAAAAGQgAAQAAGcgAAgAAGl4AA4AAH6QABQAAHCAABgAAGJwABxMTVQAQk1UACswNzIwACswNzMwACswOQArMDgAV0lCAApXSUItNwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAAAABAAAABL/////uhbBmP/////QWLnw//////S1omgBAgMAAIPoAAAAAH6QAAQAAIWYAAgAAH6QAA5MTVQAKzA5ACswOTMwAFdJVAAKV0lULTkK",
    "VFppZjMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABkAAAABQAAABX/////VrbC+v////+eMEWI/////8hZzwD/////yPqmAP/////JOJyA/////8zl64D/////zaz+AP/////Oxx8A/////8+PgwD/////0KmkAP/////RhH0A/////9KK14D/////02WwgP/////UbAsA/////9daMID/////199YAP/////YL8OA/////9keYwD/////2hD3AP/////a69AA/////9u0NAD/////3Lk9AP/////d4I0A/////960zoD/////36S/gP/////gi3YA/////+FWfQD/////4r5mgP/////jNl8A/////+SeSID/////5RZBAP/////mdPAA/////+cR0oD/////6CatgP/////o6HoAAAAAAAh8i+AAAAAACP2w0AAAAAAJ9upgAAAAAAqmM9AAAAAAE+n8YAAAAAAUIVtgAAAAABr6xmAAAAAAG45uYAAAAAAcvvjgAAAAAB13fNAAAAAAHsz/YAAAAAAfYJlQAAAAACCCsWAAAAAAIUm10AAAAAAiXp7gAAAAACMgXVAAAAAAJFowYAAAAAAlAD9QAAAAACYL7eAAAAAAJtbm0AAAAAAn68/gAAAAACjAA1AAAAAAKdTsYAAAAAAqqR/QAAAAACu7ZeAAAAAALIkB0AAAAAAtm0fgAAAAAC5fqVAAAAAAL3sp4AAAAAAwSMXQAAAAADFIluAAAAAAMjxuUAAAAAAzMbNgAAAAADQa/tAAAAAANRGVYAAAAAA18aZQAAAAADcECIAAAAAAN88BcAAAAAA49l+AAAAAADnc+eAAAAAAOtDtcAAAAAA7rltgAAAAADyjoHAAAAAAPaCyYAAAAAA+g4JwAAAAAD98n+AAAAAAQHM2cAAAAABBUKRgAAAAAEJMjwAAAAAAQ0hPcAAAAABELHEAAAAAAEUe9vAAAAAARgxTAAAAAABG7GPwAAAAAEfsNQAAAAAASOf1cAAAAABJzBcAAAAAAEq+nPAAAAAAS6v5AAAAAABMjAnwAAAAAE2VFYAAAAAAToebcAAAAABPdPeAAAAAAFBeQvAAAAAAUVTZgAEDAgMCAwIDAgMCAwIDBAIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIAACEGAAAAACD4AAQAACowAQgAABwgAAwAADhAARBMTVQASk1UAElEVABJU1QASUREVAAKSVNULTJJRFQsTTMuNC40LzI2LE0xMC41LjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAwAAAA7/////aYaaoP/////Q+ddAAQIAAEDgAAAAADhAAAQAAD9IAAhMTVQAKzA0ACswNDMwAAo8KzA0MzA+LTQ6MzAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAABQAAABD/////p1KWxP////+1o5rQAAAAABUnKUAAAAAAFhhdsAAAAAAXCFzAAAAAABf5kTAAAAAAGOmQQAAAAAAZ2sSwAAAAABrMFUAAAAAAG7wiYAAAAAAcrBNgAAAAAB2cBGAAAAAAHov1YAAAAAAfe+ZgAAAAACBr12AAAAAAIVvIYAAAAAAiS7lgAAAAACM7qmAAAAAAJCubYAAAAAAlG4xgAAAAACYLfWAAAAAAJwSo4AAAAAAn9JngAAAAACjkmPAAAAAAKXhA8AAAAAAp1HvgAAAAACrEbOAAAAAAK7Rd4AAAAAAspE7gAAAAAC2UP+AAAAAALoQw4AAAAAAvdCHgAAAAADBkEuAAAAAAMV0+YAAAAAAychlgAAAAADM9IGAAAAAANFH7YAAAAAA1HQJgAAAAADYx3WAAAAAANvzkYAAAAAA4GvngAAAAADjcxmAAAAAAOfrb4AAAAAA6vKhgAAAAADvaveAAAAAAPKXE4AAAAAA9up/gAAAAAD6FpuAAAAAAP5qB4AAAAABAZYjgAAAAAEGDnmAAAAAAQkVq4AAAAABDY4BgAAAAAEQlTOAAAAAARUNiYAAAAABGBS7gAAAAAEcjRGAAAAAAR+5LYAAAAABJAyZgAAAAAEnOLWAAAAAASuMIYAAAAABLrg9gAAAAAEzMMvAAAAAATY3/cAEDAgMCAwIDAgMCAwIDAgMCAwIDAgMEAQMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMEAQMAAJS8AAAAAJqwAAQAALbQAQgAAKjAAAwAAKjAAQxMTVQAKzExACsxMwArMTIACjwrMTI+LTEyCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALAAAABgAAAB3/////iX78pP/////MlTKo/////9J0Epj/////3ajgqAAAAAACT6swAAAAADyvRbAAAAAAPZ8ooAAAAABIQaAwAAAAAEkLR6AAAAAASeTdMAAAAABK7HsgAQIBAwUEBQQFBAUAAD7cAAAAAE1YAAQAAFtoAQoAAEZQABAAAFRgARQAAEZQABlMTVQAKzA1MzAAKzA2MzAAKzA1AFBLU1QAUEtUAApQS1QtNQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAgAAAAj/////sP66ZAEAAFIcAAAAAFRgAARMTVQAKzA2AAo8KzA2Pi02Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAwAAABD/////ofJ9hAAAAAAeGDCoAQIAAE/8AAAAAE1YAAQAAFDcAApMTVQAKzA1MzAAKzA1NDUACjwrMDU0NT4tNTo0NQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABDAAAACAAAABT/////odvk6/////+1o8UAAAAAABUnU3AAAAAAFhiH4AAAAAAXCIbwAAAAABf5u2AAAAAAGOm6cAAAAAAZ2u7gAAAAABrMP3AAAAAAG7xMkAAAAAAcrD2QAAAAAB2cLpAAAAAAHowfkAAAAAAffBCQAAAAACBsAZAAAAAAIVvykAAAAAAiS+OQAAAAACM71JAAAAAAJCvFkAAAAAAlG7aQAAAAACYLp5AAAAAAJwTTEAAAAAAn9MQQAAAAACjkwyAAAAAAKXhrIAAAAAAp1KYQAAAAACrElxAAAAAAK7SIEAAAAAAspHkQAAAAAC2UahAAAAAALoRbEAAAAAAvdEwQAAAAADBkPRAAAAAAMV1okAAAAAAyckOQAAAAADM9SpAAAAAANFIlkAAAAAA1HSyQAAAAADYyB5AAAAAANv0OkAAAAAA4GyQQAAAAADjc8JAAAAAAOfsGEAAAAAA6vNKQAAAAADva6BAAAAAAPKXvEAAAAAA9usoQAAAAAD6F0RAAAAAAP5qsEAAAAAA/8uRwAAAAAEBlpQAAAAAAQYO6gAAAAABCRYcAAAAAAENjnIAAAAAARCVpAAAAAABFQ36AAAAAAEYFSwAAAAAARyNggAAAAABH7meAAAAAAEkDQoAAAAAASc5JgAAAAABK4ySAAAAAAEuuK4AAAAAATMxBAAAAAABNjg2AAAAAAE5uAlAAAAAAVEvJAAEDAgMCAwIDAgMCAwIDAgMCAwIDAgMEAQMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMGBQYFBgUGBQYFBgUGBQYHBgMAAH8VAAAAAHCAAAQAAIygAQgAAH6QAAwAAH6QAQwAAJqwARAAAIygAAgAAJqwABBMTVQAKzA4ACsxMAArMDkAKzExAAo8KzA5Pi05Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBAAAABgAAABD/////ofkN8v////+1o+EgAAAAABUnb5AAAAAAFhikAAAAAAAXCKMQAAAAABf514AAAAAAGOnWkAAAAAAZ2wsAAAAAABrMW5AAAAAAG7xosAAAAAAcrFmwAAAAAB2cSrAAAAAAHow7sAAAAAAffCywAAAAACBsHbAAAAAAIVwOsAAAAAAiS/+wAAAAACM78LAAAAAAJCvhsAAAAAAlG9KwAAAAACYLw7AAAAAAJwTvMAAAAAAn9OAwAAAAACjk30AAAAAAKXiHQAAAAAAp1MIwAAAAACrEszAAAAAAK7SkMAAAAAAspJUwAAAAAC2UhjAAAAAALoR3MAAAAAAvdGgwAAAAADBkWTAAAAAAMV2EsAAAAAAycl+wAAAAADM9ZrAAAAAANFJBsAAAAAA1HUiwAAAAADYyI7AAAAAANv0qsAAAAAA4G0AwAAAAADjdDLAAAAAAOfsiMAAAAAA6vO6wAAAAADvbBDAAAAAAPKYLMAAAAAA9uuYwAAAAAD6F7TAAAAAAP5rIMAAAAABAZc8wAAAAAEGD5LAAAAAAQkWxMAAAAABDY8awAAAAAEQlkzAAAAAARUOosAAAAABGBXUwAAAAAEcjirAAAAAAR+6RsAAAAABJA2ywAAAAAEnOc7AAAAAASuNOsAAAAABLrlWwAAAAAEzMazAAAAAATY43sAAAAABUS+UgAQMCAwIDAgMCAwIDAgMCAwIDAgMCAwQBAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDBQMAAFcOAAAAAFRgAAQAAHCAAQgAAGJwAAwAAGJwAQwAAHCAAAhMTVQAKzA2ACswOAArMDcACjwrMDc+LTcK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAACAAAACD/////fjZTo/////+Gg4Wj/////7pnTpD/////wArkYP/////Ks+Vg/////8uRXwj/////0kht8AAAAAAWke4AAQIDBAUGBQcAAGFdAAAAAGFdAAQAAGJwAAgAAGcgAQwAAGcgAAwAAGl4ABIAAH6QABgAAHCAABxMTVQAU01UACswNwArMDcyMAArMDczMAArMDkAKzA4AAo8KzA4Pi04Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABHAAAABQAAABT/////hWlbjv/////LR3Xw/////8vyyuD/////zPu6UP/////N0/5g/////86dpdD/////0mF6cP/////TePhw/////9RCrfD/////1UurcP/////WdEzw/////9c/U/D/////2C9E8P/////Y+Ppw/////9oN1XD/////2tjccP/////b7bdw/////9y4vnD/////3c7q8P/////eodrw/////9+2tfD/////4IG88P/////hlpfw/////+JPKfD/////43Z58P/////kLwvw/////+VflnD/////5g7t8P/////nP6mo/////+f4Sbj/////6R+LqP/////p2Cu4/////+r/baj/////67gNuP/////s30+o/////+2X77j/////7shsKP/////vd9G4//////CoTij/////8VezuP/////yiDAo//////NA0Dj/////9GgSKP/////1ILI4//////ZH9Cj/////9yV+OP/////4FVMY//////kFYDj/////+fU1GP/////65UI4//////veX6j//////M5euP/////9vkGo//////6uQLj//////54jqAAAAAAAjiK4AAAAAAF+BagAAAAAAm4EuAAAAAADXeeoAAAAAARN5rgAAAAABUcEKAAAAAAGNwM4AAAAAAcm5igAAAAAB4M9OAAAAAAJBsgoAAAAAAn2xzgAAAAACuaqKAAAAAAL1qk4AAAAAAzGjCgAAAAAEZs5OAAAAAASb2yoAQMCAwIDAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEAAGpyAAAAAHCAAAQAAIygAQgAAH6QAAwAAH6QARBMTVQAQ1NUACsxMAArMDkAQ0RUAApDU1QtOAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABCAAAABgAAABD/////qhk2oP////+1o6jgAAAAABUnN1AAAAAAFhhrwAAAAAAXCGrQAAAAABf5n0AAAAAAGOmeUAAAAAAZ2tLAAAAAABrMI1AAAAAAG7wwcAAAAAAcrCFwAAAAAB2cEnAAAAAAHowDcAAAAAAfe/RwAAAAACBr5XAAAAAAIVvWcAAAAAAiS8dwAAAAACM7uHAAAAAAJCupcAAAAAAlG5pwAAAAACYLi3AAAAAAJwS28AAAAAAn9KfwAAAAACjkpwAAAAAAKXhPAAAAAAAp1InwAAAAACrEevAAAAAAK7Rr8AAAAAAspFzwAAAAAC2UTfAAAAAALoQ+8AAAAAAvdC/wAAAAADBkIPAAAAAAMV1McAAAAAAycidwAAAAADM9LnAAAAAANFIJcAAAAAA1HRBwAAAAADYx63AAAAAANvzycAAAAAA4GwfwAAAAADjc1HAAAAAAOfrp8AAAAAA6vLZwAAAAADvay/AAAAAAPKXS8AAAAAA9uq3wAAAAAD6FtPAAAAAAP5qP8AAAAABAZZbwAAAAAEGDrHAAAAAAQkV48AAAAABDY45wAAAAAEQlWvAAAAAARUNwcAAAAABGBTzwAAAAAEcjUnAAAAAAR+5ZcAAAAABJAzRwAAAAAEnOO3AAAAAASuMWcAAAAABLrh1wAAAAAEzMMvAAAAAATY3/cAAAAABUS6zgAAAAAFcbnAABAwIDAgMCAwIDAgMCAwIDAgMCAwIDBAEDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMFAQMAAI1gAAAAAIygAAQAAKjAAQgAAJqwAAwAAJqwAQwAAKjAAAhMTVQAKzEwACsxMgArMTEACjwrMTE+LTExCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAABQAAABX/////ofJdkP////+6FtWQ/////8uIHYD/////0lbucAECAwQAAG/wAAAAAG/wAAQAAHCAAAgAAH6QAAwAAHCAABBMTVQATU1UACswOAArMDkAV0lUQQAKV0lUQS04Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAABQAAABD/////FOHcGP////97u3pA/////8Gc9ID/////wgEYcP/////LP5sA/////8uMA/D/////0UtN8P/////SseXw/////+JsOQD/////4rNb8AAAAAANm/wAAAAAAA6GmPAAAAAAJla/AAAAAAAmsahwAQMCAwIEAgMCAwIDAgP//x/oAAAAAHFoAAAAAH6QAQQAAHCAAAgAAH6QAAxMTVQAUERUAFBTVABKU1QAClBTVC04Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAxAAAAAwAAAA3/////pXceuAAAAAAJ7a/gAAAAAArdktAAAAAAC/pk4AAAAAAMvsZQAAAAAA2kOWAAAAAADorh0AAAAAAPhBtgAAAAABB1T9AAAAAAEWP9YAAAAAASU+BQAAAAABNNGeAAAAAAFDPCUAAAAAAVI8FgAAAAABYTpFAAAAAAFwOjYAAAAAAX84ZQAAAAABjjhWAAAAAAGdNoUAAAAAAaw2dgAAAAABu8hNAAAAAAHKyD4AAAAAAdnGbQAAAAAB6MZeAAAAAAH3xI0AAAAAAgbEfgAAAAACFcKtAAAAAAIkwp4AAAAAAjPAzQAAAAACQsC+AAAAAAJRvu0AAAAAAmC+3gAAAAACcFC1AAAAAAJ/UKYAAAAAAo5O1QAAAAACnU7GAAAAAAKsTPUAAAAAArtM5gAAAAACyksVAAAAAALZSwYAAAAAAuhJNQAAAAAC90kmAAAAAAMGR1UAAAAAAxXa7gAAAAADJNkdAAAAAAMz2Q4AAAAAA0LXPQAAAAADUdcuAAAAAANesO0AIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQEAAB9IAAAAACowAQQAABwgAAlMTVQARUVTVABFRVQACkVFVC0yRUVTVCxNMy41LjAvMyxNMTAuNS4wLzQK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAABQAAABD/////qhggwP////+1o+EgAAAAABUnb5AAAAAAFhikAAAAAAAXCKMQAAAAABf514AAAAAAGOnWkAAAAAAZ2wsAAAAAABrMW5AAAAAAG7xosAAAAAAcrFmwAAAAAB2cSrAAAAAAHow7sAAAAAAffCywAAAAACBsHbAAAAAAIVwOsAAAAAAiS/+wAAAAACM78LAAAAAAJCvhsAAAAAAlG9KwAAAAACYLw7AAAAAAJwTvMAAAAAAn9OAwAAAAACjk30AAAAAAKXiHQAAAAAAp1MIwAAAAACrEszAAAAAAK7SkMAAAAAAspJUwAAAAAC2UhjAAAAAALoR3MAAAAAAvdGgwAAAAADBkWTAAAAAAMV2EsAAAAAAycl+wAAAAADM9ZrAAAAAANFJBsAAAAAA1HUiwAAAAADYyI7AAAAAANv0qsAAAAAA4G0AwAAAAADjdDLAAAAAAOfsiMAAAAAA6vO6wAAAAADvbBDAAAAAAPKYLMAAAAAA9uuYwAAAAAD6F7TAAAAAAP5rIMAAAAABAZc8wAAAAAEGD5LAAAAAAQkWxMAAAAABDY8awAAAAAEQlkzAAAAAARUOosAAAAABGBXUwAAAAAEcjirAAAAAAR+6RsAAAAABJA2ywAAAAAEnOc7AAAAAASuNOsAAAAABLrlWwAAAAAEzMeUAAAAAATY5FwAEDAgMCAwIDAgMCAwIDAgMCAwIDAgMEAQMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMEAQMAAFHAAAAAAFRgAAQAAHCAAQgAAGJwAAwAAGJwAQxMTVQAKzA2ACswOAArMDcACjwrMDc+LTcK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABDAAAABQAAABD/////odsZJP////+1o+EgAAAAABUnb5AAAAAAFhikAAAAAAAXCKMQAAAAABf514AAAAAAGOnWkAAAAAAZ2wsAAAAAABrMW5AAAAAAG7xosAAAAAAcrFmwAAAAAB2cSrAAAAAAHow7sAAAAAAffCywAAAAACBsHbAAAAAAIVwOsAAAAAAiS/+wAAAAACM78LAAAAAAJCvhsAAAAAAlG9KwAAAAACYLw7AAAAAAJwTvMAAAAAAn9OAwAAAAACjk30AAAAAAKXiHQAAAAAAp1MIwAAAAACrEszAAAAAAK7SkMAAAAAAr/k4AAAAAACyko0AAAAAALZSUQAAAAAAuhIVAAAAAAC90dkAAAAAAMGRnQAAAAAAxXZLAAAAAADJybcAAAAAAMz10wAAAAAA0Uk/AAAAAADUdVsAAAAAANjIxwAAAAAA2/TjAAAAAADgbTkAAAAAAON0awAAAAAA5+zBAAAAAADq8/MAAAAAAO9sSQAAAAAA8phlAAAAAAD269EAAAAAAPoX7QAAAAAA/mtZAAAAAAEBl3UAAAAAAQYPywAAAAABCRb9AAAAAAENj1MAAAAAARCWhQAAAAABFQ7bAAAAAAEYFg0AAAAAARyOYwAAAAABH7p/AAAAAAEkDesAAAAAASc6BwAAAAABK41zAAAAAAEuuY8AAAAAATMx5QAAAAABNjkXAAAAAAFRL8zAAAAAAV5PMwAEDAgMCAwIDAgMCAwIDAgMCAwIDAgMEAQMCAwIEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEDAQMAAE28AAAAAFRgAAQAAHCAAQgAAGJwAAwAAGJwAQxMTVQAKzA2ACswOAArMDcACjwrMDc+LTcK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBAAAABgAAABD/////obNAtv////+1o+8wAAAAABUnfaAAAAAAFhiyEAAAAAAXCLEgAAAAABf55ZAAAAAAGOnkoAAAAAAZ2xkQAAAAABrMaaAAAAAAG7x2wAAAAAAcrGfAAAAAAB2cWMAAAAAAHoxJwAAAAAAffDrAAAAAACBsK8AAAAAAIVwcwAAAAAAiTA3AAAAAACM7/sAAAAAAJCvvwAAAAAAlG+DAAAAAACYL0cAAAAAAJwT9QAAAAAAn9O5AAAAAACjk7VAAAAAAKXiVUAAAAAAp1NBAAAAAACrEwUAAAAAAK7SyQAAAAAAspKNAAAAAAC2UlEAAAAAALoSFQAAAAAAvdHZAAAAAADBkZ0AAAAAAMV2SwAAAAAAycm3AAAAAADM9dMAAAAAANFJPwAAAAAA1HVbAAAAAADYyMcAAAAAANv04wAAAAAA4G05AAAAAADjdGsAAAAAAOfswQAAAAAA6vPzAAAAAADvbEkAAAAAAPKYZQAAAAAA9uvRAAAAAAD6F+0AAAAAAP5rWQAAAAABAZd1AAAAAAEGD8sAAAAAAQkW/QAAAAABDY9TAAAAAAEQloUAAAAAARUO2wAAAAABGBYNAAAAAAEcjmMAAAAAAR+6fwAAAAABJA3rAAAAAAEnOgcAAAAAASuNcwAAAAABLrmPAAAAAAEzMeUAAAAAATY5FwAAAAABUS/MwAQMCAwIDAgMCAwIDAgMCAwIDAgMCAwQBAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDBQMAAETKAAAAAEZQAAQAAGJwAQgAAFRgAAwAAFRgAQwAAGJwAAhMTVQAKzA1ACswNwArMDYACjwrMDY+LTYK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzAAAABwAAABT/////qhmT3P////+1pAtQAAAAABUni7AAAAAAFhjAIAAAAAAXCLEgAAAAABf586AAAAAAGOnysAAAAAAZ2ycgAAAAABrMd7AAAAAAG7yE0AAAAAAcrHXQAAAAAB2cZtAAAAAAHoxX0AAAAAAffEjQAAAAACBsOdAAAAAAIVwq0AAAAAAiTBvQAAAAACM8DNAAAAAAJCv90AAAAAAlG/zgAAAAACYL7eAAAAAAJwUZYAAAAAAn9QpgAAAAACjk+2AAAAAAKXijYAAAAAAp1N5QAAAAACrE3WAAAAAAK7TOYAAAAAAspL9gAAAAAC2UsGAAAAAALoShYAAAAAAvdJJgAAAAADBkg2AAAAAAMV2u4AAAAAAycongAAAAADM9kOAAAAAANFJr4AAAAAA1HXLgAAAAADYyTeAAAAAANv1U4AAAAAA4G2pgAAAAADjdNuAAAAAAOftMYAAAAAA6vRjgAAAAADvbLmAAAAAAPKY1YAAAAAA9uxBgAAAAAD6GF2AAAAAAP5ryYAAAAABAZflgAAAAAEGEDuABAgMEAwIDAgMCAwIDAgMCAwIFBgUGBQYCBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQIAADAkAAAAACowAAQAAEZQAAgAAFRgAQwAAFRgAAwAAEZQAQgAADhAABBMTVQAKzAzACswNQArMDYAKzA0AAo8KzA1Pi01Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAABwAAAB//////i/+OAP////+6Ft8A/////8t5pAj/////0lbucP/////XPMYI/////9r/JgD/////9LW+iAAAAAAh2nSAAQIDAgQCBQYAAGaAAAAAAGaAAAQAAGl4AAgAAH6QAA4AAHCAABIAAHCAABYAAGJwABtMTVQAUE1UACswNzMwACswOQArMDgAV0lUQQBXSUIACldJQi03Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAABAAAAAz/////i9fxnP////+S5hb4/////9IvYXAAAAAAVc4CcAAAAABa7HVwAQIDAQMAAHXkAAAAAHeIAAQAAH6QAAgAAH6QAARMTVQAS1NUAEpTVAAKS1NULTkK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0AAAABgAAABD/////qhmIXP////+1o/1AAAAAABUni7AAAAAAFhjAIAAAAAAXCLEgAAAAABf586AAAAAAGOnysAAAAAAZ2ycgAAAAABrMd7AAAAAAG7yE0AAAAAAcrHXQAAAAAB2cZtAAAAAAHoxX0AAAAAAffEjQAAAAACBsOdAAAAAAIVwq0AAAAAAiTBvQAAAAACM8DNAAAAAAJCv90AAAAAAlG+7QAAAAACYL39AAAAAAJwULUAAAAAAn9PxQAAAAACjk+2AAAAAAKXijYAAAAAAp1N5QAAAAACrEz1AAAAAAK7TAUAAAAAAspLFQAAAAAC2UolAAAAAALoSTUAAAAAAvdIRQAAAAADBkdVAAAAAAMV2g0AAAAAAycnvQAAAAADM9gtAAAAAANFJd0AAAAAA1HWTQAAAAADYyP9AAAAAANv1G0AAAAAA4G1xQAAAAADjdKNAAAAAAOfs+UAAAAAA6vQrQAAAAADvbIFAAAAAAPKYnUAAAAAA9uwJQAAAAAD6GCVAAAAAAP5rkUAAAAABAZetQAAAAAEGEANAAAAAAZeDGIAECAwQDAgMCAwIDAgMCAwIDAgMCAwIFAQIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDBAIAADukAAAAADhAAAQAAEZQAAgAAFRgAQwAAFRgAAwAAEZQAQhMTVQAKzA0ACswNQArMDYACjwrMDU+LTUK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0AAAABgAAABD/////qhmGoP////+1o/1AAAAAABUni7AAAAAAFhjAIAAAAAAXCLEgAAAAABf586AAAAAAGOnysAAAAAAZ2ycgAAAAABrMd7AAAAAAG7yE0AAAAAAcrHXQAAAAAB2cZtAAAAAAHoxX0AAAAAAffEjQAAAAACBsOdAAAAAAIVwq0AAAAAAiTBvQAAAAACM8DNAAAAAAJCv90AAAAAAlG+7QAAAAACYL39AAAAAAJwULUAAAAAAn9PxQAAAAACjk+2AAAAAAKXiVUAAAAAAp1NBAAAAAACrEz1AAAAAAK7TAUAAAAAAspLFQAAAAAC2UolAAAAAALoSTUAAAAAAvdIRQAAAAADBkdVAAAAAAMV2g0AAAAAAycnvQAAAAADM9gtAAAAAANFJd0AAAAAA1HWTQAAAAADYyP9AAAAAANv1G0AAAAAA4G1xQAAAAADjdKNAAAAAAOfs+UAAAAAA6vQrQAAAAADvbIFAAAAAAPKYnUAAAAAA9uwJQAAAAAD6GCVAAAAAAP5rkUAAAAABAZetQAAAAAEGEANAAAAAAXBvYoAECAwQDAgMCAwIDAgMCAwIDAgMCAwIFAgQDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDBAIAAD1gAAAAADhAAAQAAEZQAAgAAFRgAQwAAFRgAAwAAEZQAQhMTVQAKzA0ACswNQArMDYACjwrMDU+LTUK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAABAAAABL/////VraJ0f////+h8nNR/////8vy/Bj/////0Zpn8AECAwIAAFovAAAAAFovAAQAAFtoAAgAAH6QAA5MTVQAUk1UACswNjMwACswOQAKPCswNjMwPi02OjMwCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABCAAAABgAAABT/////hvDNuP/////SMLLwAAAAABUnN1AAAAAAFhhrwAAAAAAXCGrQAAAAABf5n0AAAAAAGOmeUAAAAAAZ2tLAAAAAABrMI1AAAAAAG7wwcAAAAAAcrCFwAAAAAB2cEnAAAAAAHowDcAAAAAAfe/RwAAAAACBr5XAAAAAAIVvWcAAAAAAiS8dwAAAAACM7uHAAAAAAJCupcAAAAAAlG5pwAAAAACYLi3AAAAAAJwS28AAAAAAn9KfwAAAAACjkpwAAAAAAKXhPAAAAAAAp1InwAAAAACrEevAAAAAAK7Rr8AAAAAAspFzwAAAAAC2UTfAAAAAALoQ+8AAAAAAvdC/wAAAAADBkIPAAAAAAMV1McAAAAAAycidwAAAAADM9LnAAAAAANFIXgAAAAAA1HR6AAAAAADYx+YAAAAAANv0AgAAAAAA4GxYAAAAAADjc4oAAAAAAOfr4AAAAAAA6vMSAAAAAADva2gAAAAAAPKXhAAAAAAA9urwAAAAAAD6FwwAAAAAAP5qeAAAAAABAZaUAAAAAAEGDuoAAAAAAQkWHAAAAAABDY5yAAAAAAEQlaQAAAAAARUN+gAAAAABGBUsAAAAAAEcjYIAAAAAAR+5ngAAAAABJA0KAAAAAAEnOSYAAAAAASuMkgAAAAABLriuAAAAAAEzMQQAAAAAATY4NgAAAAABUS7rwAAAAAFb2sgABAwIDAgMCAwIDAgMCAwIDAgMCAwIDBAUDAgMCAwIDAgMCAwQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUDBQMAAIXIAAAAAH6QAAQAAKjAAQgAAJqwAAwAAJqwAQwAAIygABBMTVQAKzA5ACsxMgArMTEAKzEwAAo8KzExPi0xMQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYAAAABQAAABD/////qhmFN/////+1o/1AAAAAABUni7AAAAAAFhjAIAAAAAAXCLEgAAAAABf586AAAAAAGOnysAAAAAAZ2ycgAAAAABrMd7AAAAAAG7yE0AAAAAAcrHXQAAAAAB2cZtAAAAAAHoxX0AAAAAAffEjQAAAAACBsOdAAAAAAIVwq0AAAAAAiTBvQAAAAACM8DNAAAAAAJCv90AAAAAAlG+7QAAAAACYL39AAAAAAJwULUAAAAAAn9PxQAAAAACjk7VABAgMEAwIDAgMCAwIDAgMCAwIDAgMCAwIAAD7JAAAAADhAAAQAAEZQAAgAAFRgAQwAAFRgAAxMTVQAKzA0ACswNQArMDYACjwrMDU+LTUK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdAAAABgAAABD/////i9fweP////+S5hb4/////9JDJ/D/////12WPcP/////X7p1g/////9j4+nD/////2c0t4P/////a14rw/////9utD+D/////3Obi8P/////djPHg/////+JPKfD/////5Gu3+P/////lExho/////+ZiA3j/////5xFM6P/////oL3B4/////+jn9Gj/////6g9SeP/////qx9Zo/////+vvNHj/////7Ke4aP/////tzxZ4/////+6Hmmj/////8DVxeAAAAAAgo2CQAAAAACFuZ5AAAAAAIoNCkAAAAAAjTkmQAQIEAwQDBAMEAwQBBQEFAQUBBQEFAQUBBAMEAwQAAHcIAAAAAHeIAAQAAH6QAAgAAIygAQwAAH6QAAQAAIWYAQxMTVQAS1NUAEpTVABLRFQACktTVC05Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBAAAABgAAABD/////qhkz5P////+1o6jgAAAAABUnN1AAAAAAFhhrwAAAAAAXCGrQAAAAABf5n0AAAAAAGOmeUAAAAAAZ2tLAAAAAABrMI1AAAAAAG7wwcAAAAAAcrCFwAAAAAB2cEnAAAAAAHowDcAAAAAAfe/RwAAAAACBr5XAAAAAAIVvWcAAAAAAiS8dwAAAAACM7uHAAAAAAJCupcAAAAAAlG5pwAAAAACYLi3AAAAAAJwS28AAAAAAn9KfwAAAAACjkpwAAAAAAKXhPAAAAAAAp1InwAAAAACrEevAAAAAAK7Rr8AAAAAAspFzwAAAAAC2UTfAAAAAALoQ+8AAAAAAvdC/wAAAAADBkIPAAAAAAMV1McAAAAAAycidwAAAAADM9LnAAAAAANFIJcAAAAAA1HRBwAAAAADYx63AAAAAANvzycAAAAAA4GwfwAAAAADjc1HAAAAAAOfrp8AAAAAA6vLZwAAAAADvay/AAAAAAPKXS8AAAAAA9uq3wAAAAAD6FtPAAAAAAP5qP8AAAAABAZZbwAAAAAEGDrHAAAAAAQkV48AAAAABDY45wAAAAAEQlWvAAAAAARUNwcAAAAABGBTzwAAAAAEcjUnAAAAAAR+5ZcAAAAABJAzRwAAAAAEnOO3AAAAAASuMWcAAAAABLrh1wAAAAAEzMMvAAAAAATY3/cAAAAABUS6zgAQMCAwIDAgMCAwIDAgMCAwIDAgMCAwQBAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDBQMAAJAcAAAAAIygAAQAAKjAAQgAAJqwAAwAAJqwAQwAAKjAAAhMTVQAKzEwACsxMgArMTEACjwrMTE+LTExCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAApAAAABAAAABD/////dM7wGP/////DVUmA/////9JUWYD/////04t7gP/////UQq3w/////9VFIgD/////1ky/8P/////XPL8A/////9gGZnD/////2R3ygP/////Z55nw/////9r/JgD/////28jNcP/////c4FmA/////92qAPD/////3nJzAP/////ftWRw/////+B8hQD/////4ZaX8P/////iXbiA/////+N3y3D/////5D7sAP/////lMCBw/////+YhcQD/////5xKlcP/////oAqSA/////+jz2PD/////6ePYAP/////q1Qxw/////+vFC4D/////7LY/8P/////t9/wA/////+6YxPD/////79kvgP/////wefhwAAAAAAf8VgAAAAAACO2KcAAAAAAJ3YmAAAAAAArOvfAAAAAAEduhgAAAAAASVN1wAQIBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEDAQMBAwEAAHHoAAAAAHCAAAQAAH6QAAgAAH6QAQxMTVQAQ1NUAEpTVABDRFQACkNTVC04Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYAAAABQAAABD/////qhmDCf////+1o+8wAAAAABUnfaAAAAAAFhiyEAAAAAAXCLEgAAAAABf55ZAAAAAAGOnkoAAAAAAZ2xkQAAAAABrMaaAAAAAAG7x2wAAAAAAcrGfAAAAAAB2cWMAAAAAAHoxJwAAAAAAffDrAAAAAACBsK8AAAAAAIVwcwAAAAAAiTA3AAAAAACM7/sAAAAAAJCvvwAAAAAAlG+DAAAAAACYL0cAAAAAAJwT9QAAAAAAn9O5AAAAAACjk7VABAwIDAgMCAwIDAgMCAwIDAgMCAwIDBAEAAED3AAAAAEZQAAQAAGJwAQgAAFRgAAwAAFRgAQxMTVQAKzA1ACswNwArMDYACjwrMDU+LTUK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzAAAABgAAABX/////Vra6Af////+qGZoB/////+faDFAAAAAAFSeZwAAAAAAWGM4wAAAAABcIzUAAAAAAF/oBsAAAAAAY6gDAAAAAABnbNTAAAAAAGsyFwAAAAAAbvJLgAAAAABysg+AAAAAAHZx04AAAAAAejGXgAAAAAB98VuAAAAAAIGxH4AAAAAAhXDjgAAAAACJMKeAAAAAAIzwa4AAAAAAkLAvgAAAAACUb/OAAAAAAJgvt4AAAAAAnBRlgAAAAACf1CmAAAAAAKOUJcAAAAAAp1N5QAAAAACrEwUAAAAAAK7TAUAAAAAAspKNAAAAAAC2UolAAAAAALoSFQAAAAAAvdHZAAAAAADBkWTAAAAAAMV2SwAAAAAA0UkGwAAAAADUdVsAAAAAANjIjsAAAAAA2/TjAAAAAADgbQDAAAAAAON0awAAAAAA5+yIwAAAAADq8/MAAAAAAO9sEMAAAAAA8phlAAAAAAD265jAAAAAAPoX7QAAAAAA/msgwAAAAAEBl3UAAAAAAQN3HsAAAAABBhBzwAAAAAEJF6XABAgQDBAMEAwQDBAMEAwQDBAMEAwQDBAUCBQIFAgUEAwQDBAMEAwQDBAMEAwQDBAMFAgQAACn/AAAAACn/AAQAACowAAkAAEZQAQ0AADhAABEAADhAARFMTVQAVEJNVAArMDMAKzA1ACswNAAKPCswND4tNAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABHAAAABgAAABz/////mmx9yP////+/AMxIAAAAAA2URDgAAAAADq0TuAAAAAAPeXNAAAAAABAoysAAAAAAEKn9wAAAAAARrGrIAAAAABJFSrgAAAAAEzfsyAAAAAAULRW4AAAAACggdsgAAAAAKNuduAAAAAApy5zIAAAAACq+IrgAAAAAK6zQSAAAAAAsn1Y4AAAAAC2OA8gAAAAALoCJuAAAAAAvbzdIAAAAADBhvTgAAAAAMVBqyAAAAAAyQvC4AAAAADMy78gAAAAANCV1uAAAAAA1FCNIAAAAADYGqTgAAAAANvVWyAAAAAA359y4AAAAADjWikgAAAAAOckQOAAAAAA6uQ9IAAAAADurlTgAAAAAPJpCyAAAAAA9jMi4AAAAAD57dkgAAAAAP238OAAAAABAXKnIAAAAAEFPL7gAAAAAQj8uyAAAAABDMbS4AAAAAEfiyUgAAAAASNVPOAAAAABJxU5IAAAAAEq31DgAAAAAS6aByAAAAABMmQe4AAAAAE2HtUgAAAAATno7OAAAAABPaOjIAAAAAFBbbrgAAAAAUUttyAAAAABSPfO4AAAAAFMsoUgAAAAAVB8nOAAAAABVDdTIAAAAAFYAWrgAAAAAVu8ISAAAAABX4Y44AAAAAFjRjUgAAAAAWcQTOAAAAABassDIAAAAAFulRrgAAAAAXJP0SAAAAABdhno4AAAAAF51J8gAAAAAX2etuAAAAABgV6zIAAAAAGFKMrgAAAAAYjjgSAAAAABjK2Y4AQMCBQQFAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMAADA4AAAAADA4AAQAAD9IAQgAADE4AA4AAEZQARQAADhAABhMTVQAVE1UACswNDMwACswMzMwACswNQArMDQACjwrMDMzMD4tMzozMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAwAAAA7/////1eYVdAAAAAAhYU2oAQIAAFQMAAAAAE1YAAQAAFRgAApMTVQAKzA1MzAAKzA2AAo8KzA2Pi02Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJAAAAAwAAAAz/////ZcKkcP/////XPgJw/////9ftWfD/////2Pj6cP/////ZzTvw/////9sHAPD/////260d8P/////c5uLw/////92M//ACAQIBAgECAQIAAIMDAAAAAIygAQQAAH6QAAhMTVQASkRUAEpTVAAKSlNULTkK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABDAAAABQAAABD/////oeVO2f////+1o+EgAAAAABUnb5AAAAAAFhikAAAAAAAXCKMQAAAAABf514AAAAAAGOnWkAAAAAAZ2wsAAAAAABrMW5AAAAAAG7xosAAAAAAcrFmwAAAAAB2cSrAAAAAAHow7sAAAAAAffCywAAAAACBsHbAAAAAAIVwOsAAAAAAiS/+wAAAAACM78LAAAAAAJCvhsAAAAAAlG9KwAAAAACYLw7AAAAAAJwTvMAAAAAAn9OAwAAAAACjk30AAAAAAKXiHQAAAAAAp1MIwAAAAACrEszAAAAAAK7SkMAAAAAAspJUwAAAAAC2UhjAAAAAALoR3MAAAAAAvdGgwAAAAADBkWTAAAAAAMV2EsAAAAAAycl+wAAAAADM9ZrAAAAAANFJBsAAAAAA1HUiwAAAAADYyI7AAAAAANv0qsAAAAAA4G0AwAAAAADjdDLAAAAAAOfsiMAAAAAA6vO6wAAAAADvbBDAAAAAAPKYLMAAAAAA8zumwAAAAAD269EAAAAAAPoX7QAAAAAA/mtZAAAAAAEBl3UAAAAAAQYPywAAAAABCRb9AAAAAAENj1MAAAAAARCWhQAAAAABFQ7bAAAAAAEYFg0AAAAAARyOYwAAAAABH7p/AAAAAAEkDesAAAAAASc6BwAAAAABK41zAAAAAAEuuY8AAAAAATMx5QAAAAABNjkXAAAAAAFRL8zAAAAAAV0n4wAEDAgMCAwIDAgMCAwIDAgMCAwIDAgMEAQMCAwIDAgMCAwIDAgMCAwIDAgMCAwIEAQQBBAEEAQQBBAEEAQQBBAEDAQMAAE+nAAAAAFRgAAQAAHCAAQgAAGJwAAwAAGJwAQxMTVQAKzA2ACswOAArMDcACjwrMDc+LTcK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABCAAAACAAAABj/////odvduv////+1o8UAAAAAABUnU3AAAAAAFhhrwAAAAAAXCGrQAAAAABf5n0AAAAAAGOmeUAAAAAAZ2tLAAAAAABrMI1AAAAAAG7wwcAAAAAAcrCFwAAAAAB2cEnAAAAAAHowDcAAAAAAfe/RwAAAAACBr5XAAAAAAIVvWcAAAAAAiS8dwAAAAACM7uHAAAAAAJCupcAAAAAAlG5pwAAAAACYLi3AAAAAAJwS28AAAAAAn9KfwAAAAACjkpwAAAAAAKXhPAAAAAAAp1InwAAAAACrEevAAAAAAK7Rr8AAAAAAspFzwAAAAAC2UTfAAAAAALoQ+8AAAAAAvdC/wAAAAADBkIPAAAAAAMV1McAAAAAAycidwAAAAADM9LnAAAAAANFIJcAAAAAA1HRBwAAAAADYx63AAAAAANvzycAAAAAA4GwfwAAAAADjc1HAAAAAAOfrp8AAAAAA6vLZwAAAAADvay/AAAAAAPKXS8AAAAAA9uq3wAAAAAD6FtPAAAAAAP5qP8AAAAABAZZbwAAAAAEGDrHAAAAAAQkV48AAAAABDY45wAAAAAEQlWvAAAAAARUNwcAAAAABGBTzwAAAAAEcjUnAAAAAAR+5ZcAAAAABJAzRwAAAAAEnOO3AAAAAASuMWcAAAAABLrh1wAAAAAEzMMvAAAAAATY3/cAAAAABObfRAAAAAAFRLuvABAgQDBAMEAwQDBAMEAwQDBAMEAwQDBQYDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMHAwYAAIZGAAAAAHCAAAQAAH6QAAgAAJqwAAwAAKjAARAAAJqwAQwAAIygABQAAKjAABBMTVQAKzA4ACswOQArMTEAKzEyACsxMAAKPCsxMD4tMTAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBAAAABgAAABD/////p1lHXf////+1o7bwAAAAABUnRWAAAAAAFhh50AAAAAAXCHjgAAAAABf5rVAAAAAAGOmsYAAAAAAZ2uDQAAAAABrMMWAAAAAAG7w+gAAAAAAcrC+AAAAAAB2cIIAAAAAAHowRgAAAAAAffAKAAAAAACBr84AAAAAAIVvkgAAAAAAiS9WAAAAAACM7xoAAAAAAJCu3gAAAAAAlG6iAAAAAACYLmYAAAAAAJwTFAAAAAAAn9LYAAAAAACjktRAAAAAAKXhdEAAAAAAp1JgAAAAAACrEiQAAAAAAK7R6AAAAAAAspGsAAAAAAC2UXAAAAAAALoRNAAAAAAAvdD4AAAAAADBkLwAAAAAAMV1agAAAAAAycjWAAAAAADM9PIAAAAAANFIXgAAAAAA1HR6AAAAAADYx+YAAAAAANv0AgAAAAAA4GxYAAAAAADjc4oAAAAAAOfr4AAAAAAA6vMSAAAAAADva2gAAAAAAPKXhAAAAAAA9urwAAAAAAD6FwwAAAAAAP5qeAAAAAABAZaUAAAAAAEGDuoAAAAAAQkWHAAAAAABDY5yAAAAAAEQlaQAAAAAARUN+gAAAAABGBUsAAAAAAEcjYIAAAAAAR+5ngAAAAABJA0KAAAAAAEnOSYAAAAAASuMkgAAAAABLriuAAAAAAEzMQQAAAAAATY4NgAAAAABUS7rwAQMCAwIDAgMCAwIDAgMCAwIDAgMCAwQBAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDBQMAAHujAAAAAH6QAAQAAJqwAQgAAIygAAwAAIygAQwAAJqwAAhMTVQAKzA5ACsxMQArMTAACjwrMTA+LTEwCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBAAAABgAAABD/////odvqXv////+1o8UAAAAAABUnU3AAAAAAFhiH4AAAAAAXCIbwAAAAABf5u2AAAAAAGOm6cAAAAAAZ2u7gAAAAABrMP3AAAAAAG7xMkAAAAAAcrD2QAAAAAB2cLpAAAAAAHowfkAAAAAAffBCQAAAAACBsAZAAAAAAIVvykAAAAAAiS+OQAAAAACM71JAAAAAAJCvFkAAAAAAlG7aQAAAAACYLp5AAAAAAJwTTEAAAAAAn9MQQAAAAACjkwyAAAAAAKXhrIAAAAAAp1KYQAAAAACrElxAAAAAAK7SIEAAAAAAspHkQAAAAAC2UahAAAAAALoRbEAAAAAAvdEwQAAAAADBkPRAAAAAAMV1okAAAAAAyckOQAAAAADM9SpAAAAAANFIlkAAAAAA1HSyQAAAAADYyB5AAAAAANv0OkAAAAAA4GyQQAAAAADjc8JAAAAAAOfsGEAAAAAA6vNKQAAAAADva6BAAAAAAPKXvEAAAAAA9usoQAAAAAD6F0RAAAAAAP5qsEAAAAABAZbMQAAAAAEGDyJAAAAAAQkWVEAAAAABDY6qQAAAAAEQldxAAAAAARUOMkAAAAABGBVkQAAAAAEcjbpAAAAAAR+51kAAAAABJA1CQAAAAAEnOV5AAAAAASuMykAAAAABLrjmQAAAAAEzMTxAAAAAATY4bkAAAAABUS8kAAQMCAwIDAgMCAwIDAgMCAwIDAgMCAwQBAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDBQMAAHmiAAAAAHCAAAQAAIygAQgAAH6QAAwAAH6QAQwAAIygAAhMTVQAKzA4ACsxMAArMDkACjwrMDk+LTkK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABCAAAABwAAABT/////m18JJ/////+hErH//////7Wj/UAAAAAAFSeLsAAAAAAWGMAgAAAAABcIvzAAAAAAF/nzoAAAAAAY6fKwAAAAABnbJyAAAAAAGsx3sAAAAAAbvITQAAAAABysddAAAAAAHZxm0AAAAAAejFfQAAAAAB98SNAAAAAAIGw50AAAAAAhXCrQAAAAACJMG9AAAAAAIzwM0AAAAAAkK/3QAAAAACUb7tAAAAAAJgvf0AAAAAAnBQtQAAAAACf0/FAAAAAAKOT7YAAAAAApeKNgAAAAACnU3lAAAAAAKsTPUAAAAAArtMBQAAAAACyksVAAAAAALZSiUAAAAAAuhJNQAAAAAC90hFAAAAAAMGR1UAAAAAAxXaDQAAAAADJye9AAAAAAMz2C0AAAAAA0Ul3QAAAAADUdZNAAAAAANjI/0AAAAAA2/UbQAAAAADgbXFAAAAAAON0o0AAAAAA5+z5QAAAAADq9CtAAAAAAO9sgUAAAAAA8pidQAAAAAD27AlAAAAAAPoYJUAAAAAA/muRQAAAAAEBl61AAAAAAQYQA0AAAAABCRc1QAAAAAENj4tAAAAAARCWvUAAAAABFQ8TQAAAAAEYFkVAAAAAARyOm0AAAAABH7q3QAAAAAEkDiNAAAAAASc6P0AAAAABK42rQAAAAAEuucdAAAAAATMyHUAAAAABNjlPQAAAAAFRMAUABAgQDBAMEAwQDBAMEAwQDBAMEAwQDBAUCBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEBgQAADjZAAAAADTBAAQAADhAAAgAAFRgAQwAAEZQABAAAEZQARAAAFRgAAxMTVQAUE1UACswNAArMDYAKzA1AAo8KzA1Pi01Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+AAAABQAAABD/////qhmaSP/////n2gxQAAAAABUnmcAAAAAAFhjOMAAAAAAXCM1AAAAAABf6AbAAAAAAGOoAwAAAAAAZ2zUwAAAAABrMhcAAAAAAG7yS4AAAAAAcrIPgAAAAAB2cdOAAAAAAHoxl4AAAAAAffFbgAAAAACBsR+AAAAAAIVw44AAAAAAiTCngAAAAACM8GuAAAAAAJCwL4AAAAAAlG/zgAAAAACYL7eAAAAAAJwUZYAAAAAAn9QpgAAAAACjlCXAAAAAAKdT6cAAAAAAqxOtwAAAAACu03HAAAAAALKTNcAAAAAAtlL5wAAAAAC6Er3AAAAAAL3SgcAAAAAAwZJFwAAAAADM9kOAAAAAANFJr4AAAAAA1HXLgAAAAADYyTeAAAAAANv1U4AAAAAA4G2pgAAAAADjdNuAAAAAAOftMYAAAAAA6vRjgAAAAADvbLmAAAAAAPKY1YAAAAAA9uxBgAAAAAD6GF2AAAAAAP5ryYAAAAABAZflgAAAAAEGEDuAAAAAAQkXbYAAAAABDY/DgAAAAAEQlvWAAAAAARUPS4AAAAABGBZ9gAAAAAEcjtOAAAAAAR+674AAAAABJA5bgAAAAAEnOneAAAAAASuN44AAAAABLrn/gAAAAAEzMlWAAAAAATY5h4AAAAABOrHdgAQMCAwIDAgMCAwIDAgMCAwIDAgMCAwQBBAEEAQQBBAMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMAACm4AAAAACowAAQAAEZQAQgAADhAAAwAADhAAQxMTVQAKzAzACswNQArMDQACjwrMDQ+LTQK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACFAAAACAAAAB3/////Xj0bkP////+S5qqg/////5tLiZD/////m/7joP////+cnReg/////53Jn5D/////nn5LIP////+fqtMQ/////6BffqD/////oYwGkP////+iQgOg/////6Nui5D/////pCM3IP////+lT78Q/////6oGC5D/////qud8EP////+tycQQ/////66nQBD/////r6BrkP////+whyIQ/////7GJiBD/////snA+kP////+zcqSQ/////7RQIJD/////tzJokP////+4D+SQ/////7j/1ZD/////ue/GkP////+8yNQQ/////724xRD/////vp97kP////+/mKcQ/////8CbDRD/////wXiJEP/////CaHoQ/////8NYaxD/////xD8hkP/////FOE0Q/////8Y6sxD/////x1jIkP/////H2fuQ/////8kD7pD/////yfE8kP/////K4n8Q/////8u1bxD/////y+zAAP/////MgGgA/////8zcvxD/////zZVREP/////Nw2eA/////85yvwD/////zsXbkP/////PdTMQ/////8+shAD/////0FKhAP/////Qpb2Q/////9FVFRD/////0YxmAP/////SMoMA/////9KFn5D/////01nhEP/////USdIQ/////9U57UD/////1ineQP/////XGc9A/////9gJwED/////2PmxQP/////Z6aJA/////9rZk0D/////28mEQP/////cuXVA/////92yoMD/////3qKRwP/////fkoLA/////+CCc8D/////4XJkwP/////iYlXA/////+NSRsD/////5EI3wP/////lMijA/////+YiGcD/////5xtFQP/////oCzZA/////+j7J0D/////6esYQP/////q2wlA/////+vK+kD/////7LrrQP/////tqtxA/////+6azUD/////74q+QP/////weq9A//////FqoED/////8mPLwP/////zU7zA//////RDrcD/////9TOewP/////2I4/A//////cTgMD/////+ANxwP/////482LA//////njU8AAAAAAFwPNkAAAAAAX876QAAAAABjjr5AAAAAAGdOgkAAAAAAaw5GQAAAAABu8vRAAAAAAHKyuEAAAAAAdnJ8QAAAAAB6MkBAAAAAAH3yBEAAAAAAgbHIQAAAAACFcYxAAAAAAIkxUEAAAAAAjPEUQAAAAACQsNhAAAAAAJRwnEAAAAAAmDBgQAAAAACcFQ5AAAAAAJ/U0kAAAAAAo5SWQAAAAACnVFpAAAAAAKsUHkAAAAAArPQ4gAAAAACu0+JAAAAAALB/CEAAAAAAspOmQAAAAAC2U2pAAAAAALoTLkAAAAAAvdLyQAAAAADBkrZAAAAAAMV3ZEAEDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgQCAwIEAgMCBAIDAgQCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUHBgQFBAUEBQT//+fwAAD//+UoAAT///HwAQj//+PgAAwAAAAAARD///HwAAgAAA4QARQAAAAAABlMTVQASE1UAC0wMQAtMDIAKzAwAFdFU1QAV0VUAAo8LTAxPjE8KzAwPixNMy41LjAvMCxNMTAuNS4wLzEK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABfAAAABQAAABT/////aYcYRv////+czK5G/////523Szb/////nrhtxv////+fhLg2/////7TDHeb/////y2Km4P/////M07zQ/////82e0eD/////zsYT0P/////PdXlg/////9CvMFD/////0VVbYP/////SjxJQ/////9VxaGD/////1g480P/////XWoTg/////9fk5FD/////2Tpm4P/////ZxMZQ/////9sjg2D/////26SoUP/////dA2Vg/////92EilD/////3uNHYP/////fbabQ/////+ZsCeD/////5zcC0AAAAAAIILNgAAAAAAkQllAAAAAACgCVYAAAAAAK8HhQAAAAAAvgd2AAAAAADNmU0AAAAAANwFlgAAAAAA65dtAAAAAAD6l14AAAAAAQmVjQAAAAABGJV+AAAAAAEnk60AAAAAATaTngAAAAABRZHNAAAAAAFUkb4AAAAAAWOP7QAAAAABco/eAAAAAAGCIbUAAAAAAZCN/gAAAAABoB/VAAAAAAGvH8YAAAAAAb4d9QAAAAABzR3mAAAAAAHcHBUAAAAAAescBgAAAAAB+ho1AAAAAAIHXy4AAAAAAhgYVQAAAAACJV1OAAAAAAI2qh0AAAAAAkNbbgAAAAACVKg9AAAAAAJhWY4AAAAAAnKmXQAAAAACf+tWAAAAAAKQpH0AAAAAAp3pdgAAAAACrqKdAAAAAAK755YAAAAAAs00ZQAAAAAC2eW2AAAAAALrMoUAAAAAAvfj1gAAAAADCTClAAAAAAMWdZ4AAAAAAycuxQAAAAADNHO+AAAAAANFLOUAAAAAA1Jx3gAAAAADYysFAAAAAANwb/4AAAAAA4G8zQAAAAADjm4eAAAAAAOfuu0AAAAAA6xsPgAAAAADvbkNAAAAAAPK/gYAAAAAA9u3LQAAAAAD6PwmAAAAAAP5tU0AAAAABAb6RgAAAAAEGEcVAAAAAAQk+GYAAAAABDZFNQAAAAAEQvaGAAAAAARUQ1UAAAAABF85rgAgECAQIEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAP//8M6AAD//9FKAQT//8M6AAj//9XQAQz//8fAABBMTVQAQlNUAEJNVABBRFQAQVNUAApBU1Q0QURULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAAAABAAAABH/////pgRc8P/////UQfcgAAAAABNNNgAAAAAAFDP6kAAAAAAVI+uQAAAAABYT3JAAAAAAFwPNkAAAAAAX876QAAAAABjjr5AAAAAAGdOgkAAAAAAaw5GQAAAAABu8vRAAAAAAHKyuEAAAAAAdnJ8QAAAAAB6MkBAAAAAAH3yBEAAAAAAgbHIQAAAAACFcYxAAAAAAIkxUEAAAAAAjPEUQAAAAACQsNhAAAAAAJRwnEAAAAAAmDBgQAAAAACcFQ5AAAAAAJ/U0kAAAAAAo5SWQAAAAACnVFpAAAAAAKsUHkAAAAAArtPiQAAAAACyk6ZAAAAAALZTakAAAAAAuhMuQAAAAAC90vJAAAAAAMGStkAAAAAAxXdkQAQIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgP///GQAAD///HwAAQAAAAAAAgAAA4QAQxMTVQALTAxAFdFVABXRVNUAApXRVQwV0VTVCxNMy41LjAvMSxNMTAuNS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAABAAAAAz/////kuaqoP/////MlZwg/////9J0fBAAAAAACxf3QAECAQP//+n0AAD//+PgAAT///HwAQj///HwAAhMTVQALTAyAC0wMQAKPC0wMT4xCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAAAAwAAAA3/////i22kWAAAAAAVI+uQAAAAABYT3JAAAAAAFwPNkAAAAAAX876QAAAAABjjr5AAAAAAGdOgkAAAAAAaw5GQAAAAABu8vRAAAAAAHKyuEAAAAAAdnJ8QAAAAAB6MkBAAAAAAH3yBEAAAAAAgbHIQAAAAACFcYxAAAAAAIkxUEAAAAAAjPEUQAAAAACQsNhAAAAAAJRwnEAAAAAAmDBgQAAAAACcFQ5AAAAAAJ/U0kAAAAAAo5SWQAAAAACnVFpAAAAAAKsUHkAAAAAArtPiQAAAAACyk6ZAAAAAALZTakAAAAAAuhMuQAAAAAC90vJAAAAAAMGStkAAAAAAxXdkQAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQL///moAAAAAAAAAAQAAA4QAQhMTVQAV0VUAFdFU1QACldFVDBXRVNULE0zLjUuMC8xLE0xMC41LjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACDAAAABwAAAB3/////Xj0TWP////+S5pyQ/////5tLe4D/////m/7VkP////+cnQmQ/////53JkYD/////nn49EP////+fqsUA/////6BfcJD/////oYv4gP////+iQfWQ/////6NufYD/////pCMpEP////+lT7EA/////6oF/YD/////quduAP////+tybYA/////66nMgD/////r6BdgP////+whxQA/////7GJegD/////snAwgP////+zcpaA/////7RQEoD/////tzJagP////+4D9aA/////7j/x4D/////ue+4gP////+8yMYA/////724twD/////vp9tgP////+/mJkA/////8Ca/wD/////wXh7AP/////CaGwA/////8NYXQD/////xD8TgP/////FOD8A/////8Y6pQD/////x1i6gP/////H2e2A/////8kD4ID/////yfEugP/////K4nEA/////8u1YQD/////y+yx8P/////MgFnw/////8zcsQD/////zZVDAP/////Nw1lw/////85ysPD/////zsXNgP/////PdSUA/////8+sdfD/////0FKS8P/////Qpa+A/////9FVBwD/////0YxX8P/////SMnTw/////9KFkYD/////01nTAP/////UScQA/////9U53zD/////1inQMP/////XGcEw/////9gJsjD/////2PmjMP/////Z6ZQw/////9rZhTD/////28l2MP/////cuWcw/////92ykrD/////3qKDsP/////fknSw/////+CCZbD/////4XJWsP/////iYkew/////+NSOLD/////5EIpsP/////lMhqw/////+YiC7D/////5xs3MP/////oCygw/////+j7GTD/////6esKMP/////q2vsw/////+vK7DD/////7LrdMP/////tqs4w/////+6avzD/////74qwMP/////weqEw//////FqkjD/////8mO9sP/////zU66w//////RDn7D/////9TOQsP/////2I4Gw//////cTcrD/////+ANjsP/////481Sw//////njRbAAAAAAFwz6AAAAAAAX87CAAAAAABjjoYAAAAAAGdOSgAAAAAAaw4OAAAAAABu8rwAAAAAAHKygAAAAAAAdnJEAAAAAAB6MggAAAAAAH3yBEAAAAAAgbHIQAAAAACFcYxAAAAAAIkxUEAAAAAAjPEUQAAAAACQsNhAAAAAAJRwnEAAAAAAmDBgQAAAAACcFQ5AAAAAAJ/U0kAAAAAAo5SWQAAAAACnVFpAAAAAAKsUHkAAAAAArtPiQAAAAACyk6ZAAAAAALZTakAAAAAAuhMuQAAAAAC90vJAAAAAAMGStkAAAAAAxXdkQAQMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCBAIDAgQCAwIEAgMCBAIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQb///AoAAD///AoAAQAAAAAAQj///HwAAwAAA4QARAAAAAAABQAAA4QARhMTVQARk1UACswMAAtMDEAKzAxAFdFVABXRVNUAApXRVQwV0VTVCxNMy41LjAvMSxNMTAuNS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAgAAAAj/////aYb9wAH//93AAAD//+PgAARMTVQALTAyAAo8LTAyPjIK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGAAAABgAAABT/////aYcRvP////+TRF88/////8NPWsD/////xDYDMP/////FLzzA/////8YV5TD/////xxhZQP/////H/wGw/////8j4O0D/////yd7jsP/////K2B1A/////8u+xbD/////zLf/QP/////NNoEwAAAAABkR/kAAAAAAGdO8sAAAAAAa8cQgAAAAABuqZDAAAAAAHNGmIAAAAAAdikYwAAAAAB6oW7AAAAAAH2o2QAAAAAAgiD2wAAAAACFKGEAAAAAAImgfsAAAAAAjKfpAAAAAACRIAbAAAAAAJQncQAAAAAAmMR4wAAAAACbpvkAAAAAAKBEAMAAAAAAo0trAAAAAACnw4jAAAAAAKrK8wAAAAAAr0MQwAAAAACySnsAAAAAALbCmMAAAAAAucoDAAAAAAC+QiDAAAAAAMFJiwAAAAAAxeaSwAAAAADI7f0AAAAAAM1mGsAAAAAA0G2FAAAAAADU5aLAAAAAANftDQAAAAAA3GUqwAAAAADfbJUAAAAAAOPkssAAAAAA5uwdAAAAAADrZKtAAAAAAO5HK4AAAAAA8wkdQAAAAAD1xrOAAAAAAPqIpUAAAAAA/WslgAAAAAECCC1AAAAAAQTqrYAAAAABCYe1QAAAAAEMajWAAAAAAREHPUAAAAABE+m9gAAAAAEYhsVAAAAAARtpRYAAAAABICs3QAAAAAEjDbeAAAAAASeqv0AAAAABKo0/gAAAAAEvKkdAAAAAATIMx4AEDAgMCAwIDAgMCAwIDBQQFBAUCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwX//8nEAAD//8nEAAT//9XQAQj//8fAAAz//+PgARD//9XQAAhMTVQAU01UAC0wMwAtMDQALTAyAAo8LTAzPjMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABTAAAAAwAAAA7/////cxZ/PP////+cTsKA/////5y8LwD/////y1SzAP/////Lx2WA/////8y3VoD/////zadHgP/////OoHMA/////8+HKYAAAAAAA3A5gAAAAAAEDRwAAAAAAAVQG4AAAAAABfY4gAAAAAAHL/2AAAAAAAfWGoAAAAAACQ/fgAAAAAAJtfyAAAAAAArvwYAAAAAAC58ZAAAAAAAM2N4AAAAAAA1++wAAAAAADrjAAAAAAAAPXt0AAAAAABCYogAAAAAAET6/AAAAAAASeIQAAAAAABMeoQAAAAAAFFhmAAAAAAAU/oMAAAAAABY4SAAAAAAAFwyJgAAAAAAYIWSAAAAAABjHgYAAAAAAGgFGgAAAAAAap2OAAAAAABvhKIAAAAAAHIdFgAAAAAAdwQqAAAAAAB55nIAAAAAAH5eyAAAAAAAgWX6AAAAAACGAzoAAAAAAIkKbAAAAAAAjaesAAAAAACQifQAAAAAAJUnNAAAAAAAl7+oAAAAAACcprwAAAAAAJ8/MAAAAAAApCZEAAAAAACmvrgAAAAAAKulzAAAAAAArmMqAAAAAACzSj4AAAAAALXisgAAAAAAusnGAAAAAAC9YjoAAAAAAMJJTgAAAAAAxXVqAAAAAADJyNYAAAAAAMz08gAAAAAA0UheAAAAAADUdHoAAAAAANjH5gAAAAAA2/QCAAAAAADgbFgAAAAAAONzigAAAAAA5p+mAAAAAADq8xIAAAAAAO9raAAAAAAA8peEAAAAAAD26vAAAAAAAPoXDAAAAAAA/mp4AAAAAAEBlpQAAAAAAQYO6gAAAAABCRYcAAAAAAENjnIAAAAAARC6jgAAAAABFQ36AAAAAAEYFSwAAAAAARyNggAAAAABH96IAAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIAAI3EAAAAAJqwAQQAAIygAAlMTVQAQUVEVABBRVNUAApBRVNULTEwQUVEVCxNMTAuMS4wLE00LjEuMC8zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABUAAAABAAAAA7/////cxaLFP////97EgNw/////5xOyYj/////nLw2CP/////LVLoI/////8vHbIj/////zLddiP/////Np06I/////86gegj/////z4cwiAAAAAADcECIAAAAAAQNIwgAAAAABVAiiAAAAAAF9j+IAAAAAAcwBIgAAAAAB9YhiAAAAAAJD+aIAAAAAAm2A4gAAAAACu/IiAAAAAALnyAIAAAAAAzY5QgAAAAADX8CCAAAAAAOuMcIAAAAAA9e5AgAAAAAEJipCAAAAAARPsYIAAAAABJ4iwgAAAAAEx6oCAAAAAAUWG0IAAAAABT+iggAAAAAFjhPCAAAAAAW56aIAAAAABgha4gAAAAAGMeIiAAAAAAaAU2IAAAAABqnaogAAAAAG+EviAAAAAAch0yIAAAAAB3BEYgAAAAAHnmjiAAAAAAfl7kIAAAAACBZhYgAAAAAIYDViAAAAAAiQqIIAAAAACNp8ggAAAAAJCKECAAAAAAlSdQIAAAAACYCZggAAAAAJym2CAAAAAAnz9MIAAAAACkJmAgAAAAAKctkiAAAAAAq6XoIAAAAACuY0YgAAAAALNKWiAAAAAAtiyiIAAAAAC6yeIgAAAAAL3RFCAAAAAAwklqIAAAAADFdYYgAAAAAMnI8iAAAAAAzPUOIAAAAADRSHogAAAAANR0liAAAAAA2MgCIAAAAADb9B4gAAAAAOBsdCAAAAAA43OmIAAAAADn6/wgAAAAAOrzLiAAAAAA72uEIAAAAADyl6AgAAAAAPbrDCAAAAAA+hcoIAAAAAD+apQgAAAAAQGWsCAAAAABBg8GIAAAAAEJFjggAAAAAQ2OjiAAAAABELqqIAAAAAEVDhYgAAAAARgVSCAAAAABHI2eIAAAAAEf3qQgBAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMAAIHsAAAAAH6QAAQAAJOoAQkAAIWYAARMTVQAQUNTVABBQ0RUAApBQ1NULTk6MzBBQ0RULE0xMC4xLjAsTTQuMS4wLzMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARAAAAAwAAAA7/////cu2fCP////+cTsKA/////5y8LwD/////y1SzAP/////Lx2WA/////8y3VoD/////zadHgP/////OoHMA/////8+HKYAAAAAAA3A5gAAAAAAEDRwAAAAAACVJzQAAAAAAJe/qAAAAAAAnKa8AAAAAACfPzAAAAAAAKQmRAAAAAAApr64AAgECAQIBAgECAQIBAgECAQIAAI94AAAAAJqwAQQAAIygAAlMTVQAQUVEVABBRVNUAApBRVNULTEwCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABVAAAABQAAABP/////cxaIZP////92BKXg/////3sSA3D/////nE7JiP////+cvDYI/////8tUugj/////y8dsiP/////Mt12I/////82nToj/////zqB6CP/////PhzCIAAAAAANwQIgAAAAABA0jCAAAAAAFUCKIAAAAAAX2P4gAAAAABzAEiAAAAAAH1iGIAAAAAAkP5ogAAAAACbYDiAAAAAAK78iIAAAAAAufIAgAAAAADNjlCAAAAAANfwIIAAAAAA64xwgAAAAAD17kCAAAAAAQmKkIAAAAABE+xggAAAAAEniLCAAAAAATHqgIAAAAABRYbQgAAAAAFP6KCAAAAAAWOE8IAAAAABcMkIgAAAAAGCFriAAAAAAYx4iIAAAAABoBTYgAAAAAGqdqiAAAAAAb4S+IAAAAAByHTIgAAAAAHcERiAAAAAAeeaOIAAAAAB+XuQgAAAAAIFmFiAAAAAAhgNWIAAAAACJCoggAAAAAI2nyCAAAAAAkIoQIAAAAACVJ1AgAAAAAJe/xCAAAAAAnKbYIAAAAACfP0wgAAAAAKQmYCAAAAAApr7UIAAAAACrpeggAAAAAK5jRiAAAAAAs0paIAAAAAC14s4gAAAAALrJ4iAAAAAAvWJWIAAAAADCSWogAAAAAMV1hiAAAAAAycjyIAAAAADM9Q4gAAAAANFIeiAAAAAA1HSWIAAAAADYyAIgAAAAANv0HiAAAAAA4Gx0IAAAAADjc6YgAAAAAOfr/CAAAAAA6vMuIAAAAADva4QgAAAAAPKXoCAAAAAA9usMIAAAAAD6FyggAAAAAP5qlCAAAAABAZawIAAAAAEGDwYgAAAAAQkWOCAAAAABDY6OIAAAAAEQuqogAAAAARUOFiAAAAABGBVIIAAAAAEcjZ4gAAAAAR/epCAECBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQAAIScAAAAAIygAAQAAH6QAAkAAJOoAQ4AAIWYAAlMTVQAQUVTVABBQ1NUAEFDRFQACkFDU1QtOTozMEFDRFQsTTEwLjEuMCxNNC4xLjAvMwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABeAAAAAwAAAA7/////dC4A5P////+b1XiA/////5y8LwD/////ndpEgP////+egGGA/////5+6JoD/////oGBDgP/////LVLMA/////8vHZYD/////zLdWgP/////Np0eA/////86gcwD/////z4cpgP/////7wo0A//////yyfgD//////cdZAP/////+drCA//////+nOwAAAAAAAFaSgAAAAAABhx0AAAAAAAI/rwAAAAAAA3A5gAAAAAAEDRwAAAAAAAVQG4AAAAAABfY4gAAAAAAHL/2AAAAAAAfWGoAAAAAACQ/fgAAAAAAJtfyAAAAAAArvwYAAAAAAC58ZAAAAAAAM2N4AAAAAAA1++wAAAAAADrjAAAAAAAAPXt0AAAAAABCYogAAAAAAET6/AAAAAAASeIQAAAAAABMeoQAAAAAAFFhmAAAAAAAU/oMAAAAAABY4SAAAAAAAFwNPAAAAAAAYIWSAAAAAABjjMQAAAAAAGgFGgAAAAAAap2OAAAAAABvhKIAAAAAAHIdFgAAAAAAdwQqAAAAAAB5nJ4AAAAAAH5eyAAAAAAAgWX6AAAAAACGAzoAAAAAAIkKbAAAAAAAjaesAAAAAACQifQAAAAAAJUnNAAAAAAAmAl8AAAAAACcprwAAAAAAJ/S2AAAAAAAo7eGAAAAAACnUmAAAAAAAKs3DgAAAAAArtHoAAAAAACytpYAAAAAALZRcAAAAAAAujYeAAAAAAC90PgAAAAAAMG1pgAAAAAAxXVqAAAAAADJWhgAAAAAAMz08gAAAAAA0NmgAAAAAADUdHoAAAAAANhZKAAAAAAA2/QCAAAAAADf2LAAAAAAAONzigAAAAAA5p+mAAAAAADq8xIAAAAAAO78qgAAAAAA8peEAAAAAAD2fDIAAAAAAPoXDAAAAAAA/fu6AAAAAAEBlpQAAAAAAQV7QgAAAAABCRYcAAAAAAEM+soAAAAAARC6jgAAAAABFHpSAAAAAAEYFSwAAAAAARwexAAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgEAAIocAAAAAJqwAQQAAIygAAlMTVQAQUVEVABBRVNUAApBRVNULTEwQUVEVCxNMTAuMS4wLE00LjEuMC8zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKAAAABAAAAA7/////cxaSWP////97EgNw/////5xOyYj/////nLw2CP/////LVLoI/////8vHbIj/////zLddiP/////Np06I/////86gegj/////z4cwiAEDAgMCAwIDAgMAAHqoAAAAAH6QAAQAAJOoAQkAAIWYAARMTVQAQUNTVABBQ0RUAApBQ1NULTk6MzAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATAAAAAwAAABD/////dKYKsP////+cTtQU/////5y8QJT/////y1TElP/////Lx3cU/////8y3aBT/////zadZFAAAAAAJD/EUAAAAAAm2DhQAAAAAGgFYFAAAAAAap3UUAAAAACklUhQAAAAAKa+/lAAAAABFcbSUAAAAAEYFXJQAAAAARyNyFAAAAABH7nkUAAAAAEkDVBQAAAAASc5bFAIBAgECAQIBAgECAQIBAgECAQIAAHjQAAAAAIkcAQQAAHsMAApMTVQAKzA5NDUAKzA4NDUACjwrMDg0NT4tODo0NQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4AAAABQAAABn/////cxZ33AAAAAAU/mbgAAAAABY4QPgAAAAAFueKaAAAAAAYIV14AAAAABjHbGgAAAAAGgE/eAAAAAAap05oAAAAABvhIXgAAAAAHIcwaAAAAAAdwQN4AAAAAB55jnAAAAAAH5eq+AAAAAAgWXBwAAAAACGAx3gAAAAAIkKM8AAAAAAjaeP4AAAAACQibvAAAAAAJUnF+AAAAAAl79vwAAAAACcpp/gAAAAAJ8+98AAAAAApCYn4AAAAACmvn/AAAAAAKulr+AAAAAArmLxwAAAAACzSiHgAAAAALXiecAAAAAAusmp4AAAAAC9YgHAAAAAAMJJMeAAAAAAxXUxwAAAAADJyLngAAAAAMz0ucAAAAAA0UhB4AAAAADUdEHAAAAAANjHyeAAAAAA2/PJwAAAAADgbDvgAAAAAONzUcAAAAAA5p+J4AAAAADq8tnAAAAAAO9rS+AAAAAA8pdLwAAAAAD26tPgAAAAAPoW08AAAAAA/mpb4AAAAAEBllvAAAAAAQYOzeAAAAABCRXjwAAAAAENjlXgAAAAARC6VcAAAAABFQ3d4AAAAAEYFPPAAAAAARyNZeAAAAABH95PwAQMCAwIDAgMCAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMAAJUkAAAAAIygAAQAAKG4AQkAAJOoAA8AAJqwARVMTVQAQUVTVAArMTEzMAArMTAzMAArMTEACjwrMTAzMD4tMTA6MzA8KzExPi0xMSxNMTAuMS4wLE00LjEuMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVAAAAAwAAAA7/////cu2i1P////+cTsKA/////5y8LwD/////y1SzAP/////Lx2WA/////8y3VoD/////zadHgP/////OoHMA/////8+HKYAAAAAAA3A5gAAAAAAEDRwAAAAAACVJzQAAAAAAJe/qAAAAAAAnKa8AAAAAACfPzAAAAAAAKQmRAAAAAAApr64AAAAAACrpcwAAAAAAK5jKgAAAAAAs0o+AAAAAAC14rIACAQIBAgECAQIBAgECAQIBAgECAQIAAIusAAAAAJqwAQQAAIygAAlMTVQAQUVEVABBRVNUAApBRVNULTEwCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABTAAAAAwAAAA7/////cxaFGP////+cTsKA/////5y8LwD/////y1SzAP/////Lx2WA/////8y3VoD/////zadHgP/////OoHMA/////8+HKYAAAAAAA3A5gAAAAAAEDRwAAAAAAAVQG4AAAAAABfY4gAAAAAAHL/2AAAAAAAfWGoAAAAAACQ/fgAAAAAAJtfyAAAAAAArvwYAAAAAAC58ZAAAAAAAM2N4AAAAAAA1++wAAAAAADrjAAAAAAAAPXt0AAAAAABCYogAAAAAAET6/AAAAAAASeIQAAAAAABMeoQAAAAAAFFhmAAAAAAAU/oMAAAAAABY4SAAAAAAAFuefgAAAAAAYIWSAAAAAABjHgYAAAAAAGgFGgAAAAAAap2OAAAAAABvhKIAAAAAAHIdFgAAAAAAdwQqAAAAAAB55nIAAAAAAH5eyAAAAAAAgWX6AAAAAACF3lAAAAAAAIkKbAAAAAAAjaesAAAAAACQifQAAAAAAJUnNAAAAAAAmAl8AAAAAACcprwAAAAAAJ8/MAAAAAAApCZEAAAAAACmvrgAAAAAAKulzAAAAAAArmMqAAAAAACzSj4AAAAAALXisgAAAAAAusnGAAAAAAC90PgAAAAAAMJJTgAAAAAAxXVqAAAAAADJyNYAAAAAAMz08gAAAAAA0UheAAAAAADUdHoAAAAAANjH5gAAAAAA2/QCAAAAAADgbFgAAAAAAONzigAAAAAA5p+mAAAAAADq8xIAAAAAAO9raAAAAAAA8peEAAAAAAD26vAAAAAAAPoXDAAAAAAA/mp4AAAAAAEBlpQAAAAAAQYO6gAAAAABCRYcAAAAAAENjnIAAAAAARC6jgAAAAABFQ36AAAAAAEYFSwAAAAAARyNggAAAAABH96IAAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIAAIfoAAAAAJqwAQQAAIygAAlMTVQAQUVEVABBRVNUAApBRVNULTEwQUVEVCxNMTAuMS4wLE00LjEuMC8zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATAAAAAwAAAA7/////dKYW5P////+cTt6g/////5y8SyD/////y1TPIP/////Lx4Gg/////8y3cqD/////zadjoAAAAAAJD/ugAAAAAAm2GKAAAAAAGgFioAAAAAAap3+gAAAAACklXKAAAAAAKa/KIAAAAABFcb8gAAAAAEYFZyAAAAAARyN8oAAAAABH7oOgAAAAAEkDXqAAAAAASc5loAIBAgECAQIBAgECAQIBAgECAQIAAGycAAAAAH6QAQQAAHCAAAlMTVQAQVdEVABBV1NUAApBV1NULTgK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABmAAAABgAAABr/////Vrbf5v////9t6MgA/////5hESYD/////mwwlcP////+b1drw/////5zZrpD/////naS1kP////+euZCQ/////5+El5D/////n874MP////+gYKXw/////6F+u3D/////oi4S8P////+jekzw/////6Q1gfD/////pV4jcP////+mJTXw/////6cnm/D/////qCoB8P////+pB33w/////6nuNHD/////qudf8P////+r11Dw/////6zHQfD/////rcmn8P////+upyPw/////6+gT3D/////sIcF8P////+xiWvw/////7JwTKD/////s3KyoP////+0UC6g/////7VJWiD/////tjAQoP////+3Mnag/////7gP8qD/////uP/joP////+579Sg/////7rWiyD/////u9jxIP////+8yOIg/////7240yD/////vp+JoP////+/mLUg/////8CbGyD/////wXiXIP/////CaIgg/////8NYeSD/////xD8voP/////FOFsg/////8Y6wSD/////x1jWoP/////H2gmg/////8hKGSD/////zOdLEP/////NqReQ/////86iQxD/////z5I0EP/////Qbl6Q/////9FyFhD/////0k5AkP/////TkUAQ/////9RLI5AAAAAADaRjkAAAAAAOixoQAAAAAA+ERZAAAAAAEHQ2kAAAAAARZCeQAAAAABJUGJAAAAAAE01EEAAAAAAUM/qQAAAAABUj65AAAAAAFhPckAAAAAAXA82QAAAAABfzvpAAAAAAGOOvkAAAAAAZ06CQAAAAABrDkZAAAAAAG7y9EAAAAAAcrK4QAAAAAB2cnxAAAAAAHoyQEAAAAAAffIEQAAAAACBschAAAAAAIVxjEAAAAAAiTFQQAAAAACM8RRAAAAAAJCw2EAAAAAAlHCcQAAAAACYMGBAAAAAAJwVDkAAAAAAn9TSQAAAAACjlJZAAAAAAKdUWkAAAAAAqxQeQAAAAACu0+JAAAAAALKTpkAAAAAAtlNqQAAAAAC6Ey5AAAAAAL3S8kAAAAAAwZK2QAAAAADFd2RABAgMEAwQDBAMCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQAAAQaAAAAAAQaAAQAAAAAAAgAAA4QAAwAABwgARAAAA4QARVMTVQAQk1UAFdFVABDRVQAQ0VTVABXRVNUAApDRVQtMUNFU1QsTTMuNS4wLE0xMC41LjAvMwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABXAAAAAgAAAAj/////nqYsgP////+fuvlw/////6CGDoD/////oZrbcP/////LiP6A/////9JhCfD/////+vhnAP/////76Enw//////zYSQD//////cgr8P/////+uCsA//////+oDfAAAAAAAJgNAAAAAAABh+/wAAAAAAJ37wAAAAAAA3EMcAAAAAAEYQuAAAAAAAVQ7nAAAAAABkDtgAAAAAAHMNBwAAAAAAeNJ4AAAAAACRCycAAAAAAJraMAAAAAAArwlHAAAAAAC+CTgAAAAAAM2bDwAAAAAA3AdYAAAAAADrmS8AAAAAAPqZIAAAAAABCZdPAAAAAAEYl0AAAAAAASeVbwAAAAABNpVgAAAAAAFFk48AAAAAAVSTgAAAAAABY5GvAAAAAAFykaAAAAAAAYIjdwAAAAABkI/AAAAAAAGgIZcAAAAAAa8hiAAAAAABvh+3AAAAAAHNH6gAAAAAAdwd1wAAAAAB6x3IAAAAAAH6G/cAAAAAAgdg8AAAAAACGBoXAAAAAAIlXxAAAAAAAjar3wAAAAACQ10wAAAAAAJUqf8AAAAAAmFbUAAAAAACcqgfAAAAAAJ/7RgAAAAAApCmPwAAAAACnes4AAAAAAKupF8AAAAAArvpWAAAAAACzTYnAAAAAALZ53gAAAAAAus0RwAAAAAC9+WYAAAAAAMJMmcAAAAAAxZ3YAAAAAADJzCHAAAAAAM0dYAAAAAAA0UupwAAAAADUnOgAAAAAANjLMcAAAAAA3BxwAAAAAADgb6PAAAAAAOOb+AAAAAAA5+8rwAAAAADrG4AAAAAAAO9us8AAAAAA8r/yAAAAAAD27jvAAAAAAPo/egAAAAAA/m3DwAAAAAEBvwIAAAAAAQYSNcAAAAABCT6KAAAAAAENkb3AAAAAARC+EgAAAAABFRFFwAAAAAEXztwABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAH//6ugAAT//7mwAQBDRFQAQ1NUAApDU1Q2Q0RULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABuAAAABgAAABT/////aYdCCP////+5x0CI//////3RPED//////pL6sP//////zM3AAAAAAABy3LAAAAAAAXVQwAAAAAACQEmwAAAAAANVMsAAAAAABCArsAAAAAAFPk9AAAAAAAYADbAAAAAABwu8QAAAAAAH3++wAAAAAAj+E0AAAAAACb/RsAAAAAAK3fVAAAAAAAuo7jAAAAAADL3XQAAAAAANiNAwAAAAAA6duUAAAAAAD2iyMAAAAAAQhtXAAAAAABFIlDAAAAAAEma3wAAAAAATKHYwAAAAABRGmcAAAAAAFRGSsAAAAAAWJnvAAAAAABbxdLAAAAAAGAZdwAAAAAAY0VawAAAAABnmP8AAAAAAGrE4sAAAAAAbz1xAAAAAAByRGrAAAAAAHa8+QAAAAAAecPywAAAAAB+PIEAAAAAAIH8DMAAAAAAhbwJAAAAAACI5+zAAAAAAI07kQAAAAAAkGd0wAAAAACU4AMAAAAAAJfm/MAAAAAAm8vjAAAAAACfZoTAAAAAAKPfEwAAAAAApwr2wAAAAACrXpsAAAAAAK6KfsAAAAAAst4jAAAAAAC2CgbAAAAAALpdqwAAAAAAvYmOwAAAAADCAh0AAAAAAMUJFsAAAAAAyYGlAAAAAADM91zAAAAAANEBLQAAAAAA1C0QwAAAAADYNuEAAAAAANwbVsAAAAAA4AA9AAAAAADjLCDAAAAAAOekrwAAAAAA6quowAAAAADvJDcAAAAAAPIrMMAAAAAA9qO/AAAAAAD5qrjAAAAAAP4jRwAAAAABAU8qwAAAAAEFos8AAAAAAQjOssAAAAABDSJXAAAAAAEQTjrAAAAAARTGyQAAAAABF83CwAAAAAEcRlEAAAAAAR+8CMAAAAABI8XZAAAAAAEm8bzAAAAAAStFYQAAAAABLuACwAAAAAEyxOkAAAAAATcYHMAAAAABOUILAAAAAAE+crrAAAAAAUELZwAAAAABRfJCwAAAAAFIr9kAAAAAAU1xysAAAAABUC9hAAAAAAFc35jAAAAAAV6/swAAAAABZF8gwAAAAAFmPzsAAAAAAWveqMAAAAABbb7DAAAAAAFypZ7AAAAAAXXR8wAAAAABeiUmwAAAAAF9UXsAAAAAAYGkrsAAAAABhNEDAAAAAAGJJDbAAAAAAYx1dQAAAAABkKO+wAQMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQT//5l4AAD//5l4AAT//6ugAQj//52QAAz//6ugAAj//7mwARBMTVQARU1UAC0wNgAtMDcALTA1AAo8LTA2PjY8LTA1PixNOS4xLjYvMjIsTTQuMS42LzIyCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA3AAAABgAAABr/////dD+YRP////+bgCGA/////7l86eD/////ucav0P/////J8mPg/////8oQqFD/////zOdLEP/////Nqkzw/////86iGOD/////z5NpcP/////fE55g/////9+3ClAAAAAACexeYAAAAAALGPRgAAAAAAvNrgAAAAAADL2fAAAAAAANpFWAAAAAAA6MXYAAAAAAD4Q3gAAAAAAQavwQAAAAABFke/AAAAAAElKq8AAAAAATRoJgAAAAABQzwlAAAAAAFSPrkAAAAAAWE9yQAAAAABcDzZAAAAAAF/O+kAAAAAAY46+QAAAAABnToJAAAAAAGsORkAAAAAAbvL0QAAAAABysrhAAAAAAHZyfEAAAAAAejJAQAAAAAB98gRAAAAAAIGxyEAAAAAAhXGMQAAAAACJMVBAAAAAAIzxFEAAAAAAkLDYQAAAAACUcJxAAAAAAJgwYEAAAAAAnBUOQAAAAACf1NJAAAAAAKOUlkAAAAAAp1RaQAAAAACrFB5AAAAAAK7T4kAAAAAAspOmQAAAAAC2U2pAAAAAALoTLkAAAAAAvdLyQAAAAADBkrZAAAAAAMV3ZEAEDAgMCBQQFBAMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIAABY8AAAAABY8AAQAACowAQgAABwgAA0AAA4QABEAABwgARVMTVQAQU1UAEVFU1QARUVUAENFVABDRVNUAApFRVQtMkVFU1QsTTMuNS4wLzMsTTEwLjUuMC80Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABXAAAAAgAAAAj/////nqYecP////+fuutg/////6CGAHD/////oZrNYP/////LiPBw/////9Jg++D/////+vhY8P/////76Dvg//////zYOvD//////cgd4P/////+uBzw//////+n/+AAAAAAAJf+8AAAAAABh+HgAAAAAAJ34PAAAAAAA3D+YAAAAAAEYP1wAAAAAAVQ4GAAAAAABkDfcAAAAAAHMMJgAAAAAAeNGXAAAAAACRCkYAAAAAAJrZTwAAAAAArwhmAAAAAAC+CFcAAAAAAM2aLgAAAAAA3AZ3AAAAAADrmE4AAAAAAPqYPwAAAAABCZZuAAAAAAEYll8AAAAAASeUjgAAAAABNpR/AAAAAAFFkq4AAAAAAVSSnwAAAAABY5DOAAAAAAFykL8AAAAAAYIilgAAAAABkI7fAAAAAAGgILYAAAAAAa8gpwAAAAABvh7WAAAAAAHNHscAAAAAAdwc9gAAAAAB6xznAAAAAAH6GxYAAAAAAgdgDwAAAAACGBk2AAAAAAIlXi8AAAAAAjaq/gAAAAACQ1xPAAAAAAJUqR4AAAAAAmFabwAAAAACcqc+AAAAAAJ/7DcAAAAAApClXgAAAAACnepXAAAAAAKuo34AAAAAArvodwAAAAACzTVGAAAAAALZ5pcAAAAAAuszZgAAAAAC9+S3AAAAAAMJMYYAAAAAAxZ2fwAAAAADJy+mAAAAAAM0dJ8AAAAAA0UtxgAAAAADUnK/AAAAAANjK+YAAAAAA3Bw3wAAAAADgb2uAAAAAAOObv8AAAAAA5+7zgAAAAADrG0fAAAAAAO9ue4AAAAAA8r+5wAAAAAD27gOAAAAAAPo/QcAAAAAA/m2LgAAAAAEBvsnAAAAAAQYR/YAAAAABCT5RwAAAAAENkYWAAAAAARC92cAAAAABFRENgAAAAAEXzqPABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAH//7mwAAT//8fAAQBFRFQARVNUAApFU1Q1RURULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACRAAAACAAAABT/////V9EK8f////+bJrOR/////5vWCxH/////nM8woP////+dpMOg/////56cnaD/////n5caoP////+ghbog/////6F2/KD/////omWcIP////+je8ig/////6ROuKD/////pT/7IP////+mJWAg/////6cnxiD/////qCosIP////+o6/ig/////6oA06D/////qtUVIP////+r6fAg/////6zHbCD/////rcnSIP////+up04g/////6+geaD/////sIcwIP////+xktCg/////7JwTKD/////s3KyoP////+0UC6g/////7VJWiD/////tjAQoP////+3Mnag/////7gP8qD/////uRJYoP////+579Sg/////7rpACD/////u9jxIP////+821cg/////7240yD/////vrH+oP////+/mLUg/////8CbGyD/////wXiXIP/////Cev0g/////8NYeSD/////xFGkoP/////FOFsg/////8Y6wSD/////x1jWoP/////H2gmg/////9RJ4CD/////1R4hoP/////WTqwg/////9csKCD/////2C6OIP/////Y+ZUg/////9oOcCD/////2uvsIP/////b5Reg/////9zLziD/////3cT5oP/////etOqg/////9+uFiD/////4JTMoP/////hckig/////+JrdCD/////41IqoP/////kVJCg/////+UyDKD/////5j2tIP/////nGykg/////+gUVKD/////6PsLIP/////p/XEg/////+ra7SD/////691TIP/////sus8g/////+2z+qD/////7pqxIP/////vgWeg//////CffSD/////8WFJoP/////yf18g//////NKZiD/////9F9BIP/////1IQ2g//////Y/IyD/////9wDvoP/////4HwUg//////jg0aD/////+f7nIP/////6wLOg//////voA6D//////HuroP/////9x7twAAAAAANwxiAAAAAABClYIAAAAAAFUKggAAAAAAYJOiAAAAAABzCKIAAAAAAH6RwgAAAAAAkQbCAAAAAACcj+IAAAAAAK8E4gAAAAAAuyGqAAAAAADNAwIAAAAAANkfygAAAAAA6wEiAAAAAAD3HeoAAAAAAQmS6gAAAAABFRwKAAAAAAEnkQoAAAAAATMaKgAAAAABRY8qAAAAAAFSPrkAAAAAAWOMaQAAAAABcDzZAAAAAAGBiokAAAAAAY46+QAAAAABn4ipAAAAAAGsORkAAAAAAb4acQAAAAABysrhAAAAAAHcGJEAAAAAAejJAQAAAAAB+haxAAAAAAIGxyEAAAAAAhgU0QAAAAACJMVBAAAAAAI2EvEAAAAAAkLDYQAAAAACVKS5AAAAAAJgwYEAAAAAAnKi2QAAAAACf1NJAAAAAAKQoPkAAAAAAp1RaQAAAAACrp8ZAAAAAAK7T4kAAAAAAsydOQAAAAAC2U2pAAAAAALqm1kAAAAAAvdLyQAAAAADCJl5AAAAAAMV3ZEAECBAMEAwQDBAMEAwQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgcGBwYHBgf///oPAAD///oPAAQAAAgfAQgAAA4QAQwAAAAAABAAAA4QAQgAAAAAARAAAA4QAAhMTVQARE1UAElTVABCU1QAR01UAApJU1QtMUdNVDAsTTEwLjUuMCxNMy41LjAvMQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAQAAAAAAABHTVQACkdNVDAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAT///HwAAAtMDEACjwtMDE+MQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAT//3NgAAAtMTAACjwtMTA+MTAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAT//2VQAAAtMTEACjwtMTE+MTEK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAT//1dAAAAtMTIACjwtMTI+MTIK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAT//+PgAAAtMDIACjwtMDI+Mgo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAT//9XQAAAtMDMACjwtMDM+Mwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAT//8fAAAAtMDQACjwtMDQ+NAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAT//7mwAAAtMDUACjwtMDU+NQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAT//6ugAAAtMDYACjwtMDY+Ngo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAT//52QAAAtMDcACjwtMDc+Nwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAT//4+AAAAtMDgACjwtMDg+OAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAT//4FwAAAtMDkACjwtMDk+OQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAQAAA4QAAArMDEACjwrMDE+LTEK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAQAAIygAAArMTAACjwrMTA+LTEwCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAQAAJqwAAArMTEACjwrMTE+LTExCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAQAAKjAAAArMTIACjwrMTI+LTEyCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAQAALbQAAArMTMACjwrMTM+LTEzCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAQAAMTgAAArMTQACjwrMTQ+LTE0Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAQAABwgAAArMDIACjwrMDI+LTIK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAQAACowAAArMDMACjwrMDM+LTMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAQAADhAAAArMDQACjwrMDQ+LTQK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAQAAEZQAAArMDUACjwrMDU+LTUK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAQAAFRgAAArMDYACjwrMDY+LTYK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAQAAGJwAAArMDcACjwrMDc+LTcK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAQAAHCAAAArMDgACjwrMDg+LTgK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAQAAH6QAAArMDkACjwrMDk+LTkK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAQAAAAAAABVVEMAClVUQzAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZAAAABAAAABH/////fjazlP/////UQdsAAAAAABysrhAAAAAAHZyfEAAAAAAejJAQAAAAAB98gRAAAAAAIGxyEAAAAAAhXGMQAAAAACJMVBAAAAAAIzxFEAAAAAAkLDYQAAAAACUcJxAAAAAAJgwYEAAAAAAnBUOQAAAAACf1NJAAAAAAKOUlkAAAAAAp1RaQAAAAACrFB5AAAAAAK7T4kAAAAAAspOmQAAAAAC2U2pAAAAAALoTLkAAAAAAvdLyQAAAAADBkrZAAAAAAMV3ZEAECAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMAAAFsAAAAAAAAAAQAAA4QAAgAABwgAQxMTVQAV0VUAENFVABDRVNUAApDRVQtMUNFU1QsTTMuNS4wLE0xMC41LjAvMwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAABQAAABD/////qhhFdP////+1pAtQAAAAABUnmcAAAAAAFhjOMAAAAAAXCM1AAAAAABf6AbAAAAAAGOoAwAAAAAAZ2zUwAAAAABrMhcAAAAAAG7yS4AAAAAAcrIPgAAAAAB2cdOAAAAAAHoxl4AAAAAAffFbgAAAAACBsR+AAAAAAIVw44AAAAAAiTCngAAAAACM8GuAAAAAAJCwL4AAAAAAlHArwAAAAACYL+/AAAAAAJwUncAAAAAAn9RhwAAAAACnU7GAAAAAAKsTrcAAAAAArtNxwAAAAACykzXAAAAAALZS+cAAAAAAuhK9wAAAAAC90oHAAAAAAMGSRcAAAAAAxXbzwAAAAADJyl/AAAAAAMz2e8AAAAAA0UnnwAAAAADUdgPAAAAAANjJb8AAAAAA2/WLwAAAAADgbeHAAAAAAON1E8AAAAAA5+1pwAAAAADq9JvAAAAAAO9s8cAAAAAA8pkNwAAAAAD27HnAAAAAAPoYlcAAAAAA/mwBwAAAAAEBmB3AAAAAAQYQc8AAAAABCRelwAAAAAENj/vAAAAAARCXLcAAAAABFQ+DwAAAAAEYFrXAAAAAARyPC8AAAAABH7snwAAAAAEkDpPAAAAAASc6r8AAAAABK44bwAAAAAEuujfAAAAAATMyjcAAAAABNjm/wAAAAAFRMHWAAAAAAVvcUcAEDAgMCAwIDAgMCAwIDAgMCAwQBBAEDBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEDAQMAAC0MAAAAACowAAQAAEZQAQgAADhAAAwAADhAAQxMTVQAKzAzACswNQArMDQACjwrMDQ+LTQK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACfAAAABQAAABH/////Gl0Jy/////+bJq2g/////5vWBSD/////nM8woP////+dpMOg/////56cnaD/////n5caoP////+ghbog/////6F2/KD/////omWcIP////+je8ig/////6ROuKD/////pT/7IP////+mJWAg/////6cnxiD/////qCosIP////+o6/ig/////6oA06D/////qtUVIP////+r6fAg/////6zHbCD/////rcnSIP////+up04g/////6+geaD/////sIcwIP////+xktCg/////7JwTKD/////s3KyoP////+0UC6g/////7VJWiD/////tjAQoP////+3Mnag/////7gP8qD/////uRJYoP////+579Sg/////7rpACD/////u9jxIP////+821cg/////7240yD/////vrH+oP////+/mLUg/////8CbGyD/////wXiXIP/////Cev0g/////8NYeSD/////xFGkoP/////FOFsg/////8Y6wSD/////x1jWoP/////H2gmg/////8oWJpD/////ypdZkP/////L0R6Q/////8x3O5D/////zbEAkP/////OYFgQ/////8+Q4pD/////0G5ekP/////RchYQ/////9H7MhD/////0mn+IP/////TYymg/////9RJ4CD/////1R4hoP/////VQv2Q/////9Xf4BD/////1k6sIP/////W/gOg/////9gujiD/////2PmVIP/////aDnAg/////9rr7CD/////2+UXoP/////cy84g/////93E+aD/////3rTqoP/////frhYg/////+CUzKD/////4XJIoP/////ia3Qg/////+NSKqD/////5FSQoP/////lMgyg/////+Y9rSD/////5xspIP/////oFFSg/////+j7CyD/////6f1xIP/////q2u0g/////+vdUyD/////7LrPIP/////ts/qg/////+6asSD/////74FnoP/////wn30g//////FhSaD/////8n9fIP/////zSmYg//////RfQSD/////9SENoP/////2PyMg//////cA76D/////+B8FIP/////44NGg//////n+5yD/////+sCzoP/////76AOg//////x7q6D//////ce7cAAAAAADcMYgAAAAAAQpWCAAAAAABVCoIAAAAAAGCTogAAAAAAcwiiAAAAAAB+kcIAAAAAAJEGwgAAAAAAnI/iAAAAAACvBOIAAAAAALshqgAAAAAAzQMCAAAAAADZH8oAAAAAAOsBIgAAAAAA9x3qAAAAAAEJkuoAAAAAARUcCgAAAAABJ5EKAAAAAAEzGioAAAAAAUWPKgAAAAABUj65AAAAAAFjjGkAAAAAAXA82QAAAAABgYqJAAAAAAGOOvkAAAAAAZ+IqQAAAAABrDkZAAAAAAG+GnEAAAAAAcrK4QAAAAAB3BiRAAAAAAHoyQEAAAAAAfoWsQAAAAACBschAAAAAAIYFNEAAAAAAiTFQQAAAAACNhLxAAAAAAJCw2EAAAAAAlSkuQAAAAACYMGBAAAAAAJyotkAAAAAAn9TSQAAAAACkKD5AAAAAAKdUWkAAAAAAq6fGQAAAAACu0+JAAAAAALMnTkAAAAAAtlNqQAAAAAC6ptZAAAAAAL3S8kAAAAAAwiZeQAAAAADDnJAACAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQMBAwEDAQMBAwECAQIBAwECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgEEAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgL///+1AAAAAA4QAQQAAAAAAAgAABwgAQwAAA4QAARMTVQAQlNUAEdNVABCRFNUAApHTVQwQlNULE0zLjUuMC8xLE0xMC41LjAK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkAAAAAwAAAA3/////XjzwSP/////KAjXg/////8znSxD/////zakXkP/////OokMQ/////8+SNBD/////0IIlEP/////RoYwQ/////9JOQJAAAAAAGOOvkAAAAAAZ06CQAAAAABrDkZAAAAAAG7y9EAAAAAAcrK4QAAAAAB2cnxAAAAAAHoyQEAAAAAAffIEQAAAAACBschAAAAAAIVxjEAAAAAAiTFQQAAAAACM8RRAAAAAAJCw2EAAAAAAlHCcQAAAAACYMGBAAAAAAJwVDkAAAAAAn9TSQAAAAACjlJZAAAAAAKdUWkAAAAAAqxQeQAAAAACu0+JAAAAAALKTpkAAAAAAtlNqQAAAAAC6Ey5AAAAAAL3S8kAAAAAAwZK2QAAAAADFd2RABAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIAABM4AAAAAA4QAAQAABwgAQhMTVQAQ0VUAENFU1QACkNFVC0xQ0VTVCxNMy41LjAsTTEwLjUuMC8zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9AAAABQAAABX/////HkmS+P////9sz+r4/////5sMF2D/////m9Xa8P////+c2a6Q/////52ktZD/////nrmQkP////+fhJeQ/////8gJcZD/////zOdLEP/////NqReQ/////86iQxD/////z5I0EP/////QgiUQ/////9FyFhD/////0mIHEP/////TgByQ/////9RJ0hD/////1JO0IP/////VAnIg/////9VMOBD/////1im0EP/////XLBoQ/////9gJlhD/////2QFwEP/////Z6XgQAAAAABFkJ5AAAAAAElQYkAAAAAATTUQQAAAAABQz+pAAAAAAFSPrkAAAAAAWE9yQAAAAABcDzZAAAAAAF/O+kAAAAAAY46+QAAAAABnToJAAAAAAGsORkAAAAAAbvL0QAAAAABysrhAAAAAAHZyfEAAAAAAejJAQAAAAAB98gRAAAAAAIGxyEAAAAAAhXGMQAAAAACJMVBAAAAAAIzxFEAAAAAAkLDYQAAAAACUcJxAAAAAAJgwYEAAAAAAnBUOQAAAAACf1NJAAAAAAKOUlkAAAAAAp1RaQAAAAACrFB5AAAAAAK7T4kAAAAAAspOmQAAAAAC2U2pAAAAAALoTLkAAAAAAvdLyQAAAAADBkrZAAAAAAMV3ZEAEDAgMCAwIDAgMCAwIDAgMCAwQDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIAAA2IAAAAAA2IAAQAABwgAQgAAA4QAA0AAAAAARFMTVQAUE1UAENFU1QAQ0VUAEdNVAAKQ0VULTFDRVNULE0zLjUuMCxNMTAuNS4wLzMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA3AAAABAAAABH/////bM/gCP////+3sNII/////7k+82D/////ue+cYP////+6341g/////7vPfmD/////vMip4P////+9uJrg/////76oi+D/////v5h84P/////AiG3g/////8F4XuD/////wmhP4P/////DWEDg/////8RIMeD/////xTgi4P/////GKBPg/////8cYBOAAAAAAEa3RYAAAAAASU+BQAAAAABNNC9AAAAAAFDPQYAAAAAAVI92AAAAAABYTzoAAAAAAFwO/gAAAAAAX87CAAAAAABjjoYAAAAAAGdOSgAAAAAAaw4OAAAAAABu8rwAAAAAAHKygAAAAAAAdnJEAAAAAAB6MggAAAAAAH3xzAAAAAAAgbGQAAAAAACFcVQAAAAAAIkxGAAAAAAAjPDcAAAAAACQsKAAAAAAAJRwZAAAAAAAmDAoAAAAAACcFNYAAAAAAJ/UKYAAAAAAo5PtgAAAAACnU7GAAAAAAKsTdYAAAAAArtM5gAAAAACykv2AAAAAALZSwYAAAAAAuhJNQAAAAAC90kmAAAAAAMGR1UAAAAAAxXa7gAAAAADJye9AAAAAAMsmM4AEDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwMAABh4AAAAABh4AAQAACowAQgAABwgAA1MTVQAQk1UAEVFU1QARUVUAApFRVQtMkVFU1QsTTMuNS4wLzMsTTEwLjUuMC80Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABEAAAAAwAAAA3/////axeRnP////+bDBdg/////5vV2vD/////nNmukP////+dpLWQ/////565kJD/////n4SXkP////+gmsQQ/////6FkeZD/////onAaEP////+jTZYQ/////8nztWD/////zOdLEP/////NqReQ/////86iQxD/////z5I0EP/////QgiUQ/////9GZeOD/////0orJcP/////TUKaQ/////9RLFYD/////1TnDEP/////WKbQQ/////9cZpRD/////2AmWEP/////ZAsGQ/////9npeBD/////4qKo8P/////jUfJg/////+SCpxD/////5TH+kP/////mdP4Q/////+cR4JD/////6FTgEP/////o8cKQAAAAABNNJ/AAAAAAFDPecAAAAAAVI89wAAAAABYTwHAAAAAAFwOxcAAAAAAX86JwAAAAABjjk3AAAAAAGdOEcAAAAAAaw5GQAAAAABu8vRAAAAAAHKyuEAAAAAAdnJ8QAAAAAB6MkBAAAAAAH3yBEAAAAAAgbHIQAAAAACFcYxAAAAAAIkxUEAAAAAAjPEUQAAAAACQsNhAAAAAAJRwnEAAAAAAmDBgQAAAAACcFQ5AAAAAAJ/U0kAAAAAAo5SWQAAAAACnVFpAAAAAAKsUHkAAAAAArtPiQAAAAACyk6ZAAAAAALZTakAAAAAAuhMuQAAAAAC90vJAAAAAAMGStkAAAAAAxXdkQAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgEAABHkAAAAABwgAQQAAA4QAAlMTVQAQ0VTVABDRVQACkNFVC0xQ0VTVCxNMy41LjAsTTEwLjUuMC8zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlAAAABAAAABH/////JPDqgP////9x1AaG/////8oXagD/////yuJxAP/////L90wA/////8zCUwAAAAAAFSPrkAAAAAAWE9yQAAAAABcDzZAAAAAAF/O+kAAAAAAY46+QAAAAABnToJAAAAAAGsORkAAAAAAbvL0QAAAAABysrhAAAAAAHZyfEAAAAAAejJAQAAAAAB98gRAAAAAAIGxyEAAAAAAhXGMQAAAAACJMVBAAAAAAIzxFEAAAAAAkLDYQAAAAACUcJxAAAAAAJgwYEAAAAAAnBUOQAAAAACf1NJAAAAAAKOUlkAAAAAAp1RaQAAAAACrFB5AAAAAAK7T4kAAAAAAspOmQAAAAAC2U2pAAAAAALoTLkAAAAAAvdLyQAAAAADBkrZAAAAAAMV3ZEAEDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIAAAgAAAAAAAb6AAQAABwgAQgAAA4QAA1MTVQAQk1UAENFU1QAQ0VUAApDRVQtMUNFU1QsTTMuNS4wLE0xMC41LjAvMwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABuAAAACQAAACb/////VrbI+P////+ea58M/////7ew0gj/////uT7zYP////+575xg/////7rfjWD/////u89+YP////+8yKng/////724muD/////vqiL4P////+/mHzg/////8CIbeD/////wXhe4P/////CaE/g/////8NYQOD/////xEgx4P/////FOCLg/////8YoE+D/////xxgE4P/////IvJNg/////8p3fVD/////zOdLEP/////NqReQ/////86iQxD/////z5I0EP/////QTpBgAAAAABUnp9AAAAAAFhjcQAAAAAAXCNtQAAAAABf6D8AAAAAAGOoO0AAAAAAZ20NAAAAAABrMk9AAAAAAG7yg8AAAAAAcrJHwAAAAAB2cgvAAAAAAHoxz8AAAAAAffGTwAAAAACBsVfAAAAAAIVxG8AAAAAAiTDfwAAAAACM8KPAAAAAAJCwZ8AAAAAAlHArwAAAAACYL+/AAAAAAJkNM4AAAAAAnBTWAAAAAACf1JoAAAAAAKOUXgAAAAAAp1OxgAAAAACrEz1AAAAAAK7TOYAAAAAAspLFQAAAAAC2UsGAAAAAALoSTUAAAAAAvdJJgAAAAADBkdVAAAAAAMV2u4AAAAAAycnvQAAAAADM9rQAAAAAANFKIAAAAAAA1HY8AAAAAADYyagAAAAAANv1xAAAAAAA4G4aAAAAAADjdUwAAAAAAOftogAAAAAA6vTUAAAAAADvbSoAAAAAAPKZRgAAAAAA9uyyAAAAAAD6GM4AAAAAAP5sOgAAAAABAZhWAAAAAAEGEKwAAAAAAQkX3gAAAAABDZA0AAAAAAEQl2YAAAAAARUPvAAAAAABGBbuAAAAAAEcj0QAAAAAAR+7YAAAAAABJA7MAAAAAAEnOugAAAAAASuOVAAAAAABLrpwAAAAAAEzMsYAAAAAATY5+AAAAAABOrJOAAAAAAE9uYAAAAAAAUIx1gAAAAABRV3yAAAAAAFJsV4AAAAAAUzdegAAAAABUTDmAAAAAAFUXQIAAAAAAViwbgAAAAABW9yKAAAAAAFgVOAAAAAAAWNcEgAAAAABZ9RoAAAAAAFq25oAAAAAAW9T8AAAAAABcoAMAAAAAAF203gAAAAAAXn/lAAAAAABflMAAAAAAAGBfxwAAAAAAYX3cgAAAAABhz31gAQIEAwQDBAMEAwQDBAMEAwQDBAMGBQYFBggHCAcIBwgHCAcIBwgHCAcIBwgHAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAQAABsIAAAAABr0AAQAABh4AAgAACowAQwAABwgABEAAA4QABUAABwgARkAADhAAR4AACowACJMTVQAQ01UAEJNVABFRVNUAEVFVABDRVQAQ0VTVABNU0QATVNLAApFRVQtMkVFU1QsTTMuNS4wLzMsTTEwLjUuMC80Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABzAAAABgAAABr/////V9EKBP////+bJq2g/////5vWBSD/////nM8woP////+dpMOg/////56cnaD/////n5caoP////+ghbog/////6F2/KD/////omWcIP////+je8ig/////6ROuKD/////pT/7IP////+mJWAg/////6cnxiD/////qCosIP////+o6/ig/////6oA06D/////qtUVIP////+r6fAg/////6zHbCD/////rcnSIP////+up04g/////6+geaD/////sIcwIP////+xktCg/////7JwTKD/////s3KyoP////+0UC6g/////7VJWiD/////tjAQoP////+3Mnag/////7gP8qD/////uRJYoP////+579Sg/////7rpACD/////u9jxIP////+821cg/////7240yD/////vrH+oP////+/mLUg/////8CbGyD/////wXiXIP/////Cev0g/////8NYeSD/////xFGkoP/////FOFsg/////8Y6wSD/////x1jWoP/////H2gmg/////8oWJpD/////ypdZkP/////L0R6Q/////8x3O5D/////zbEAkP/////OYFgQ/////8+Q4pD/////0G5ekP/////RchYQ/////9H7MhD/////0mn+IP/////TYymg/////9RJ4CD/////1R4hoP/////VQv2Q/////9Xf4BD/////1k6sIP/////W/gOg/////9gujiD/////2PmVIP/////aDnAg/////9rr7CD/////2+UXoP/////cy84g/////93E+aD/////3rTqoP/////frhYg/////+CUzKD/////4XJIoP/////ia3Qg/////+NSKqD/////5FSQoP/////lMgyg/////+Y9rSD/////5xspIP/////oFFSgAAAAABcDzZAAAAAAF/O+kAAAAAAY46+QAAAAABnToJAAAAAAGsORkAAAAAAbvL0QAAAAABysrhAAAAAAHZyfEAAAAAAejJAQAAAAAB98gRAAAAAAIGxyEAAAAAAhXGMQAAAAACJMVBAAAAAAIzxFEAAAAAAkLDYQAAAAACUcJxAAAAAAJgwYEAAAAAAnBUOQAAAAACf1NJAAAAAAKOUlkAAAAAAp1RaQAAAAACrFB5AAAAAAK7T4kAAAAAAspOmQAAAAAC2U2pAAAAAALoTLkAAAAAAvdLyQAAAAADBkrZAAAAAAMV3ZEAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAwEDAQMBAwEDAQIBAgEDAQIBAgECAQIBAgECAQIBAgECAQIEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAX///r8AAAAAA4QAQQAAAAAAAgAABwgAQwAAA4QABEAABwgARVMTVQAQlNUAEdNVABCRFNUAENFVABDRVNUAApDRVQtMUNFU1QsTTMuNS4wLE0xMC41LjAvMwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAAAABAAAABH/////U7omm/////+kc28b/////8vOUWD/////zMDlYAAAAAAVI92AAAAAABYTzoAAAAAAFwO/gAAAAAAX87CAAAAAABjjr5AAAAAAGdOgkAAAAAAaw5GQAAAAABu8vRAAAAAAHKyuEAAAAAAdnJ8QAAAAAB6MkBAAAAAAH3yBEAAAAAAgbHIQAAAAACFcYxAAAAAAIkxUEAAAAAAjPEUQAAAAACQsNhAAAAAAJRwnEAAAAAAmDBgQAAAAACcFQ5AAAAAAJ/U0kAAAAAAo5SWQAAAAACnVFpAAAAAAKsUHkAAAAAArtPiQAAAAACyk6ZAAAAAALZTakAAAAAAuhMuQAAAAAC90vJAAAAAAMGStkAAAAAAxXdkQAQMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIAABdlAAAAABdlAAQAACowAQgAABwgAA1MTVQASE1UAEVFU1QARUVUAApFRVQtMkVFU1QsTTMuNS4wLzMsTTEwLjUuMC80Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAACAAAACL/////b6JbSP////+bDBdg/////5vV2vD/////nNmukP////+dpLWQ/////565kJD/////n4SXkP/////ICXGQ/////8znSxD/////zakXkP/////OokMQ/////8+SNBD/////0IIlEP/////RchYQ/////9F8d+D/////0ZWEYP/////Siq1Q/////9NZtuAAAAAAFSen0AAAAAAWGNxAAAAAABcI21AAAAAAF/oPwAAAAAAY6g7QAAAAABnbQ0AAAAAAGsyT0AAAAAAbvKDwAAAAAByskfAAAAAAHZyC8AAAAAAejHPwAAAAAB98ZPAAAAAAIGxV8AAAAAAhXEbwAAAAACJMN/AAAAAAIzwo8AAAAAAkLBnwAAAAACUcGQAAAAAAJgwKAAAAAAAnBTWAAAAAACf1JoAAAAAAKOUXgAAAAAAp1QiAAAAAACrE+YAAAAAAK7TqgAAAAAAspNuAAAAAAC2UzIAAAAAALoS9gAAAAAAvdK6AAAAAADBkn4AAAAAAMV3LAAAAAAAycqYAAAAAADM9rQAAAAAANFKIAAAAAAA1HY8AAAAAADYyagAAAAAANv1xAAAAAAA4G4aAAAAAADjdUwAAAAAAOftogAAAAAA6vTUAAAAAADvbSoAAAAAAPKZRgAAAAAA9uyyAAAAAAD6GM4AAAAAAP5sOgAAAAABAZhWAAAAAAEGEKwAAAAAAQkX3gAAAAABDZA0AAAAAAEQl2YAAAAAARUPvAAAAAABGBbuAAAAAAEcj0QAAAAAAR+7YAAAAAABJA7MAAAAAAEnOugAAAAAASuOVAAAAAABLrpwAAAAAAEzMsYAAAAAATY5+AAAAAABUTCtwAgECAQIBAgECAQIBAgEEAwQGBQYFBgUGBQYFBgUGBQYFBgMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMEBwQAABM4AAAAABwgAQQAAA4QAAkAACowAQ0AABwgABIAADhAARYAACowABoAACowAB5MTVQAQ0VTVABDRVQARUVTVABFRVQATVNEAE1TSwArMDMACkVFVC0yCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAnAAAACAAAACL/////VrbHZP////+qGadk/////7WkGWD/////ys0u0P/////M50sQ/////82pF5D/////zqJDEP/////OzahwAAAAABUnp9AAAAAAFhjcQAAAAAAXCNtQAAAAABf6D8AAAAAAGOoO0AAAAAAZ20NAAAAAABrMk9AAAAAAG7yg8AAAAAAcrJHwAAAAAB2cgvAAAAAAHoxz8AAAAAAffGTwAAAAACBsVfAAAAAAIVxG8AAAAAAiTDfwAAAAACM8KPAAAAAAJCwZ8AAAAAAlHArwAAAAACYL+/AAAAAAJo0g4AAAAAAo5ReAAAAAACnVCIAAAAAAKsT5gAAAAAArtOqAAAAAACyk24AAAAAALZTMgAAAAAAuhL2AAAAAAC90roAAAAAAMGSfgAAAAAAxXcsAAAAAADGWUVABAgMFBAUEAwYDBgMGAwYDBgMGAwYDBgMGAwYHAgcCBwIHAgcCBwcAABycAAAAABycAAQAABwgAAgAACowAAwAAA4QABAAABwgARQAADhAARkAACowAR1MTVQAS01UAEVFVABNU0sAQ0VUAENFU1QATVNEAEVFU1QACkVFVC0yRUVTVCxNMy41LjAvMyxNMTAuNS4wLzQK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/AAAABwAAABj/////oQA5gP////+1pAtQAAAAABUnmcAAAAAAFhjOMAAAAAAXCM1AAAAAABf6AbAAAAAAGOoAwAAAAAAZ2zUwAAAAABrMhcAAAAAAG7yS4AAAAAAcrIPgAAAAAB2cdOAAAAAAHoxl4AAAAAAffFbgAAAAACBsR+AAAAAAIVw44AAAAAAiTCngAAAAACM8GuAAAAAAJCwL4AAAAAAlHArwAAAAACYL+/AAAAAAJwUncAAAAAAn9RhwAAAAACnU7GAAAAAAKsTrcAAAAAArtNxwAAAAACykzXAAAAAALZS+cAAAAAAuhK9wAAAAAC90oHAAAAAAMGSRcAAAAAAxXbzwAAAAADJyl/AAAAAAMz2e8AAAAAA0UnnwAAAAADUdgPAAAAAANjJb8AAAAAA2/WLwAAAAADgbeHAAAAAAON1E8AAAAAA5+1pwAAAAADq9JvAAAAAAO9s8cAAAAAA8pkNwAAAAAD27HnAAAAAAPoYlcAAAAAA/mwBwAAAAAEBmB3AAAAAAQYQc8AAAAABCRelwAAAAAENj/vAAAAAARCXLcAAAAABFQ+DwAAAAAEYFrXAAAAAARyPC8AAAAABH7snwAAAAAEkDpPAAAAAASc6r8AAAAABK44bwAAAAAEuujfAAAAAATMyjcAAAAABNjm/wAAAAAFRMHWABAwIDAgMCAwIDAgMCAwIDAgMEBQQFAwQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBgUAAC6YAAAAACowAAQAAEZQAQgAADhAAAwAADhAARAAACowABQAADhAABRMTVQAKzAzACswNQArMDQATVNEAE1TSwAKTVNLLTMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACOAAAABgAAABv/////Xj0MHf////+S5o6A/////5tLbXD/////m/7HgP////+cnPuA/////53Jg3D/////nn4vAP////+fqrbw/////6BfYoD/////oYvqcP////+iQeeA/////6Nub3D/////pCMbAP////+lT6Lw/////6oF73D/////qudf8P////+tyafw/////66nI/D/////r6BPcP////+whwXw/////7GJa/D/////snAicP////+zcohw/////7RQBHD/////tzJMcP////+4D8hw/////7j/uXD/////ue+qcP////+8yLfw/////724qPD/////vp9fcP////+/mIrw/////8Ca8PD/////wXhs8P/////CaF3w/////8NYTvD/////xD8FcP/////FODDw/////8Y6lvD/////x1iscP/////H2d9w/////8kD0nD/////yfEgcP/////K4mLw/////8u1UvD/////y+yj4P/////MgEvg/////8zcovD/////zZU08P/////Nw0tg/////85youD/////zsW/cP/////PdRbw/////8+sZ+D/////0FKE4P/////QpaFw/////9FU+PD/////0YxJ4P/////SMmbg/////9KFg3D/////01nE8P/////USbXw/////9U50SD/////1inCIP/////XGbMg/////9gJpCD/////2PmVIP/////Z6YYg/////9rZdyD/////28loIP/////cuVkg/////92yhKD/////3qJ1oP/////fkmag/////+CCV6D/////4XJIoP/////iYjmg/////+NSKqD/////5EIboP/////lMgyg/////+Yh/aD/////5xspIP/////oCxog/////+j7CyD/////6er8IP/////q2u0g/////+vK3iD/////7LrPIP/////tqsAg/////+6asSD/////74qiIP/////wepMg//////FqhCD/////8mOvoP/////zU6Cg//////RDkaD/////9TOCoP/////2I3Og//////cTZKD/////+ANVoP/////480ag//////njN6AAAAAADKsqAAAAAAANmxsAAAAAAA6LDAAAAAAAD4RFkAAAAAAQdDaQAAAAABFkJ5AAAAAAElQYkAAAAAATTUQQAAAAABQz+pAAAAAAFSPdgAAAAAAWE86AAAAAABcDv4AAAAAAF/OwgAAAAAAY46GAAAAAABnTkoAAAAAAGsODgAAAAAAbvK8AAAAAABysoAAAAAAAHZyRAAAAAAAejJAQAAAAAB98gRAAAAAAIGxyEAAAAAAhXGMQAAAAACJMVBAAAAAAIzxFEAAAAAAkLDYQAAAAACUcJxAAAAAAJgwYEAAAAAAnBUOQAAAAACf1NJAAAAAAKOUlkAAAAAAp1RaQAAAAACrFB5AAAAAAK7T4kAAAAAAspOmQAAAAAC2U2pAAAAAALoTLkAAAAAAvdLyQAAAAADBkrZAAAAAAMV3ZEAACAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQMBAgEDAQIBAwECAQMBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBBAIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBBAUEBQQFBAH///djAAAAAA4QAQQAAAAAAAkAABwgAQ0AAA4QABIAABwgARZMTVQAV0VTVABXRVQAV0VNVABDRVQAQ0VTVAAKV0VUMFdFU1QsTTMuNS4wLzEsTTEwLjUuMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABPAAAABgAAABv/////fja1AP////+eusXw/////5+gOQD/////oJAb8P////+hgWyA/////6oF73D/////quduAP////+tyafw/////66nMgD/////r6BPcP////+whxQA/////7GJegD/////snAwgP////+zcohw/////7RQEoD/////wsns8P/////DWF0A/////8RIP/D/////xG0b4P/////FOXRg/////8chW4D/////x/WO8P/////L9d5g/////8yVcfD/////zcNLYP/////OoNVw/////8+jLWD/////0IC3cP/////Rgw9g/////9JgmXD/////02LxYP/////UQHtw/////9keRuD/////2elb8AAAAAAIDc3gAAAAAAj0knAAAAAACe2v4AAAAAAK1HRwAAAAAAu7HOAAAAAADKsb8AAAAAANpDlgAAAAAA6K/fAAAAAAD4RFkAAAAAAQdDaQAAAAABFkJ5AAAAAAElQYkAAAAAATTUQQAAAAABQz+pAAAAAAFSPrkAAAAAAWE9yQAAAAABcDzZAAAAAAF/O+kAAAAAAY46+QAAAAABnToJAAAAAAGsORkAAAAAAbvL0QAAAAABysrhAAAAAAHZyfEAAAAAAejJAQAAAAAB98gRAAAAAAIGxyEAAAAAAhXGMQAAAAACJMVBAAAAAAIzxFEAAAAAAkLDYQAAAAACUcJxAAAAAAJgwYEAAAAAAnBUOQAAAAACf1NJAAAAAAKOUlkAAAAAAp1RaQAAAAACrFB5AAAAAAK7T4kAAAAAAspOmQAAAAAC2U2pAAAAAALoTLkAAAAAAvdLyQAAAAADBkrZAAAAAAMV3ZEAIBAgECAQIBAgECAQIBAgECAQMBAgUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQT///yMAAAAAA4QAQQAAAAAAAkAABwgAQ0AABwgARIAAA4QABdMTVQAV0VTVABXRVQAV0VNVABDRVNUAENFVAAKQ0VULTFDRVNULE0zLjUuMCxNMTAuNS4wLzMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABWAAAAAwAAAA3/////cL3TZP////+bOPhw/////5vVzOD/////nMXL8P////+dtwBg/////56J/nD/////n6Ac4P////+gYKXw/////6F+rWD/////olw3cP////+jTBpg/////8hsNfD/////zOdLEP/////NqReQ/////86iQxD/////z5DikP/////Qbl6Q/////9FyFhD/////0kzS8P/////TPjGQ/////9RJ0hD/////1R33cP/////WKZfw/////9brgJD/////2AmWEP/////5M7Xw//////nZxOD/////+xzScP/////7ubTw//////z8tHD//////ZmW8P/////+5dDw//////+Cs3AAAAAAAMWy8AAAAAABYpVwAAAAAAKcWnAAAAAAA0J3cAAAAAAEhXbwAAAAAAUrk/AAAAAABhozcAAAAAAHCiRwAAAAAAgXFnAAAAAACNo0cAAAAAAJ9xSQAAAAAArCDYAAAAAAC9b2kAAAAAAMoe+AAAAAAA222JAAAAAADoHRgAAAAAAPlrqQAAAAABBhs4AAAAAAEXackAAAAAASQZWAAAAAABNFWxAAAAAAFCqyAAAAAAAVI+uQAAAAABYT3JAAAAAAFwPNkAAAAAAX876QAAAAABjjr5AAAAAAGdOgkAAAAAAaw5GQAAAAABu8vRAAAAAAHKyuEAAAAAAdnJ8QAAAAAB6MkBAAAAAAH3yBEAAAAAAgbHIQAAAAACFcYxAAAAAAIkxUEAAAAAAjPEUQAAAAACQsNhAAAAAAJRwnEAAAAAAmDBgQAAAAACcFQ5AAAAAAJ/U0kAAAAAAo5SWQAAAAACnVFpAAAAAAKsUHkAAAAAArtPiQAAAAACyk6ZAAAAAALZTakAAAAAAuhMuQAAAAAC90vJAAAAAAMGStkAAAAAAxXdkQAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgEAAA2cAAAAABwgAQQAAA4QAAlMTVQAQ0VTVABDRVQACkNFVC0xQ0VTVCxNMy41LjAsTTEwLjUuMC8zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABEAAAACQAAACb/////VrbKKP////+qGao4/////7WkGWD/////yl5w0P/////M50sQ/////82pF5D/////zqJDEP/////PkjQQ/////9AKAmAAAAAAFSen0AAAAAAWGNxAAAAAABcI21AAAAAAF/oPwAAAAAAY6g7QAAAAABnbQ0AAAAAAGsyT0AAAAAAbvKDwAAAAAByskfAAAAAAHZyC8AAAAAAejHPwAAAAAB98ZPAAAAAAIGxV8AAAAAAhXEbwAAAAACJMN/AAAAAAIzwo8AAAAAAkLBnwAAAAACUcCvAAAAAAJ/UYcAAAAAAo5ReAAAAAACnVCIAAAAAAKsT5gAAAAAArtOqAAAAAACyk24AAAAAALZTMgAAAAAAuhL2AAAAAAC90roAAAAAAMGSfgAAAAAAxXcsAAAAAADJypgAAAAAAMz2tAAAAAAA0UogAAAAAADUdjwAAAAAANjJqAAAAAAA2/XEAAAAAADgbhoAAAAAAON1TAAAAAAA5+2iAAAAAADq9NQAAAAAAO9tKgAAAAAA8plGAAAAAAD27LIAAAAAAPoYzgAAAAAA/mw6AAAAAAEBmFYAAAAAAQYQrAAAAAABCRfeAAAAAAENkDQAAAAAARCXZgAAAAABFQ+8AAAAAAEYFu4AAAAAARyPRAAAAAABH7tgAAAAAAEkDswAAAAAASc66AAAAAABK45UAAAAAAEuunAAAAAAATMyxgAAAAABNjn4AAQIDBQQFBAUDBgMGAwYDBgMGAwYDBgMGAwYDBwIHAgcCBwIHAgcCBwIHAgcCBwIHAgcCBwIHAgcCBwIHAgcCBwIHAggAABnYAAAAABnIAAQAABwgAAgAACowAAwAAA4QABAAABwgARQAADhAARkAACowAR0AACowACJMTVQATU1UAEVFVABNU0sAQ0VUAENFU1QATVNEAEVFU1QAKzAzAAo8KzAzPi0zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABlAAAABwAAAB//////a8mbz/////+RYFBP/////5tHePD/////m9cscP////+cvJFw/////53ASPD/////non+cP////+foCrw/////6BgpfD/////oYAM8P////+iLhLw/////6N6TPD/////pDWB8P////+lXiNw/////6YlNfD/////pyeb8P////+oWCZw/////6kHffD/////qe40cP////+q51/w/////6vXUPD/////rMdB8P////+tyafw/////66nI/D/////r6BPcP////+whwXw/////7GJa/D/////snAicP////+zcohw/////7RQBHD/////tUkv8P////+2L+Zw/////7cyTHD/////uA/IcP////+4/7lw/////7nvqnD/////utZg8P////+72Mbw/////7zIt/D/////vbio8P////++n19w/////7+YivD/////wJrw8P/////BeGzw/////8JoXfD/////w1hO8P/////EPwVw/////8U4MPD/////xjqW8P/////HWKxw/////8faCaD/////yGwn4P/////M50sQ/////82pF5D/////zqJDEP/////PkjQQ/////9BP4eD/////0Inx8P/////RchYQ/////9JOQJAAAAAAC7s5AAAAAAAMqxvwAAAAAA2kY5AAAAAADosaEAAAAAAPhEWQAAAAABB0NpAAAAAAEWQnkAAAAAASVBiQAAAAABNNRBAAAAAAFDP6kAAAAAAVI+uQAAAAABYT3JAAAAAAFwPNkAAAAAAX876QAAAAABjjr5AAAAAAGdOgkAAAAAAaw5GQAAAAABu8vRAAAAAAHKyuEAAAAAAdnJ8QAAAAAB6MkBAAAAAAH3yBEAAAAAAgbHIQAAAAACFcYxAAAAAAIkxUEAAAAAAjPEUQAAAAACQsNhAAAAAAJRwnEAAAAAAmDBgQAAAAACcFQ5AAAAAAJ/U0kAAAAAAo5SWQAAAAACnVFpAAAAAAKsUHkAAAAAArtPiQAAAAACyk6ZAAAAAALZTakAAAAAAuhMuQAAAAAC90vJAAAAAAMGStkAAAAAAxXdkQAQMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCBQQFBAUGAgYEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUAAAIxAAAAAAIxAAQAAA4QAQgAAAAAAA0AAA4QABEAABwgARUAABwgARpMTVQAUE1UAFdFU1QAV0VUAENFVABDRVNUAFdFTVQACkNFVC0xQ0VTVCxNMy41LjAsTTEwLjUuMC8zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABOAAAACwAAACb/////VrbAx/////+bXx7H/////50+8nn/////niru+f////+e9zlp/////5+EV/n/////oNhs6f////+hADmA/////6E8pkD/////pBBtwP////+kPTKw/////6UVaLD/////pT0DwP////+nHkVQ/////7WkGWAAAAAAFSen0AAAAAAWGNxAAAAAABcI21AAAAAAF/oPwAAAAAAY6g7QAAAAABnbQ0AAAAAAGsyT0AAAAAAbvKDwAAAAAByskfAAAAAAHZyC8AAAAAAejHPwAAAAAB98ZPAAAAAAIGxV8AAAAAAhXEbwAAAAACJMN/AAAAAAIzwo8AAAAAAkLBnwAAAAACUcCvAAAAAAJgv78AAAAAAnBSdwAAAAACf1GHAAAAAAKOUXgAAAAAApeL+AAAAAACnU+nAAAAAAKsTrcAAAAAArtNxwAAAAACykzXAAAAAALZS+cAAAAAAuhK9wAAAAAC90oHAAAAAAMGSRcAAAAAAxXbzwAAAAADJyl/AAAAAAMz2e8AAAAAA0UnnwAAAAADUdgPAAAAAANjJb8AAAAAA2/WLwAAAAADgbeHAAAAAAON1E8AAAAAA5+1pwAAAAADq9JvAAAAAAO9s8cAAAAAA8pkNwAAAAAD27HnAAAAAAPoYlcAAAAAA/mwBwAAAAAEBmB3AAAAAAQYQc8AAAAABCRelwAAAAAENj/vAAAAAARCXLcAAAAABFQ+DwAAAAAEYFrXAAAAAARyPC8AAAAABH7snwAAAAAEkDpPAAAAAASc6r8AAAAABK44bwAAAAAEuujfAAAAAATMyjcAAAAABNjm/wAAAAAFRMHWABAwIDBAIEBQYFBwUGCAYFBgUGBQYFBgUGBQYFBgUGBQYFBgkIBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGBQYFBgUGCgYAACM5AAAAACM5AAQAADGHAQgAACN3AAQAAD+XAQwAADhAAREAACowABUAAEZQARkAABwgAB0AACowASEAADhAABVMTVQATU1UAE1TVABNRFNUAE1TRABNU0sAKzA1AEVFVABFRVNUAApNU0stMwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1AAAACQAAACb/////VrbNXv////+euYf+/////5+Ejv7/////oIhGfv////+gy4L+/////63n8d7/////yK9kYP/////KYmVQ/////8znSxD/////zakXkP/////OokMQ/////8+SNBD/////0IIlEP/////QkIlwAAAAABUnp9AAAAAAFhjcQAAAAAAXCNtQAAAAABf6D8AAAAAAGOoO0AAAAAAZ20NAAAAAABrMk9AAAAAAG7yg8AAAAAAcrJHwAAAAAB2cgvAAAAAAHoxz8AAAAAAffGTwAAAAACBsVfAAAAAAIVxG8AAAAAAiTDfwAAAAACM8KPAAAAAAJCwZ8AAAAAAlHBkAAAAAACYMCgAAAAAAJwU1gAAAAAAn9SaAAAAAACjlF4AAAAAAKdUIgAAAAAAqxPmAAAAAACu06oAAAAAALKTbgAAAAAAtlMyAAAAAAC6EvYAAAAAAL3SugAAAAAAwZJ+AAAAAADFdywAAAAAAMk28AAAAAAAzPbsQAAAAADRSlhAAAAAANR2dEAAAAAA2MngQAAAAADb9fxAAAAAAOBuUkAAAAAA6UP3gAQIBAgEDBAYFBgUGBQQHBAcEBwQHBAcEBwQHBAcECAMIAwgDCAMIAwgDCAMIAwgDCAMIAwMAABaiAAAAABaiAAQAACSyAQgAABwgAAwAACowABAAAA4QABQAABwgARgAADhAAR0AACowASFMTVQAUk1UAExTVABFRVQATVNLAENFVABDRVNUAE1TRABFRVNUAApFRVQtMkVFU1QsTTMuNS4wLzMsTTEwLjUuMC80Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABXAAAABAAAABH/////PijoTP////9wvIFw/////5s4+HD/////m9XM4P////+cxcvw/////523AGD/////non+cP////+foBzg/////6BgpfD/////oX6tYP////+iXDdw/////6NMGmD/////yGw18P/////M50sQ/////82pF5D/////zqJDEP/////PkjQQ/////9BuXpD/////0XIWEP/////STNLw/////9M+MZD/////1EnSEP/////VHfdw/////9Ypl/D/////1uuAkP/////YCZYQ//////kztfD/////+dnE4P/////7HNJw//////u5tPD//////Py0cP/////9mZbw//////7l0PD//////4KzcAAAAAAAxbLwAAAAAAFilXAAAAAAApxacAAAAAADQndwAAAAAASFdvAAAAAABSuT8AAAAAAGbpNwAAAAAAcLdfAAAAAACEU68AAAAAAI61fwAAAAAAouV3AAAAAACss58AAAAAAMDjlwAAAAAAyrG/AAAAAADeTg8AAAAAAOiv3wAAAAAA/N/XAAAAAAEHQacAAAAAARrd9wAAAAABJT/HAAAAAAE01EEAAAAAAUM/qQAAAAABUj65AAAAAAFhPckAAAAAAXA82QAAAAABfzvpAAAAAAGOOvkAAAAAAZ06CQAAAAABrDkZAAAAAAG7y9EAAAAAAcrK4QAAAAAB2cnxAAAAAAHoyQEAAAAAAffIEQAAAAACBschAAAAAAIVxjEAAAAAAiTFQQAAAAACM8RRAAAAAAJCw2EAAAAAAlHCcQAAAAACYMGBAAAAAAJwVDkAAAAAAn9TSQAAAAACjlJZAAAAAAKdUWkAAAAAAqxQeQAAAAACu0+JAAAAAALKTpkAAAAAAtlNqQAAAAAC6Ey5AAAAAAL3S8kAAAAAAwZK2QAAAAADFd2RABAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIAAAu0AAAAAAu0AAQAABwgAQgAAA4QAA1MTVQAUk1UAENFU1QAQ0VUAApDRVQtMUNFU1QsTTMuNS4wLE0xMC41LjAvMwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAABgAAABD/////oQA5gP////+1pAtQAAAAABUnmcAAAAAAFhjOMAAAAAAXCM1AAAAAABf6AbAAAAAAGOoAwAAAAAAZ2zUwAAAAABrMhcAAAAAAG7yS4AAAAAAcrIPgAAAAAB2cdOAAAAAAHoxl4AAAAAAffFbgAAAAACBsR+AAAAAAIVw44AAAAAAiTCngAAAAACM8GuAAAAAAJCwL4AAAAAAlHArwAAAAACYL+/AAAAAAJwUncAAAAAAn9RhwAAAAACjlF4AAAAAAKQDHAAAAAAAp1OxgAAAAACrE3WAAAAAAK7TOYAAAAAAspL9gAAAAAC2UsGAAAAAALoShYAAAAAAvdJJgAAAAADBkg2AAAAAAMV2u4AAAAAAycongAAAAADM9kOAAAAAANFJr4AAAAAA1HXLgAAAAADYyTeAAAAAANv1U4AAAAAA4G2pgAAAAADjdNuAAAAAAOftMYAAAAAA6vRjgAAAAADvbLmAAAAAAPKY1YAAAAAA9uxBgAAAAAD6GF2AAAAAAP5ryYAAAAABAZflgAAAAAEGEDuAAAAAAQkXbYAAAAABDY/DgAAAAAEQlvWAAAAAARUPS4AAAAABGBZ9gAAAAAEcjtOAAAAAAR+674AAAAABJA5bgAAAAAEnOneAAAAAASuN44AAAAABLrn/gAAAAAEzMo3AAAAAATY5v8AECAwIDAgMCAwIDAgMCAwIDAgQBBAEFAQIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIEAQIAAC70AAAAACowAAQAADhAAAgAAEZQAQwAADhAAQgAACowAQRMTVQAKzAzACswNAArMDUACjwrMDQ+LTQK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAABQAAABD/////oQA5gP////+1pAtQAAAAABUnmcAAAAAAFhjOMAAAAAAXCM1AAAAAABf6AbAAAAAAGOoAwAAAAAAZ2zUwAAAAABrMhcAAAAAAG7yS4AAAAAAcrIPgAAAAAB2cdOAAAAAAHoxl4AAAAAAffFbgAAAAACBsR+AAAAAAIVw44AAAAAAiTCngAAAAACM8KPAAAAAAJCwZ8AAAAAAlHArwAAAAACYL+/AAAAAAJwUncAAAAAAn9RhwAAAAACnU7GAAAAAAKsTrcAAAAAArtNxwAAAAACykzXAAAAAALZS+cAAAAAAuhK9wAAAAAC90oHAAAAAAMGSRcAAAAAAxXbzwAAAAADJyl/AAAAAAMz2e8AAAAAA0UnnwAAAAADUdgPAAAAAANjJb8AAAAAA2/WLwAAAAADgbeHAAAAAAON1E8AAAAAA5+1pwAAAAADq9JvAAAAAAO9s8cAAAAAA8pkNwAAAAAD27HnAAAAAAPoYlcAAAAAA/mwBwAAAAAEBmB3AAAAAAQYQc8AAAAABCRelwAAAAAENj/vAAAAAARCXLcAAAAABFQ+DwAAAAAEYFrXAAAAAARyPC8AAAAABH7snwAAAAAEkDpPAAAAAASc6r8AAAAABK44bwAAAAAEuujfAAAAAATMyjcAAAAABNjm/wAAAAAFRMHWAAAAAAWENOcAEDAgMCAwIDAgMCAwIDAgMEAQQBBAEDBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEDAQMAACsyAAAAACowAAQAAEZQAQgAADhAAAwAADhAAQxMTVQAKzAzACswNQArMDQACjwrMDQ+LTQK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABLAAAACQAAACL/////VrbECP////+qGaQg/////7WkGWD/////ywSN0P/////M50sQ/////82pF5D/////zqJDEP/////PkjQQ/////8+fOOAAAAAAFSen0AAAAAAWGNxAAAAAABcI21AAAAAAF/oPwAAAAAAY6g7QAAAAABnbQ0AAAAAAGsyT0AAAAAAbvKDwAAAAAByskfAAAAAAHZyC8AAAAAAejHPwAAAAAB98ZPAAAAAAIGxV8AAAAAAhXEbwAAAAACJMN/AAAAAAIzwo8AAAAAAkLBnwAAAAACUcCvAAAAAAJo0u8AAAAAAp1QiAAAAAACrE+YAAAAAAK7TqgAAAAAAspNuAAAAAAC2UzIAAAAAALcLG0AAAAAAuhK9wAAAAAC90oHAAAAAAMGSRcAAAAAAxXaDQAAAAADJypgAAAAAAMz27EAAAAAA0UpYQAAAAADUdnRAAAAAANjJ4EAAAAAA2/X8QAAAAADgblJAAAAAAON1hEAAAAAA5+3aQAAAAADq9QxAAAAAAO9tYkAAAAAA8pl+QAAAAAD27OpAAAAAAPoZBkAAAAAA/mxyQAAAAAEBmI5AAAAAAQYQ5EAAAAABCRgWQAAAAAENkGxAAAAAARCXnkAAAAABFQ/0QAAAAAEYFyZAAAAAARyPfEAAAAABH7uYQAAAAAEkDwRAAAAAASc7IEAAAAABK46MQAAAAAEuuqhAAAAAATMy/kAAAAABNjowQAAAAAE6soZAAAAAAT25uEAAAAABQjIOQAAAAAFFXipAAAAAAUmxlkAAAAABTN16AAAAAAFRMHWABAgMFBAUEBQMGAwYDBgMGAwYDBgMGAwYDBgMCBwIHAgcGAwYDBgMHAgcCBwIHAgcCBwIHAgcCBwIHAgcCBwIHAgcCBwIHAgcCCAMAAB/4AAAAAB/gAAQAABwgAAgAACowAAwAAA4QABAAABwgARQAADhAARkAACowAR0AADhAAAxMTVQAU01UAEVFVABNU0sAQ0VUAENFU1QATVNEAEVFU1QACk1TSy0zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtAAAABgAAABr/////VrbOJP////9yw+MY/////8znSxD/////zakXkP/////OokMQ/////8+SNBD/////0IIlEP/////RciQgAAAAABFj71AAAAAAElU/4AAAAAATTQvQAAAAABQ1IeAAAAAAFSzt0AAAAAAWE8BwAAAAABcMz9AAAAAAF/OwgAAAAAAY46GAAAAAABnTkoAAAAAAGsODgAAAAAAbvK8AAAAAABysoAAAAAAAHZyRAAAAAAAejIIAAAAAAB98cwAAAAAAIGxkAAAAAAAhXFUAAAAAACJMRgAAAAAAIzw3AAAAAAAkLCgAAAAAACUcGQAAAAAAJgwKAAAAAAAnBTWAAAAAACf1CmAAAAAAKOTtUAAAAAAp1OxgAAAAACrEz1AAAAAAK7TOYAAAAAAspLFQAAAAAC2UsGAAAAAALoSTUAAAAAAvdJJgAAAAADBkdVAAAAAAMV2u4AAAAAAycnvQAAAAADLJjOABAgMEAwQDAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgUCBQIFAgIAABXcAAAAABtoAAQAABwgAAgAAA4QAAwAABwgARAAACowARVMTVQASU1UAEVFVABDRVQAQ0VTVABFRVNUAApFRVQtMkVFU1QsTTMuNS4wLzMsTTEwLjUuMC80Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0AAAACAAAACL/////VrbMzP////+eWS3M/////565kJD/////n4SXkP////+hACtw/////6Rzb0z/////yLC14P/////KxpdQ/////8znSxD/////zakXkP/////OokMQ/////8+SNBD/////0HTL4AAAAAAVJ6fQAAAAABYY3EAAAAAAFwjbUAAAAAAX+g/AAAAAABjqDtAAAAAAGdtDQAAAAAAazJPQAAAAABu8oPAAAAAAHKyR8AAAAAAdnILwAAAAAB6Mc/AAAAAAH3xk8AAAAAAgbFXwAAAAACFcRvAAAAAAIkw38AAAAAAjPCjwAAAAACQsGfAAAAAAJRwZAAAAAAAmDAoAAAAAACcFNYAAAAAAJ/UmgAAAAAAo5ReAAAAAACnVCIAAAAAAKsT5gAAAAAArtOqAAAAAACyk24AAAAAALZTMgAAAAAAuhL2AAAAAAC90roAAAAAAMGSfgAAAAAAxXcsAAAAAADJypgAAAAAAMz2tAAAAAAA0UogAAAAAADUdjwAAAAAANjJ4EAAAAAA2/X8QAAAAADgblJAAAAAAPHQcYAEDAgMBBAUCAwIDAgUGBQYFBgUGBQYFBgUGBQYFBwQHBAcEBwQHBAcEBwQHBAcEBwQHBAQAABc0AAAAABc0AAQAABwgAQgAAA4QAA0AABwgABEAACowABUAADhAARkAACowAR1MTVQAVE1UAENFU1QAQ0VUAEVFVABNU0sATVNEAEVFU1QACkVFVC0yRUVTVCxNMy41LjAvMyxNMTAuNS4wLzQK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAyAAAAAwAAAA3/////lqo0aP/////IbYdw/////8znSxD/////zakXkP/////NuOmQAAAAAAgoOfAAAAAACO8+YAAAAAAKBXjwAAAAAArQceAAAAAAC+lPcAAAAAAMtEhgAAAAAA3Sa/AAAAAADpQqYAAAAAAPsPxwAAAAABB0DGAAAAAAEZDecAAAAAASU+5gAAAAABNwwHAAAAAAFDu5YAAAAAAVSLlwAAAAABYTsmAAAAAAFzHV8AAAAAAX/M7gAAAAABkAlHAAAAAAGdtfYAAAAAAazK/wAAAAABu8vRAAAAAAHKyuEAAAAAAdnJ8QAAAAAB6MkBAAAAAAH3yBEAAAAAAgbHIQAAAAACFcYxAAAAAAIkxUEAAAAAAjPEUQAAAAACQsNhAAAAAAJRwnEAAAAAAmDBgQAAAAACcFQ5AAAAAAJ/U0kAAAAAAo5SWQAAAAACnVFpAAAAAAKsUHkAAAAAArtPiQAAAAACyk6ZAAAAAALZTakAAAAAAuhMuQAAAAAC90vJAAAAAAMGStkAAAAAAxXdkQAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIAABKYAAAAAA4QAAQAABwgAQhMTVQAQ0VUAENFU1QACkNFVC0xQ0VTVCxNMy41LjAsTTEwLjUuMC8zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABCAAAABwAAABT/////oQA5gP////+1pAtQAAAAABUnmcAAAAAAFhjOMAAAAAAXCM1AAAAAABf6AbAAAAAAGOoAwAAAAAAZ2zUwAAAAABrMhcAAAAAAG7yS4AAAAAAcrIPgAAAAAB2cdOAAAAAAHoxl4AAAAAAffFbgAAAAACBsR+AAAAAAIVw44AAAAAAiTCngAAAAACM8GuAAAAAAJCwL4AAAAAAlHArwAAAAACYL+/AAAAAAJwUncAAAAAAn9RhwAAAAACjlF4AAAAAAKXi/gAAAAAAp1PpwAAAAACrE63AAAAAAK7TccAAAAAAspM1wAAAAAC2UvnAAAAAALoSvcAAAAAAvdKBwAAAAADBkkXAAAAAAMV288AAAAAAycpfwAAAAADM9nvAAAAAANFJ58AAAAAA1HYDwAAAAADYyW/AAAAAANv1i8AAAAAA4G3hwAAAAADjdRPAAAAAAOftacAAAAAA6vSbwAAAAADvbPHAAAAAAPKZDcAAAAAA9ux5wAAAAAD6GJXAAAAAAP5sAcAAAAABAZgdwAAAAAEGEHPAAAAAAQkXpcAAAAABDY/7wAAAAAEQly3AAAAAARUPg8AAAAABGBa1wAAAAAEcjwvAAAAAAR+7J8AAAAABJA6TwAAAAAEnOq/AAAAAASuOG8AAAAABLro3wAAAAAEzMo3AAAAAATY5v8AAAAABUTB1gAAAAAFb3FHABAwIDAgMCAwIDAgMCAwIDAgMEAQQBBQYBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEEAQQBBAEDAQMAAC1gAAAAACowAAQAAEZQAQgAADhAAAwAADhAAQwAACowAQQAABwgABBMTVQAKzAzACswNQArMDQAKzAyAAo8KzA0Pi00Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4AAAAAwAAAA3/////b6JfL/////+bDBdg/////5vV2vD/////nNmukP////+dpLWQ/////565kJD/////n4SXkP////+icBoQ/////6NEW5D/////yAlxkP/////M50sQ/////82pF5D/////zqJDEP/////PkjQQ/////9CCJRD/////0XIWEP/////Rf0UQ/////9NjG5D/////1EsjkP/////VOcMQ/////9YptBD/////1ywaEP/////YCZYQAAAAABNNJ/AAAAAAFDPQYAAAAAAVI+uQAAAAABYT3JAAAAAAFwPNkAAAAAAX876QAAAAABjjr5AAAAAAGdOgkAAAAAAaw5GQAAAAABu8vRAAAAAAHKyuEAAAAAAdnJ8QAAAAAB6MkBAAAAAAH3yBEAAAAAAgbHIQAAAAACFcYxAAAAAAIkxUEAAAAAAjPEUQAAAAACQsNhAAAAAAJRwnEAAAAAAmDBgQAAAAACcFQ5AAAAAAJ/U0kAAAAAAo5SWQAAAAACnVFpAAAAAAKsUHkAAAAAArtPiQAAAAACyk6ZAAAAAALZTakAAAAAAuhMuQAAAAAC90vJAAAAAAMGStkAAAAAAxXdkQAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgEAAA9RAAAAABwgAQQAAA4QAAlMTVQAQ0VTVABDRVQACkNFVC0xQ0VTVCxNMy41LjAsTTEwLjUuMC8zCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzAAAACQAAACb/////VrbMRP////+cTx9Q/////6GFSpj/////ovEw8P////+jZnhg/////8isz3D/////ylkq0P/////M50sQ/////82pF5D/////zqJDEP/////PkjQQ/////9AwPeAAAAAAFSen0AAAAAAWGNxAAAAAABcI21AAAAAAF/oPwAAAAAAY6g7QAAAAABnbQ0AAAAAAGsyT0AAAAAAbvKDwAAAAAByskfAAAAAAHZyC8AAAAAAejHPwAAAAAB98ZPAAAAAAIGxV8AAAAAAhXEbwAAAAACJMN/AAAAAAIzwo8AAAAAAkLBnwAAAAACUcGQAAAAAAJgwKAAAAAAAnBTWAAAAAACf1JoAAAAAAKOUXgAAAAAAp1QiAAAAAACrE+YAAAAAAK7TqgAAAAAAspNuAAAAAAC2UzIAAAAAALoS9gAAAAAAvdK6AAAAAADBkn4AAAAAAMV3LAAAAAAAycqYAAAAAADM9rQAAAAAANFKIAAAAAAA1HZ0QAAAAADYyeBAAAAAANv1/EAAAAAA4G5SQAAAAAD4SE2ABAgMEAwUGAwYDBgUHBQcFBwUHBQcFBwUHBQcFCAQIBAgECAQIBAgECAQIBAgEBgMGBAQAABe8AAAAABOwAAQAABZoAAgAAA4QAAwAABwgABAAACowABQAABwgARgAADhAAR0AACowASFMTVQAV01UAEtNVABDRVQARUVUAE1TSwBDRVNUAE1TRABFRVNUAApFRVQtMkVFU1QsTTMuNS4wLzMsTTEwLjUuMC80Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBAAAABwAAABj/////ofVG3P////+1pAtQAAAAABUnmcAAAAAAFhjOMAAAAAAXCM1AAAAAABf6AbAAAAAAGOoAwAAAAAAZ2zUwAAAAABrMhcAAAAAAG7yS4AAAAAAcrIPgAAAAAB2cdOAAAAAAHoxl4AAAAAAffFbgAAAAACBsR+AAAAAAIVw44AAAAAAiTCngAAAAACM8KPAAAAAAJCwZ8AAAAAAlHArwAAAAACYL+/AAAAAAJwUncAAAAAAn9RhwAAAAACnU7GAAAAAAKsTrcAAAAAArtNxwAAAAACykzXAAAAAALZS+cAAAAAAuhK9wAAAAAC90oHAAAAAAMGSRcAAAAAAxXbzwAAAAADJyl/AAAAAAMz2e8AAAAAA0UnnwAAAAADUdgPAAAAAANjJb8AAAAAA2/WLwAAAAADgbeHAAAAAAON1E8AAAAAA5+1pwAAAAADq9JvAAAAAAO9s8cAAAAAA8pkNwAAAAAD27HnAAAAAAPoYlcAAAAAA/mwBwAAAAAEBmB3AAAAAAQYQc8AAAAABCRelwAAAAAENj/vAAAAAARCXLcAAAAABFQ+DwAAAAAEYFrXAAAAAARyPC8AAAAABH7snwAAAAAEkDpPAAAAAASc6r8AAAAABK44bwAAAAAEuujfAAAAAATMyjcAAAAABNjm/wAAAAAFRMHWAAAAAAW9Tt8AAAAABf57JgAQIDAgMCAwIDAgMCAwIDAgQFBAUEBQIEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQQFBAUEBQYFAgUAACmkAAAAACowAAQAADhAAAgAAEZQAQwAADhAARAAACowABQAADhAABRMTVQAKzAzACswNAArMDUATVNEAE1TSwAKTVNLLTMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABSAAAABgAAABr/////VrbQUP////+ZqCrQ/////5sMF2D/////m9Xa8P////+c2a6Q/////52ktZD/////nrmQkP////+fhJeQ/////6CatgD/////oWW9AP////+mfXxg/////8h23hD/////zOdLEP/////NqReQ/////86iQxD/////z5I0EP/////QhLoA/////9GVknD/////0oq7YP/////TYv9w/////9RLI5D/////1V6tEP/////WKbQQ/////9csGhD/////2AmWEP/////ZAsGQ/////9npeBD/////6FTSAP/////o8bSA/////+nhpYD/////6tGWgP/////sFJYA/////+y6swD/////7aqkAP/////umpUA/////+/UWgD/////8Hp3AP/////xtDwA//////JaWQD/////85QeAP/////0OjsA//////V9OoD/////9hodAAAAAAANpFWAAAAAAA6LDAAAAAAAD4Q3gAAAAAAQdCiAAAAAABFkGYAAAAAAElQKgAAAAAATTTYAAAAAABQz7IAAAAAAFSPdgAAAAAAWE86AAAAAABcDv4AAAAAAF/OwgAAAAAAY46GAAAAAABnTkoAAAAAAGsODgAAAAAAbvK8AAAAAABysoAAAAAAAHZyRAAAAAAAejIIAAAAAAB98cwAAAAAAIGxkAAAAAAAhXFUAAAAAACJMVBAAAAAAIzxFEAAAAAAkLDYQAAAAACUcJxAAAAAAJgwYEAAAAAAnBUOQAAAAACf1NJAAAAAAKOUlkAAAAAAp1RaQAAAAACrFB5AAAAAAK7T4kAAAAAAspOmQAAAAAC2U2pAAAAAALoTLkAAAAAAvdLyQAAAAADBkrZAAAAAAMV3ZEAEDAgMCAwIFBAUDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIAABOwAAAAABOwAAQAABwgAQgAAA4QAA0AACowAREAABwgABZMTVQAV01UAENFU1QAQ0VUAEVFU1QARUVUAApDRVQtMUNFU1QsTTMuNS4wLE0xMC41LjAvMwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAAABgAAABT/////dOBwvv////+7BUNI/////7shcVj/////y4k9yP/////SI/Rw/////9JhSTj/////1Y1zSAECAQMEAQX//2wCAAD//2xYAAT//3poAQj//3poAQz//3poARD//3NgAARMTVQASFNUAEhEVABIV1QASFBUAApIU1QxMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAwAAAAz/////iX73nAAAAAAw5t2wAQIAAEPkAAAAAEZQAAQAAFRgAAhMTVQAKzA1ACswNgAKPCswNj4tNgo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAwAAAAz/////VrafGP/////tL8OYAQIAAEToAAAAAEToAAQAAEZQAAhMTVQATU1UACswNQAKPCswNT4tNQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAwAAAAz/////iX8FmAAAAAAYBe1AAAAAABjbcjAAAAAASQOW4AAAAABJzo/QAgECAQIAADXoAAAAAEZQAQQAADhAAAhMTVQAKzA1ACswNAAKPCswND4tNAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGAAAABgAAABj/////fjYYIP/////B7TXQ/////8nqCmD/////z0aB8P//////hhtQAAAAACx2DkABAgMBBAUAAJzgAAAAAJqwAAQAAIygAAgAAH6QAAz//1dAABAAAKjAABRMTVQAKzExACsxMAArMDkALTEyACsxMgAKPCsxMj4tMTIK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABXAAAAAgAAAAj/////nqY6kP////+fuweA/////6CGHJD/////oZrpgP/////LiQyQ/////9JhGAD/////+vh1EP/////76FgA//////zYVxD//////cg6AP/////+uDkQ//////+oHAAAAAAAAJgbEAAAAAABh/4AAAAAAAJ3/RAAAAAAA3EagAAAAAAEYRmQAAAAAAVQ/IAAAAAABkD7kAAAAAAHMN6AAAAAAAeNNZAAAAAACRDAgAAAAAAJrbEQAAAAAArwooAAAAAAC+ChkAAAAAAM2b8AAAAAAA3Ag5AAAAAADrmhAAAAAAAPqaAQAAAAABCZgwAAAAAAEYmCEAAAAAASeWUAAAAAABNpZBAAAAAAFFlHAAAAAAAVSUYQAAAAABY5KQAAAAAAFykoEAAAAAAYIkWAAAAAABkJChAAAAAAGgIngAAAAAAa8iaQAAAAABviCYAAAAAAHNIIkAAAAAAdweuAAAAAAB6x6pAAAAAAH6HNgAAAAAAgdh0QAAAAACGBr4AAAAAAIlX/EAAAAAAjaswAAAAAACQ14RAAAAAAJUquAAAAAAAmFcMQAAAAACcqkAAAAAAAJ/7fkAAAAAApCnIAAAAAACnewZAAAAAAKupUAAAAAAArvqOQAAAAACzTcIAAAAAALZ6FkAAAAAAus1KAAAAAAC9+Z5AAAAAAMJM0gAAAAAAxZ4QQAAAAADJzFoAAAAAAM0dmEAAAAAA0UviAAAAAADUnSBAAAAAANjLagAAAAAA3ByoQAAAAADgb9wAAAAAAOOcMEAAAAAA5+9kAAAAAADrG7hAAAAAAO9u7AAAAAAA8sAqQAAAAAD27nQAAAAAAPo/skAAAAAA/m38AAAAAAEBvzpAAAAAAQYSbgAAAAABCT7CQAAAAAENkfYAAAAAARC+SkAAAAABFRF+AAAAAAEXzxRABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAH//52QAAT//6ugAQBNRFQATVNUAApNU1Q3TURULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABFAAAABAAAABb/////QbdEhP/////S2pa8AAAAAAkY/eAAAAAACayl4AAAAAAK76VgAAAAAAue/OAAAAAADNjB4AAAAAANft7gAAAAAA64o+AAAAAAD17A4AAAAAAQmIXgAAAAABE+ouAAAAAAEnhn4AAAAAATHoTgAAAAABRYSeAAAAAAFP5m4AAAAAAWOCvgAAAAABbng2AAAAAAGCFIYAAAAAAYx2VgAAAAABoBKmAAAAAAGqdHYAAAAAAb4QxgAAAAAByHKWAAAAAAHcDuYAAAAAAeZwtgAAAAAB+g0GAAAAAAIEbtYAAAAAAhgLJgAAAAACIwCeAAAAAAI2nO4AAAAAAkD+vgAAAAACUuAWAAAAAAJgJC4AAAAAAnDeNgAAAAACfiJOAAAAAAKO3FYAAAAAApwgbgAAAAACrNp2AAAAAAK6sjYAAAAAAsrYlgAAAAAC2LBWAAAAAALo1rYAAAAAAvaudgAAAAADBtTWAAAAAAMUrJYAAAAAAyVmngAAAAADMqq2AAAAAANDZL4AAAAAA1Co1gAAAAADYWLeAAAAAANvOp4AAAAAA39g/gAAAAADjTi+AAAAAAOdXx4AAAAAA6s23gAAAAADu/DmAAAAAAPJNP4AAAAAA9nvBgAAAAAD5zMeAAAAAAP37SYAAAAABAXE5gAAAAAEFetGAAAAAAQjwwYAAAAABDPpZgAAAAAEQcEmAAAAAARR54YAAAAABF+/RgAAAAAEb+WmABAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIDAgMCAwIAAKv8AAAAAKxEAAQAAMFcAQoAALNMABBMTVQAKzEyMTUAKzEzNDUAKzEyNDUACjwrMTI0NT4tMTI6NDU8KzEzNDU+LE05LjUuMC8yOjQ1LE00LjEuMC8zOjQ1Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABXAAAAAgAAAAj/////nqZIoP////+fuxWQ/////6CGKqD/////oZr3kP/////LiRqg/////9JhJhD/////+viDIP/////76GYQ//////zYZSD//////chIEP/////+uEcg//////+oKhAAAAAAAJgpIAAAAAABiAwQAAAAAAJ4CyAAAAAAA3EokAAAAAAEYSegAAAAAAVRCpAAAAAABkEJoAAAAAAHMOyQAAAAAAeNQ6AAAAAACRDOkAAAAAAJrb8gAAAAAArwsJAAAAAAC+CvoAAAAAAM2c0QAAAAAA3AkaAAAAAADrmvEAAAAAAPqa4gAAAAABCZkRAAAAAAEYmQIAAAAAASeXMQAAAAABNpciAAAAAAFFlVEAAAAAAVSVQgAAAAABY5NxAAAAAAFyk2IAAAAAAYIlOQAAAAABkJGCAAAAAAGgI1kAAAAAAa8jSgAAAAABviF5AAAAAAHNIWoAAAAAAdwfmQAAAAAB6x+KAAAAAAH6HbkAAAAAAgdisgAAAAACGBvZAAAAAAIlYNIAAAAAAjatoQAAAAACQ17yAAAAAAJUq8EAAAAAAmFdEgAAAAACcqnhAAAAAAJ/7toAAAAAApCoAQAAAAACnez6AAAAAAKupiEAAAAAArvrGgAAAAACzTfpAAAAAALZ6ToAAAAAAus2CQAAAAAC9+daAAAAAAMJNCkAAAAAAxZ5IgAAAAADJzJJAAAAAAM0d0IAAAAAA0UwaQAAAAADUnViAAAAAANjLokAAAAAA3BzggAAAAADgcBRAAAAAAOOcaIAAAAAA5++cQAAAAADrG/CAAAAAAO9vJEAAAAAA8sBigAAAAAD27qxAAAAAAPo/6oAAAAAA/m40QAAAAAEBv3KAAAAAAQYSpkAAAAABCT76gAAAAAENki5AAAAAARC+goAAAAABFRG2QAAAAAEXz0yABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAH//4+AAAT//52QAQBQRFQAUFNUAApQU1Q4UERULE0zLjIuMCxNMTEuMS4wCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAaAAAABwAAABr/////bj3JAP////+RBfwA/////9piBDgAAAAATJ8nsAAAAABNlyvgAAAAAE594mAAAAAATv2LoAAAAABPdw3gAAAAAFBm/uAAAAAAUWAqYAAAAABSRuDgAAAAAFNADGAAAAAAVCbC4AAAAABVH+5gAAAAAFYGpOAAAAAAVv/QYAAAAABX5obgAAAAAFjfsmAAAAAAWcZo4AAAAABav5RgAAAAAFuvhWAAAAAAXKiw4AAAAABdj2dgAAAAAF6IkuAAAAAAX29JYAAAAABgaHTgAQIEAwQDBgUGBQYFBgUGBQYFBgUGBQYFBgUAALCAAAD//18AAAD//15IAAT//3NgAQr//2VQAA4AALbQABIAAMTgARZMTVQALTExMzAALTEwAC0xMQArMTMAKzE0AAo8KzEzPi0xMwo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAABQAAABX/////VrZSKP////9y7aSQ/////8xDNmD/////0its8AAAAABUnteAAQIDAgQAAJHYAAAAAInwAAQAAIygAAkAAH6QAA0AAJqwABFMTVQAUE1NVAArMTAAKzA5ACsxMQAKPCsxMT4tMTEK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXAAAAAwAAAAz/////kvXCtAAAAAAHeZlAAAAAAAf6zEAAAAAAGdL30AAAAAAawtrAAAAAABuy2dAAAAAAHKK8wAAAAAAdm/ZQAAAAAB6CnsAAAAAAH3vYUAAAAAAga7tAAAAAACFbulAAAAAAIkudQAAAAAAjO5xQAAAAACQrf0AAAAAAJRt+UAAAAAAmC2FAAAAAACb7YFAAAAAAJ+tDQAAAAAAo5HzQAAAAACmBUUAAAAAAKulI0AAAAAArYTNAAgECAQIBAgECAQIBAgECAQIBAgECAQIAAJ3MAAAAAKjAAQQAAJqwAAhMTVQAKzEyACsxMQAKPCsxMT4tMTEK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAAAABAAAABD/////wyzbgAAAAAASVgTAAAAAAC8FObABAgMAAAAAAAD//1dAAAT//2VQAAgAALbQAAwtMDAALTEyAC0xMQArMTMACjwrMTM+LTEzCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAwAAAAz/////fjdViAAAAABO/ZmwAQL//194AAD//2VQAAQAALbQAAhMTVQALTExACsxMwAKPCsxMz4tMTMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdAAAAAwAAAAz/////mhOxwAAAAAA2OxfgAAAAADbX+mAAAAAAOCQ0YAAAAAA4t9xgAAAAAEsRLOAAAAAAS64PYAAAAABMwupgAAAAAE1yQeAAAAAATqLMYAAAAABPGsTgAAAAAFCCrmAAAAAAUPqm4AAAAABSa8rgAAAAAFLaetAAAAAAVFTnYAAAAABUumrgAAAAAFY0yWAAAAAAVppM4AAAAABYHeXgAAAAAFh6LuAAAAAAWf3H4AAAAABaWhDgAAAAAFvdqeAAAAAAXDny4AAAAABdxsZgAAAAAF4Z1OAAAAAAX94HYAAAAABgAvFgAgECAQIBAgECAQIBAgECAQIBAgECAQIBAgECAQIAAKfAAAAAALbQAQQAAKjAAAhMTVQAKzEzACsxMgAKPCsxMj4tMTIK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAgAAAAj/////fjYSzAEAAKI0AAAAAKjAAARMTVQAKzEyAAo8KzEyPi0xMgo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAABAAAAAz/////tqRMgAAAAAAeGMRQAAAAACsXCuAAAAAAK3H0UAEDAgP//6wAAAD//7mwAAT//7mwAQT//6ugAAhMTVQALTA1AC0wNgAKPC0wNj42Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAgAAAAj/////lFBIBAH//4F8AAD//4FwAARMTVQALTA5AAo8LTA5PjkK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAgAAAAj/////lE8zjAEAAJX0AAAAAJqwAARMTVQAKzExAAo8KzExPi0xMQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVAAAABgAAABX/////FOHFzP////9+Ni1M/////8s3leD/////0C6J8P/////sN74A/////+82+PD/////+5sAAP/////+PyeM//////8BHgD//////11Y8AAAAAAAlywAAAAAAAFGdXAAAAAAAncOAAAAAAADJldwAAAAAAdwlwAAAAAAB8zR8AAAAAAMCJEAAAAAAAx8hywAAAAADb+UgAAAAAAOZaNwAAAAADpDXmABAgMCBAIEAgQCBAIEAgQCBAIEAgX//zY0AAAAAIe0AAAAAIygAAQAAH6QAAgAAJqwAQwAAIygABBMTVQAR1NUACswOQBHRFQAQ2hTVAAKQ2hTVC0xMAo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAAAABAAAABL/////fjdIgAAAAAASVfIAAAAAAC8FK6ABAgP//2yAAAD//2oAAAT//3NgAAoAAMTgAA5MTVQALTEwNDAALTEwACsxNAAKPCsxND4tMTQK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJAAAABgAAABT/////FOG0tP////9+Nhw0/////5gRldD/////oDn58P/////B7TXQ/////8nqCmD/////0hEO8P//////hhtQAAAAADaLZ0ABAgMCBAMCBQL//0dMAAAAAJjMAAAAAJqwAAQAAH6QAAgAAIygAAwAAKjAABBMTVQAKzExACswOQArMTAAKzEyAAo8KzExPi0xMQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAgAAAAr/////lFBMSAH//304AAD//3poAARMTVQALTA5MzAACjwtMDkzMD45OjMwCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAwAAAAj/////bj3ICP////+RBfsIAQIAALF4AAD//1/4AAD//2VQAARMTVQAU1NUAApTU1QxMQo=",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAABAAAABL/////o+crBP/////MkOnI/////9JDJ/AAAAAAESGo6AECAQMAAJx8AAAAAKG4AAQAAH6QAAoAAKjAAA5MTVQAKzExMzAAKzA5ACsxMgAKPCsxMj4tMTIK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAwAAAA7/////36FqTP/////1prhgAQL//2C0AAD//2CgAAT//2VQAApMTVQALTExMjAALTExAAo8LTExPjExCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGAAAABQAAABr/////fjYXiP/////cQfiAAAAAAAkPymgAAAAACbXnaAAAAABWD+ZoAAAAAF0YslABAgMCBAQAAJ14AAAAAJ2AAAQAAKG4AAoAAK/IARAAAJqwABZMTVQAKzExMTIAKzExMzAAKzEyMzAAKzExAAo8KzExPi0xMTwrMTI+LE0xMC4xLjAsTTQuMS4wLzMK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAAAAwAAAAz/////kvXEdAAAAAAO5rpQAAAAAA9Wu8AAAAAAEMacUAAAAAARN+9AAAAAADKgS/AAAAAAMxhEcAIBAgECAQIAAJwMAAAAAKjAAQQAAJqwAAhMTVQAKzEyACsxMQAKPCsxMT4tMTEK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAwAAAAj/////FOHPbP////9+NjbsAQL//yyUAAAAAH4UAAAAAH6QAARMTVQAKzA5AAo8KzA5Pi05Cg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAwAAAA7/////fjcu9AAAAAA1REIIAQL//4YMAAD//4h4AAT//4+AAApMTVQALTA4MzAALTA4AAo8LTA4PjgK",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcAAAABQAAABT/////fEzcyP/////foWDIAAAAABCsGygAAAAAET+1GAAAAAASeYEgAAAAABMflxgAAAAAFFljIAAAAAAU/3kYAAAAABY5RSAAAAAAFuiVmAAAAAAYImGgAAAAABjId5gAAAAAGgJDoAAAAAAaqFmYAAAAABviJaAAAAAAHIg7mAAAAAAdwgegAAAAAB5oHZgAAAAAH6HpoAAAAAAgR/+YAAAAACGBy6AAAAAAIjEcGAAAAAAjauggAAAAACQQ/hgAAAAAJUrKIAAAAAAl8OAYAAAAACcqrCAAAAAAJ9DCGAECBAMEAwQDBAMEAwQDBAMEAwQDBAMEAwQDBAMAALu4AAD//2o4AAD//2xYAAT//3NgAAr//3poAQ5MTVQALTEwMzAALTEwAC0wOTMwAAo8LTEwPjEwCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAgAAAAj/////lFBVuAH//3PIAAD//3NgAARMTVQALTEwAAo8LTEwPjEwCg==",
    "VFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAAAAAAAVFppZjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKAAAABAAAABL/////0kWcQP/////vEeAQAAAAADf7R9AAAAAAONN90AAAAAA6BAhQAAAAADpyuEAAAAAAO+PqUAAAAAA8UppAAAAAAFgd19AAAAAAWHog0AECAwIDAgMCAwIAAK1AAAAAAK1wAAQAALbQAAoAAMTgAQ5MTVQAKzEyMjAAKzEzACsxNAAKPCsxMz4tMTMK"
  ]
};

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/date-engine/timezone-reader.js
var TimezoneDataUnavailable = class extends Error {
};
var decode = (bytes) => {
  if (bytes.some((byte) => byte > 127))
    throw new Error("Non-ASCII TZif text");
  return String.fromCharCode(...bytes);
};
function civil(year, month2 = 1, day = 1) {
  const date2 = /* @__PURE__ */ new Date(0);
  date2.setUTCFullYear(year, month2 - 1, day);
  return date2.getTime() / 1e3;
}
function clock(text) {
  const match = /^([+-]?)(\d{1,3})(?::([0-5]\d))?(?::([0-5]\d))?$/.exec(text);
  if (!match || Number(match[2]) > 167)
    throw new Error("Unsupported TZ clock: " + text);
  return (match[1] === "-" ? -1 : 1) * (+match[2] * 3600 + +(match[3] || 0) * 60 + +(match[4] || 0));
}
function rule(text) {
  const [date2, time = "2", extra] = text.split("/");
  if (extra !== void 0)
    throw new Error("Invalid transition rule");
  const seconds = clock(time);
  const month2 = /^M(\d{1,2})\.([1-5])\.([0-6])$/.exec(date2);
  if (month2) {
    const m2 = +month2[1], week = +month2[2], weekday = +month2[3];
    if (m2 < 1 || m2 > 12)
      throw new Error("Invalid rule month");
    return (year) => {
      const first = new Date(civil(year, m2) * 1e3).getUTCDay();
      let day = 1 + (weekday - first + 7) % 7 + (week - 1) * 7;
      if (day > new Date(civil(year, m2 + 1, 0) * 1e3).getUTCDate())
        day -= 7;
      return civil(year, m2, day) + seconds;
    };
  }
  const julian = /^(J?)(\d{1,3})$/.exec(date2);
  if (!julian)
    throw new Error("Unsupported transition rule: " + text);
  const n2 = +julian[2], ignoresLeap = julian[1] === "J";
  if (n2 < (ignoresLeap ? 1 : 0) || n2 > 365)
    throw new Error("Invalid Julian rule");
  return (year) => {
    const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
    return civil(year) + (n2 - (ignoresLeap ? 1 : 0) + (ignoresLeap && leap && n2 >= 60 ? 1 : 0)) * 86400 + seconds;
  };
}
function footer(text) {
  if (!text)
    return null;
  const name = "(?:<[A-Za-z0-9+-]{3,}>|[A-Za-z]{3,})";
  const offset = "([+-]?\\d{1,3}(?::[0-5]\\d){0,2})";
  const match = new RegExp("^" + name + offset + "(?:" + name + offset + "?,([^,]+),([^,]+))?$").exec(text);
  if (!match)
    throw new Error("Unsupported TZ footer: " + text);
  const standard = -clock(match[1]);
  if (!match[3])
    return {
      offsets: [standard],
      at: () => standard,
      events: (_year) => [],
      observances: [],
      isDaylight: (_seconds) => false
    };
  const daylight = match[2] === void 0 ? standard + 3600 : -clock(match[2]);
  const start = rule(match[3]), end = rule(match[4]);
  const eventsForYear = (year) => [
    [start(year) - standard, daylight],
    [end(year) - daylight, standard]
  ];
  let cachedYear;
  let cachedEvents = [];
  return {
    offsets: [standard, daylight],
    observances: [
      {
        rule: match[3],
        daylight: true,
        offsetFrom: standard,
        offsetTo: daylight,
        onset: (year) => start(year) - standard
      },
      {
        rule: match[4],
        daylight: false,
        offsetFrom: daylight,
        offsetTo: standard,
        onset: (year) => end(year) - daylight
      }
    ],
    events: eventsForYear,
    isDaylight(seconds) {
      return this.at(seconds) === daylight;
    },
    at(seconds) {
      const year = new Date(seconds * 1e3).getUTCFullYear();
      if (cachedYear !== year) {
        const events = [];
        for (let y2 = year - 1; y2 <= year + 1; y2++)
          events.push(...eventsForYear(y2));
        events.sort((a2, b2) => a2[0] - b2[0]);
        cachedEvents = events;
        cachedYear = year;
      }
      let result;
      for (const [instant, offset2] of cachedEvents)
        if (instant <= seconds)
          result = offset2;
      if (result === void 0)
        throw new Error("Missing future-rule state");
      return result;
    }
  };
}
function readZone(bytes) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const header = (at2, width) => {
    if (at2 + 44 > bytes.length || decode(bytes.subarray(at2, at2 + 4)) !== "TZif")
      throw new Error("Invalid TZif header");
    if (![50, 51, 52].includes(bytes[at2 + 4]))
      throw new Error("TZif v2+ required");
    const counts = Array.from({ length: 6 }, (_2, i2) => view.getUint32(at2 + 20 + i2 * 4));
    const [ut2, standard, leaps, times, types2, chars] = counts;
    const end = at2 + 44 + times * (width + 1) + types2 * 6 + chars + leaps * (width + 4) + ut2 + standard;
    if (end > bytes.length || types2 < 1 || types2 > 256 || leaps)
      throw new Error("Unsupported TZif block");
    return { at: at2 + 44, end, times, types: types2, chars };
  };
  const block = header(header(0, 4).end, 8);
  const transitions = [];
  for (let i2 = 0; i2 < block.times; i2++) {
    const value = Number(view.getBigInt64(block.at + i2 * 8));
    if (!Number.isSafeInteger(value) || i2 && value <= transitions[i2 - 1])
      throw new Error("Invalid transition ordering");
    transitions.push(value);
  }
  const indices = bytes.subarray(block.at + block.times * 8, block.at + block.times * 9);
  const typeAt = block.at + block.times * 9;
  const abbreviations = bytes.subarray(typeAt + block.types * 6, typeAt + block.types * 6 + block.chars);
  const types = Array.from({ length: block.types }, (_2, i2) => {
    const designation = bytes[typeAt + i2 * 6 + 5];
    const end = abbreviations.indexOf(0, designation);
    if (designation >= abbreviations.length || end < 0)
      throw new Error("Invalid designation");
    return {
      offset: view.getInt32(typeAt + i2 * 6),
      daylight: bytes[typeAt + i2 * 6 + 4] === 1,
      unspecified: decode(abbreviations.subarray(designation, end)) === "-00"
    };
  });
  if ([...indices].some((index) => index >= types.length))
    throw new Error("Invalid transition type");
  const tail = decode(bytes.subarray(block.end));
  if (!/^\n[^\n\0]*\n$/.test(tail))
    throw new Error("Invalid TZif footer");
  const future = footer(tail.slice(1, -1));
  const offsetAt = (seconds) => {
    if (!Number.isFinite(seconds))
      throw new Error("Invalid instant");
    if (!transitions.length || seconds >= transitions.at(-1)) {
      if (future)
        return future.at(seconds);
      if (transitions.length)
        throw new TimezoneDataUnavailable("Timezone data is unavailable after the final recorded transition.");
    }
    let lo2 = 0, hi2 = transitions.length;
    while (lo2 < hi2) {
      const mid = lo2 + hi2 >>> 1;
      if (transitions[mid] <= seconds)
        lo2 = mid + 1;
      else
        hi2 = mid;
    }
    const type = types[lo2 ? indices[lo2 - 1] : 0];
    if (type.unspecified)
      throw new TimezoneDataUnavailable("Timezone data is unavailable for this historical period.");
    return type.offset;
  };
  const offsets = [.../* @__PURE__ */ new Set([...types.map((type) => type.offset), ...future?.offsets || []])];
  return {
    footer: tail.slice(1, -1),
    futureFrom: transitions.at(-1) ?? null,
    futureObservances: future?.observances ?? [],
    isDaylightAt(seconds) {
      offsetAt(seconds);
      if (future && (!transitions.length || seconds >= transitions.at(-1)))
        return future.isDaylight(seconds);
      let lo2 = 0, hi2 = transitions.length;
      while (lo2 < hi2) {
        const mid = lo2 + hi2 >>> 1;
        if (transitions[mid] <= seconds)
          lo2 = mid + 1;
        else
          hi2 = mid;
      }
      return types[lo2 ? indices[lo2 - 1] : 0].daylight;
    },
    offsetAt,
    transitionInstants(from, through) {
      if (!Number.isFinite(from) || !Number.isFinite(through) || through < from || through - from > 12 * 366 * 86400)
        throw new RangeError("Transition coverage must be finite and at most twelve years.");
      const found = transitions.filter((instant) => instant >= from && instant <= through);
      if (future) {
        const firstYear = new Date(from * 1e3).getUTCFullYear() - 1;
        const lastYear = new Date(through * 1e3).getUTCFullYear() + 1;
        for (let year = firstYear; year <= lastYear; year++) {
          for (const [instant] of future.events(year))
            if (instant >= from && instant <= through && (!transitions.length || instant >= transitions.at(-1)))
              found.push(instant);
        }
      }
      return [...new Set(found)].sort((a2, b2) => a2 - b2).filter((instant) => offsetAt(instant - 1) !== offsetAt(instant));
    },
    possibleInstants(civilMilliseconds2) {
      return offsets.map((offset) => civilMilliseconds2 - offset * 1e3).filter((instant) => offsetAt(instant / 1e3) === (civilMilliseconds2 - instant) / 1e3).sort((a2, b2) => a2 - b2).map((instant) => new Date(instant).toISOString());
    }
  };
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/date-engine/timezone-database.js
var names = new Map(Object.keys(timezoneData.aliases).map((name) => [name.toLowerCase(), name]));
var cache = /* @__PURE__ */ new Map();
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
function bytesFromBase64(value) {
  if (!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value))
    throw new Error("Invalid bundled timezone encoding.");
  const size = value.length / 4 * 3 - (value.endsWith("==") ? 2 : value.endsWith("=") ? 1 : 0);
  const bytes = new Uint8Array(size);
  let cursor = 0;
  for (let i2 = 0; i2 < value.length; i2 += 4) {
    const bits = alphabet.indexOf(value[i2]) << 18 | alphabet.indexOf(value[i2 + 1]) << 12 | Math.max(0, alphabet.indexOf(value[i2 + 2])) << 6 | Math.max(0, alphabet.indexOf(value[i2 + 3]));
    for (const shift of [16, 8, 0])
      if (cursor < size)
        bytes[cursor++] = bits >>> shift & 255;
  }
  return bytes;
}
function timezoneDatabase(name) {
  const canonical = name.length <= 64 ? names.get(name.toLowerCase()) : void 0;
  if (!canonical)
    throw new RangeError("Unknown IANA timezone.");
  const index = timezoneData.aliases[canonical];
  let zone = cache.get(index);
  if (!zone) {
    zone = readZone(bytesFromBase64(timezoneData.files[index]));
    if (cache.size >= 64)
      cache.delete(cache.keys().next().value);
    cache.set(index, zone);
  }
  return zone;
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/date-engine/zoned-date.js
var AmbiguousLocalTime = class extends RangeError {
};
function civilMilliseconds(local) {
  return qi.Instant.from(`${local.toString()}Z`).epochMilliseconds;
}
function offsetText(seconds) {
  const absolute = Math.abs(seconds);
  const pad = (value) => String(value).padStart(2, "0");
  return `${seconds < 0 ? "-" : "+"}${pad(Math.floor(absolute / 3600))}:${pad(Math.floor(absolute % 3600 / 60))}${absolute % 60 ? `:${pad(absolute % 60)}` : ""}`;
}
var ZonedDate = class _ZonedDate {
  #plainDateTime;
  timeZoneId;
  instant;
  offsetSeconds;
  constructor(instant, timezone) {
    if (instant.epochNanoseconds % 1000000n !== 0n)
      throw new RangeError("Zoned dates require millisecond precision.");
    this.instant = instant;
    this.timeZoneId = timezone;
    this.offsetSeconds = timezoneDatabase(timezone).offsetAt(instant.epochMilliseconds / 1e3);
  }
  get epochMilliseconds() {
    return this.instant.epochMilliseconds;
  }
  get epochNanoseconds() {
    return this.instant.epochNanoseconds;
  }
  get offset() {
    return offsetText(this.offsetSeconds);
  }
  get year() {
    return this.toPlainDateTime().year;
  }
  get day() {
    return this.toPlainDateTime().day;
  }
  get dayOfWeek() {
    return this.toPlainDateTime().dayOfWeek;
  }
  toInstant() {
    return this.instant;
  }
  toPlainDateTime() {
    if (!this.#plainDateTime) {
      const civil2 = new Date(this.epochMilliseconds + this.offsetSeconds * 1e3).toISOString();
      this.#plainDateTime = qi.PlainDateTime.from(civil2.slice(0, -1));
    }
    return this.#plainDateTime;
  }
  toPlainDate() {
    return this.toPlainDateTime().toPlainDate();
  }
  addElapsed(change) {
    return new _ZonedDate(this.instant.add(change), this.timeZoneId);
  }
};
function zonedInstant(instant, timezone) {
  return new ZonedDate(typeof instant === "string" ? qi.Instant.from(instant) : instant, timezone);
}
function gapTransition(local, timezone) {
  const milliseconds = civilMilliseconds(local);
  const database = timezoneDatabase(timezone);
  for (const instant of database.transitionInstants(milliseconds / 1e3 - 172800, milliseconds / 1e3 + 172800)) {
    const before = database.offsetAt(instant - 1);
    const after = database.offsetAt(instant);
    if (after > before && milliseconds >= (instant + before) * 1e3 && milliseconds < (instant + after) * 1e3)
      return { instant, before, after };
  }
  throw new RangeError("No recorded transition explains this unavailable clock.");
}
function zonedLocal(local, timezone, disambiguation = "reject") {
  const milliseconds = civilMilliseconds(local);
  const candidates = timezoneDatabase(timezone).possibleInstants(milliseconds);
  if (candidates.length === 1)
    return zonedInstant(candidates[0], timezone);
  if (disambiguation === "reject")
    throw new AmbiguousLocalTime("That local time is skipped or occurs twice in this timezone.");
  if (candidates.length)
    return zonedInstant(disambiguation === "later" ? candidates.at(-1) : candidates[0], timezone);
  const transition = gapTransition(local, timezone);
  const offset = disambiguation === "earlier" ? transition.after : transition.before;
  return zonedInstant(qi.Instant.fromEpochMilliseconds(milliseconds - offset * 1e3), timezone);
}
function startOfZonedDay(date2, timezone) {
  const midnight = date2.toPlainDateTime();
  const candidates = timezoneDatabase(timezone).possibleInstants(civilMilliseconds(midnight));
  if (candidates.length)
    return zonedInstant(candidates[0], timezone);
  const transition = gapTransition(midnight, timezone);
  return zonedInstant(qi.Instant.fromEpochMilliseconds(transition.instant * 1e3), timezone);
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/date-engine/vocabulary.js
var aliases = {
  y: "year",
  yr: "year",
  yrs: "year",
  mo: "month",
  mos: "month",
  w: "week",
  wk: "week",
  wks: "week",
  d: "day",
  h: "hour",
  hr: "hour",
  hrs: "hour",
  m: "minute",
  min: "minute",
  mins: "minute",
  s: "second",
  sec: "second",
  secs: "second",
  ms: "millisecond"
};
function timeUnit(value) {
  if (!value)
    return;
  const plain = value.replace(/s$/, "");
  if (plain === "fortnight")
    return { unit: "day", factor: 14n };
  if (plain === "quarter" || plain === "qtr")
    return { unit: "month", factor: 3n };
  const unit = Object.hasOwn(aliases, value) ? aliases[value] : plain;
  if (["year", "month", "week", "day", "hour", "minute", "second", "millisecond"].includes(unit))
    return { unit, factor: 1n };
}
var weekdayAliases = {
  sun: "sunday",
  mon: "monday",
  tue: "tuesday",
  tues: "tuesday",
  wed: "wednesday",
  thu: "thursday",
  thur: "thursday",
  thurs: "thursday",
  fri: "friday",
  sat: "saturday"
};

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/date-engine/types.js
var CalculationFailure = class extends Error {
  issue;
  constructor(issue2) {
    super(issue2.message);
    this.issue = issue2;
  }
};
function fail(code, message, hint, span) {
  throw new CalculationFailure({ code, message, hint, ...span ? { span } : {} });
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/date-engine/grammar.js
var months = {
  jan: 1,
  january: 1,
  feb: 2,
  february: 2,
  mar: 3,
  march: 3,
  apr: 4,
  april: 4,
  may: 5,
  jun: 6,
  june: 6,
  jul: 7,
  july: 7,
  aug: 8,
  august: 8,
  sep: 9,
  sept: 9,
  september: 9,
  oct: 10,
  october: 10,
  nov: 11,
  november: 11,
  dec: 12,
  december: 12
};
var weekdays = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"];
var numbers = {
  zero: 0,
  one: 1,
  two: 2,
  three: 3,
  four: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10,
  eleven: 11,
  twelve: 12,
  thirteen: 13,
  fourteen: 14,
  fifteen: 15,
  sixteen: 16,
  seventeen: 17,
  eighteen: 18,
  nineteen: 19,
  twenty: 20,
  thirty: 30,
  forty: 40,
  fifty: 50,
  sixty: 60,
  seventy: 70,
  eighty: 80,
  ninety: 90
};
function tokenize(input2) {
  if (!input2.trim())
    fail("syntax", "Enter a date phrase.", "Try \u201Ctomorrow\u201D or \u201Cin 3 days\u201D.");
  if (input2.length > 200)
    fail("range", "That phrase is too long.", "Use at most 200 characters.");
  const tokens = [];
  const pattern = /\d{4}-\d{2}-\d{2}|\d{1,2}:\d{2}(?::\d{2}(?:\.\d+)?)?|\d+\/\d+|\d+(?:\.\d+)?(?:st|nd|rd|th)?|[a-z]+\.?|[½¼¾]|[+-]/iy;
  for (let i2 = 0; i2 < input2.length; ) {
    if (/[\s,;]/.test(input2[i2]) || input2[i2] === "." && !input2.slice(i2 + 1).trim()) {
      i2++;
      continue;
    }
    pattern.lastIndex = i2;
    const match = pattern.exec(input2);
    if (!match)
      fail("syntax", `Unexpected character \u201C${input2[i2]}\u201D.`, "Use a named date, ISO date, or a date phrase.", { start: i2, end: i2 + 1 });
    tokens.push({
      text: match[0],
      value: { "\xBD": "1/2", "\xBC": "1/4", "\xBE": "3/4" }[match[0]] ?? match[0].toLowerCase().replace(/\.$/, ""),
      start: i2,
      end: pattern.lastIndex
    });
    i2 = pattern.lastIndex;
  }
  return tokens;
}
function rational(value) {
  if (value.includes("/")) {
    const [n2, d2] = value.split("/").map(BigInt);
    if (d2 === 0n)
      fail("precision", "A fraction cannot divide by zero.", "Use a fraction such as 1/2.");
    return { numerator: n2, denominator: d2 };
  }
  const [whole, fraction = ""] = value.split(".");
  return { numerator: BigInt(whole + fraction), denominator: 10n ** BigInt(fraction.length) };
}
function parseExpression(input2) {
  const tokens = tokenize(input2);
  let index = 0;
  const peek = () => tokens[index]?.value;
  const take = () => tokens[index++];
  const syntax = (message, hint = "Try \u201Ctoday plus 2 days\u201D or \u201C2 weeks before may 1\u201D.") => fail("syntax", message, hint, tokens[index] ?? { start: input2.length, end: input2.length });
  const integer = () => {
    const value = peek()?.replace(/(st|nd|rd|th)$/, "");
    if (value && Object.hasOwn(numbers, value))
      return underHundred();
    if (!value || !/^\d+$/.test(value))
      return syntax("Expected a whole date number.");
    take();
    const result = Number(value);
    if (!Number.isSafeInteger(result))
      return syntax("That date number is too large.");
    return result;
  };
  const readAnchor = () => {
    if (peek() === "the" || peek() === "on")
      take();
    const value = peek();
    if (!value)
      return null;
    if (value === "day" && ["before", "after"].includes(tokens[index + 1]?.value)) {
      const relation = tokens[index + 1].value;
      const relative = tokens[index + 2]?.value;
      if (relation === "after" && relative === "tomorrow" || relation === "before" && relative === "yesterday") {
        index += 3;
        return {
          kind: "relative",
          value: relation === "after" ? "day-after-tomorrow" : "day-before-yesterday"
        };
      }
    }
    const dayFirst = /^\d+(st|nd|rd|th)?$/.test(value) && (Object.hasOwn(months, tokens[index + 1]?.value ?? "") || tokens[index + 1]?.value === "of" && Object.hasOwn(months, tokens[index + 2]?.value ?? ""));
    if (dayFirst) {
      const day2 = integer();
      if (peek() === "of")
        take();
      const month2 = months[take().value];
      const year = peek() && /^\d{4}$/.test(peek()) ? integer() : void 0;
      return { kind: "date", month: month2, day: day2, year };
    }
    if (["now", "today", "tomorrow", "yesterday"].includes(value)) {
      take();
      return { kind: "relative", value };
    }
    if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
      take();
      const [year, month2, day2] = value.split("-").map(Number);
      return { kind: "date", year, month: month2, day: day2 };
    }
    if (Object.hasOwn(months, value)) {
      take();
      const day2 = integer();
      const year = peek() && /^\d+$/.test(peek()) && !["am", "pm"].includes(tokens[index + 1]?.value) ? integer() : void 0;
      return { kind: "date", month: months[value], day: day2, year };
    }
    const modifier = ["next", "last", "this"].includes(value) ? value : null;
    const weekday = modifier ? tokens[index + 1]?.value : value;
    const day = weekdays.indexOf(weekdayAliases[weekday ?? ""] ?? weekday ?? "") + 1;
    if (day) {
      if (modifier)
        take();
      take();
      let direction = modifier ?? "next";
      let week = false;
      if (!modifier && ["next", "last", "this"].includes(peek() ?? "")) {
        direction = take().value;
        if (peek() !== "week")
          syntax("Expected \u201Cweek\u201D after the weekday modifier.");
        take();
        week = true;
      }
      return { kind: "weekday", day, direction, week };
    }
    if (tokens.length === 1 && /^\d+(st|nd|rd|th)?$/.test(value))
      return { kind: "day-number", day: integer() };
    return null;
  };
  const readTime = () => {
    if (peek() === "at")
      take();
    else if (!(["noon", "midnight"].includes(peek() ?? "") || /^\d{1,2}:/.test(peek() ?? "") || /^\d{1,2}$/.test(peek() ?? "") && ["am", "pm"].includes(tokens[index + 1]?.value)))
      return void 0;
    if (peek() === "noon" || peek() === "midnight")
      return take().value === "noon" ? "12:00:00" : "00:00:00";
    const value = peek();
    if (!value || !/^\d{1,2}(:\d{2}(:\d{2}(\.\d{1,3})?)?)?$/.test(value))
      syntax("Expected a clock time after \u201Cat\u201D.", "Use \u201Cat 14:30\u201D or \u201Cat 2 pm\u201D; precision is one millisecond.");
    take();
    const parts = value.split(":");
    let hour = Number(parts[0]);
    const meridian = peek();
    if (meridian === "am" || meridian === "pm") {
      if (hour < 1 || hour > 12)
        syntax("Use hours 1\u201312 with am or pm.");
      hour = hour % 12 + (meridian === "pm" ? 12 : 0);
      take();
    } else if (parts.length === 1)
      syntax("That clock time needs minutes or am/pm.", "Use \u201Cat 14:00\u201D or \u201Cat 2 pm\u201D.");
    if (hour > 23 || Number(parts[1] ?? 0) > 59 || Number(parts[2] ?? 0) >= 60)
      syntax("That clock time is outside the valid range.", "Use hours 00\u201323, minutes 00\u201359, and seconds below 60.");
    return `${String(hour).padStart(2, "0")}:${parts[1] ?? "00"}:${parts[2] ?? "00"}`;
  };
  const underHundred = () => {
    const value = peek();
    if (!value || !Object.hasOwn(numbers, value))
      return void 0;
    let n2 = numbers[take().value];
    const hyphen = peek() === "-";
    const next = tokens[index + (hyphen ? 1 : 0)]?.value;
    if (n2 >= 20 && n2 % 10 === 0 && next && Object.hasOwn(numbers, next) && numbers[next] > 0 && numbers[next] < 10) {
      if (hyphen)
        take();
      n2 += numbers[take().value];
    }
    return n2;
  };
  const wordGroup = () => {
    let n2 = underHundred();
    if (peek() === "hundred" && (n2 === void 0 || n2 >= 1 && n2 <= 9)) {
      take();
      n2 = (n2 ?? 1) * 100;
      if (peek() === "and" && Object.hasOwn(numbers, tokens[index + 1]?.value ?? ""))
        take();
      n2 += underHundred() ?? 0;
    }
    return n2;
  };
  const fraction = () => {
    const word = peek();
    if (word === "half" || word === "quarter") {
      take();
      if (peek() === "of")
        take();
      if (peek() === "a" || peek() === "an")
        take();
      return { numerator: 1n, denominator: word === "half" ? 2n : 4n };
    }
    if (/^\d+\/\d+$/.test(word ?? "")) {
      take();
      return rational(word);
    }
    return void 0;
  };
  const readAmount = () => {
    if ((peek() === "a" || peek() === "an") && (["half", "couple"].includes(tokens[index + 1]?.value) || tokens[index + 1]?.value === "quarter" && (tokens[index + 2]?.value === "of" || timeUnit(tokens[index + 2]?.value))))
      take();
    if (peek() === "couple") {
      take();
      if (peek() === "of")
        take();
      return { numerator: 2n, denominator: 1n };
    }
    const part = fraction();
    if (part)
      return part;
    let amount;
    if (/^\d+(\.\d+)?$/.test(peek() ?? ""))
      amount = rational(take().value);
    else if (peek() === "a" || peek() === "an") {
      take();
      amount = { numerator: 1n, denominator: 1n };
    } else {
      let total = 0;
      let group = wordGroup();
      let previousScale = Infinity;
      const scales = { million: 1e6, thousand: 1e3 };
      while (Object.hasOwn(scales, peek() ?? "")) {
        if (group === void 0 && previousScale !== Infinity)
          syntax("Expected a number between scales.");
        const scale = scales[take().value];
        if (scale >= previousScale)
          syntax("Number scales must run from largest to smallest.");
        total += (group ?? 1) * scale;
        previousScale = scale;
        if (peek() === "and" && Object.hasOwn(numbers, tokens[index + 1]?.value ?? ""))
          take();
        group = wordGroup();
      }
      if (group === void 0 && !total)
        syntax("Expected a number and time unit.");
      amount = { numerator: BigInt(total + (group ?? 0)), denominator: 1n };
    }
    const mixedStart = index;
    const explicitMixed = peek() === "and";
    if (explicitMixed)
      take();
    if (peek() === "a" || peek() === "an")
      take();
    const mixed = explicitMixed || peek() !== "quarter" ? fraction() : void 0;
    if (mixed) {
      if (amount.denominator !== 1n || mixed.numerator >= mixed.denominator)
        syntax("Use a whole number followed by a fraction smaller than one.");
      amount = {
        numerator: amount.numerator * mixed.denominator + mixed.numerator,
        denominator: mixed.denominator
      };
    } else
      index = mixedStart;
    return amount;
  };
  const readOperation = (sign) => {
    const start = tokens[index]?.start ?? input2.length;
    const amount = readAmount();
    const parsedUnit = timeUnit(peek());
    if (!parsedUnit)
      syntax("Expected a time unit after the number.", "Use years, months, weeks, days, hours, minutes, seconds, or milliseconds.");
    const end = take().end;
    return {
      amount: { ...amount, numerator: amount.numerator * parsedUnit.factor },
      unit: parsedUnit.unit,
      sign,
      source: `${sign < 0 ? "Subtract" : "Add"} ${input2.slice(start, end)}`,
      span: { start, end }
    };
  };
  const operations = [];
  const append = (sign) => {
    if (operations.length >= 20)
      syntax("Too many calculation steps.", "Use at most 20 changes in one phrase.");
    operations.push(readOperation(sign));
  };
  const tail = () => {
    while (peek() === "plus" || peek() === "+" || peek() === "minus" || peek() === "-" || peek() === "and" || /^\d/.test(peek() ?? "") || Object.hasOwn(numbers, peek() ?? "")) {
      const connector = ["plus", "+", "minus", "-", "and"].includes(peek() ?? "") ? take().value : "plus";
      append(connector === "minus" || connector === "-" ? -1 : 1);
    }
  };
  let anchor = readAnchor();
  let time;
  if (anchor) {
    time = readTime();
    tail();
  } else {
    const inPrefix = peek() === "in";
    if (inPrefix)
      take();
    if ((peek() === "next" || peek() === "last") && timeUnit(tokens[index + 1]?.value)) {
      const modifier = take();
      const unit = take();
      operations.push({
        amount: { numerator: timeUnit(unit.value).factor, denominator: 1n },
        unit: timeUnit(unit.value).unit,
        sign: modifier.value === "next" ? 1 : -1,
        source: `${modifier.value === "next" ? "Add" : "Subtract"} 1 ${unit.value}`,
        span: { start: modifier.start, end: unit.end }
      });
    } else {
      const sign = peek() === "-" || peek() === "minus" ? -1 : 1;
      if (["-", "+", "minus", "plus"].includes(peek() ?? ""))
        take();
      append(sign);
    }
    tail();
    const relation = peek();
    if (["before", "after", "from"].includes(relation ?? "")) {
      if (inPrefix)
        syntax("Use either \u201Cin\u201D or a reference date.");
      take();
      anchor = readAnchor();
      if (!anchor)
        syntax("Expected a starting date after the relation.");
      time = readTime();
      if (relation === "before")
        operations.forEach((op) => {
          op.sign = op.sign === 1 ? -1 : 1;
          op.source = op.source.replace(/^(Add|Subtract)/, op.sign === 1 ? "Add" : "Subtract");
        });
      tail();
    } else {
      anchor = { kind: "relative", value: "now" };
      if (relation === "ago" || relation === "earlier" || relation === "later") {
        if (inPrefix)
          syntax("\u201CIn\u201D and \u201Cago\u201D point in different directions.", "Use \u201Cin 2 days\u201D or \u201C2 days ago\u201D.");
        take();
        if (relation !== "later")
          operations.forEach((op) => {
            op.sign = op.sign === 1 ? -1 : 1;
            op.source = op.source.replace(/^(Add|Subtract)/, op.sign === 1 ? "Add" : "Subtract");
          });
        tail();
      }
    }
  }
  if (index < tokens.length)
    syntax(`Couldn\u2019t use \u201C${input2.slice(tokens[index].start)}\u201D.`, "Every part of the phrase must describe the date. Use plus or minus between changes.");
  return { anchor, time, operations, tokens };
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/date-parser.js
var DAY_MS = 86400000n;
var elapsedFactors = {
  hour: 3600000n,
  minute: 60000n,
  second: 1000n,
  millisecond: 1n
};
var weekdayNames = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
function snapshot(date2) {
  if (date2.year < 1 || date2.year > 9999)
    fail("range", "The result is outside the supported date range.", "Use dates between years 0001 and 9999.");
  return {
    iso: date2.toInstant().toString({ smallestUnit: "millisecond" }),
    local: date2.toPlainDateTime().toString({ smallestUnit: "millisecond" }),
    offset: date2.offset,
    timestamp: date2.epochMilliseconds
  };
}
function zoned(local, timezone) {
  try {
    return zonedLocal(local, timezone);
  } catch (error) {
    if (!(error instanceof AmbiguousLocalTime))
      throw error;
    fail("ambiguous-time", "That local time is skipped or occurs twice in this timezone.", "Choose a different clock time. For elapsed time across a clock change, use hours instead of calendar days.");
  }
}
function resolveAnchor(anchor, reference, time, resolve = zoned) {
  const today = reference.toPlainDate();
  let date2 = today;
  let description = "";
  switch (anchor.kind) {
    case "relative":
      if (anchor.value === "now" && !time)
        return { date: reference, description: "Start at the captured reference time." };
      date2 = today.add({
        days: anchor.value === "tomorrow" ? 1 : anchor.value === "yesterday" ? -1 : anchor.value === "day-after-tomorrow" ? 2 : anchor.value === "day-before-yesterday" ? -2 : 0
      });
      description = `Use ${anchor.value === "now" ? "today" : anchor.value.replaceAll("-", " ")} in ${reference.timeZoneId}.`;
      break;
    case "date":
      try {
        date2 = qi.PlainDate.from({ year: anchor.year ?? today.year, month: anchor.month, day: anchor.day }, { overflow: "reject" });
      } catch {
        fail("date", "That calendar date does not exist.", "Check the day, month, and leap year; for example, February 30 is never valid.");
      }
      description = anchor.year === void 0 ? `Use the named date in the reference year, ${today.year}.` : "Use the exact calendar date.";
      break;
    case "weekday": {
      const delta = anchor.week ? (anchor.direction === "next" ? 7 : anchor.direction === "last" ? -7 : 0) + anchor.day - today.dayOfWeek : anchor.direction === "this" ? (anchor.day - today.dayOfWeek + 7) % 7 : anchor.direction === "next" ? (anchor.day - today.dayOfWeek + 7) % 7 || 7 : -((today.dayOfWeek - anchor.day + 7) % 7 || 7);
      date2 = today.add({ days: delta });
      description = anchor.direction === "this" && !anchor.week ? `Use the next ${weekdayNames[anchor.day - 1]}, including today.` : anchor.week ? `Use ${weekdayNames[anchor.day - 1]} in ${anchor.direction} week. Weeks start on Monday.` : `Use the ${anchor.direction === "next" ? "next" : "previous"} ${weekdayNames[anchor.day - 1]}, excluding today.`;
      break;
    }
    case "day-number": {
      if (anchor.day < 1 || anchor.day > 31)
        fail("date", "A day number must be between 1 and 31.", "Use a named date such as \u201CMay 15\u201D for a particular month.");
      let month2 = today.with({ day: 1 });
      let found;
      for (let i2 = 0; i2 < 12; i2++) {
        if (anchor.day <= month2.daysInMonth) {
          const candidate = month2.with({ day: anchor.day });
          if (qi.PlainDate.compare(candidate, today) >= 0) {
            found = candidate;
            break;
          }
        }
        month2 = month2.add({ months: 1 });
      }
      if (!found)
        fail("date", "Couldn\u2019t find that day.", "Use an explicit calendar date.");
      date2 = found;
      description = `Use the next calendar occurrence of day ${anchor.day}, including today.`;
    }
  }
  let clock6;
  try {
    clock6 = qi.PlainTime.from(time ?? "00:00", { overflow: "reject" });
  } catch {
    fail("date", "That clock time is invalid.", "Use hours 00\u201323, minutes/seconds 00\u201359, and at most three decimal places for seconds.");
  }
  return {
    date: resolve(date2.toPlainDateTime(clock6), reference.timeZoneId),
    description: `${description} ${time ? `Set the clock to ${clock6.toString()}.` : "Start at midnight."}`
  };
}
function applyOperation(before, operation, resolve = zoned) {
  const { numerator, denominator } = operation.amount;
  const details = [];
  const warnings = [];
  const sign = operation.sign;
  if (numerator > 1000000000n * denominator)
    fail("range", "That time change is too large.", "Use an amount no larger than one billion per step.", operation.span);
  let after = before;
  if (operation.unit === "month" || operation.unit === "year") {
    const whole = numerator / denominator;
    let remainder = numerator % denominator;
    let months2 = 0n;
    if (operation.unit === "year") {
      months2 = remainder * 12n / denominator;
      remainder = remainder * 12n % denominator;
    }
    const count = Number(whole) * sign;
    const calendar = (date2, change) => {
      const after2 = resolve(date2.toPlainDateTime().add(change, { overflow: "constrain" }), date2.timeZoneId);
      if ((change.years || change.months) && after2.day !== date2.day)
        details.push(`Day ${date2.day} does not exist in the destination month; clamp to day ${after2.day}.`);
      return after2;
    };
    if (count)
      after = calendar(after, operation.unit === "month" ? { months: count } : { years: count });
    if (months2) {
      after = calendar(after, { months: Number(months2) * sign });
      details.push(`Convert the year fraction into ${months2} whole calendar month${months2 === 1n ? "" : "s"}.`);
    }
    if (remainder) {
      const dayNumerator = remainder * (operation.unit === "month" ? 30436875n : 36525n);
      const dayDenominator = denominator * (operation.unit === "month" ? 1000000n : 1200n);
      const days2 = (2n * dayNumerator + dayDenominator) / (2n * dayDenominator);
      if (days2)
        after = calendar(after, { days: Number(days2) * sign });
      const warning = `Approximation: the remaining ${operation.unit} fraction becomes ${days2} calendar day${days2 === 1n ? "" : "s"}, rounded to the nearest day using ${operation.unit === "month" ? "30.436875 days/month" : "365.25 days/year"}.`;
      warnings.push(warning);
      details.push(warning);
    }
    details.push("Calendar change, applied to this step\u2019s starting date.");
  } else if (operation.unit === "day" || operation.unit === "week") {
    const daysNumerator = numerator * (operation.unit === "week" ? 7n : 1n);
    const wholeDays = daysNumerator / denominator;
    const remainder = daysNumerator % denominator;
    const msNumerator = remainder * DAY_MS;
    if (msNumerator % denominator !== 0n)
      fail("precision", "This fraction is smaller than the supported precision.", "Use a duration that resolves to a whole number of milliseconds.", operation.span);
    if (wholeDays !== 0n)
      after = resolve(before.toPlainDateTime().add({ days: Number(wholeDays) * sign }), before.timeZoneId);
    const milliseconds = Number(msNumerator / denominator) * sign;
    if (milliseconds)
      after = after.addElapsed({ milliseconds });
    details.push(`${wholeDays} calendar day${wholeDays === 1n ? "" : "s"}${milliseconds ? ` and ${Math.abs(milliseconds).toLocaleString("en-US")} elapsed milliseconds` : ""}. No rounding.`);
  } else {
    const msNumerator = numerator * elapsedFactors[operation.unit];
    if (msNumerator % denominator !== 0n)
      fail("precision", "This fraction is smaller than the supported precision.", "Use a duration that resolves to a whole number of milliseconds.", operation.span);
    const milliseconds = Number(msNumerator / denominator) * sign;
    if (!Number.isSafeInteger(milliseconds))
      fail("range", "That duration is too large.", "Use a smaller elapsed duration.", operation.span);
    after = before.addElapsed({ milliseconds });
    details.push(`${Math.abs(milliseconds).toLocaleString("en-US")} elapsed milliseconds. No rounding.`);
  }
  if (before.offset !== after.offset)
    details.push(`The timezone offset changes from ${before.offset} to ${after.offset}.`);
  return { after, details, warnings };
}
function calculateDate(expression, options) {
  return calculateWithClockResolver(expression, options, zoned);
}
function calculateWithClockResolver(expression, options, resolve) {
  try {
    const plan = parseExpression(expression);
    let instant;
    try {
      instant = qi.Instant.from(options.reference);
      if (instant.epochNanoseconds % 1000000n !== 0n)
        fail("reference", "Reference time has unsupported precision.", "Use an ISO instant with at most millisecond precision.");
    } catch (error) {
      if (error instanceof CalculationFailure)
        throw error;
      fail("reference", "The reference time needs an explicit UTC offset.", "Use an ISO instant such as 2026-01-26T13:30:00Z.");
    }
    let reference;
    try {
      reference = zonedInstant(instant, options.timezone);
    } catch (error) {
      if (error instanceof TimezoneDataUnavailable)
        throw error;
      fail("timezone", "That timezone is not recognized.", "Use an IANA timezone such as America/Chicago or UTC.");
    }
    snapshot(reference);
    const anchor = resolveAnchor(plan.anchor, reference, plan.time, resolve);
    const start = snapshot(anchor.date);
    let current = anchor.date;
    const steps = [];
    const warnings = [];
    for (const operation of plan.operations) {
      const before = snapshot(current);
      const { after, details, warnings: stepWarnings } = applyOperation(current, operation, resolve);
      warnings.push(...stepWarnings);
      steps.push({ source: operation.source, before, after: snapshot(after), details });
      current = after;
    }
    return {
      ok: true,
      engineVersion: 2,
      expression: expression.trim(),
      timezone: reference.timeZoneId,
      reference: instant.toString({ smallestUnit: "millisecond" }),
      normalized: plan.tokens.map((token) => token.value).join(" "),
      anchor: start,
      anchorDescription: anchor.description,
      steps,
      warnings: [...new Set(warnings)],
      result: snapshot(current)
    };
  } catch (error) {
    return {
      ok: false,
      engineVersion: 2,
      error: error instanceof TimezoneDataUnavailable ? {
        code: "timezone",
        message: error.message,
        hint: "Choose a date covered by the recorded timezone history."
      } : error instanceof CalculationFailure ? error.issue : {
        code: "range",
        message: "That calculation exceeds the supported date range.",
        hint: "Use dates between years 0001 and 9999 and smaller time changes."
      }
    };
  }
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/calculate-schedule-date.js
var DATE_START_POLICY = "This date uses its first valid local time as a day boundary; no appointment time was supplied.";
function calculateScheduleDate(expression, options) {
  let strict = calculateDate(expression, options);
  if (!strict.ok && strict.error.code !== "ambiguous-time")
    return strict;
  const plan = parseExpression(expression);
  if (!strict.ok && !plan.time && !plan.operations.length && !(plan.anchor.kind === "relative" && plan.anchor.value === "now")) {
    const reference2 = zonedInstant(options.reference, options.timezone);
    const civil2 = calculateDate(expression, {
      timezone: "UTC",
      reference: `${reference2.toPlainDateTime().toString()}Z`
    });
    if (!civil2.ok)
      return civil2;
    const date2 = qi.PlainDate.from(civil2.result.local.slice(0, 10));
    const boundary = startOfZonedDay(date2, options.timezone);
    if (!boundary.toPlainDate().equals(date2))
      return strict;
    const snapshot2 = {
      iso: boundary.toInstant().toString({ smallestUnit: "millisecond" }),
      local: boundary.toPlainDateTime().toString({ smallestUnit: "millisecond" }),
      offset: boundary.offset,
      timestamp: boundary.epochMilliseconds
    };
    strict = {
      ...civil2,
      timezone: options.timezone,
      reference: qi.Instant.from(options.reference).toString({ smallestUnit: "millisecond" }),
      anchor: snapshot2,
      result: snapshot2,
      anchorDescription: DATE_START_POLICY,
      warnings: [DATE_START_POLICY]
    };
  }
  if (plan.anchor.kind !== "weekday" || plan.operations.length || /^(?:next|last|this)\b/i.test(expression.trim()))
    return strict;
  const reference = zonedInstant(options.reference, options.timezone);
  if (plan.anchor.day !== reference.dayOfWeek)
    return strict;
  const today = calculateScheduleDate(`this ${expression.trim()}`, options);
  if (!today.ok)
    return today;
  return !plan.time || today.result.timestamp >= reference.epochMilliseconds ? today : strict;
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/date-engine/format-zoned.js
var labelFormatters = /* @__PURE__ */ new Map();
var civilFormatters = /* @__PURE__ */ new Map();
function timezoneLabel(value, style) {
  try {
    const key = `${value.timeZoneId}:${style}`;
    let formatter = labelFormatters.get(key);
    if (!formatter) {
      formatter = new Intl.DateTimeFormat("en-US", {
        timeZone: value.timeZoneId,
        year: "numeric",
        month: "numeric",
        day: "numeric",
        hour: "numeric",
        minute: "numeric",
        second: "numeric",
        hourCycle: "h23",
        timeZoneName: style
      });
      if (labelFormatters.size >= 32)
        labelFormatters.delete(labelFormatters.keys().next().value);
      labelFormatters.set(key, formatter);
    }
    const parts = formatter.formatToParts(value.epochMilliseconds);
    const local = value.toPlainDateTime();
    const keys = ["year", "month", "day", "hour", "minute", "second"];
    if (keys.every((key2) => Number(parts.find((part) => part.type === key2)?.value) === local[key2])) {
      const label = parts.find((part) => part.type === "timeZoneName")?.value;
      if (label)
        return label;
    }
  } catch {
  }
  return `GMT${value.offset}`;
}
function describeZonedInstant(timestamp, timezone) {
  const value = zonedInstant(qi.Instant.fromEpochMilliseconds(timestamp), timezone);
  const civil2 = new Date(timestamp + value.offsetSeconds * 1e3);
  const precision = timestamp % 1e3 ? 3 : value.toPlainDateTime().second ? 1 : 0;
  let formatter = civilFormatters.get(precision);
  if (!formatter) {
    formatter = new Intl.DateTimeFormat("en-US", {
      timeZone: "UTC",
      month: "long",
      day: "numeric",
      year: "numeric",
      hour: "numeric",
      minute: "2-digit",
      ...precision ? { second: "2-digit" } : {},
      ...precision === 3 ? { fractionalSecondDigits: 3 } : {}
    });
    civilFormatters.set(precision, formatter);
  }
  const formatted = formatter.format(civil2);
  return `${formatted} ${timezoneLabel(value, "short")}`;
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/clarify-clock.js
function clockChoices(expression, options) {
  const failed = calculateScheduleDate(expression, options);
  if (failed.ok || failed.error.code !== "ambiguous-time")
    return null;
  const plan = parseExpression(expression);
  if (plan.operations.length || !plan.time)
    return null;
  const reference = zonedInstant(options.reference, options.timezone);
  const civil2 = calculateScheduleDate(expression, {
    timezone: "UTC",
    reference: `${reference.toPlainDateTime().toString()}Z`
  });
  if (!civil2.ok)
    return null;
  const local = qi.PlainDateTime.from(civil2.result.local);
  const earlier = zonedLocal(local, options.timezone, "earlier");
  const later = zonedLocal(local, options.timezone, "later");
  if (earlier.epochNanoseconds === later.epochNanoseconds)
    return null;
  const repeated = earlier.toPlainDateTime().equals(local) && later.toPlainDateTime().equals(local);
  return {
    question: repeated ? "Which occurrence of this time?" : "That clock time does not exist. Which time should replace it?",
    choices: [earlier, later].map((date2, index) => ({
      id: date2.toInstant().toString(),
      expression,
      label: `${repeated ? index === 0 ? "First: " : "Second: " : "Use "}${describeZonedInstant(date2.epochMilliseconds, options.timezone)} (UTC${date2.offset})`
    }))
  };
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/clarify-numeric-date.js
var MAX_SELECTION_HISTORY = 64;
function retainOccurrenceDecisions(history, next) {
  if (/^list:year:\d{4}$/.test(next))
    return history.filter((id) => !id.startsWith("list:") || /^list:\d+:month:/.test(id));
  if (next === "monthly:skip" || next === "monthly:last-day")
    return history.filter((id) => !id.startsWith("monthly:") && !id.startsWith("recurrence:") && !id.startsWith("count:"));
  if (next.startsWith("count:past:"))
    return history.filter((id) => !id.startsWith("count:") && !id.startsWith("recurrence:"));
  if (next.startsWith("count:exclusions:"))
    return history.filter((id) => !id.startsWith("count:exclusions:") && !id.startsWith("recurrence:"));
  const intervalDate = /^interval:(start|end):date:/.exec(next);
  if (next.startsWith("interval:end:boundary:"))
    return history.filter((id) => !id.startsWith("interval:end:boundary:"));
  if (intervalDate)
    return history.filter((id) => !id.startsWith(`interval:${intervalDate[1]}:`) && !(intervalDate[1] === "start" && id.startsWith("interval:end:")));
  const intervalClock = /^interval:(start|end):\d{4}-/.exec(next);
  const intervalTime = /^interval:(start|end):time:/.exec(next);
  if (intervalTime)
    return history.filter((id) => !id.startsWith(`interval:${intervalTime[1]}:`) || id.startsWith(`interval:${intervalTime[1]}:date:`));
  if (intervalClock)
    return history.filter((id) => !id.startsWith(`interval:${intervalClock[1]}:`) || id.startsWith(`interval:${intervalClock[1]}:date:`) || id.startsWith(`interval:${intervalClock[1]}:time:`));
  const listMonth = /^(list:\d+):month:/.exec(next);
  if (listMonth)
    return history.filter((id) => !id.startsWith(`${listMonth[1]}:`));
  const listYear = /^(list:\d+):year:/.exec(next);
  if (listYear)
    return history.filter((id) => !id.startsWith(`${listYear[1]}:`) || id.startsWith(`${listYear[1]}:month:`));
  const listTime = /^(list:\d+):time:/.exec(next);
  if (listTime)
    return history.filter((id) => !id.startsWith(`${listTime[1]}:`) || id.startsWith(`${listTime[1]}:date:`) || id.startsWith(`${listTime[1]}:year:`) || id.startsWith(`${listTime[1]}:month:`));
  const listDate = /^(list:\d+):date:/.exec(next);
  if (listDate)
    return history.filter((id) => !id.startsWith(`${listDate[1]}:`));
  const match = /^(recurrence:\d{4}-\d{2}-\d{2}|group:\d+|list:\d+):(start|end):/.exec(next);
  if (!match)
    return history;
  const [, occurrence, endpoint] = match;
  return history.filter((id) => !id.startsWith(`${occurrence}:${endpoint}:`) && !(endpoint === "start" && (id.startsWith(`${occurrence}:end:`) || id === `${occurrence}:end-next-day`)));
}
function appendSelection(previous, next) {
  if (!next || previous?.contextKey !== next.contextKey)
    return next;
  const arithmeticPosition = /^arithmetic:(\d+):/.exec(next.id)?.[1];
  const history = retainOccurrenceDecisions([...previous.previous ?? [], previous.id], next.id).filter((id) => {
    const position = /^arithmetic:(\d+):/.exec(id)?.[1];
    return arithmeticPosition === void 0 || position === void 0 || Number(position) < Number(arithmeticPosition);
  });
  return {
    ...next,
    previous: [...new Set(history)].slice(-MAX_SELECTION_HISTORY)
  };
}
function interpretationContextKey(input2, options) {
  return JSON.stringify([input2, options.timezone, options.reference]);
}
function numericDateChoices(text) {
  const match = /^(\d{1,2})\/(\d{1,2})\/(\d{4})(\s+(?:at|for)\s+.+)?$/i.exec(text);
  if (!match)
    return null;
  const [, first, second, year, time = ""] = match;
  const choices2 = [];
  for (const [month2, day] of [
    [first, second],
    [second, first]
  ]) {
    try {
      const date2 = qi.PlainDate.from({ year: Number(year), month: Number(month2), day: Number(day) }, { overflow: "reject" });
      if (date2.year < 1 || choices2.some((choice) => choice.id === date2.toString()))
        continue;
      choices2.push({
        id: date2.toString(),
        expression: `${date2.toString()}${time}`,
        label: date2.toLocaleString("en-US", { month: "long", day: "numeric", year: "numeric" })
      });
    } catch {
    }
  }
  return choices2;
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/interpret-interval.js
var clock2 = String.raw`(?:\d{1,2}(?::\d{2})?\s*[ap]m|\d{1,2}:\d{2}|noon|midnight)`;
var range = new RegExp(`^(.+?)\\s+(?:from\\s+)?(${clock2})\\s*(?:to|[-\u2013])\\s*(${clock2})$`, "i");
var duration = /^for\s+(\d+)\s+(days?|weeks?|hours?|minutes?|seconds?)\s+from\s+(.+)$/i;
var trailingDuration = /^(.+?)\s+for\s+(\d+)\s+(days?|weeks?|hours?|minutes?|seconds?)$/i;
function normalizeHalfHour(text) {
  return text.replace(/\bfor\s+half\s+an\s+hour(?=\s+(?:from|starting|until|except)\s|$)/i, "for 30 minutes");
}
var issue = (message, hint) => ({
  ok: false,
  error: { code: "syntax", message, hint }
});
function interpretInterval(text, options) {
  if (text.length > 200)
    return null;
  const selectedClocks = [];
  const prompts = {};
  const endpoint = (expression, name) => {
    const result = calculateScheduleDate(expression, options);
    if (result.ok || result.error.code !== "ambiguous-time")
      return result;
    const prompt = clockChoices(expression, options);
    if (!prompt)
      return result;
    const clockPrompt = { ...prompt, endpoint: name };
    prompts[name] = clockPrompt;
    const selected = prompt.choices.find((choice) => choice.id === options.clockSelections?.[name]);
    if (!selected)
      return { ...result, clockPrompt };
    const chosen = calculateDate("now", { timezone: options.timezone, reference: selected.id });
    if (!chosen.ok)
      return chosen;
    selectedClocks.push(`${name === "start" ? "Start" : "End"}: ${selected.label}`);
    return {
      ...chosen,
      anchorDescription: `Use the explicitly selected ${name}: ${selected.label}`
    };
  };
  const datedRange = /^from\s+(.+?)\s+(?:to|until)\s+(.+)$/i.exec(text);
  if (datedRange) {
    const resolved = [];
    const timed = [];
    const expressions = [];
    const writtenTimes = [];
    for (const [index, name] of ["start", "end"].entries()) {
      let expression = datedRange[index + 1];
      if (/^\d{1,2}\/\d{1,2}\/\d{4}(?:\s|$)/.test(expression)) {
        const choices2 = numericDateChoices(expression);
        if (!choices2?.length)
          return issue("A range endpoint is not a valid date.", "Write a complete date and time for both endpoints.");
        const choice = choices2.length === 1 ? choices2[0] : choices2.find((value2) => value2.id === options.dateSelections?.[name]);
        if (!choice)
          return {
            ok: false,
            error: {
              code: "syntax",
              message: "Which date did you mean?",
              hint: "Choose this endpoint\u2019s date."
            },
            clockPrompt: {
              endpoint: name,
              question: "Which date did you mean?",
              choices: choices2.map((value2) => ({ ...value2, id: `date:${value2.id}` }))
            }
          };
        expression = choice.expression;
        if (choices2.length > 1)
          selectedClocks.push(`${name === "start" ? "Start" : "End"} date: ${choice.label}`);
      }
      const value = endpoint(expression, name);
      if (!value.ok)
        return value;
      if (value.steps.length)
        return issue("Use one date and time for each endpoint.", "Calculate endpoint arithmetic separately first.");
      const plan = parseExpression(expression);
      expressions.push(expression);
      writtenTimes.push(plan.time);
      timed.push(Boolean(plan.time) || plan.anchor.kind === "relative" && plan.anchor.value === "now");
      resolved.push(value);
    }
    const allDay = timed.every((value) => !value);
    if (timed[0] !== timed[1]) {
      const index = timed[0] ? 1 : 0;
      const name = index === 0 ? "start" : "end";
      const written = writtenTimes[1 - index];
      const choices2 = [
        ...written && written !== "00:00:00" ? [
          {
            id: "time:written",
            label: `Use ${written.replace(/:00$/, "")}, matching the written time`,
            expression: `${expressions[index]} at ${written}`
          }
        ] : [],
        {
          id: "time:midnight",
          label: "Use midnight at the start of this date",
          expression: `${expressions[index]} at midnight`
        }
      ];
      const chosen = choices2.find((choice) => choice.id === options.timeSelections?.[name]);
      if (!chosen)
        return {
          ok: false,
          error: {
            code: "syntax",
            message: "What time belongs on this date?",
            hint: "Choose a time here, or write a different time in the original input. The other endpoint stays unchanged."
          },
          clockPrompt: { endpoint: name, question: "What time belongs on this date?", choices: choices2 }
        };
      selectedClocks.push(`${name === "start" ? "Start" : "End"}: ${chosen.label}`);
      const value = endpoint(chosen.expression, name);
      if (!value.ok)
        return value;
      resolved[index] = value;
    }
    const [start2, writtenEnd] = resolved;
    let end2 = writtenEnd;
    if (allDay) {
      const endDate2 = qi.PlainDate.from(writtenEnd.result.local.slice(0, 10));
      const choices2 = [
        {
          id: "boundary:exclusive",
          label: `End before ${endDate2.toString()} begins`,
          expression: text
        },
        {
          id: "boundary:inclusive",
          label: `Include all of ${endDate2.toString()}`,
          expression: text
        }
      ];
      const chosen = choices2.find((choice) => choice.id === options.dateEndPolicy);
      if (!chosen)
        return {
          ok: false,
          error: {
            code: "syntax",
            message: "Should the last date be included?",
            hint: "Choose which dates belong in this all-day range."
          },
          clockPrompt: { endpoint: "end", question: "Should the last date be included?", choices: choices2 }
        };
      if (chosen.id === "boundary:inclusive") {
        const next = endDate2.add({ days: 1 });
        if (next.year > 9999)
          return issue("The exclusive end is outside the supported years.", "Use a last included date before December 31, 9999.");
        const boundary = calculateScheduleDate(next.toString(), options);
        if (!boundary.ok)
          return boundary;
        end2 = boundary;
      }
      selectedClocks.push(chosen.label);
    }
    if (end2.result.timestamp <= start2.result.timestamp)
      return issue("The end must follow the start.", "Correct the written dates or times. Neither endpoint has been moved.");
    return {
      ok: true,
      kind: "interval",
      start: start2,
      end: end2,
      allDay,
      endExclusive: true,
      overnight: false,
      ...selectedClocks.length ? { selectedClocks } : {}
    };
  }
  const durationText = normalizeHalfHour(text);
  const trailing = trailingDuration.exec(durationText);
  const span = duration.exec(durationText) ?? (trailing ? [trailing[0], trailing[2], trailing[3], trailing[1]] : null);
  if (span) {
    const [, amount, unit, anchor2] = span;
    if (!Number.isSafeInteger(Number(amount)) || Number(amount) < 1 || Number(amount) > 1e6)
      return issue("That interval length is outside the supported range.", "Use 1 to 1,000,000 units.");
    const start2 = endpoint(anchor2, "start");
    if (!start2.ok)
      return start2;
    if (start2.steps.length)
      return issue("Use one start date for this interval.", "Calculate date arithmetic separately first.");
    let end2 = calculateDate(`now plus ${amount} ${unit}`, {
      ...options,
      reference: start2.result.iso
    });
    const plan = parseExpression(anchor2);
    const allDay = /^(?:day|week)/i.test(unit) && !plan.time && !(plan.anchor.kind === "relative" && plan.anchor.value === "now");
    if (allDay) {
      const endDate2 = qi.PlainDate.from(start2.result.local.slice(0, 10)).add({
        days: Number(amount) * (/^week/i.test(unit) ? 7 : 1)
      });
      end2 = calculateScheduleDate(endDate2.toString(), options);
    }
    if (!end2.ok && end2.error.code === "ambiguous-time" && !allDay && /^(?:day|week)/i.test(unit)) {
      const civil2 = calculateDate(`now plus ${amount} ${unit}`, {
        timezone: "UTC",
        reference: `${start2.result.local}Z`
      });
      if (!civil2.ok)
        return civil2;
      const local = civil2.result.local;
      end2 = endpoint(`${local.slice(0, 10)} at ${local.slice(11)}`, "end");
    }
    if (!end2.ok)
      return end2;
    if (end2.result.timestamp <= start2.result.timestamp)
      return issue("The selected end must follow the start.", "Choose another endpoint or edit the duration.");
    return {
      ok: true,
      kind: "interval",
      start: start2,
      end: end2,
      allDay,
      endExclusive: true,
      overnight: false,
      ...selectedClocks.length ? { selectedClocks } : {}
    };
  }
  if (/\bfor\b/i.test(text))
    return issue("How long should this event last?", "Use a positive whole number and seconds, minutes, hours, days or weeks, such as \u201Ctomorrow at noon for 30 minutes\u201D.");
  const match = range.exec(text);
  if (!match)
    return null;
  const [, anchor, startClock, endClock] = match;
  const startExpression = `${anchor} at ${startClock}`;
  const start = endpoint(startExpression, "start");
  if (!start.ok)
    return start;
  if (start.steps.length)
    return issue("Use one date before the time range.", "For example: \u201CFriday 10pm-12am\u201D.");
  let writtenStart = start.result.local;
  if (prompts.start) {
    const localReference = zonedInstant(options.reference, options.timezone).toPlainDateTime().toString();
    const civil2 = calculateScheduleDate(startExpression, {
      timezone: "UTC",
      reference: `${localReference}Z`
    });
    if (!civil2.ok)
      return civil2;
    writtenStart = civil2.result.local;
  }
  let endTime;
  try {
    endTime = parseExpression(`2000-01-01 at ${endClock}`).time;
  } catch {
    const clockOnly = calculateDate(`2000-01-01 at ${endClock}`, { ...options, timezone: "UTC" });
    if (!clockOnly.ok)
      return clockOnly;
    endTime = clockOnly.result.local.slice(11);
  }
  const order = qi.PlainTime.compare(qi.PlainTime.from(endTime), qi.PlainDateTime.from(writtenStart).toPlainTime());
  if (order === 0 && options.equalEndpoints !== "next-day")
    return {
      ok: false,
      equalEndpoints: true,
      error: {
        code: "syntax",
        message: "Do you mean a full day?",
        hint: "Confirm that the end is on the next date, or edit the time range."
      }
    };
  const endDate = qi.PlainDate.from(writtenStart.slice(0, 10)).add({
    days: order <= 0 ? 1 : 0
  });
  const end = endpoint(`${endDate.toString()} at ${endClock}`, "end");
  if (!end.ok)
    return end;
  if (end.result.timestamp <= start.result.timestamp)
    return {
      ok: false,
      error: {
        code: "ambiguous-time",
        message: "These choices put the end at or before the start.",
        hint: "Choose another clock occurrence, restart the choices, or edit the range. The end date has not been moved."
      },
      ...prompts.end ?? prompts.start ? { clockPrompt: prompts.end ?? prompts.start } : {}
    };
  return {
    ok: true,
    kind: "interval",
    start,
    end,
    allDay: false,
    endExclusive: true,
    overnight: order <= 0,
    ...selectedClocks.length ? { selectedClocks } : {}
  };
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/interpret-date-list.js
var month = "January|February|March|April|May|June|July|August|September|October|November|December";
var date = String.raw`(?:\d{4}-\d{2}-\d{2}|(?:${month})\s+\d{1,2}(?:st|nd|rd|th)?(?:,\s*|\s+)\d{4}|\d{1,2}/\d{1,2}/\d{4})`;
var clock3 = String.raw`(?:\d{1,2}(?::\d{2})?\s*[ap]m|\d{1,2}:\d{2}|noon|midnight)`;
var timeSuffix = `((?: at ${clock3}(?: for \\d+ (?:seconds?|minutes?|hours?|days?|weeks?))?| from ${clock3} to ${clock3})?)`;
var clause = new RegExp(`^(${date})${timeSuffix}$`, "i");
var shorthand = new RegExp(`^(?:(${month})\\s+)?(\\d{1,2}(?:st|nd|rd|th)?)(?:(?:,\\s*|\\s+)(\\d{4}))?${timeSuffix}$`, "i");
var namedStart = new RegExp(`^(?:${month})\\s+\\d{1,2}(?:st|nd|rd|th)?(?: |,|$)`, "i");
function expandNamedDates(pieces, selectedYear) {
  const matches = pieces.map((piece) => shorthand.exec(normalizeHalfHour(piece)));
  if (matches.some((match) => !match) || !matches[0]?.[1])
    return null;
  const months2 = [...new Set(matches.map((match) => match[1]?.toLowerCase()).filter(Boolean))];
  const years = [...new Set(matches.map((match) => match[3]).filter(Boolean))];
  if (!years.length && selectedYear)
    years.push(selectedYear);
  if (years.length !== 1)
    return null;
  if (months2.length > 1 && (!selectedYear || matches.some((match) => !match[1])))
    return null;
  return matches.map((match) => `${match[1] ?? months2[0]} ${match[2]}, ${years[0]}${match[4]}`);
}
function interpretDateList(text, options) {
  if (text.length > 200 || !/\s+and\s+/i.test(text))
    return null;
  const pieces = text.split(/\s+and\s+/i);
  if (!new RegExp(`^${date}(?: |$)`, "i").test(pieces[0]) && !namedStart.test(pieces[0]))
    return null;
  const invalid2 = (message) => ({
    ok: false,
    error: {
      code: "syntax",
      message,
      hint: "Write complete dates, or one month and year for same-month dates joined by \u2018and\u2019. No date or qualifier has been discarded."
    }
  });
  if (pieces.length > 14)
    return invalid2("Use at most 14 dates in one input.");
  const shorthandMatches = pieces.map((piece) => shorthand.exec(normalizeHalfHour(piece)));
  const namedPieces = [...pieces];
  const monthNotes = [];
  const writtenMonths = [
    ...new Set(shorthandMatches.map((match) => match?.[1]?.toLowerCase()).filter(Boolean))
  ];
  if (shorthandMatches.every(Boolean) && shorthandMatches[0]?.[1] && writtenMonths.length > 1) {
    for (const [index, match] of shorthandMatches.entries()) {
      if (match[1])
        continue;
      const prefix = `list:${index}:month:`;
      const choices2 = month.split("|").filter((name) => writtenMonths.includes(name.toLowerCase())).map((name) => ({
        id: `${prefix}${name.toLowerCase()}`,
        label: `${name} ${match[2]}`,
        expression: `${name} ${pieces[index]}`
      }));
      const answers = [...new Set(options.clockDecisions?.filter((id) => id.startsWith(prefix)))];
      const selected = answers.length === 1 ? choices2.find((choice) => choice.id === answers[0]) : void 0;
      if (!selected) {
        const question = `Which month applies to date ${index + 1} (${pieces[index]})?`;
        return {
          ok: false,
          error: {
            code: "syntax",
            message: question,
            hint: "Choose a written month, or add another month to this date in the input. No month has been assumed."
          },
          clockPrompt: { question, choices: choices2 }
        };
      }
      namedPieces[index] = selected.expression;
      shorthandMatches[index] = shorthand.exec(normalizeHalfHour(selected.expression));
      monthNotes.push(`Date ${index + 1}: ${selected.label}`);
    }
  }
  const needsYear = shorthandMatches.every(Boolean) && shorthandMatches[0]?.[1] && shorthandMatches.every((match) => !match[3]) && (shorthandMatches.every((match) => Boolean(match[1])) || new Set(shorthandMatches.map((match) => match[1]?.toLowerCase()).filter(Boolean)).size === 1);
  let selectedYear;
  if (needsYear) {
    const year = zonedInstant(options.reference, options.timezone).year;
    const years = [year, year + 1].filter((value) => value >= 1 && value <= 9999).map((value) => String(value).padStart(4, "0"));
    const answers = [
      ...new Set(options.clockDecisions?.filter((id) => id.startsWith("list:year:")))
    ];
    if (answers.length === 1 && years.some((value) => answers[0] === `list:year:${value}`))
      selectedYear = answers[0].slice("list:year:".length);
    if (!selectedYear) {
      const question = "Which year applies to all these dates?";
      return {
        ok: false,
        error: {
          code: "syntax",
          message: question,
          hint: "Choose one year for all dates, or write another year on each date. No year or year rollover has been assumed."
        },
        clockPrompt: {
          question,
          choices: years.map((value) => ({
            id: `list:year:${value}`,
            label: String(value),
            expression: String(value)
          }))
        }
      };
    }
  }
  let expanded = expandNamedDates(namedPieces, selectedYear) ?? namedPieces;
  const itemYearNotes = [];
  const writtenYears = [...new Set(shorthandMatches.map((match) => match?.[3]).filter(Boolean))];
  if (shorthandMatches.every((match) => Boolean(match?.[1])) && new Set(shorthandMatches.map((match) => match[1].toLowerCase())).size > 1 && writtenYears.length === 1 && shorthandMatches.some((match) => !match[3])) {
    expanded = [];
    const anchorYear = Number(writtenYears[0]);
    const years = [anchorYear - 1, anchorYear, anchorYear + 1].filter((year) => year >= 1 && year <= 9999).map((year) => String(year).padStart(4, "0"));
    for (const [index, match] of shorthandMatches.entries()) {
      let year = match[3];
      if (!year) {
        const prefix = `list:${index}:year:`;
        const answers = [...new Set(options.clockDecisions?.filter((id) => id.startsWith(prefix)))];
        year = answers.length === 1 && years.includes(answers[0].slice(prefix.length)) ? answers[0].slice(prefix.length) : void 0;
        if (!year) {
          const question = `Which year applies to ${match[1]} ${match[2]}?`;
          return {
            ok: false,
            error: {
              code: "syntax",
              message: question,
              hint: "Choose this date\u2019s year, or write it in the input. Written years stay unchanged."
            },
            clockPrompt: {
              question,
              choices: years.map((value) => ({
                id: `${prefix}${value}`,
                label: value,
                expression: `${match[1]} ${match[2]}, ${value}${match[4]}`
              }))
            }
          };
        }
        itemYearNotes.push(`Date ${index + 1}: ${year}`);
      }
      expanded.push(`${match[1]} ${match[2]}, ${year}${match[4]}`);
    }
  }
  const matches = expanded.map((piece) => clause.exec(normalizeHalfHour(piece)));
  if (matches.some((match) => !match))
    return invalid2("Complete every listed date and its time or range.");
  const writtenTimes = [...new Set(matches.map((match) => match[2]).filter(Boolean))];
  const occurrences = [];
  const notes = [
    ...selectedYear ? [`${selectedYear} for every listed date`] : [],
    ...monthNotes,
    ...itemYearNotes
  ];
  const seen = /* @__PURE__ */ new Set();
  let position = 0;
  for (const [index, piece] of pieces.entries()) {
    const start = text.indexOf(piece, position);
    position = start + piece.length;
    const source = { text: piece, span: { start, end: position } };
    const match = matches[index];
    const choicesFor = (endpoint) => {
      const prefix = `list:${index}:${endpoint}:`;
      const answers = [...new Set(options.clockDecisions?.filter((id) => id.startsWith(prefix)))];
      return answers.length === 1 ? answers[0].slice(prefix.length) : void 0;
    };
    const prompt = (question, choices2, endpoint) => ({
      ok: false,
      error: {
        code: endpoint === "date" || endpoint === "time" ? "syntax" : "ambiguous-time",
        message: question,
        hint: "Choose an interpretation for this listed date."
      },
      clockPrompt: {
        question: `Date ${index + 1} (${piece}): ${question}`,
        choices: choices2.map((choice) => ({
          ...choice,
          id: `list:${index}:${endpoint}:${choice.id}`
        }))
      }
    });
    let anchor = match[1];
    if (match[1].includes("/")) {
      const alternatives = numericDateChoices(match[1]);
      const chosen = alternatives?.length === 1 ? alternatives[0] : alternatives?.find((choice) => choice.id === choicesFor("date"));
      if (!chosen) {
        if (!alternatives?.length)
          return invalid2("A listed date is not valid.");
        return prompt("Which date did you mean?", alternatives, "date");
      }
      anchor = chosen.expression;
      if (alternatives.length > 1)
        notes.push(`Date ${index + 1}: ${chosen.label}`);
    }
    let suffix = match[2];
    if (!suffix && writtenTimes.length) {
      const choices2 = [
        ...writtenTimes.map((time, timeIndex) => ({
          id: String(timeIndex),
          label: time.trim().replace(/^./, (char) => char.toUpperCase()),
          expression: anchor + time
        })),
        { id: "date-only", label: "Keep this date without a time", expression: anchor }
      ];
      const chosen = choices2.find((choice) => choice.id === choicesFor("time"));
      if (!chosen)
        return prompt("What time applies to this date?", choices2, "time");
      suffix = chosen.id === "date-only" ? "" : writtenTimes[Number(chosen.id)];
      notes.push(`Date ${index + 1}: ${chosen.label}`);
    }
    const expression = anchor + suffix;
    let occurrence;
    if (/\b(?:from|for)\b/i.test(suffix)) {
      let range2 = interpretInterval(expression, {
        ...options,
        clockSelections: { start: choicesFor("start"), end: choicesFor("end") }
      });
      if (!range2)
        return invalid2("A listed range could not be resolved.");
      if (!range2.ok && range2.equalEndpoints) {
        const candidate = interpretInterval(expression, {
          ...options,
          equalEndpoints: "next-day",
          clockSelections: { start: choicesFor("start"), end: choicesFor("end") }
        });
        if (candidate?.ok) {
          const id = `list:${index}:end-next-day`;
          const label = `End on ${candidate.end.result.local.slice(0, 10)} at ${candidate.end.result.local.slice(11, 16)}`;
          if (!options.clockDecisions?.includes(id))
            return {
              ok: false,
              error: range2.error,
              clockPrompt: {
                question: `Date ${index + 1}: should this end on the next date?`,
                choices: [{ id, label, expression }]
              }
            };
          notes.push(`Date ${index + 1}: ${label}`);
          range2 = candidate;
        } else if (candidate)
          range2 = candidate;
      }
      if (!range2.ok) {
        if (range2.clockPrompt)
          return prompt(range2.clockPrompt.question, range2.clockPrompt.choices, range2.clockPrompt.endpoint);
        return { ok: false, error: range2.error };
      }
      notes.push(...(range2.selectedClocks ?? []).map((label) => `Date ${index + 1}: ${label}`));
      occurrence = { start: range2.start, end: range2.end, allDay: false, source };
    } else {
      let calculation = calculateScheduleDate(expression, options);
      if (!calculation.ok && calculation.error.code === "ambiguous-time") {
        const question = clockChoices(expression, options);
        if (question) {
          const chosen = question.choices.find((choice) => choice.id === choicesFor("start"));
          if (!chosen)
            return prompt(question.question, question.choices, "start");
          calculation = calculateScheduleDate("now", {
            timezone: options.timezone,
            reference: chosen.id
          });
          if (calculation.ok)
            calculation = {
              ...calculation,
              anchorDescription: `Use the explicitly selected time for listed date ${index + 1}: ${chosen.label}`
            };
          notes.push(`Date ${index + 1}: ${chosen.label}`);
        }
      }
      if (!calculation.ok)
        return { ok: false, error: calculation.error };
      occurrence = { start: calculation, allDay: !suffix, source };
    }
    const key = `${occurrence.start.result.iso}/${occurrence.end?.result.iso ?? ""}/${occurrence.allDay}`;
    if (seen.has(key))
      return invalid2("The same date or interval appears more than once.");
    seen.add(key);
    occurrences.push(occurrence);
  }
  return {
    ok: true,
    kind: "collection",
    timezone: options.timezone,
    truncated: false,
    occurrences,
    ...notes.length ? { selectedClocks: notes } : {}
  };
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/monthly-date.js
function monthlyDate(month2, rule2) {
  if (!Number.isInteger(rule2.dayOfMonth) || rule2.dayOfMonth < 1 || rule2.dayOfMonth > 31)
    throw new Error("Invalid monthly day.");
  if (rule2.shortMonth !== "skip" && rule2.shortMonth !== "last-day")
    throw new Error("Invalid short-month choice.");
  if (rule2.dayOfMonth > month2.daysInMonth && rule2.shortMonth === "skip")
    return null;
  return month2.with({ day: Math.min(rule2.dayOfMonth, month2.daysInMonth) });
}
function nextMonthlyDate(from, rule2) {
  let month2 = from.with({ day: 1 });
  for (let attempts = 0; attempts < 13; attempts++, month2 = month2.add({ months: 1 })) {
    const candidate = monthlyDate(month2, rule2);
    if (candidate && qi.PlainDate.compare(candidate, from) >= 0)
      return candidate;
  }
  throw new Error("No monthly date could be selected.");
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/interpret-recurrence.js
var weekdays2 = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"];
var weekdayName = `(?:${weekdays2.join("|")})s?`;
var weekdayList = `${weekdayName}(?:(?:,\\s*(?:and\\s+)?|\\s+and\\s+)${weekdayName}){0,6}`;
var cadence = `(?:${weekdayList}|days?|weekdays?|weekends?)`;
var weeklyPrefix = new RegExp(`^weekly on (?=${weekdayName}\\b)`, "i");
var missingClock = new RegExp("^every (" + cadence + ")$", "i");
var clock4 = String.raw`(?:\d{1,2}(?::\d{2})?\s*[ap]m|\d{1,2}:\d{2}|noon|midnight)`;
var isoDate = String.raw`\d{4}-\d{2}-\d{2}`;
var weekly = new RegExp(`^every (${cadence}) (?:(?:at (${clock4})(?: for (\\d+) (days?|weeks?|hours?|minutes?|seconds?))?)|(?:from (${clock4}) to (${clock4})))(?: starting (${isoDate}))?(?: until (${isoDate}))?(?: except (${isoDate}(?:,\\s*${isoDate})*))?$`, "i");
var invalid = (message) => ({
  ok: false,
  error: {
    code: "range",
    message,
    hint: "Use a valid weekly schedule, 1\u2013100 preview occurrences and at most 10 excluded dates."
  }
});
function resolveOccurrence(date2, clocks, options) {
  const { pointClock, durationAmount, durationUnit, rangeStart, rangeEnd } = clocks;
  const dateKey = date2.toString();
  const clockOverrides = [];
  const clockSelections = {};
  for (const endpoint of ["start", "end"]) {
    const prefix = `recurrence:${dateKey}:${endpoint}:`;
    const decisions2 = [...new Set(options.clockDecisions?.filter((id) => id.startsWith(prefix)))];
    if (decisions2.length === 1)
      clockSelections[endpoint] = decisions2[0].slice(prefix.length);
  }
  const promptFor = (prompt, endpoint) => ({
    question: `${dateKey} ${endpoint}: ${prompt.question}`,
    choices: prompt.choices.map((choice) => ({
      ...choice,
      id: `recurrence:${dateKey}:${endpoint}:${choice.id}`
    }))
  });
  let point = pointClock && !durationAmount ? calculateDate(`${date2.toString()} at ${pointClock}`, options) : void 0;
  if (point && !point.ok && point.error.code === "ambiguous-time") {
    const prompt = clockChoices(`${dateKey} at ${pointClock}`, options);
    if (prompt) {
      const chosen = prompt.choices.find((choice) => choice.id === clockSelections.start);
      if (!chosen)
        return { ...point, clockPrompt: promptFor(prompt, "start") };
      point = calculateDate("now", { timezone: options.timezone, reference: chosen.id });
      if (point.ok)
        point = {
          ...point,
          anchorDescription: `Use the explicitly selected occurrence on ${dateKey}: ${chosen.label}`
        };
      clockOverrides.push({
        date: dateKey,
        endpoint: "start",
        instant: chosen.id,
        label: chosen.label
      });
    }
  }
  const range2 = rangeStart || durationAmount ? interpretInterval(durationAmount ? `${dateKey} at ${pointClock} for ${durationAmount} ${durationUnit}` : `${date2.toString()} from ${rangeStart} to ${rangeEnd}`, {
    ...options,
    clockSelections
  }) : void 0;
  if (point && !point.ok)
    return point;
  if (range2 && !range2.ok)
    return {
      ok: false,
      error: range2.error,
      ...range2.clockPrompt ? { clockPrompt: promptFor(range2.clockPrompt, range2.clockPrompt.endpoint) } : {}
    };
  if (range2?.ok) {
    for (const endpoint of ["start", "end"]) {
      const label = range2.selectedClocks?.find((item) => item.startsWith(endpoint === "start" ? "Start:" : "End:"));
      if (label && clockSelections[endpoint])
        clockOverrides.push({
          date: dateKey,
          endpoint,
          instant: clockSelections[endpoint],
          label
        });
    }
  }
  if (!point?.ok && !range2?.ok)
    return invalid("The occurrence could not be resolved completely.");
  const start = point?.ok ? point : range2.ok ? range2.start : void 0;
  if (!start)
    return invalid("Missing occurrence start.");
  return {
    ok: true,
    occurrence: { start, ...range2?.ok ? { end: range2.end } : {} },
    clockOverrides
  };
}
function interpretRecurrence(text, options) {
  if (text.length > 200)
    return null;
  let normalized = normalizeHalfHour(text).trim().replace(/\s+/g, " ").replace(/^daily(?= |$)/i, "every day").replace(weeklyPrefix, "every ");
  let interval = 1;
  const counted = /\s+for (\S+) (?:occurrences?|times?)(?= starting | until | except |$)/i.exec(normalized);
  const countWords = [
    "one",
    "two",
    "three",
    "four",
    "five",
    "six",
    "seven",
    "eight",
    "nine",
    "ten"
  ];
  const count = counted ? /^\d+$/.test(counted[1]) ? Number(counted[1]) : countWords.indexOf(counted[1].toLowerCase()) + 1 : void 0;
  if (counted) {
    if (!count || count > 1e3)
      return invalid("Use a whole occurrence count from 1 to 1,000. No count has been rounded or shortened.");
    normalized = normalized.slice(0, counted.index) + normalized.slice(counted.index + counted[0].length);
  }
  const spacedWeeks = /^every (\d+) weeks? on /i.exec(normalized);
  const alternateWeekday = new RegExp(`^every other (?=${weekdayName}(?: (?:at|from)\\b|$))`, "i");
  if (spacedWeeks) {
    interval = Number(spacedWeeks[1]);
    if (!Number.isInteger(interval) || interval < 1 || interval > 52)
      return null;
    normalized = normalized.replace(/^every \d+ weeks? on /i, "every ");
  } else if (alternateWeekday.test(normalized)) {
    interval = 2;
    normalized = normalized.replace(/^every other /i, "every ");
  }
  const monthly = /^every month on (?:the )?(first|second|third|(?:[1-9]|[12]\d|3[01])(?:st|nd|rd|th)?)(?= |$)/i.exec(normalized);
  const dayOfMonth = monthly ? { first: 1, second: 2, third: 3 }[monthly[1].toLowerCase()] ?? Number.parseInt(monthly[1], 10) : void 0;
  if (monthly && /\d/.test(monthly[1])) {
    const written = monthly[1].toLowerCase();
    const suffix = written.replace(/^\d+/, "");
    const day = dayOfMonth;
    const expected = day >= 11 && day <= 13 ? "th" : { 1: "st", 2: "nd", 3: "rd" }[day % 10] ?? "th";
    if (suffix && suffix !== expected)
      return null;
  }
  const match = weekly.exec(monthly ? normalized.replace(monthly[0], "every day") : normalized);
  if (!match) {
    if (/^every\b/i.test(normalized) && /\bfor\s+\S+\s+(?:occurrences?|times?)\b/i.test(normalized))
      return {
        ok: false,
        error: {
          code: "syntax",
          message: "Repeating a set number of times is not supported yet.",
          hint: "Your requested count has not been applied. No schedule or calendar file has been created."
        }
      };
    if (!missingClock.test(monthly ? normalized.replace(monthly[0], "every day") : normalized))
      return null;
    const validated2 = calculateDate("now", options);
    if (!validated2.ok)
      return validated2;
    return {
      ok: false,
      needsClock: true,
      error: {
        code: "syntax",
        message: "What time should this repeat?",
        hint: "Add a time, such as \u201Cat noon\u201D, or a range such as \u201Cfrom 9 am to 5 pm\u201D. No time has been assumed."
      }
    };
  }
  const limit = options.complete ? 1e3 : options.limit ?? 3;
  if (!Number.isInteger(limit) || limit < 1 || limit > (options.complete ? 1e3 : 100))
    return invalid("Preview limit must be between 1 and 100.");
  const validated = calculateDate("now", options);
  if (!validated.ok)
    return validated;
  let monthlyRule;
  if (dayOfMonth !== void 0) {
    const policies = [
      ...new Set((options.policyDecisions ?? []).filter((id) => id === "monthly:skip" || id === "monthly:last-day"))
    ];
    if (dayOfMonth > 28 && policies.length !== 1) {
      return {
        ok: false,
        error: {
          code: "syntax",
          message: "Some months do not have that date.",
          hint: "Choose what happens in those months. Your original text stays unchanged."
        },
        policyPrompt: {
          question: `What happens in months without day ${dayOfMonth}?`,
          choices: [
            { id: "monthly:skip", label: "Skip that month", expression: text },
            { id: "monthly:last-day", label: "Use the last day of that month", expression: text }
          ]
        }
      };
    }
    monthlyRule = {
      frequency: "monthly",
      dayOfMonth,
      shortMonth: policies[0] === "monthly:last-day" ? "last-day" : "skip"
    };
  }
  const [, weekday, pointClock, durationAmount, durationUnit, rangeStart, rangeEnd, starting, until, exceptionText] = match;
  let startTime;
  try {
    startTime = parseExpression(`2000-01-01 at ${pointClock ?? rangeStart}`).time;
    if (rangeEnd) {
      const endTime = parseExpression(`2000-01-01 at ${rangeEnd}`).time;
      if (qi.PlainTime.compare(startTime, endTime) === 0)
        return invalid("The start and end times match. Enter a different end time, or use a duration such as \u201Cat 9am for 1 day\u201D.");
    }
  } catch (error) {
    if (error instanceof CalculationFailure)
      return { ok: false, error: error.issue };
    return invalid("The schedule clock could not be validated.");
  }
  if (durationAmount && (!Number.isSafeInteger(Number(durationAmount)) || Number(durationAmount) < 1 || Number(durationAmount) > 1e6))
    return invalid("Use a duration of 1 to 1,000,000 whole seconds, minutes, hours, days or weeks.");
  const namedDays = weekday.toLowerCase().split(/,\s*(?:and\s+)?|\s+and\s+/).map((name) => weekdays2.indexOf(name.replace(/s$/, "")) + 1).sort((a2, b2) => a2 - b2);
  const label = weekday.toLowerCase().replace(/s$/, "");
  const days2 = label === "day" ? [1, 2, 3, 4, 5, 6, 7] : label === "weekday" ? [1, 2, 3, 4, 5] : label === "weekend" ? [6, 7] : namedDays;
  if (new Set(days2).size !== days2.length)
    return invalid("Each weekday should appear only once.");
  const exceptions = exceptionText?.split(/,\s*/).map((date2) => date2.trim()) ?? [];
  if (exceptions.length > 10)
    return invalid("Too many excluded dates.");
  const countAnswers = [
    ...new Set((options.policyDecisions ?? []).filter((id) => id === "count:exclusions:consume" || id === "count:exclusions:replace"))
  ];
  const countExclusions = count && exceptions.length && countAnswers.length === 1 ? countAnswers[0] === "count:exclusions:consume" ? "consume" : "replace" : void 0;
  try {
    const today = qi.PlainDate.from(validated.result.local.slice(0, 10));
    let beginning = starting ? qi.PlainDate.from(starting) : today;
    const ending = until ? qi.PlainDate.from(until) : void 0;
    const pastStart = count && starting && (qi.PlainDate.compare(beginning, today) < 0 || beginning.equals(today) && zonedLocal(beginning.toPlainDateTime(startTime), options.timezone, "earlier").epochMilliseconds < validated.result.timestamp);
    const pastAnswers = [
      ...new Set((options.policyDecisions ?? []).filter((id) => id === "count:past:consume" || id === "count:past:upcoming"))
    ];
    const countPast = pastStart && pastAnswers.length === 1 ? pastAnswers[0] === "count:past:consume" ? "consume" : "upcoming" : void 0;
    if (options.complete && !ending && !count)
      return invalid("An explicit end date is required for complete bounded export.");
    if (options.complete && ending && qi.PlainDate.compare(ending, today.add({ years: 10 })) > 0)
      return invalid("Complete export is limited to ten calendar years; no end date has been changed.");
    for (const date3 of [
      beginning,
      ...ending ? [ending] : [],
      ...exceptions.map((date4) => qi.PlainDate.from(date4))
    ]) {
      if (date3.year < 1 || date3.year > 9999)
        return invalid("Schedule dates must be in years 0001\u20139999.");
    }
    if (ending && qi.PlainDate.compare(ending, beginning) < 0)
      return invalid("The last schedule date precedes its start.");
    if (pastStart && !countPast) {
      return {
        ok: false,
        error: {
          code: "syntax",
          message: "Does the count include starts before the reference time?",
          hint: "The written start still anchors the schedule. Only future events can be exported."
        },
        policyPrompt: {
          question: "Does the count include starts before the reference time?",
          choices: ["consume", "upcoming"].map((policy) => {
            const id = `count:past:${policy}`;
            const preview = interpretRecurrence(text, {
              ...options,
              complete: void 0,
              limit: 3,
              policyDecisions: [
                ...(options.policyDecisions ?? []).filter((answer) => !answer.startsWith("count:past:")),
                id
              ]
            });
            const dates = preview?.ok ? preview.occurrences.map((row) => row.start.result.local.slice(0, 10)).join(", ") || "No future events remain" : "Another date or clock choice is needed";
            return {
              id,
              expression: text,
              label: `${policy === "consume" ? "Count from the written start, including past dates" : "Count upcoming starts; keep the written cadence"} \xB7 ${dates}${preview?.ok && preview.truncated ? " \u2026" : ""}`
            };
          })
        }
      };
    }
    if (count && exceptions.length && !countExclusions) {
      return {
        ok: false,
        error: {
          code: "syntax",
          message: "Do excluded dates use one of the requested occurrences?",
          hint: "Choose whether to keep the original count slots or replace excluded dates. Your text stays unchanged."
        },
        policyPrompt: {
          question: "Do excluded dates use one of the requested occurrences?",
          choices: ["consume", "replace"].map((policy) => {
            const id = `count:exclusions:${policy}`;
            const preview = interpretRecurrence(text, {
              ...options,
              complete: void 0,
              limit: 3,
              policyDecisions: [
                ...(options.policyDecisions ?? []).filter((answer) => !answer.startsWith("count:exclusions:")),
                id
              ]
            });
            const dates = preview?.ok ? preview.occurrences.map((row) => row.start.result.local.slice(0, 10)).join(", ") || "No events remain" : "Another date or clock choice is needed";
            return {
              id,
              expression: text,
              label: `${policy === "consume" ? "Count excluded dates; do not replace them" : "Replace excluded dates to keep the event count"} \xB7 ${dates}${preview?.ok && preview.truncated ? " \u2026" : ""}`
            };
          })
        }
      };
    }
    let date2 = countPast === "consume" || qi.PlainDate.compare(beginning, today) > 0 ? beginning : today;
    date2 = date2.add({ days: Math.min(...days2.map((day) => (day - date2.dayOfWeek + 7) % 7)) });
    const nextWeekday = (current) => current.add({ days: Math.min(...days2.map((day) => (day - current.dayOfWeek + 7) % 7 || 7)) });
    if (interval > 1 && !starting) {
      if (date2.equals(today) && ["earlier", "later"].every((policy) => zonedLocal(date2.toPlainDateTime(startTime), options.timezone, policy).epochMilliseconds < qi.Instant.from(options.reference).epochMilliseconds))
        date2 = nextWeekday(date2);
      beginning = date2;
    }
    const anchorWeek = beginning.subtract({ days: beginning.dayOfWeek - 1 });
    const alignWeek = (candidate) => {
      const phase = Math.floor(candidate.since(anchorWeek).days / 7) % interval;
      if (phase === 0)
        return candidate;
      return candidate.subtract({ days: candidate.dayOfWeek - 1 }).add({ days: (interval - phase) * 7 + days2[0] - 1 });
    };
    date2 = monthlyRule ? nextMonthlyDate(date2, monthlyRule) : alignWeek(date2);
    const nextDate = (current) => monthlyRule ? nextMonthlyDate(current.add({ days: 1 }), monthlyRule) : alignWeek(nextWeekday(current));
    const occurrences = [];
    const clockOverrides = [];
    const reference = qi.Instant.from(options.reference).epochMilliseconds;
    let countedStarts = 0;
    for (let attempts = 0; attempts < (count ? 1012 : options.complete ? 3665 : 512); attempts++, date2 = nextDate(date2)) {
      if (ending && qi.PlainDate.compare(date2, ending) > 0)
        break;
      if (count && qi.PlainDate.compare(date2, today.add({ years: 10 })) > 0)
        return invalid("The requested count exceeds the ten-year export window. No partial schedule is available.");
      if (date2.year > 9999)
        return invalid("The preview exceeds the supported calendar range.");
      if (qi.PlainDate.compare(date2, today) <= 0) {
        const localStart = date2.toPlainDateTime(startTime);
        if (["earlier", "later"].every((disambiguation) => zonedLocal(localStart, options.timezone, disambiguation).epochMilliseconds < reference)) {
          if (countPast === "consume" && (!exceptions.includes(date2.toString()) || countExclusions === "consume")) {
            countedStarts++;
            if (countedStarts === count)
              break;
          }
          continue;
        }
      }
      if (exceptions.includes(date2.toString())) {
        if (countExclusions === "consume") {
          if (date2.equals(today) && zonedLocal(date2.toPlainDateTime(startTime), options.timezone, "earlier").epochMilliseconds < reference) {
            const excluded = resolveOccurrence(date2, { pointClock: pointClock ?? rangeStart }, options);
            if (!excluded.ok)
              return {
                ...excluded,
                ...excluded.clockPrompt ? {
                  clockPrompt: {
                    ...excluded.clockPrompt,
                    question: `Excluded date ${date2.toString()}: which clock determines its count slot?`
                  }
                } : {}
              };
            clockOverrides.push(...excluded.clockOverrides);
            if (excluded.occurrence.start.result.timestamp < reference) {
              if (countPast !== "consume")
                continue;
            }
          }
          countedStarts++;
          if (countedStarts === count)
            break;
        }
        continue;
      }
      const resolved = resolveOccurrence(date2, { pointClock, durationAmount, durationUnit, rangeStart, rangeEnd }, options);
      if (!resolved.ok)
        return resolved;
      const { start } = resolved.occurrence;
      clockOverrides.push(...resolved.clockOverrides);
      if (start.result.timestamp < reference) {
        if (countPast === "consume") {
          countedStarts++;
          if (countedStarts === count)
            break;
        }
        continue;
      }
      occurrences.push(resolved.occurrence);
      countedStarts++;
      if (count && countedStarts === count)
        break;
      if (occurrences.length > limit) {
        if (options.complete)
          return invalid("Complete export exceeds 1,000 occurrences; no partial file is available.");
        break;
      }
    }
    if (count && countedStarts < count && occurrences.length <= limit)
      return invalid("These boundaries do not contain the requested occurrence count. Change the count or boundary; no partial schedule is available.");
    return {
      ok: true,
      kind: "recurrence",
      timezone: options.timezone,
      rule: {
        ...monthlyRule ?? {
          frequency: "weekly",
          ...interval > 1 ? { interval } : {},
          weekdays: days2
        },
        startClock: pointClock ?? rangeStart,
        ...rangeEnd ? { endClock: rangeEnd } : {},
        ...durationAmount ? { duration: { amount: Number(durationAmount), unit: durationUnit.toLowerCase() } } : {},
        starting: beginning.toString(),
        ...ending ? { until: ending.toString() } : {},
        ...count ? { count } : {},
        ...countExclusions ? { countExclusions } : {},
        ...countPast ? { countPast } : {},
        exceptions,
        ...clockOverrides.length ? { clockOverrides } : {}
      },
      occurrences: occurrences.slice(0, limit),
      truncated: occurrences.length > limit,
      validation: "preview-only"
    };
  } catch {
    return invalid("A schedule boundary or excluded date is invalid.");
  }
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/interpret-groups.js
var days = [
  "monday",
  "tuesday",
  "wednesday",
  "thursday",
  "friday",
  "saturday",
  "sunday",
  ...Object.keys(weekdayAliases)
].join("|");
var clock5 = String.raw`(?:\d{1,2}(?::\d{2})?\s*[ap]m|\d{1,2}:\d{2}|noon|midnight)`;
function interpretGroups(text, options) {
  if (text.length > 200)
    return null;
  const group = new RegExp(`((?:${days})(?:\\s+(?:${days}))*)\\s+(?:from\\s+)?(${clock5})\\s*(?:to|[-\u2013])\\s*(${clock5})`, "iy");
  const occurrences = [];
  let position = 0;
  const duplicate = /* @__PURE__ */ new Set();
  const selectedClocks = [];
  const matches = [];
  const invalid2 = (message) => ({
    ok: false,
    error: {
      code: "syntax",
      message,
      hint: "Use complete weekday ranges, such as \u201CSat Sun 1pm-8pm Mon 10pm-12am\u201D."
    }
  });
  while (position < text.length) {
    group.lastIndex = position;
    const match = group.exec(text);
    if (!match)
      return matches.length ? invalid2("Complete every weekday range and remove unsupported trailing text.") : null;
    if (position === 0 && group.lastIndex === text.length && !/\s/.test(match[1]))
      return null;
    matches.push({ match, start: position, end: group.lastIndex });
    position = group.lastIndex;
    if (position === text.length)
      break;
    const separator = /^(?:\s+|;\s*|,\s*)/.exec(text.slice(position));
    if (!separator || position + separator[0].length === text.length)
      return null;
    position += separator[0].length;
  }
  const count = matches.reduce((sum, { match }) => sum + match[1].split(/\s+/).length, 0);
  if (count < 2)
    return null;
  if (count > 14)
    return invalid2("Use at most 14 intervals in one input.");
  for (const { match, start, end } of matches) {
    const source = { text: match[0], span: { start, end } };
    for (const day of match[1].split(/\s+/)) {
      const rangeIndex = occurrences.length;
      const clockSelections = {};
      for (const endpoint of ["start", "end"]) {
        const prefix = `group:${rangeIndex}:${endpoint}:`;
        const decisions2 = [
          ...new Set(options.clockDecisions?.filter((id2) => id2.startsWith(prefix)))
        ];
        if (decisions2.length === 1)
          clockSelections[endpoint] = decisions2[0].slice(prefix.length);
      }
      const expression = `${day} ${match[2]}-${match[3]}`;
      const intervalOptions = {
        ...options,
        clockSelections
      };
      let interval = interpretInterval(expression, intervalOptions);
      if (!interval)
        return invalid2("An interval could not be interpreted completely.");
      if (!interval.ok && interval.equalEndpoints) {
        const candidate = interpretInterval(expression, {
          ...intervalOptions,
          equalEndpoints: "next-day"
        });
        if (candidate && !candidate.ok)
          interval = candidate;
        if (candidate?.ok) {
          const id2 = `group:${rangeIndex}:end-next-day`;
          const label = `End on ${candidate.end.result.local.slice(0, 10)} at ${candidate.end.result.local.slice(11, 16)} (${options.timezone}, UTC${candidate.end.result.offset})`;
          if (!options.clockDecisions?.includes(id2))
            return {
              ok: false,
              error: interval.error,
              clockPrompt: {
                question: `Range ${rangeIndex + 1} (${day}): should this end on the next date?`,
                choices: [{ id: id2, label, expression }]
              }
            };
          interval = candidate;
          selectedClocks.push(`Range ${rangeIndex + 1} (${day}): ${label}`);
        }
      }
      if (!interval.ok)
        return {
          ok: false,
          error: interval.error,
          ...interval.clockPrompt ? {
            clockPrompt: {
              question: `Range ${rangeIndex + 1} (${day}), ${interval.clockPrompt.endpoint}: ${interval.clockPrompt.question}`,
              choices: interval.clockPrompt.choices.map((choice) => ({
                ...choice,
                id: `group:${rangeIndex}:${interval.clockPrompt.endpoint}:${choice.id}`
              }))
            }
          } : {}
        };
      selectedClocks.push(...(interval.selectedClocks ?? []).map((label) => `Range ${rangeIndex + 1} (${day}): ${label}`));
      const id = `${interval.start.result.iso}/${interval.end.result.iso}`;
      if (duplicate.has(id))
        return invalid2("The same interval appears more than once.");
      duplicate.add(id);
      occurrences.push({ start: interval.start, end: interval.end, source });
    }
  }
  return {
    ok: true,
    kind: "collection",
    timezone: options.timezone,
    truncated: false,
    occurrences,
    ...selectedClocks.length ? { selectedClocks } : {}
  };
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/clarify-arithmetic.js
function clarifyArithmetic(expression, options, selections) {
  const strict = calculateDate(expression, options);
  if (strict.ok || strict.error.code !== "ambiguous-time" || !parseExpression(expression).operations.length)
    return null;
  let prompt;
  const decisions2 = [];
  const labels = [];
  let index = 0;
  const calculation = calculateWithClockResolver(expression, options, (local, timezone) => {
    const position = index++;
    try {
      return zonedLocal(local, timezone);
    } catch (error) {
      if (!(error instanceof AmbiguousLocalTime))
        throw error;
    }
    const dates = [zonedLocal(local, timezone, "earlier"), zonedLocal(local, timezone, "later")];
    const choices2 = dates.map((date2) => ({
      id: `arithmetic:${position}:${local.toString()}:${date2.toInstant().toString()}`,
      expression,
      label: `${describeZonedInstant(date2.epochMilliseconds, timezone)} (UTC${date2.offset})`
    }));
    const matching = choices2.filter((choice) => selections.includes(choice.id));
    const selected = matching.length === 1 ? choices2.indexOf(matching[0]) : -1;
    if (selected < 0) {
      prompt = {
        question: "Which clock time should the calculation use before continuing?",
        choices: choices2
      };
      fail("ambiguous-time", prompt.question, "Choose a clock time to continue the remaining arithmetic.");
    }
    decisions2.push(`At ${local.toString()}, you selected ${choices2[selected].label}. Remaining operations retain their written order.`);
    labels.push(choices2[selected].label);
    return dates[selected];
  });
  return {
    calculation: calculation.ok ? { ...calculation, warnings: [...calculation.warnings, ...decisions2] } : calculation,
    prompt,
    decisions: decisions2,
    labels
  };
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/interpret-date.js
var temporalStart = /\b(?:every|for|noon|midnight|today|tomorrow|yesterday|next|last|this|in|on|at|monday|tuesday|wednesday|thursday|friday|saturday|sunday|mon|tue|wed|thu|fri|sat|sun|jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?|days?|weeks?|months?|years?|hours?|minutes?|seconds?|\d+)\b/i;
var reminderBoundary = new RegExp(temporalStart.source + "|\\b(?:each|alternate|alternating|repeat|repeating|recurring|sometime|roughly|approximately|now|tonight|daily|weekly|monthly|yearly|annually|hourly|nightly|quarterly|biweekly|fortnightly|weekdays?|weekends?|mornings?|afternoons?|evenings?|regularly|often|once|twice|before|after|between|until|starting|from|since|around|about|through|during|within|by|earlier|later|soon|zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand|million|half|couple|quarter|mondays|tuesdays|wednesdays|thursdays|fridays|saturdays|sundays)\\b|\\ba(?=\\s+(?:half|couple|quarter|day|week|month|year|hour|minute|second|fortnight)\\b)", "i");
var labelIdentifier = /\b(room|ticket|invoice|order|person|extension|issue|flight|gate|route|table|chapter|item|case)\s+#?(\d+|zero|one|two|three|four|five|six|seven|eight|nine|ten)\b(?!\s*(?:[:/]|(?:[ap]\.?m\.?|and|half|quarter|days?|weeks?|months?|years?|hours?|minutes?|seconds?)\b))/gi;
function labelBoundary(text) {
  const identifiers = [...text.matchAll(labelIdentifier)];
  const boundaries = text.matchAll(new RegExp(reminderBoundary.source, "gi"));
  for (const match of boundaries) {
    if (!identifiers.some((identifier) => {
      const numberStart = identifier.index + identifier[0].length - identifier[2].length;
      return match.index >= numberStart && match.index < identifier.index + identifier[0].length;
    }))
      return match.index;
  }
  return -1;
}
function validEventLabel(text) {
  return /^[\p{L}][\p{L}'’-]*(?:\s+[\p{L}][\p{L}'’-]*)*$/u.test(text.replace(labelIdentifier, "$1"));
}
function interpretDate(input2, options) {
  const unresolved = (status, message, hint) => ({
    interpretationVersion: 1,
    status,
    error: { code: "syntax", message, hint }
  });
  const fromCalculation = (calculation, start, text2, event2, selectedClock = false) => {
    if (!calculation.ok)
      return {
        interpretationVersion: 1,
        status: calculation.error.code === "ambiguous-time" ? "needs-clarification" : "unsupported",
        error: {
          ...calculation.error,
          ...calculation.error.span ? {
            span: {
              start: start + calculation.error.span.start,
              end: start + calculation.error.span.end
            }
          } : {}
        }
      };
    const plan = parseExpression(calculation.expression);
    const clockSource = selectedClock || plan.time ? "explicit" : plan.anchor.kind === "relative" && plan.anchor.value === "now" ? "reference" : plan.operations.some((operation) => ["hour", "minute", "second", "millisecond"].includes(operation.unit)) || calculation.steps.some((step) => step.before.local.slice(11) !== step.after.local.slice(11)) ? "arithmetic" : "default";
    return {
      interpretationVersion: 1,
      status: "resolved",
      value: {
        kind: "point",
        calculation,
        precision: clockSource === "default" ? "date" : "time",
        clockSource
      },
      source: { text: text2, span: { start, end: start + text2.length } },
      ...event2 ? { event: event2 } : {},
      ...calculation.warnings.includes(DATE_START_POLICY) ? { apiReplay: false } : {},
      assumptions: [
        ...event2 ? ["The event text is a label only; no reminder has been created."] : [],
        ...calculation.warnings.filter((warning) => warning === DATE_START_POLICY)
      ]
    };
  };
  const fromGroups = (text2, start, event2) => {
    const contextKey = interpretationContextKey(input2, options);
    const clockDecisions = options.selection?.contextKey === contextKey ? [
      options.selection.id,
      ...(options.selection.previous ?? []).slice(-MAX_SELECTION_HISTORY).reverse()
    ] : [];
    const groups = interpretDateList(text2, { ...options, clockDecisions }) ?? interpretGroups(text2, { ...options, clockDecisions });
    if (!groups)
      return null;
    if (!groups.ok) {
      const { span: _span, ...error } = groups.error;
      return {
        interpretationVersion: 1,
        status: groups.clockPrompt || error.code === "ambiguous-time" || error.message === "Do you mean a full day?" ? "needs-clarification" : "unsupported",
        error: groups.clockPrompt ? {
          ...error,
          message: groups.clockPrompt.question,
          hint: groups.clockPrompt.choices.some((choice) => choice.id.startsWith("list:year:")) ? error.hint : `${error.message} This choice affects only this listed date or range.`
        } : error,
        ...groups.clockPrompt ? { clarification: { contextKey, ...groups.clockPrompt } } : {}
      };
    }
    return {
      interpretationVersion: 1,
      status: "resolved",
      value: {
        ...groups,
        occurrences: groups.occurrences.map((row) => ({
          ...row,
          allDay: "allDay" in row && row.allDay,
          source: {
            text: row.source.text,
            span: { start: start + row.source.span.start, end: start + row.source.span.end }
          }
        }))
      },
      source: { text: text2, span: { start, end: start + text2.length } },
      ...event2 ? { event: event2 } : {},
      apiReplay: false,
      assumptions: [
        "Each listed date or range occurs once; this is not a repeating rule.",
        ...(groups.selectedClocks ?? []).map((label) => `You selected ${label}.`)
      ]
    };
  };
  const fromRecurrence = (text2, start, event2) => {
    const contextKey = interpretationContextKey(input2, options);
    const clockDecisions = options.selection?.contextKey === contextKey ? [
      options.selection.id,
      ...(options.selection.previous ?? []).slice(-MAX_SELECTION_HISTORY).reverse()
    ] : [];
    const recurrence2 = interpretRecurrence(text2, {
      ...options,
      clockDecisions,
      policyDecisions: clockDecisions
    });
    if (!recurrence2) {
      if (/^(?:every|daily|weekly)\s/i.test(text2) && /\bexcept\b/i.test(text2))
        return unresolved("unsupported", "This repeating schedule or exclusion is not supported yet.", "Use full weekday names with a shared time and exact excluded dates, for example: \u201Cevery Monday and Wednesday at noon except 2026-09-16\u201D.");
      return null;
    }
    if (!recurrence2.ok) {
      const { span: _span, ...error } = recurrence2.error;
      return {
        interpretationVersion: 1,
        status: error.code === "ambiguous-time" || recurrence2.needsClock || recurrence2.policyPrompt ? "needs-clarification" : "unsupported",
        error: recurrence2.policyPrompt ? { ...error, message: recurrence2.policyPrompt.question } : recurrence2.clockPrompt ? {
          ...error,
          message: recurrence2.clockPrompt.question,
          hint: `${error.message} Your choice applies only to this occurrence. Other dates keep their written local clocks.`
        } : error,
        ...recurrence2.policyPrompt ?? recurrence2.clockPrompt ? {
          clarification: {
            contextKey,
            ...recurrence2.policyPrompt ?? recurrence2.clockPrompt
          }
        } : {}
      };
    }
    return {
      interpretationVersion: 1,
      status: "resolved",
      value: recurrence2,
      ...recurrence2.rule.countPast || recurrence2.rule.countExclusions ? {
        selectedChoice: [
          recurrence2.rule.countPast === "consume" ? "The count includes past starts." : recurrence2.rule.countPast === "upcoming" ? "Only upcoming starts use count slots; the written cadence is retained." : void 0,
          recurrence2.rule.countExclusions === "consume" ? "Excluded dates use count slots and are not replaced." : recurrence2.rule.countExclusions === "replace" ? "Excluded dates are replaced to keep the requested event count." : void 0
        ].filter(Boolean).join(" ")
      } : {},
      source: { text: text2, span: { start, end: start + text2.length } },
      ...event2 ? { event: event2 } : {},
      apiReplay: false,
      assumptions: [
        "Only upcoming occurrence starts appear in the preview.",
        "Recurrence export has not been validated.",
        ...(recurrence2.rule.clockOverrides ?? []).map((choice) => `For ${choice.date} ${choice.endpoint} only, you selected ${choice.label}. Other occurrences keep their written local clocks.`)
      ]
    };
  };
  const fromInterval = (text2, start, event2) => {
    const contextKey = interpretationContextKey(input2, options);
    const decisions2 = options.selection?.contextKey === contextKey ? [
      options.selection.id,
      ...(options.selection.previous ?? []).slice(-MAX_SELECTION_HISTORY).reverse()
    ] : [];
    const clockSelections = Object.fromEntries(["start", "end"].map((endpoint) => {
      const prefix = `interval:${endpoint}:`;
      const answers = [
        ...new Set(decisions2.filter((id) => id.startsWith(prefix) && !id.startsWith(`${prefix}date:`) && !id.startsWith(`${prefix}time:`) && !id.startsWith(`${prefix}boundary:`)))
      ];
      return [endpoint, answers.length === 1 ? answers[0].slice(prefix.length) : void 0];
    }));
    const dateSelections = Object.fromEntries(["start", "end"].map((endpoint) => {
      const prefix = `interval:${endpoint}:date:`;
      const answers = [...new Set(decisions2.filter((id) => id.startsWith(prefix)))];
      return [endpoint, answers.length === 1 ? answers[0].slice(prefix.length) : void 0];
    }));
    const boundaryAnswers = [
      ...new Set(decisions2.filter((id) => id.startsWith("interval:end:boundary:")))
    ];
    const dateEndPolicy = boundaryAnswers.length === 1 ? boundaryAnswers[0].slice("interval:end:".length) : void 0;
    const timeSelections = Object.fromEntries(["start", "end"].map((endpoint) => {
      const prefix = `interval:${endpoint}:time:`;
      const answers = [...new Set(decisions2.filter((id) => id.startsWith(prefix)))];
      return [
        endpoint,
        answers.length === 1 ? answers[0].slice(`interval:${endpoint}:`.length) : void 0
      ];
    }));
    const intervalOptions = {
      ...options,
      clockSelections,
      dateSelections,
      dateEndPolicy,
      timeSelections
    };
    let interval = interpretInterval(text2, intervalOptions);
    if (!interval)
      return null;
    let chosenLabel;
    if (!interval.ok && interval.equalEndpoints) {
      const candidate = interpretInterval(text2, { ...intervalOptions, equalEndpoints: "next-day" });
      if (candidate && !candidate.ok)
        interval = candidate;
      if (candidate?.ok) {
        const id = "interval:end-next-day";
        const label = `End on ${candidate.end.result.local.slice(0, 10)} at ${candidate.end.result.local.slice(11, 16)} (${options.timezone}, UTC${candidate.end.result.offset})`;
        if (decisions2.includes(id)) {
          interval = candidate;
          chosenLabel = label;
        } else {
          return {
            interpretationVersion: 1,
            status: "needs-clarification",
            error: {
              ...interval.error,
              message: "Should this range end on the next date?"
            },
            clarification: {
              contextKey,
              question: "Should this range end on the next date?",
              choices: [{ id, label, expression: text2 }]
            }
          };
        }
      }
    }
    if (!interval.ok) {
      const { span: _span, ...error } = interval.error;
      return {
        interpretationVersion: 1,
        status: interval.clockPrompt || error.code === "ambiguous-time" || error.message === "Do you mean a full day?" ? "needs-clarification" : "unsupported",
        error: interval.clockPrompt ? {
          ...error,
          message: `${interval.clockPrompt.endpoint === "start" ? "Start" : "End"}: ${error.message}`
        } : error,
        ...interval.clockPrompt ? {
          clarification: {
            contextKey,
            question: `${interval.clockPrompt.endpoint === "start" ? "Start" : "End"}: ${interval.clockPrompt.question}`,
            choices: interval.clockPrompt.choices.map((choice) => ({
              ...choice,
              id: `interval:${interval.clockPrompt.endpoint}:${choice.id}`
            }))
          }
        } : {}
      };
    }
    return {
      interpretationVersion: 1,
      status: "resolved",
      value: interval,
      source: { text: text2, span: { start, end: start + text2.length } },
      ...event2 ? { event: event2 } : {},
      ...chosenLabel || interval.selectedClocks?.length ? {
        selectedChoice: [chosenLabel, ...interval.selectedClocks ?? []].filter(Boolean).join("; "),
        apiReplay: false
      } : {},
      assumptions: [
        "The interval end is exclusive.",
        ...(interval.selectedClocks ?? []).map((label) => `You selected ${label}.`),
        ...chosenLabel ? [
          "You confirmed that the written matching end clock refers to the next date. Any selected clock replacement may change the duration."
        ] : [],
        ...interval.overnight ? ["The end clock falls on the following date."] : []
      ]
    };
  };
  const fromClock = (expression, start, event2, sourceText = expression) => {
    const arithmeticContext = interpretationContextKey(input2, options);
    const arithmeticSelection = options.selection?.contextKey === arithmeticContext ? options.selection : void 0;
    const arithmetic = clarifyArithmetic(expression, options, arithmeticSelection ? [...arithmeticSelection.previous ?? [], arithmeticSelection.id] : []);
    if (arithmetic) {
      if (arithmetic.prompt)
        return {
          interpretationVersion: 1,
          status: "needs-clarification",
          error: {
            code: "ambiguous-time",
            message: arithmetic.prompt.question,
            hint: "Choose a clock time to continue the remaining arithmetic."
          },
          clarification: { contextKey: arithmeticContext, ...arithmetic.prompt }
        };
      const result2 = fromCalculation(arithmetic.calculation, start, sourceText, event2, true);
      return result2.status === "resolved" ? {
        ...result2,
        apiReplay: false,
        selectedChoice: arithmetic.labels.join("; "),
        assumptions: [...result2.assumptions, ...arithmetic.decisions]
      } : result2;
    }
    const prompt = clockChoices(expression, options);
    if (!prompt)
      return null;
    const contextKey = interpretationContextKey(input2, options);
    const selected = options.selection?.contextKey === contextKey ? prompt.choices.find((choice) => choice.id === options.selection?.id) : void 0;
    if (!selected)
      return {
        interpretationVersion: 1,
        status: "needs-clarification",
        error: {
          code: "ambiguous-time",
          message: prompt.question,
          hint: "Choose an explicit time and UTC offset, or edit the original phrase."
        },
        clarification: { contextKey, ...prompt }
      };
    const calculation = calculateDate("now", {
      timezone: options.timezone,
      reference: selected.id
    });
    if (!calculation.ok)
      return fromCalculation(calculation, start, sourceText, event2);
    const result = fromCalculation({
      ...calculation,
      anchorDescription: "Use the explicitly selected instant: " + selected.label
    }, start, sourceText, event2, true);
    return result.status === "resolved" ? {
      ...result,
      selectedChoice: selected.label.replace(/^Use /, ""),
      apiReplay: false,
      assumptions: [
        ...result.assumptions,
        "The user selected this clock occurrence or replacement. Strict API v2 does not resolve this ambiguity."
      ]
    } : result;
  };
  const fromNumeric = (text2, start, event2) => {
    const choices2 = numericDateChoices(text2);
    if (choices2 === null)
      return null;
    const validContext = calculateDate("now", options);
    if (!validContext.ok)
      return fromCalculation(validContext, start, text2, event2);
    if (!choices2.length)
      return unresolved("unsupported", "That calendar date does not exist.", "Check the day, month and year.");
    const contextKey = interpretationContextKey(input2, options);
    const selected = choices2.length === 1 ? choices2[0] : options.selection?.contextKey === contextKey ? [
      options.selection.id,
      ...(options.selection.previous ?? []).slice(-MAX_SELECTION_HISTORY).reverse()
    ].map((id) => choices2.find((choice) => choice.id === id)).find((choice) => choice !== void 0) : void 0;
    if (!selected)
      return {
        interpretationVersion: 1,
        status: "needs-clarification",
        error: {
          code: "syntax",
          message: "Which date do you mean?",
          hint: "Choose the month and day. Your original text stays here."
        },
        clarification: { contextKey, question: "Which date do you mean?", choices: choices2 }
      };
    const interval = fromInterval(selected.expression, start, event2);
    if (interval) {
      if (interval.status !== "resolved")
        return interval;
      return {
        ...interval,
        source: { text: text2, span: { start, end: start + text2.length } },
        selectedChoice: [selected.label, interval.selectedChoice].filter(Boolean).join("; "),
        assumptions: [...interval.assumptions, `Date interpreted as ${selected.label}.`]
      };
    }
    const calculation = calculateScheduleDate(selected.expression, options);
    if (!calculation.ok) {
      const clock6 = fromClock(selected.expression, start, event2, text2);
      if (clock6)
        return clock6;
      const { span: _span, ...error } = calculation.error;
      return {
        interpretationVersion: 1,
        status: error.code === "ambiguous-time" ? "needs-clarification" : "unsupported",
        error
      };
    }
    const result = fromCalculation(calculation, start, text2, event2);
    return result.status === "resolved" ? {
      ...result,
      ...choices2.length > 1 ? { selectedChoice: selected.label } : {},
      assumptions: [...result.assumptions, `Date interpreted as ${selected.label}.`]
    } : result;
  };
  const strict = calculateScheduleDate(input2, options);
  const leading = input2.length - input2.trimStart().length;
  if (strict.ok)
    return fromCalculation(strict, leading, input2.trim());
  if (input2.length > 200)
    return fromCalculation(strict, 0, input2);
  const text = input2.trim().replace(/[.!?]+$/, "").trimEnd();
  if (!text)
    return unresolved("no-expression", "Enter a date phrase.", "Try \u201Ctomorrow at noon\u201D.");
  if (/\b(?:not|never|cannot|cancel|cancelled|canceled)\b|\b(?:ca|wo|sha|do|does|did|is|are|was|were|has|have|had|could|should|would|must|need)n['’]t\b/i.test(text)) {
    return unresolved("no-expression", "No date selected from this instruction.", "It contains a cancellation or negative instruction. Enter only the date you want to calculate.");
  }
  const alternatives = /^(?:(meet)\s+)?(.+?)\s+or\s+(.+)$/i.exec(text);
  const isAlternative = Boolean(alternatives) && (text.match(/\bor\b/gi)?.length ?? 0) === 1 && !/\b(?:actually|instead|unless|except|if|reschedule)\b/i.test(text);
  const correction = (isAlternative ? alternatives : null) ?? /^(?:(meet)\s+)?(.+?)(?:,\s*|\s+)actually\s+(.+?)(?:\s+instead)?$/i.exec(text);
  if (correction && (isAlternative || (text.match(/\bactually\b/gi)?.length ?? 0) === 1 && !/\b(?:unless|except|if|or|reschedule)\b/i.test(text))) {
    const [, meet, before, after] = correction;
    const contextKey = interpretationContextKey(input2, options);
    const branchKind = isAlternative ? "alternative" : "correction";
    const branchResult = (clause2, index) => {
      const prefix = `${branchKind}:branch:${index}:`;
      let selection2;
      if (options.selection?.contextKey === contextKey) {
        for (const id of [...options.selection.previous ?? [], options.selection.id]) {
          if (id.startsWith(prefix))
            selection2 = appendSelection(selection2, {
              contextKey: interpretationContextKey(clause2, options),
              id: id.slice(prefix.length)
            });
        }
      }
      return interpretDate(clause2, {
        timezone: options.timezone,
        reference: options.reference,
        ...selection2 ? { selection: selection2 } : {}
      });
    };
    const beforeResult = branchResult(before, 0);
    const afterResult = branchResult(after, 1);
    const branches = [beforeResult, afterResult];
    if (branches.every((result) => result.status === "resolved" ? result.value.kind === "point" || result.value.kind === "interval" : Boolean(result.clarification)) && !(afterResult.status === "resolved" && afterResult.event)) {
      const index = branches.findIndex((result) => result.status !== "resolved");
      const pending = branches[index];
      if (pending && pending.status !== "resolved" && pending.clarification) {
        const clauseLabel = isAlternative ? `${index === 0 ? "First" : "Second"} alternative` : index === 0 ? "Original date" : "Replacement date";
        const question = `${clauseLabel}: ${pending.clarification.question}`;
        return {
          ...pending,
          error: { ...pending.error, message: question },
          clarification: {
            contextKey,
            question,
            choices: pending.clarification.choices.map((choice) => ({
              ...choice,
              id: `${branchKind}:branch:${index}:${choice.id}`
            }))
          }
        };
      }
    }
    if (beforeResult.status === "resolved" && afterResult.status === "resolved" && !afterResult.event && beforeResult.value.kind !== "recurrence" && beforeResult.value.kind !== "collection" && afterResult.value.kind !== "recurrence" && afterResult.value.kind !== "collection") {
      const candidates = [
        {
          id: isAlternative ? "alternative:first" : "keep",
          result: beforeResult,
          expression: before
        },
        {
          id: isAlternative ? "alternative:second" : "replace",
          result: afterResult,
          expression: after
        }
      ];
      const describe = (result) => {
        const value = result.value;
        if (value.kind === "recurrence" || value.kind === "collection")
          return "Multiple occurrences";
        const first = value.kind === "point" ? value.calculation : value.start;
        const describeDate = (local) => new Intl.DateTimeFormat("en-US", {
          timeZone: "UTC",
          month: "long",
          day: "numeric",
          year: "numeric"
        }).format(/* @__PURE__ */ new Date(`${local.slice(0, 10)}T12:00:00Z`));
        if (value.kind === "point" && value.precision === "date")
          return `${describeDate(first.result.local)} (date only)`;
        if (value.kind === "interval" && value.allDay)
          return `${describeDate(first.result.local)} to ${describeDate(value.end.result.local)} (all day; exclusive end)`;
        const start = describeZonedInstant(first.result.timestamp, first.timezone);
        return value.kind === "point" ? start : `${start} to ${describeZonedInstant(value.end.result.timestamp, first.timezone)} (exclusive end)`;
      };
      const choices2 = candidates.map((candidate) => ({
        id: candidate.id,
        expression: candidate.expression,
        label: `${candidate.id === "keep" ? "Keep" : "Use"} ${describe(candidate.result)}`
      }));
      const chosen = options.selection?.contextKey === contextKey ? candidates.find((candidate) => candidate.id === options.selection?.id) : void 0;
      const question = isAlternative ? "Which date do you want?" : "Did the second date replace the first?";
      if (!chosen)
        return {
          interpretationVersion: 1,
          status: "needs-clarification",
          error: {
            code: "syntax",
            message: question,
            hint: "Choose the date or range to use. Your original text stays here."
          },
          clarification: {
            contextKey,
            question,
            choices: choices2
          }
        };
      const originalEvent = beforeResult.event;
      const event2 = originalEvent ? {
        text: originalEvent.text,
        span: {
          start: leading + text.indexOf(before) + originalEvent.span.start,
          end: leading + text.indexOf(before) + originalEvent.span.end
        }
      } : meet ? { text: meet, span: { start: leading, end: leading + meet.length } } : void 0;
      return {
        ...chosen.result,
        apiReplay: false,
        source: { text, span: { start: leading, end: leading + text.length } },
        ...event2 ? { event: event2 } : {},
        selectedChoice: describe(chosen.result),
        assumptions: [
          ...chosen.result.assumptions,
          isAlternative ? `You selected the ${chosen.id === "alternative:first" ? "first" : "second"} written alternative.` : chosen.id === "replace" ? "You confirmed that the second date replaces the first." : "You chose to keep the first date."
        ]
      };
    }
  }
  const recurrence = fromRecurrence(text, leading);
  if (recurrence)
    return recurrence;
  if (/\b(?:actually|instead|unless|if|or|reschedule)\b/i.test(text) || /\bexcept\b/i.test(text) && !/\b(?:every|daily|weekly)\b/i.test(text)) {
    return unresolved("needs-clarification", "Which date do you want?", "This needs a more specific date or condition. Enter one complete date phrase for each correction.");
  }
  const punctuated = calculateScheduleDate(text, options);
  if (punctuated.ok)
    return fromCalculation(punctuated, leading, text);
  let dateStart;
  let event;
  let confirmedTitle = false;
  const reminder = /^(?:please\s+)?remind me to\s+/i.exec(text);
  const actionPattern = /^(?:call|email|text|visit|pay|buy|send|submit|pick up)\s+/i;
  if (reminder || actionPattern.test(text)) {
    const prefixLength = reminder?.[0].length ?? 0;
    const rest = text.slice(prefixLength);
    if (!actionPattern.test(rest)) {
      return unresolved("unsupported", "This reminder form is not supported yet.", "Try \u201CRemind me to call Sam tomorrow at noon\u201D, or enter just the date.");
    }
    const action = actionPattern.exec(rest);
    const target = rest.slice(action[0].length);
    const boundary = labelBoundary(target);
    const labelTarget = boundary >= 0 ? target.slice(0, boundary).trimEnd() : "";
    if (/\b(?:maybe|perhaps|probably|possibly|tentatively|optionally)\b/i.test(labelTarget)) {
      return unresolved("needs-clarification", "Is this a definite reminder?", "The phrase includes uncertain wording. Keep editing, or remove that wording if you want to schedule it. No event has been selected.");
    }
    if (labelTarget && validEventLabel(labelTarget)) {
      const label = rest.slice(0, action[0].length + boundary).trimEnd();
      dateStart = prefixLength + action[0].length + boundary;
      event = {
        text: label,
        span: {
          start: leading + prefixLength,
          end: leading + prefixLength + label.length
        }
      };
    }
  } else {
    const absence = /^(?:set\s+)?(OOO)\s+/i.exec(text);
    const meeting = /^(?:the\s+)?meeting is\s+/i.exec(text);
    const question = /^(?:can|could) we (talk|meet)\s+/i.exec(text);
    const prefix = absence ?? meeting ?? question;
    if (prefix) {
      dateStart = prefix[0].length;
      const label = absence ? absence[1] : meeting ? "meeting" : question[1];
      const index = text.toLowerCase().indexOf(label.toLowerCase());
      event = {
        text: text.slice(index, index + label.length),
        span: { start: leading + index, end: leading + index + label.length }
      };
    }
  }
  if (dateStart === void 0) {
    const boundary = labelBoundary(text);
    const title = boundary > 0 ? text.slice(0, boundary).trimEnd() : "";
    if (title && validEventLabel(title) && !/\b(?:maybe|perhaps|probably|possibly|tentatively|optionally|might|must|should|would|could|can|cannot|cant|is|are|was|were|have|has|had|will|wont)\b|['’]t\b/i.test(title)) {
      const phrase = text.slice(boundary);
      const candidate = interpretDate(phrase, {
        timezone: options.timezone,
        reference: options.reference
      });
      const supported = candidate.status === "resolved" ? !candidate.event : Boolean(candidate.clarification);
      if (supported) {
        const contextKey = interpretationContextKey(input2, options);
        const confirmed = options.selection?.contextKey === contextKey && [...options.selection.previous ?? [], options.selection.id].includes("event:title");
        if (!confirmed) {
          const question = `Use \u201C${title}\u201D as the event title?`;
          return {
            interpretationVersion: 1,
            status: "needs-clarification",
            error: {
              code: "syntax",
              message: question,
              hint: `Date phrase: ${phrase}. Confirm the title or edit your input.`
            },
            clarification: {
              contextKey,
              question,
              choices: [{ id: "event:title", label: `Use \u201C${title}\u201D`, expression: phrase }]
            }
          };
        }
        confirmedTitle = true;
        dateStart = boundary;
        event = { text: title, span: { start: leading, end: leading + title.length } };
      }
    }
  }
  if (dateStart === void 0)
    return fromGroups(text, leading) ?? fromClock(text, leading) ?? fromNumeric(text, leading) ?? fromInterval(text, leading) ?? fromCalculation(strict, 0, input2);
  let date2 = text.slice(dateStart);
  const on2 = /^on\s+/i.exec(date2);
  if (on2) {
    dateStart += on2[0].length;
    date2 = date2.slice(on2[0].length);
  }
  const resolved = fromGroups(date2, leading + dateStart, event) ?? fromRecurrence(date2, leading + dateStart, event) ?? fromClock(date2, leading + dateStart, event) ?? fromNumeric(date2, leading + dateStart, event) ?? fromInterval(date2, leading + dateStart, event) ?? fromCalculation(calculateScheduleDate(date2, options), leading + dateStart, date2, event);
  return confirmedTitle && resolved.status === "resolved" ? {
    ...resolved,
    apiReplay: false,
    selectedChoice: [`Title: ${event.text}`, resolved.selectedChoice].filter(Boolean).join("; ")
  } : resolved;
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/sdk.js
var SDK_VERSION = "0.1.0";
var limits = Object.freeze({
  inputCharacters: 200,
  clarificationHistory: MAX_SELECTION_HISTORY,
  batchSize: 100,
  weeklyPreview: 3,
  weeklyInterval: 52,
  groupedIntervals: 14,
  excludedDates: 10
});
function optionsSnapshot(options) {
  if (!options || typeof options.timezone !== "string" || typeof options.reference !== "string")
    throw new TypeError("Provide a timezone and reference as strings.");
  const selection2 = options.selection;
  if (selection2 !== void 0 && (selection2 === null || typeof selection2 !== "object" || typeof selection2.contextKey !== "string" || typeof selection2.id !== "string" || selection2.previous !== void 0 && (!Array.isArray(selection2.previous) || selection2.previous.length > MAX_SELECTION_HISTORY || selection2.previous.some((id) => typeof id !== "string"))))
    throw new TypeError("Invalid clarification selection.");
  return {
    timezone: options.timezone,
    reference: options.reference,
    ...selection2 ? {
      selection: {
        contextKey: selection2.contextKey,
        id: selection2.id,
        ...selection2.previous ? { previous: [...selection2.previous] } : {}
      }
    } : {}
  };
}
function parse(input2, options) {
  if (typeof input2 !== "string")
    throw new TypeError("Input must be a string.");
  const context2 = optionsSnapshot(options);
  return {
    ...interpretDate(input2, context2),
    sdkVersion: SDK_VERSION,
    input: input2,
    context: { timezone: context2.timezone, reference: context2.reference }
  };
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/calendar-file.js
function escapeText(value) {
  for (const char of value) {
    const code = char.charCodeAt(0);
    if (code < 32 && ![9, 10, 13].includes(code) || code === 127)
      throw new Error("Calendar text contains an unsupported control character.");
  }
  return value.replace(/\\/g, "\\\\").replace(/\r\n|\r|\n/g, "\\n").replace(/;/g, "\\;").replace(/,/g, "\\,");
}
function fold(line) {
  let output2 = "";
  let bytes = 0;
  for (const char of line) {
    const code = char.codePointAt(0);
    if (code >= 55296 && code <= 57343)
      throw new Error("Calendar text contains invalid Unicode.");
    const width = code < 128 ? 1 : code < 2048 ? 2 : code < 65536 ? 3 : 4;
    if (bytes + width > 75) {
      output2 += "\r\n ";
      bytes = 1;
    }
    output2 += char;
    bytes += width;
  }
  return output2;
}
function utc(iso, metadata = false) {
  const instant = qi.Instant.from(iso);
  if (!metadata && instant.epochNanoseconds % 1000000000n !== 0n)
    throw new Error("Calendar export cannot preserve fractions of a second. Choose a whole-second time.");
  const value = instant.toString({ smallestUnit: "second", roundingMode: "floor" });
  if (!/^\d{4}-/.test(value) || value.startsWith("0000-"))
    throw new Error("Calendar dates must use years 0001\u20139999.");
  return value.replace(/[-:]/g, "");
}
function dateValue(calculation) {
  return qi.PlainDate.from(calculation.result.local.slice(0, 10)).toString().replace(/-/g, "");
}
function prepareCalendarFile(interpretation, options) {
  if (interpretation.status !== "resolved")
    return { ok: false, code: "unresolved", reason: "Resolve the date before exporting it." };
  if (interpretation.value.kind === "recurrence")
    return {
      ok: false,
      code: "recurrence-required",
      reason: "Recurrence export still needs timezone and rule validation. A preview cannot replace the full schedule."
    };
  if (interpretation.value.kind === "point" && !options.pointMode)
    return {
      ok: false,
      code: "point-mode-required",
      reason: "Choose an all-day date or an exact-time event before exporting this point."
    };
  try {
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(options.uid))
      throw new Error("Provide a unique UUID for this calendar file.");
    if (!options.title.trim() || options.title.length > 2e3)
      throw new Error("Provide a calendar title of 1\u20132000 characters.");
    if (options.pointMode !== void 0 && !["date", "instant"].includes(options.pointMode))
      throw new Error("Choose a supported point format.");
    const stamp = utc(options.stamp, true);
    const value = interpretation.value;
    const events = value.kind === "point" ? [{ start: value.calculation, allDay: options.pointMode === "date" }] : value.kind === "interval" ? [value] : value.occurrences.map((row) => ({ ...row, allDay: "allDay" in row && row.allDay }));
    if (!events.length || events.length > 14)
      throw new Error("Export requires 1\u201314 complete events.");
    const lines = [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "PRODID:-//Tempus//Calendar Export//EN",
      "CALSCALE:GREGORIAN"
    ];
    for (const [index, event] of events.entries()) {
      if (event.end && event.end.result.timestamp <= event.start.result.timestamp)
        throw new Error("The calendar end must follow its start.");
      lines.push("BEGIN:VEVENT", `UID:${options.uid}-${index}@tempus.invalid`, `DTSTAMP:${stamp}`, `SUMMARY:${escapeText(options.title)}`, `DESCRIPTION:${escapeText([`Date phrase: ${interpretation.source.text}`, `Timezone: ${event.start.timezone}`, ...interpretation.assumptions].join("\n"))}`, event.allDay ? `DTSTART;VALUE=DATE:${dateValue(event.start)}` : `DTSTART:${utc(event.start.result.iso)}`);
      if (event.end)
        lines.push(event.allDay ? `DTEND;VALUE=DATE:${dateValue(event.end)}` : `DTEND:${utc(event.end.result.iso)}`);
      lines.push("END:VEVENT");
    }
    lines.push("END:VCALENDAR");
    return {
      ok: true,
      text: lines.map(fold).join("\r\n") + "\r\n",
      eventCount: events.length,
      mimeType: "text/calendar;charset=utf-8"
    };
  } catch (error) {
    return {
      ok: false,
      code: "invalid-file",
      reason: error instanceof Error ? error.message : "Could not prepare this calendar file."
    };
  }
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/recurrence-clock-conflicts.js
function cadence2(options) {
  if ("monthly" in options)
    return { interval: 1, phase: (_date) => 0 };
  const interval = options.interval ?? 1;
  if (!Number.isInteger(interval) || interval < 1 || interval > 52)
    throw new Error("Invalid weekly interval.");
  const firstDate = zonedInstant(options.reference, options.timezone).toPlainDate();
  const anchor = options.weekAnchor ? qi.PlainDate.from(options.weekAnchor) : firstDate.subtract({ days: firstDate.dayOfWeek - 1 });
  return {
    interval,
    phase: (date2) => (Math.floor(date2.since(anchor).days / 7) % interval + interval) % interval
  };
}
function* futureTransitions(options) {
  const zone = timezoneDatabase(options.timezone);
  if (!zone.footer)
    throw new Error("Future timezone rules are unavailable.");
  const first = qi.Instant.from(options.reference).epochMilliseconds / 1e3;
  const { interval } = cadence2(options);
  let a2 = interval, b2 = 20871;
  while (b2)
    [a2, b2] = [b2, a2 % b2];
  const cycleYears = 400 * (interval / a2);
  const futureYear = Math.max(new Date(Math.max(first, zone.futureFrom ?? first) * 1e3).getUTCFullYear(), ...options.exceptions.map((date2) => qi.PlainDate.from(date2).year + 1));
  const through = Date.parse(`${Math.min(9999, futureYear + cycleYears + 1)}-12-31T23:59:59Z`) / 1e3;
  for (let cursor = first - 2 * 86400; cursor <= through; ) {
    const end = Math.min(through, cursor + 10 * 365 * 86400);
    yield* zone.transitionInstants(cursor, end);
    cursor = end + 1;
  }
}
function recurrenceIntervalConflict(options) {
  if (!Number.isSafeInteger(options.durationMilliseconds) || options.durationMilliseconds <= 0)
    throw new Error("Invalid recurrence duration.");
  const { interval, phase } = cadence2(options);
  const first = zonedInstant(options.reference, options.timezone);
  const clock6 = first.toPlainDateTime().toPlainTime();
  const exclusions = new Set(options.exceptions);
  const firstDate = first.toPlainDate().toString();
  for (const transition of futureTransitions(options)) {
    if (transition * 1e3 <= first.epochMilliseconds)
      continue;
    const before = zonedInstant(new Date((transition - 1) * 1e3).toISOString(), options.timezone);
    if ("monthly" in options) {
      let month2 = before.toPlainDate().with({ day: 1 });
      for (let attempt = 0; attempt < 13 * (exclusions.size + 2); attempt++, month2 = month2.subtract({ months: 1 })) {
        const date2 = monthlyDate(month2, options.monthly);
        if (!date2)
          continue;
        if (date2.toString() < firstDate)
          break;
        if (exclusions.has(date2.toString()))
          continue;
        const start = zonedLocal(date2.toPlainDateTime(clock6), options.timezone);
        if (start.epochMilliseconds >= transition * 1e3)
          continue;
        if (start.epochMilliseconds >= first.epochMilliseconds && start.epochMilliseconds + options.durationMilliseconds >= transition * 1e3)
          return new Date(transition * 1e3).toISOString();
        break;
      }
      continue;
    }
    for (const weekday of options.weekdays) {
      let date2 = before.toPlainDate().subtract({ days: (before.dayOfWeek - weekday + 7) % 7 });
      date2 = date2.subtract({ days: phase(date2) * 7 });
      for (let skipped = 0; skipped <= exclusions.size + 1 && date2.toString() >= firstDate; skipped++) {
        if (!exclusions.has(date2.toString())) {
          const start = zonedLocal(date2.toPlainDateTime(clock6), options.timezone);
          if (start.epochMilliseconds < transition * 1e3) {
            if (start.epochMilliseconds >= first.epochMilliseconds && start.epochMilliseconds + options.durationMilliseconds >= transition * 1e3)
              return new Date(transition * 1e3).toISOString();
            break;
          }
        }
        date2 = date2.subtract({ days: interval * 7 });
      }
    }
  }
  return null;
}
function recurrenceClockConflict(options) {
  const { phase } = cadence2(options);
  const zone = timezoneDatabase(options.timezone);
  if (!zone.footer)
    throw new Error("Future timezone rules are unavailable.");
  if (!("monthly" in options) && (!options.weekdays.length || options.weekdays.some((day) => !Number.isInteger(day) || day < 1 || day > 7)))
    throw new Error("Invalid recurrence weekdays.");
  const time = calculateDate(`2000-01-01 at ${options.clock}`, {
    timezone: "UTC",
    reference: options.reference
  });
  if (!time.ok)
    throw new Error(time.error.message);
  const clock6 = qi.PlainTime.from(time.result.local.slice(11));
  const first = qi.Instant.from(options.reference).epochMilliseconds / 1e3;
  const exclusions = new Set(options.exceptions);
  for (const instant of futureTransitions(options)) {
    const before = zone.offsetAt(instant - 1), after = zone.offsetAt(instant);
    const low = Math.min(instant + before, instant + after);
    const high = Math.max(instant + before, instant + after);
    let date2 = qi.PlainDate.from(new Date(low * 1e3).toISOString().slice(0, 10));
    const last = qi.PlainDate.from(new Date((high - 1e-3) * 1e3).toISOString().slice(0, 10));
    while (qi.PlainDate.compare(date2, last) <= 0) {
      const occurrenceDate = "monthly" in options ? date2.subtract({ days: options.dayShift ?? 0 }) : date2;
      const local = date2.toPlainDateTime(clock6);
      const civil2 = Date.parse(local.toString() + "Z") / 1e3;
      if (civil2 >= low && civil2 < high && ("monthly" in options ? monthlyDate(occurrenceDate, options.monthly)?.equals(occurrenceDate) : options.weekdays.includes(date2.dayOfWeek)) && phase(date2) === 0 && !exclusions.has(occurrenceDate.toString())) {
        const choices2 = ["earlier", "later"].map((policy) => zonedLocal(local, options.timezone, policy).toInstant().toString());
        if (choices2.some((choice) => Date.parse(choice) / 1e3 >= first))
          return { local: local.toString(), choices: choices2 };
      }
      date2 = date2.add({ days: 1 });
    }
  }
  return null;
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/calendar-transition-rule.js
function calendarTransitionRule(text) {
  const match = /^M(\d{1,2})\.([1-5])\.([0-6])(?:\/([+-]?)(\d{1,3})(?::([0-5]\d))?(?::([0-5]\d))?)?$/.exec(text);
  if (!match)
    throw new Error("Unsupported calendar transition rule.");
  const month2 = Number(match[1]);
  const week = Number(match[2]);
  const weekday = Number(match[3]);
  const hours = Number(match[5] ?? 2);
  if (month2 < 1 || month2 > 12 || hours > 167)
    throw new Error("Invalid calendar transition rule.");
  const seconds = (match[4] === "-" ? -1 : 1) * (hours * 3600 + Number(match[6] ?? 0) * 60 + Number(match[7] ?? 0));
  const shift = Math.floor(seconds / 86400);
  const clock6 = new Date((seconds % 86400 + 86400) % 86400 * 1e3).toISOString().slice(11, 19).replaceAll(":", "");
  const dayName = ["SU", "MO", "TU", "WE", "TH", "FR", "SA"][((weekday + shift) % 7 + 7) % 7];
  const groups = /* @__PURE__ */ new Map();
  const length = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month2 - 1];
  if (week === 5 && shift === 0)
    return { clock: clock6, rules: [`FREQ=YEARLY;BYMONTH=${month2};BYDAY=-1${dayName}`] };
  for (let index = 0; index < 7; index++) {
    let targetMonth = month2;
    let day = (week === 5 ? -7 + index : 1 + (week - 1) * 7 + index) + shift;
    if (week === 5) {
      if (day >= 0) {
        targetMonth = month2 % 12 + 1;
        day += 1;
      }
    } else if (day <= 0) {
      targetMonth = (month2 + 10) % 12 + 1;
      day -= 1;
    } else if (day > length) {
      if (month2 === 2)
        throw new Error("Leap-dependent calendar transition spill is unsupported.");
      targetMonth = month2 % 12 + 1;
      day -= length;
    }
    if (day < 0) {
      if (targetMonth === 2)
        throw new Error("Leap-dependent calendar transition spill is unsupported.");
      day += [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][targetMonth - 1] + 1;
    }
    const days2 = groups.get(targetMonth) ?? [];
    days2.push(day);
    groups.set(targetMonth, days2);
  }
  return {
    clock: clock6,
    rules: [...groups].map(([targetMonth, days2]) => `FREQ=YEARLY;BYMONTH=${targetMonth};BYDAY=${dayName};BYMONTHDAY=${days2.join(",")}`)
  };
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/calendar-timezone-ongoing.js
function calendarTimezoneOngoing(timezone, from) {
  if (!/^[A-Za-z0-9_+./-]+$/.test(timezone))
    throw new Error("Unsupported calendar timezone ID.");
  const first = qi.Instant.from(from).epochMilliseconds / 1e3;
  if (!Number.isFinite(first))
    throw new Error("Invalid timezone coverage start.");
  const zone = timezoneDatabase(timezone);
  if (!zone.footer)
    throw new Error("No explicit future timezone rule is available.");
  const civil2 = (seconds) => {
    const iso = new Date(seconds * 1e3).toISOString();
    if (!/^\d{4}-/.test(iso) || iso.startsWith("0000"))
      throw new Error("Unsupported calendar timezone year.");
    return iso.slice(0, 19).replace(/[-:]/g, "");
  };
  const offset = (seconds) => {
    const n2 = Math.abs(seconds);
    if (n2 >= 86400)
      throw new Error("Unsupported calendar timezone offset.");
    const part = (value) => String(value).padStart(2, "0");
    return (seconds < 0 ? "-" : "+") + part(Math.floor(n2 / 3600)) + part(Math.floor(n2 / 60) % 60) + (n2 % 60 ? part(n2 % 60) : "");
  };
  const lines = ["BEGIN:VTIMEZONE", `TZID:${timezone}`];
  const append = (instant, before, after, daylight, rule2) => {
    const kind = daylight ? "DAYLIGHT" : "STANDARD";
    lines.push(`BEGIN:${kind}`, `DTSTART:${civil2(instant + before)}`, `TZOFFSETFROM:${offset(before)}`, `TZOFFSETTO:${offset(after)}`, ...rule2 ? [`RRULE:${rule2}`] : [], `END:${kind}`);
  };
  const historyStart = first - 370 * 86400;
  const baseline = Math.floor(historyStart) - 1;
  append(baseline, zone.offsetAt(baseline), zone.offsetAt(baseline), zone.isDaylightAt(baseline));
  const cutover = zone.futureFrom ?? first;
  let count = 0;
  for (let cursor = historyStart; cursor <= cutover; ) {
    const end = Math.min(cutover, cursor + 10 * 365 * 86400);
    for (const instant of zone.transitionInstants(cursor, end)) {
      if (++count > 4096)
        throw new Error("Too many recorded timezone transitions.");
      append(instant, zone.offsetAt(instant - 1), zone.offsetAt(instant), zone.isDaylightAt(instant));
    }
    cursor = end + 1;
  }
  const futureStart = Math.max(historyStart, cutover + 1);
  const year = new Date(futureStart * 1e3).getUTCFullYear();
  for (const observance of zone.futureObservances) {
    const converted = calendarTransitionRule(observance.rule);
    for (const rule2 of converted.rules) {
      const month2 = Number(/BYMONTH=(\d+)/.exec(rule2)[1]);
      let onset;
      for (let y2 = year - 1; y2 <= year + 400; y2++) {
        const instant = observance.onset(y2);
        if (instant >= futureStart && new Date((instant + observance.offsetFrom) * 1e3).getUTCMonth() + 1 === month2) {
          onset = instant;
          break;
        }
      }
      if (onset === void 0)
        throw new Error("No future timezone onset found.");
      append(onset, observance.offsetFrom, observance.offsetTo, observance.daylight, rule2);
    }
  }
  lines.push("END:VTIMEZONE");
  return lines.map((line) => {
    let folded = line.slice(0, 75);
    for (let at2 = 75; at2 < line.length; at2 += 74)
      folded += "\r\n " + line.slice(at2, at2 + 74);
    return folded;
  }).join("\r\n") + "\r\n";
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/node_modules/.pnpm/@tempus-date+core@file+tempus-date-core-0.1.0.tgz/node_modules/@tempus-date/core/dist/recurring-calendar-file.js
function fixedFuture(timezone, from) {
  const zone = timezoneDatabase(timezone);
  if (!/^(?:<[A-Za-z0-9+-]{3,}>|[A-Za-z]{3,})[+-]?\d{1,3}(?::[0-5]\d){0,2}$/.test(zone.footer))
    return false;
  const last = Date.parse("9999-12-31T23:59:59Z") / 1e3;
  for (let start = from + 1e-3; start < last; start += 10 * 365 * 86400) {
    if (zone.transitionInstants(start, Math.min(last, start + 10 * 365 * 86400)).length)
      return false;
  }
  return true;
}
var utcDate = (iso) => {
  const text = iso.replace(/[-:]/g, "").replace(/\.000Z$/, "Z");
  if (!/^\d{8}T\d{6}Z$/.test(text))
    throw new Error("Calendar dates require four-digit years and whole seconds.");
  return text;
};
function resolveRecurringExport(interpretation, reference, decisions2 = []) {
  if (interpretation.status !== "resolved" || interpretation.value.kind !== "recurrence")
    return null;
  const value = interpretation.value;
  const inherited = (value.rule.clockOverrides ?? []).map((choice) => `recurrence:${choice.date}:${choice.endpoint}:${choice.instant}`);
  const parseOptions = {
    timezone: value.timezone,
    reference,
    policyDecisions: [
      ...value.rule.frequency === "monthly" ? [`monthly:${value.rule.shortMonth}`] : [],
      ...value.rule.countExclusions ? [`count:exclusions:${value.rule.countExclusions}`] : [],
      ...value.rule.countPast ? [`count:past:${value.rule.countPast}`] : []
    ],
    clockDecisions: [
      ...decisions2,
      ...decisions2.reduce((history, next) => retainOccurrenceDecisions(history, next), inherited)
    ]
  };
  const plan = interpretRecurrence(interpretation.source.text, parseOptions);
  if (!plan?.ok)
    return plan;
  if (plan.rule.until || plan.rule.count)
    return interpretRecurrence(interpretation.source.text, { ...parseOptions, complete: true });
  if (!plan.occurrences.length)
    return plan;
  try {
    const first = plan.occurrences[0].start;
    if (plan.rule.frequency === "monthly") {
      const conflict = recurrenceClockConflict({
        timezone: value.timezone,
        reference: first.result.iso,
        monthly: plan.rule,
        clock: plan.rule.startClock,
        exceptions: plan.rule.exceptions
      });
      if (conflict || plan.rule.clockOverrides?.length)
        throw new Error("A monthly occurrence reaches a skipped or repeated clock. Ongoing export needs a future clock-choice policy; your schedule has not been shortened.");
      const end = plan.occurrences[0].end;
      let durationSeconds;
      if (end) {
        const durationMilliseconds = end.result.timestamp - first.result.timestamp;
        const dayShift = qi.PlainDate.from(end.result.local.slice(0, 10)).since(qi.PlainDate.from(first.result.local.slice(0, 10))).days;
        const endConflict = recurrenceClockConflict({
          timezone: value.timezone,
          reference: end.result.iso,
          monthly: plan.rule,
          dayShift,
          clock: end.result.local.slice(11),
          exceptions: plan.rule.exceptions
        });
        const change = recurrenceIntervalConflict({
          timezone: value.timezone,
          reference: first.result.iso,
          monthly: plan.rule,
          clock: plan.rule.startClock,
          exceptions: plan.rule.exceptions,
          durationMilliseconds
        });
        if (endConflict || change)
          throw new Error("A future monthly occurrence ends at an ambiguous clock or spans an offset change. This interval needs a validated clock-change policy before ongoing export.");
        durationSeconds = durationMilliseconds / 1e3;
        if (!Number.isSafeInteger(durationSeconds))
          throw new Error("Calendar export requires whole-second duration.");
      }
      const day = plan.rule.dayOfMonth;
      if (plan.rule.shortMonth === "last-day" && day > 28 && day < 31)
        throw new Error("Ongoing export for this short-month policy has not passed independent recurrence validation. Your schedule has not been shortened.");
      const monthDays = plan.rule.shortMonth === "last-day" && day === 31 ? "-1" : String(day);
      return {
        ...plan,
        exportRule: `FREQ=MONTHLY;BYMONTHDAY=${monthDays}`,
        ...durationSeconds !== void 0 ? { exportDurationSeconds: durationSeconds } : {},
        exclusions: plan.rule.exceptions.filter((date2) => date2 >= first.result.local.slice(0, 10)).map((date2) => utcDate(`${date2}T${first.result.local.slice(11)}Z`).slice(0, -1)),
        exportTimezone: calendarTimezoneOngoing(value.timezone, first.result.iso)
      };
    }
    if (!fixedFuture(value.timezone, first.result.timestamp / 1e3)) {
      const firstDate = qi.PlainDate.from(first.result.local.slice(0, 10));
      const weekAnchor = firstDate.subtract({ days: firstDate.dayOfWeek - 1 });
      const conflict = recurrenceClockConflict({
        timezone: value.timezone,
        reference: first.result.iso,
        interval: plan.rule.interval,
        weekAnchor: weekAnchor.toString(),
        weekdays: plan.rule.weekdays,
        clock: plan.rule.startClock,
        exceptions: plan.rule.exceptions
      });
      if (conflict)
        throw new Error(`A future occurrence reaches ${conflict.local.replace("T", " at ")}, a skipped or repeated clock. Export needs a policy for future clock choices. Your schedule has not been shortened.`);
      const end = plan.occurrences[0].end;
      let durationSeconds;
      if (end) {
        const durationMilliseconds = end.result.timestamp - first.result.timestamp;
        const shift2 = qi.PlainDate.from(end.result.local.slice(0, 10)).since(qi.PlainDate.from(first.result.local.slice(0, 10))).days;
        const endConflict = recurrenceClockConflict({
          timezone: value.timezone,
          reference: end.result.iso,
          interval: plan.rule.interval,
          weekAnchor: weekAnchor.add({ days: shift2 }).toString(),
          weekdays: plan.rule.weekdays.map((day) => (day - 1 + shift2) % 7 + 1),
          clock: end.result.local.slice(11),
          exceptions: plan.rule.exceptions.map((date2) => qi.PlainDate.from(date2).add({ days: shift2 }).toString())
        });
        const change = recurrenceIntervalConflict({
          timezone: value.timezone,
          reference: first.result.iso,
          interval: plan.rule.interval,
          weekAnchor: weekAnchor.toString(),
          weekdays: plan.rule.weekdays,
          clock: plan.rule.startClock,
          exceptions: plan.rule.exceptions,
          durationMilliseconds
        });
        if (endConflict || change)
          throw new Error("A future occurrence ends at an ambiguous clock or spans an offset change. This interval needs a validated clock-change policy before ongoing export.");
        durationSeconds = durationMilliseconds / 1e3;
        if (!Number.isSafeInteger(durationSeconds))
          throw new Error("Calendar export requires whole-second duration.");
      }
      {
        const weekdays4 = ["MO", "TU", "WE", "TH", "FR", "SA", "SU"];
        const exclusions2 = plan.rule.exceptions.filter((date2) => date2 >= first.result.local.slice(0, 10)).map((date2) => utcDate(`${date2}T${first.result.local.slice(11)}Z`).slice(0, -1));
        return {
          ...plan,
          exportRule: `FREQ=WEEKLY;${plan.rule.interval ? `INTERVAL=${plan.rule.interval};WKST=MO;` : ""}BYDAY=${plan.rule.weekdays.map((day) => weekdays4[day - 1]).join(",")}`,
          exclusions: exclusions2,
          exportTimezone: calendarTimezoneOngoing(value.timezone, first.result.iso),
          ...durationSeconds !== void 0 ? { exportDurationSeconds: durationSeconds } : {}
        };
      }
    }
    const localDate = qi.PlainDate.from(first.result.local.slice(0, 10));
    const writtenClock = calculateDate(`${localDate.toString()} at ${plan.rule.startClock}`, {
      timezone: "UTC",
      reference
    });
    if (!writtenClock.ok || writtenClock.result.local.slice(11) !== first.result.local.slice(11))
      throw new Error("This first clock choice changes the repeating time. Export of that unbounded override is not ready.");
    const utcDay = qi.PlainDate.from(first.result.iso.slice(0, 10));
    const shift = utcDay.since(localDate).days;
    const weekdays3 = ["MO", "TU", "WE", "TH", "FR", "SA", "SU"];
    const days2 = plan.rule.weekdays.map((day) => weekdays3[(day - 1 + shift + 7) % 7]);
    const exclusions = [];
    for (const date2 of plan.rule.exceptions) {
      const local = qi.PlainDate.from(date2);
      if (qi.PlainDate.compare(local, localDate) < 0 || !plan.rule.weekdays.includes(local.dayOfWeek))
        continue;
      const excluded = calculateDate(`${date2} at ${plan.rule.startClock}`, {
        timezone: value.timezone,
        reference
      });
      if (!excluded.ok)
        throw new Error(excluded.error.message);
      exclusions.push(utcDate(excluded.result.iso));
    }
    return {
      ...plan,
      exportRule: `FREQ=WEEKLY;${plan.rule.interval ? `INTERVAL=${plan.rule.interval};WKST=${weekdays3[(shift + 7) % 7]};` : ""}BYDAY=${days2.join(",")}`,
      exclusions
    };
  } catch (error) {
    return {
      ok: false,
      error: {
        code: "timezone",
        message: error instanceof Error ? error.message : "The complete recurring rule could not be prepared.",
        hint: "You can explicitly add an end date to export a finite schedule; no end date is chosen for you."
      }
    };
  }
}
function prepareRecurringCalendarFile(interpretation, options) {
  return prepareRecurringCalendarReview(interpretation, options).file;
}
function prepareRecurringCalendarReview(interpretation, options) {
  const plan = resolveRecurringExport(interpretation, options.reference, options.decisions);
  return { plan, file: calendarFileFromPlan(interpretation, options, plan) };
}
function calendarFileFromPlan(interpretation, options, plan) {
  if (!plan || !plan.ok || interpretation.status !== "resolved")
    return {
      ok: false,
      code: interpretation.status !== "resolved" ? "unresolved" : plan && !plan.ok && plan.clockPrompt ? "clarification-required" : "export-blocked",
      reason: plan && !plan.ok ? plan.error.message : "No complete recurring schedule is available."
    };
  if (!plan.occurrences.length)
    return {
      ok: false,
      code: "empty-schedule",
      reason: "No upcoming occurrences remain to export."
    };
  const starts = /* @__PURE__ */ new Set();
  const events = [];
  for (const [index, row] of (plan.exportRule ? plan.occurrences.slice(0, 1) : plan.occurrences).entries()) {
    if (starts.has(row.start.result.iso))
      return {
        ok: false,
        code: "invalid-file",
        reason: "Two occurrences share a start instant. They cannot be merged into one recurrence set."
      };
    starts.add(row.start.result.iso);
    const value = row.end ? {
      ok: true,
      kind: "interval",
      start: row.start,
      end: row.end,
      allDay: false,
      endExclusive: true,
      overnight: false
    } : {
      kind: "point",
      calculation: row.start,
      precision: "time",
      clockSource: "explicit"
    };
    const file = prepareCalendarFile({
      ...interpretation,
      value,
      assumptions: [
        ...interpretation.assumptions.filter((s2) => s2 !== "Recurrence export has not been validated."),
        ...plan.rule.countPast ? [
          plan.rule.countPast === "consume" ? "The count includes past starts from the written start. Only future events are included in this file." : "The count includes upcoming starts only; the written start still anchors the cadence."
        ] : [],
        ...plan.rule.countExclusions ? [
          plan.rule.countExclusions === "consume" ? "Excluded dates use count slots and are not replaced." : "Excluded dates are replaced to keep the requested event count."
        ] : [],
        plan.exportRule ? plan.exportTimezone ? "Repeats at the written local clock using the embedded pinned timezone rules. Future timezone-law updates require a new file." : "Repeats without an end date using the timezone\u2019s pinned fixed-offset future rules. No future timezone-law updates are applied to this file." : "Complete bounded recurrence set; dates are fixed to the timezone rules used when this file was generated.",
        ...(plan.rule.clockOverrides ?? []).map((choice) => `${choice.date} ${choice.endpoint}: ${choice.label}`)
      ]
    }, { ...options, pointMode: "instant" });
    if (!file.ok)
      return file;
    let event = file.text.slice(file.text.indexOf("BEGIN:VEVENT\r\n"), file.text.indexOf("\r\nEND:VEVENT") + "\r\nEND:VEVENT".length);
    const start = event.match(/\r\nDTSTART:([^\r]+)/)?.[1];
    if (!start)
      return { ok: false, code: "invalid-file", reason: "Missing complete occurrence start." };
    if (plan.exportTimezone)
      event = event.replace(`DTSTART:${start}`, `DTSTART;TZID=${plan.timezone}:${utcDate(row.start.result.local + "Z").slice(0, -1)}`);
    if (plan.exportDurationSeconds !== void 0)
      event = event.replace(/\r\nDTEND:[^\r]+/, `\r
DURATION:PT${plan.exportDurationSeconds}S`);
    events.push(index === 0 ? event : event.replace(/^BEGIN:VEVENT\r\n/, `BEGIN:VEVENT\r
RECURRENCE-ID:${start}\r
`));
  }
  const recurrenceDates = plan.exportRule ? [
    `RRULE:${plan.exportRule}`,
    ...(plan.exclusions ?? []).map((date2) => `EXDATE${plan.exportTimezone ? `;TZID=${plan.timezone}` : ""}:${date2}`)
  ].join("\r\n") : plan.occurrences.map((row) => `RDATE:${utcDate(row.start.result.iso)}`).join("\r\n");
  if (recurrenceDates)
    events[0] = events[0].replace(/\r\nEND:VEVENT$/, `\r
${recurrenceDates}\r
END:VEVENT`);
  return {
    ok: true,
    text: [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "PRODID:-//Tempus//Calendar Export//EN",
      "CALSCALE:GREGORIAN",
      ...plan.exportTimezone ? [plan.exportTimezone.trimEnd()] : [],
      ...events,
      "END:VCALENDAR",
      ""
    ].join("\r\n"),
    eventCount: events.length,
    mimeType: "text/calendar;charset=utf-8"
  };
}

// ../../../Documents/Codex/2026-09-13-tempus-identifiers-checked-sdk/calendar-browser.ts
var input = document.querySelector("#phrase");
var output = document.querySelector("#result");
var summary = document.querySelector("#interpretation-summary");
var choices = document.querySelector("#choices");
var download = document.querySelector("#download");
var feedback = document.querySelector("#feedback");
var context = { timezone: "America/Chicago", reference: "2026-09-12T16:00:00Z" };
var selection;
var decisions = [];
function render() {
  const result = parse(input.value, { ...context, selection });
  const plan = result.status === "resolved" && result.value.kind === "recurrence" ? resolveRecurringExport(result, result.context.reference, decisions) : void 0;
  output.textContent = JSON.stringify(
    { result, ...plan ? { completeExportPlan: plan } : {} },
    null,
    2
  );
  summary.replaceChildren();
  const line = (text, tag = "p") => {
    const element = document.createElement(tag);
    element.textContent = text;
    summary.append(element);
  };
  const date2 = (value, allDay = false) => {
    const [day, clock6] = value.local.split("T");
    return allDay ? `${day} \xB7 all day` : `${day} at ${clock6} (UTC${value.offset})`;
  };
  if (result.status !== "resolved") {
    line(
      result.status === "needs-clarification" ? "Choose an interpretation" : "No calendar file yet",
      "h2"
    );
    if (!result.clarification) line(result.error.message);
    if (result.error.hint) line(result.error.hint);
  } else {
    const value = result.value;
    line(result.event?.text ?? "Your date", "h2");
    line(result.context.timezone);
    if (plan && !plan.ok) {
      line("The calendar file needs attention.");
      line(plan.error.message);
      if (plan.error.hint) line(plan.error.hint);
    } else {
      const rows = value.kind === "point" ? [{ start: value.calculation, allDay: value.precision === "date", end: void 0 }] : value.kind === "interval" ? [value] : plan?.ok ? plan.occurrences : value.occurrences;
      line(
        plan?.ok && plan.exportRule ? "Repeats without an end date. Upcoming occurrences:" : `${rows.length} ${rows.length === 1 ? "event" : "events"} in the complete file.`
      );
      const list = document.createElement("ol");
      for (const row of rows.slice(0, 3)) {
        const item = document.createElement("li");
        const allDay = "allDay" in row && row.allDay === true;
        item.textContent = date2(row.start.result, allDay) + (row.end ? ` \u2192 ${date2(row.end.result, allDay)} (end not included)` : "");
        list.append(item);
      }
      summary.append(list);
      if (rows.length > 3)
        line(`Showing the first 3 of ${rows.length} events. All are included in the file.`);
      if (rows.some((row) => !row.end && !("allDay" in row && row.allDay)))
        line("No duration is added to timed points. Your calendar may display its own default.");
    }
  }
  choices.replaceChildren();
  feedback.textContent = "";
  download.disabled = result.status !== "resolved" || plan !== void 0 && (!plan?.ok || !plan.occurrences.length);
  download.onclick = () => {
    try {
      const metadata = {
        uid: crypto.randomUUID(),
        stamp: (/* @__PURE__ */ new Date()).toISOString(),
        title: result.status === "resolved" ? result.event?.text ?? input.value : input.value
      };
      const file = result.status === "resolved" && result.value.kind === "recurrence" ? prepareRecurringCalendarFile(result, {
        ...metadata,
        reference: result.context.reference,
        decisions
      }) : prepareCalendarFile(result, {
        ...metadata,
        pointMode: result.status === "resolved" && result.value.kind === "point" && result.value.precision === "date" ? "date" : "instant"
      });
      if (!file.ok) {
        feedback.textContent = file.reason;
        return;
      }
      const link = document.createElement("a");
      const url = URL.createObjectURL(new Blob([file.text], { type: file.mimeType }));
      try {
        link.href = url;
        link.download = "tempus-events.ics";
        document.body.append(link);
        link.click();
      } finally {
        link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1e3);
      }
      feedback.textContent = "Download requested. No calendar import or reminder was created.";
    } catch {
      feedback.textContent = "The file could not be downloaded. Try again in your browser.";
    }
  };
  const prompt = result.status === "needs-clarification" ? result.clarification : plan && !plan.ok ? plan.clockPrompt : void 0;
  if (prompt) {
    const question = document.createElement("p");
    question.textContent = prompt.question;
    choices.append(question);
    for (const choice of prompt.choices) {
      const button = document.createElement("button");
      button.textContent = choice.label;
      button.onclick = () => {
        if (result.status === "needs-clarification" && result.clarification) {
          selection = appendSelection(selection, {
            contextKey: result.clarification.contextKey,
            id: choice.id
          });
          decisions = [];
        } else decisions = [choice.id, ...retainOccurrenceDecisions(decisions, choice.id)];
        render();
        summary.focus();
      };
      choices.append(button);
    }
  }
}
input.addEventListener("input", () => {
  selection = void 0;
  decisions = [];
  render();
});
document.querySelector("#restart").onclick = () => {
  selection = void 0;
  decisions = [];
  render();
  summary.focus();
};
render();
