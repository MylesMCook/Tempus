import assert from 'node:assert/strict';import {parse,calculateDate,appendSelection} from '@tempus-date/core';import {prepareCalendarFile} from '@tempus-date/core/calendar';
const context={timezone:'America/Chicago',reference:'2026-09-12T16:00:00Z'};
for(const [input,ids,expected] of [
 ['Buy apples for Sam At noon tomorrow',['event:title'],'2026-09-13T17:00:00.000Z'],
 ['Buy apples for Sam at 1:30am on 11/01/2026',['event:title','2026-11-01','2026-11-01T07:30:00Z'],'2026-11-01T07:30:00.000Z']]){
 let selection;const metadata={title:'Buy apples for Sam',uid:'11111111-2222-4333-8444-555555555555',stamp:context.reference,pointMode:'instant'};
 for(const id of ids){const r=parse(input,{...context,selection});assert.equal(r.status,'needs-clarification');assert.ok(r.clarification.choices.some(x=>x.id===id));assert.equal(prepareCalendarFile(r,metadata).ok,false);selection=appendSelection(selection,{contextKey:r.clarification.contextKey,id});}
 const r=parse(input,{...context,selection});assert.equal(r.status,'resolved');assert.equal(r.value.calculation.result.iso,expected);assert.equal(r.input,input);assert.equal(r.event.text,metadata.title);assert.equal(input.slice(r.source.span.start,r.source.span.end),r.source.text);assert.equal(r.apiReplay,false);assert.equal(calculateDate(r.source.text,context).ok,false);assert.equal(prepareCalendarFile(r,metadata).ok,true);const edited=input.replace('Sam','Jo');assert.deepEqual(parse(edited,{...context,selection}),parse(edited,context));console.log(JSON.stringify({status:'passed',node:process.version,input,expected}));
}
